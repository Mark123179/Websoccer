"""
run_match.py — Websoccer Match Simulation (Standalone, Django-free)
====================================================================

Benötigt nur die Python-Standardbibliothek (math, random, json).
Kein Django, kein ORM, keine Datenbank.

Schnellstart
------------
    import json
    from run_match import simulate_match

    with open('bayern_fixture.json', encoding='utf-8') as f:
        team = json.load(f)

    result = simulate_match(home_team=team, away_team=team)
    print(result['home_goals'], ':', result['away_goals'])

Batch-Analyse (10.000 Simulationen)
------------------------------------
    results = [simulate_match(team, team) for _ in range(10_000)]
    avg_goals = sum(r['home_goals'] + r['away_goals'] for r in results) / len(results)

Taktik-Variante testen
-----------------------
    custom_tactic = {**team['tactic'], 'attack_focus': 'sturmlauf'}
    result = simulate_match(team, team, home_tactic=custom_tactic)

Status der Taktik-Parameter
-----------------------------
    AKTIV:    Spielerstärke (final_strength), Positions-Fit (HP/NP/FP)
    AKTIV:    Ballbesitz-Formel (50 + Stärkedifferenz * 22)
    AKTIV:    Poisson-Torberechnung (expected goals aus Stärke-Ratio)
    AKTIV:    Teamwork-Summe pro Team (Ausgabe in result)
    GEPLANT:  Pressing-Bonus auf Stärke (stub: _pressing_modifier)
    GEPLANT:  Angriffsfokus-Modifier (stub: _attack_focus_modifier)
    GEPLANT:  Teamwork-Multiplikator auf Gesamtstärke (stub: _teamwork_modifier)
    GEPLANT:  Tempo-Einfluss auf Frischeverbrauch
    GEPLANT:  Bedingungs-/Matchplan-Wechsel zur Laufzeit
"""

import json
import math
import random
from typing import Optional

# ── Gruppen → Stärke-Kategorie ───────────────────────────────────────────────

_GROUP_KEY: dict[str, str] = {
    'goalkeeper':         'goalkeeper',
    'defense':            'defense',
    'defensive_midfield': 'midfield',
    'midfield':           'midfield',
    'offensive_midfield': 'midfield',
    'attack':             'attack',
}

# ── Torwahrscheinlichkeit je Positions-Gruppe ─────────────────────────────────

_GOAL_WEIGHTS: dict[str, float] = {
    'goalkeeper':         0.01,
    'defense':            0.04,
    'defensive_midfield': 0.07,
    'midfield':           0.13,
    'offensive_midfield': 0.22,
    'attack':             0.53,
}


# ═══════════════════════════════════════════════════════════════════════════════
# Stärke-Berechnung
# ═══════════════════════════════════════════════════════════════════════════════

def _pos_factor(player: dict, position_code: str) -> tuple[float, str]:
    """Positionsfit-Multiplikator.

    HP (Hauptposition)  → 1.00  — kein Malus
    NP (Nebenposition)  → 0.90  — -10 %
    FP (Fremdposition)  → 0.80  — -20 %
    """
    if position_code in player.get('main_positions', []):
        return 1.0, 'HP'
    if position_code in player.get('secondary_positions', []):
        return 0.90, 'NP'
    return 0.80, 'FP'


# ── GEPLANT: Taktik-Modifikatoren (Stubs) ────────────────────────────────────

def _pressing_modifier(pressing: dict) -> float:
    """GEPLANT: Pressing-Intensität → Stärke-Multiplikator (±0–5%).
    Höheres Pressing erhöht defensive Stärke, kostet aber Frische.
    Aktuell: gibt 1.0 zurück (kein Effekt).
    """
    return 1.0


def _attack_focus_modifier(attack_focus: str, line: str) -> float:
    """GEPLANT: Angriffsfokus → Stärke-Shift zwischen Linien.
    z.B. 'sturmlauf' → Angriff +5%, Abwehr -3%
    Aktuell: gibt 1.0 zurück (kein Effekt).
    """
    return 1.0


def _teamwork_modifier(team: dict) -> float:
    """GEPLANT: Teamwork-Summe der Startelf → Stärke-Multiplikator.
    Hoher Teamwork-Wert (z.B. 800/800) → kleiner Bonus auf Gesamtstärke.
    Aktuell: gibt 1.0 zurück (kein Effekt).
    """
    return 1.0


def calculate_lineup_strength(team: dict, tactic_override: Optional[dict] = None) -> dict:
    """Berechnet Linienstärken aus Team-Dict.

    Args:
        team:            Team-Dict im Format von bayern_fixture.json
        tactic_override: Optional — überschreibt team['tactic'] für Analyse

    Returns:
        dict mit goalkeeper, defense, midfield, attack, overall (alle float, 2 Dezimalstellen)

    Aktiv:   final_strength × Positions-Fit (HP/NP/FP)
    Geplant: × pressing_modifier × attack_focus_modifier × teamwork_modifier
    """
    players_by_id = {p['id']: p for p in team.get('players', [])}
    tactic = tactic_override or team.get('tactic', {})

    lines: dict[str, list[float]] = {
        'goalkeeper': [], 'defense': [], 'midfield': [], 'attack': []
    }

    for slot in team.get('lineup', []):
        pid = slot.get('player_id')
        if not pid:
            continue
        player = players_by_id.get(pid)
        if not player:
            continue

        group = slot.get('group', 'attack')
        line  = _GROUP_KEY.get(group, 'attack')

        factor, fit = _pos_factor(player, slot['position'])
        strength    = player.get('final_strength', 50.0) * factor

        # ── GEPLANT ──────────────────────────────────────────────────────────
        # strength *= _attack_focus_modifier(tactic.get('attack_focus'), line)
        # strength *= _pressing_modifier(tactic.get('pressing', {}))
        # ─────────────────────────────────────────────────────────────────────

        lines[line].append(strength)

    def avg(lst: list) -> float:
        return sum(lst) / len(lst) if lst else 50.0

    gk = avg(lines['goalkeeper'])
    de = avg(lines['defense'])
    mi = avg(lines['midfield'])
    at = avg(lines['attack'])

    all_vals = lines['goalkeeper'] + lines['defense'] + lines['midfield'] + lines['attack']
    overall  = avg(all_vals)

    # ── GEPLANT: Teamwork-Gesamtbonus ────────────────────────────────────────
    # overall *= _teamwork_modifier(team)
    # ─────────────────────────────────────────────────────────────────────────

    return {
        'goalkeeper': round(gk, 2),
        'defense':    round(de, 2),
        'midfield':   round(mi, 2),
        'attack':     round(at, 2),
        'overall':    round(overall, 2),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Tor-Berechnung (Poisson)
# ═══════════════════════════════════════════════════════════════════════════════

def _poisson(lam: float) -> int:
    """Poisson-Zufallsvariable nach Knuth."""
    L = math.exp(-lam)
    k, p = 0, 1.0
    while p > L:
        k += 1
        p *= random.random()
    return k - 1


def _expected_goals(strength: float, opp_strength: float) -> float:
    """Erwartete Tore basierend auf Stärke-Ratio.
    λ = 1.4 × (eigene_stärke / gegner_stärke), Minimum 0.2
    """
    ratio = strength / max(opp_strength, 1.0)
    return max(0.2, 1.4 * ratio)


# ═══════════════════════════════════════════════════════════════════════════════
# Tor-Events
# ═══════════════════════════════════════════════════════════════════════════════

def _goal_events(
    n: int,
    team_key: str,
    lineup_players: list[dict],
    minute_pool: list[int],
) -> list[dict]:
    """Erzeugt n Tor-Events mit Schütze und optionaler Vorlage."""
    if not lineup_players:
        return []

    weights = [_GOAL_WEIGHTS.get(p.get('group', 'attack'), 0.05) for p in lineup_players]
    w_sum   = sum(weights) or 1.0
    weights = [w / w_sum for w in weights]

    events = []
    for _ in range(n):
        if minute_pool:
            minute = minute_pool.pop(random.randint(0, len(minute_pool) - 1))
        else:
            minute = random.randint(1, 90)

        scorer   = random.choices(lineup_players, weights=weights, k=1)[0]
        assister = None
        if random.random() < 0.72:
            cands = [p for p in lineup_players if p['id'] != scorer['id']]
            if cands:
                assister = random.choice(cands)

        events.append({
            'minute':        minute,
            'team':          team_key,
            'scorer_id':     scorer['id'],
            'scorer_name':   scorer['name'],
            'scorer_pos':    scorer.get('position', '?'),
            'assister_id':   assister['id']   if assister else None,
            'assister_name': assister['name'] if assister else None,
        })

    return events


# ═══════════════════════════════════════════════════════════════════════════════
# Spiel-Statistiken
# ═══════════════════════════════════════════════════════════════════════════════

def _match_stats(h_str: dict, a_str: dict, hg: int, ag: int) -> dict:
    """Klassische Match-Statistiken (Ballbesitz, Schüsse, Fouls usw.)."""
    h, a = h_str['overall'], a_str['overall']
    total = h + a or 1.0

    # Ballbesitz: bei gleicher Stärke exakt 50/50
    home_poss = int(round(max(30, min(70, 50 + (h - a) / total * 22))))

    def shots(goals: int) -> tuple[int, int]:
        on_target = goals + random.randint(2, 5)
        total_    = on_target + random.randint(3, 9)
        return on_target, total_

    h_on, h_all = shots(hg)
    a_on, a_all = shots(ag)

    return {
        'home_possession':       home_poss,
        'away_possession':       100 - home_poss,
        'home_shots':            h_all,
        'away_shots':            a_all,
        'home_shots_on_target':  h_on,
        'away_shots_on_target':  a_on,
        'home_corners':          random.randint(2, 10),
        'away_corners':          random.randint(2, 10),
        'home_fouls':            random.randint(8, 20),
        'away_fouls':            random.randint(8, 20),
        'home_yellow':           random.randint(0, 3),
        'away_yellow':           random.randint(0, 3),
        'home_red':              1 if random.random() < 0.04 else 0,
        'away_red':              1 if random.random() < 0.04 else 0,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Haupt-Einstiegspunkt
# ═══════════════════════════════════════════════════════════════════════════════

def simulate_match(
    home_team:    dict,
    away_team:    dict,
    home_tactic:  Optional[dict] = None,
    away_tactic:  Optional[dict] = None,
) -> dict:
    """Simuliert ein komplettes Spiel aus zwei Team-Dicts.

    Parameters
    ----------
    home_team :    Team-Dict (Format: bayern_fixture.json)
    away_team :    Team-Dict
    home_tactic :  Optional — überschreibt home_team['tactic'] für Varianten-Analyse
    away_tactic :  Optional — überschreibt away_team['tactic']

    Returns
    -------
    dict mit:
        home_team, away_team      — Teamnamen
        home_goals, away_goals    — Ergebnis
        goal_events               — [{minute, team, scorer_name, scorer_pos, assister_name}, …]
        match_stats               — {possession, shots, corners, fouls, yellow, red}
        home_players, away_players— Startelf mit goals/assists
        home_strength, away_strength — {goalkeeper, defense, midfield, attack, overall}
        home_teamwork, away_teamwork  — Summe Teamwork der Startelf
    """
    # ── 1. Linienstärken ─────────────────────────────────────────────────────
    h_str = calculate_lineup_strength(home_team, home_tactic)
    a_str = calculate_lineup_strength(away_team, away_tactic)

    # ── 2. Tore (Poisson) ───────────────────────────────────────────────────
    h_goals = _poisson(_expected_goals(h_str['overall'], a_str['overall']))
    a_goals = _poisson(_expected_goals(a_str['overall'], h_str['overall']))

    # ── 3. Lineup-Spieler aufbereiten ────────────────────────────────────────
    def _lineup_players(team: dict) -> list[dict]:
        pid_map = {p['id']: p for p in team.get('players', [])}
        result  = []
        for slot in team.get('lineup', []):
            p = pid_map.get(slot.get('player_id'))
            if p:
                result.append({
                    **p,
                    'position': slot['position'],
                    'group':    slot.get('group', 'attack'),
                })
        return result

    h_lineup = _lineup_players(home_team)
    a_lineup = _lineup_players(away_team)

    # ── 4. Tor-Events ────────────────────────────────────────────────────────
    minutes = list(range(1, 91))
    random.shuffle(minutes)
    events = sorted(
        _goal_events(h_goals, 'home', h_lineup, minutes) +
        _goal_events(a_goals, 'away', a_lineup, minutes),
        key=lambda e: e['minute'],
    )

    # ── 5. Tore/Assists auf Spieler buchen ───────────────────────────────────
    h_stats = {p['id']: {'goals': 0, 'assists': 0} for p in h_lineup}
    a_stats = {p['id']: {'goals': 0, 'assists': 0} for p in a_lineup}
    for evt in events:
        stats_map = h_stats if evt['team'] == 'home' else a_stats
        if evt['scorer_id'] in stats_map:
            stats_map[evt['scorer_id']]['goals'] += 1
        if evt['assister_id'] and evt['assister_id'] in stats_map:
            stats_map[evt['assister_id']]['assists'] += 1

    def _enrich(lineup: list[dict], stats: dict) -> list[dict]:
        return [{**p, **stats.get(p['id'], {'goals': 0, 'assists': 0})} for p in lineup]

    h_players = _enrich(h_lineup, h_stats)
    a_players = _enrich(a_lineup, a_stats)

    # ── 6. Statistiken & Teamwork ────────────────────────────────────────────
    stats       = _match_stats(h_str, a_str, h_goals, a_goals)
    h_teamwork  = sum(p.get('teamwork', 50) for p in h_players)
    a_teamwork  = sum(p.get('teamwork', 50) for p in a_players)

    return {
        'home_team':      home_team['team']['name'],
        'away_team':      away_team['team']['name'],
        'home_goals':     h_goals,
        'away_goals':     a_goals,
        'goal_events':    events,
        'match_stats':    stats,
        'home_players':   h_players,
        'away_players':   a_players,
        'home_strength':  h_str,
        'away_strength':  a_str,
        'home_teamwork':  h_teamwork,
        'away_teamwork':  a_teamwork,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Direkt ausführen: python run_match.py [fixture.json] [n_simulations]
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import sys

    fixture_path = sys.argv[1] if len(sys.argv) > 1 else 'bayern_fixture.json'
    n_sims       = int(sys.argv[2]) if len(sys.argv) > 2 else 1000

    with open(fixture_path, encoding='utf-8') as f:
        team = json.load(f)

    team_name = team['team']['name']
    print(f'Simuliere {n_sims}× {team_name} vs {team_name} …')

    outcomes    = {'home': 0, 'draw': 0, 'away': 0}
    total_goals = 0
    total_poss  = 0

    for _ in range(n_sims):
        r = simulate_match(team, team)
        hg, ag = r['home_goals'], r['away_goals']
        total_goals += hg + ag
        total_poss  += r['match_stats']['home_possession']
        if   hg > ag:  outcomes['home'] += 1
        elif hg == ag: outcomes['draw'] += 1
        else:          outcomes['away'] += 1

    print(f'\nErgebnisse ({n_sims} Spiele):')
    print(f'  Heimsieg:       {outcomes["home"]:>5}  ({outcomes["home"]/n_sims*100:.1f} %)')
    print(f'  Unentschieden:  {outcomes["draw"]:>5}  ({outcomes["draw"]/n_sims*100:.1f} %)')
    print(f'  Auswärtssieg:   {outcomes["away"]:>5}  ({outcomes["away"]/n_sims*100:.1f} %)')
    print(f'  Ø Tore/Spiel:   {total_goals / n_sims:.2f}')
    print(f'  Ø Ballbesitz H: {total_poss / n_sims:.1f} %')

    sample = simulate_match(team, team)
    print(f'\nBeispiel-Stärken:')
    for k, v in sample['home_strength'].items():
        print(f'  {k:<15} {v}')
    print(f'  Teamwork:       {sample["home_teamwork"]}')
