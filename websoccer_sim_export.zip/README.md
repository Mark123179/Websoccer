# Websoccer Match Simulation — Export

Standalone-Exportpaket zur externen Analyse der Spielsimulation.
Kein Django, kein ORM, keine Datenbank erforderlich.

---

## Schnellstart

```bash
# 1.000 Simulationen Bayern vs. Bayern
python run_match.py bayern_fixture.json 1000

# 10.000 Simulationen
python run_match.py bayern_fixture.json 10000
```

Oder als Python-Modul:

```python
import json
from run_match import simulate_match

with open('bayern_fixture.json', encoding='utf-8') as f:
    team = json.load(f)

result = simulate_match(home_team=team, away_team=team)
print(result['home_goals'], ':', result['away_goals'])
```

---

## Dateiübersicht

| Datei               | Zweck |
|---------------------|-------|
| `run_match.py`      | **Einstiegspunkt** — standalone, Django-frei |
| `match_engine.py`   | Original Django-Version (ORM-abhängig) |
| `match_readiness.py`| Original Aufstellungs- & Stärke-Logik (ORM-abhängig) |
| `tactics.py`        | Original Taktik-System mit allen Konstanten |
| `bayern_fixture.json` | Vollständige Bayern-Daten (Spieler, Lineup, Taktik) |

---

## Schlüsselfunktionen

### `run_match.py` — Die Standalone-API

#### `simulate_match(home_team, away_team, home_tactic=None, away_tactic=None)`
Simuliert ein komplettes Spiel. Haupteinstiegspunkt für Batch-Analysen.

```python
result = simulate_match(home_team, away_team)
# result enthält:
# - home_goals, away_goals
# - goal_events        [{minute, team, scorer_name, scorer_pos, assister_name}]
# - match_stats        {possession, shots, corners, fouls, yellow, red}
# - home_players       [{name, position, final_strength, teamwork, goals, assists}]
# - away_players
# - home_strength      {goalkeeper, defense, midfield, attack, overall}
# - away_strength
# - home_teamwork      int (Summe Teamwork der Startelf)
# - away_teamwork
```

#### `calculate_lineup_strength(team, tactic_override=None)`
Berechnet Linienstärken aus Team-Dict.
Berücksichtigt Positions-Fit (HP/NP/FP).

#### `_pos_factor(player, position_code) → (float, str)`
Positionsfit-Multiplikator: HP=1.0 / NP=0.90 / FP=0.80

#### `_poisson(lam) → int`
Poisson-Zufallsvariable für Torberechnung (Knuth-Algorithmus).

#### `_expected_goals(strength, opp_strength) → float`
λ = 1.4 × (eigene_stärke / gegner_stärke), Minimum 0.2

---

### `match_engine.py` — Original Django-Version

#### `simulate_match(home_club, away_club) → dict`
Django-Version. Erfordert Club-ORM-Objekte. Identische Logik wie `run_match.py`,
aber liest Daten direkt aus der PostgreSQL-Datenbank.

---

### `match_readiness.py` — Aufstellung & Stärke (Django)

#### `calculate_lineup_strength(lineup, formation, malus=1.0) → dict`
Berechnet Linienstärken aus DB-Lineup. Wendet HP/NP/FP-Malus an.

#### `ensure_default_tactic(club) → (TacticSetup, changed)`
Legt/repariert TacticSetup für einen Verein. Wählt Formation automatisch
nach maximaler HP-Abdeckung (keine FP-Zuweisung).

#### `calculate_team_strength(club, malus=1.0) → dict`
Berechnet Stärke direkt aus Vereins-Objekt.

---

### `tactics.py` — Taktik-System (Django)

#### `tactic_payload_from_setup(setup) → dict`
Wandelt TacticSetup-ORM in serialisierbares Dict um.

#### `formation_slots(formation) → list`
Gibt alle Slots einer Formation zurück:
`[{key, code, group, occurrence}, …]`

#### `normalize_instructions(raw) → dict`
Validiert und normalisiert alle Taktik-Anweisungen.

#### `normalize_conditions(raw) → list`
Validiert und normalisiert Matchplan-Bedingungen.

---

## Aktueller Simulationsstatus

### ✅ Aktiv (beeinflusst das Ergebnis)

| Feature | Implementierung |
|---------|----------------|
| Spielerstärke (`final_strength`) | `calculate_lineup_strength()` |
| Positions-Fit HP/NP/FP | `_pos_factor()` |
| Poisson-Torberechnung | `_poisson()` + `_expected_goals()` |
| Ballbesitz-Formel (symmetrisch) | `_match_stats()` |
| Tor-Events mit Schütze/Vorlage | `_goal_events()` |
| Teamwork-Ausgabe (Summe) | `simulate_match()` |

### 🔧 Geplant (Stubs vorhanden, noch ohne Effekt)

| Feature | Stub-Funktion | Einbauort |
|---------|--------------|-----------|
| Pressing-Bonus auf Stärke | `_pressing_modifier()` | `calculate_lineup_strength()` |
| Angriffsfokus-Shift (Linien) | `_attack_focus_modifier()` | `calculate_lineup_strength()` |
| Teamwork-Multiplikator | `_teamwork_modifier()` | `calculate_lineup_strength()` |
| Tempo → Frischeverbrauch | — | `simulate_match()` |
| Matchplan-Wechsel (conditions) | — | `simulate_match()` |

---

## Taktik-Varianten analysieren

### Gleiche Aufstellung, verschiedene Taktik:

```python
import json
from run_match import simulate_match

with open('bayern_fixture.json', encoding='utf-8') as f:
    team = json.load(f)

# Basis-Taktik
base = team['tactic']

# Variante: Angriffsfokus ändern (Effekt sobald _attack_focus_modifier implementiert)
tactic_sturmlauf = {**base, 'attack_focus': 'sturmlauf'}
tactic_konter    = {**base, 'attack_focus': 'konter'}

n = 10_000
results_base     = [simulate_match(team, team) for _ in range(n)]
results_sturm    = [simulate_match(team, team, home_tactic=tactic_sturmlauf) for _ in range(n)]

avg_goals = lambda rs: sum(r['home_goals'] for r in rs) / len(rs)
print(f'Basis:     Ø {avg_goals(results_base):.3f} Tore')
print(f'Sturmlauf: Ø {avg_goals(results_sturm):.3f} Tore')
```

### Pressing-Intensität vergleichen:

```python
# Sobald _pressing_modifier implementiert ist:
tactic_high_press = {**base, 'pressing': {
    'defense': 'hoch', 'midfield': 'hoch', 'attack': 'hoch'
}}
results_press = [simulate_match(team, team, home_tactic=tactic_high_press) for _ in range(n)]
```

---

## Datenformat — `bayern_fixture.json`

```json
{
  "team": {
    "id": 2,
    "name": "FC Bayern München",
    "fm_inside_id": 915
  },
  "formation_raw": {
    "defense": "4n",
    "defensive_midfield": "2",
    "midfield": "0",
    "offensive_midfield": "1",
    "attack": "3"
  },
  "players": [
    {
      "id": 21609,
      "name": "Harry Kane",
      "main_positions": ["ST"],
      "secondary_positions": [],
      "age": 31,
      "base_strength": 178.5,
      "final_strength": 178.5,
      "freshness": 100.0,
      "form_modifier": 0.0,
      "teamwork": 75,
      "injury_days": 0,
      "suspension_matches": 0,
      "in_lineup": true
    }
  ],
  "lineup": [
    {
      "slot": "ST-1",
      "position": "ST",
      "group": "attack",
      "player_id": 21609
    }
  ],
  "tactic": {
    "attack_focus": "ausgewogen",
    "buildup": { "defense": "kurz", "midfield": "kombinationsspiel", ... },
    "defending": { "deckung": "hybrid", "zweikampf": "normal", ... },
    "pressing": { "defense": "normal", "midfield": "normal", "attack": "normal" },
    "pressing_triggers": { "ballverlust": false, "gegenpressing": false, ... },
    "conditions": [
      { "active": false, "minute": "01", "condition": "rueckstand", "plan": "aggressiv_risiko" }
    ]
  }
}
```

---

## Systemanforderungen

- Python 3.10+
- Nur Standardbibliothek (`math`, `random`, `json`)
- Keine externen Pakete
