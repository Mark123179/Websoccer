# Drehbuch: Borussia Dortmund – 1. FC Heidenheim 1846  (1:1)
Spiel-ID 6 · pokal · penalties  
Zeilen 123 · sichtbar 109 · Sequenzen 57 · Abspieldauer 21.8 min  
Kernzahlen: Schüsse 5/10 · aufs Tor 2/2 · Ecken 4/4 · Fouls 20/13 · Ballbesitz 42/58

**Prüfhinweise:**
- 18': Engine nennt Torwart Diant Ramaj als Kopfballspieler nach Ecke — ersetzt (Engine-Ticket)
- 65': Engine gibt Mathias Honsak eine Karte, der nicht auf dem Platz ist – im Text ersetzt durch Patrick Mainka (Engine-Ticket)
- Elfmeterschießen Runde 1: Torwart Diant Ramaj schießt – Engine-Reihenfolge prüfen
- Elfmeterschießen Runde 2: Torwart Gregor Kobel schießt – Engine-Reihenfolge prüfen
- Elfmeterschießen Runde 2: Engine nennt Marvin Pieringer, der nicht auf dem Platz war – im Text ersetzt durch Sirlord Conteh (Engine-Ticket)

| Min | Team | Ebene | Text | Bild |
|---|---|---|---|---|
| 0' |  | ·· | **Anpfiff! Schiedsrichter Tobias Reichel gibt das Spiel frei.** | 11 s |
| 0' | BVB | ◇ | Dortmund (4n-0-4-0-2) spielt ohne festen Schwerpunkt, ausgewogen im Umschalten, mit mittlerem Pressing und gemischter Deckung. | — |
| 0' | FCH | ◇ | Heidenheim (3n-2-0-1-4) spielt ohne festen Schwerpunkt, ausgewogen im Umschalten, mit mittlerem Pressing und gemischter Deckung. | — |
| 2' |  | ◇ | **Beide Teams tasten sich ab, viel Mittelfeld, wenig Zug zum Tor.** | — |
| 8' | BVB | ·· | **Patrick Mainka gewinnt das Duell gegen Waldemar Anton, Heidenheim hat den Ball.** | 7 s (2 Beats) |
| 13' | BVB | ▲▲ | **Fábio Silva hält aus der Distanz drauf, Diant Ramaj hat den Ball sicher.** | 14 s (2 Beats) |
| 14' | BVB | · | **Dortmund setzt nach: Julian Brandt holt sich den Ball von Niklas Dorsch.** | 7 s |
| 14' | BVB | ▲ | Felix Nmecha zieht in den Strafraum, Omar Traoré kommt zu spät! | 7 s |
| 14' | BVB | ·· | Patrick Mainka bringt Nmecha zu Fall – Gelb! | 12 s (2 Beats) |
| 18' | FCH | ◇ | **Heidenheim schnürt Dortmund hinten ein.** | — |
| 18' | FCH | ▲ | **Ecke Niklas Dorsch, Leart Paçarada steigt hoch, der Kopfball geht drüber.** | 21 s (2 Beats) |
| 24' | FCH | ▲ | **Julian Niehues lässt Julian Brandt stehen – freie Bahn Richtung Tor!** | 15 s (2 Beats) |
| 24' | FCH | ·· | Nico Schlotterbeck stoppt Niehues regelwidrig, Niklas Dorsch macht schnell weiter. | 16 s (2 Beats) |
| 26' | FCH | ·· | **Heidenheim bleibt dran: Julian Niehues wirft kurz ein, Diagonalball von Arijon Ibrahimovic auf Niklas Dorsch.** | 15 s (2 Beats) |
| 26' | FCH | ▲ | Marvin Pieringer trifft den Ball nicht richtig, Abstoß. | 14 s |
| 30' | FCH | ·· | **Julian Niehues gewinnt den Ball gegen Carney Chukwuemeka, Niklas Dorsch spielt weit nach vorn.** | 15 s (2 Beats) |
| 30' | FCH | ★ | Mathias Honsak bleibt ruhig, umkurvt Gregor Kobel und schiebt ein – 0:1! | 44 s (2 Beats) |
| 31' | FCH | · | **Heidenheim bleibt dran: Leart Paçarada setzt sich gegen Ramy Bensebaini durch.** | 7 s |
| 31' | FCH | ·· | Taktisches Foul von Felix Nmecha an Paçarada – Gelb, das war klar. | 12 s (2 Beats) |
| 31' | FCH | ·· | Niklas Dorsch bringt den Freistoß in den Strafraum, Nico Schlotterbeck klärt vor Omar Traoré. | 11 s |
| 32' | FCH | ▲ | **Arijon Ibrahimovic tanzt Julian Brandt aus und ist im Sechzehner.** | 15 s (2 Beats) |
| 32' | FCH | ·· | Brandt kommt zu spät gegen Ibrahimovic und sieht Gelb. | 12 s (2 Beats) |
| 32' | FCH | ·· | Ibrahimovic spielt den Freistoß kurz weiter. | 11 s |
| 34' | FCH | ◇ | **Heidenheim setzt nach dem Tor sofort nach.** | — |
| 34' | FCH | ·· | **Omar Traoré schlägt den langen Ball, Niklas Dorsch verlagert auf Julian Niehues.** | 22 s (3 Beats) |
| 34' | FCH | ▲▲ | Latte! Arijon Ibrahimovic hämmert den Ball an die Querlatte – Gregor Kobel wäre geschlagen gewesen. | 14 s |
| 37' | BVB | ◇ | **Dortmund wird gefährlicher.** | — |
| 37' | BVB | ·· | **Serhou Guirassy versucht es, Leart Paçarada fälscht ab – Eckball Dortmund.** | 7 s (2 Beats) |
| 37' | BVB | ·· | Ecke Felix Nmecha, Omar Traoré klärt per Kopf. | 14 s (2 Beats) |
| 39' | BVB | · | **Maximilian Beier läuft Patrick Mainka an, der Pass wird zu kurz – Ballgewinn 30 Meter vor dem Tor.** | 7 s |
| 39' | BVB | ·· | Foul von Eren Dinkçi an Beier, dafür gibt es die Gelbe Karte. | 12 s (2 Beats) |
| 39' | BVB | ·· | Freistoß Carney Chukwuemeka, kurz ausgeführt. | 11 s |
| 43' | BVB | ★ | **Ecke Julian Brandt, Kopfball Nico Schlotterbeck – TOR! 1:1!** | 52 s (3 Beats) |
| 45+2' |  | ·· | **Halbzeit. 1:1.** | 18 s |
| 45+2' |  | ◇ | Zwischenbilanz: 1:1. Schüsse 2:4, Ecken 2:1, Ballbesitz 42:58 Prozent. Dortmund greift vor allem über links an (40 Prozent), Heidenheim über rechts (42 Prozent). | — |
| 46' |  | ·· | **Weiter geht's, zweite Halbzeit.** | 11 s |
| 48' | FCH | · | **Heidenheim reagiert: Patrick Mainka bleibt im Duell mit Waldemar Anton oben.** | 7 s |
| 48' | FCH | ·· | Zu hastig: Mainka verliert den Ball an Julian Ryerson. | 7 s |
| 49' | FCH | ·· | **Julian Ryerson kommt zu spät gegen Niklas Dorsch und sieht Gelb.** | 12 s (3 Beats) |
| 49' | FCH | ·· | Freistoß-Flanke Julian Niehues, Ramy Bensebaini köpft heraus. | 11 s |
| 50' | BVB | ◇ | **Dortmund hat jetzt mehr vom Spiel.** | — |
| 50' | BVB | · | **Julian Ryerson spitzelt Omar Traoré den Ball weg.** | 7 s |
| 50' | BVB | ·· | Traoré stellt Ryerson und klärt. | 7 s |
| 54' | BVB | · | **Waldemar Anton ist im Zweikampf mit Julian Niehues der Stärkere.** | 7 s |
| 54' | BVB | ▲ | Jetzt wird es gefährlich: Carney Chukwuemeka spielt Serhou Guirassy in die Schnittstelle. | 7 s |
| 54' | BVB | ·· | Omar Traoré blockt die Hereingabe von Chukwuemeka über die Grundlinie. Ecke. | 7 s |
| 54' | BVB | ·· | Felix Nmecha tritt die Ecke, Leart Paçarada gewinnt das Luftduell gegen Ramy Bensebaini. | 14 s (2 Beats) |
| 58' | FCH | · | **Arijon Ibrahimovic zieht nach innen, Carney Chukwuemeka kommt nicht hinterher.** | 15 s (2 Beats) |
| 58' | FCH | ▲ | Niklas Dorsch und Julian Niehues spielen sich mit einem Doppelpass durch die Abwehr! | 7 s |
| 58' | FCH | ·· | Julian Brandt bringt Dorsch zu Fall – Freistoß Heidenheim. | 5 s |
| 58' | FCH | ·· | Freistoß-Flanke Ibrahimovic, Nico Schlotterbeck köpft heraus. | 11 s |
| 61' | BVB | · | **Niklas Dorsch spielt zu ungenau, Julian Ryerson nimmt den Ball auf.** | 7 s |
| 61' | BVB | ·· | Fábio Silva wird angespielt, steht aber im Abseits. | 7 s |
| 63' | FCH | ·· | **Mathias Honsak geht unter Applaus vom Platz, Adrian Beck kommt.** | 5 s |
| 63' |  | ◇ | **Offener Schlagabtausch! Chancen auf beiden Seiten.** | — |
| 63' | BVB | ·· | **Dortmund setzt nach: Nico Schlotterbeck steht im Passweg von Arijon Ibrahimovic, Julian Brandt hebt den Ball über die erste Linie.** | 15 s (2 Beats) |
| 63' | BVB | ▲ | Zu hoch, Felix Nmecha setzt den Ball über das Tor. | 14 s |
| 65' | BVB | ·· | **Ballgewinn Nico Schlotterbeck gegen Niklas Dorsch, Julian Ryerson baut in Ruhe auf.** | 15 s (2 Beats) |
| 65' | BVB | ▲ | Carney Chukwuemeka geht ins Eins-gegen-eins mit Patrick Mainka und gewinnt es. | 7 s |
| 65' | BVB | ·· | Mainka bringt Chukwuemeka zu Fall – Gelb! | 12 s (2 Beats) |
| 65' | BVB | ·· | Freistoß Serhou Guirassy, kurz ausgeführt. | 11 s |
| 68' | FCH | · | **Julian Brandt will sofort vertikal spielen, Leart Paçarada ahnt es und ist zuerst am Ball.** | 7 s |
| 68' | FCH | ▲▲ | Großchance Budu Zivzivadze! Gregor Kobel kann den Schuss gerade noch über die Latte lenken. | 14 s |
| 70' | BVB | ▲ | **Carney Chukwuemeka zieht in den Strafraum, Patrick Mainka kommt zu spät!** | 15 s (2 Beats) |
| 70' | BVB | ▲ | Fábio Silva schießt – Mainka wirft sich in den Ball. | 14 s |
| 70' | BVB | ·· | Zweiter Ball Dortmund: Chukwuemeka bleibt an Niklas Dorsch hängen. | 7 s (2 Beats) |
| 71' | FCH | ▲ | **Arijon Ibrahimovic bringt die Ecke, Marvin Pieringer setzt den Kopfball neben das Tor.** | 21 s (2 Beats) |
| 73' | BVB | · | **Dortmund presst Patrick Mainka beim Aufbau zu, Fábio Silva gewinnt den Ball in der gegnerischen Hälfte.** | 7 s |
| 73' | BVB | ▲ | Doppelpass Felix Nmecha – Serhou Guirassy, und Dortmund ist im Strafraum. | 7 s |
| 73' | BVB | ·· | Omar Traoré kommt zu spät gegen Nmecha. | 5 s |
| 73' | BVB | ·· | Julian Brandt bringt den Freistoß in den Strafraum, Leart Paçarada klärt vor Julian Ryerson. | 11 s |
| 74' | FCH | · | **Arijon Ibrahimovic wechselt die Seite zu Julian Niehues.** | 15 s (2 Beats) |
| 74' | FCH | ▲ | Adrian Beck hat die Chance, setzt den Ball aber drüber. | 14 s |
| 75' | BVB | · | **Julian Ryerson fängt den Pass von Adrian Beck ab.** | 7 s |
| 75' | BVB | ·· | Ryerson flankt, Omar Traoré klärt ins Toraus – Ecke Dortmund. | 7 s |
| 75' | BVB | ·· | Ecke Guirassy, nichts zu holen: Diant Ramaj hat den Ball. | 14 s (2 Beats) |
| 78' | FCH | ◇ | **Heidenheim kommt besser ins Spiel.** | — |
| 78' | FCH | · | **Patrick Mainka holt sich den Ball von Julian Brandt.** | 7 s |
| 78' | FCH | ▲ | Niklas Dorsch sieht den Laufweg von Marvin Pieringer und bedient ihn hinter die Kette. | 7 s |
| 78' | FCH | ▲ | Pieringer verzieht aus guter Position. | 14 s |
| 80' | FCH | ·· | **Heidenheim wechselt – Marvin Pieringer runter, Sirlord Conteh rein.** | 5 s |
| 80' | BVB | · | **Nico Schlotterbeck liest den Pass von Adrian Beck und ist dazwischen.** | 7 s |
| 80' | BVB | ▲ | Steilpass Julian Brandt, Maximilian Beier ist durch! | 7 s |
| 80' | BVB | ▲ | Beier schiebt den Ball am langen Pfosten vorbei. | 14 s |
| 82' | BVB | ·· | **Dortmund setzt nach: Wieder das Pressing: Fábio Silva stellt Niklas Dorsch zu und hat den Ball, über Ramy Bensebaini geht es ins Mittelfeld.** | 15 s (2 Beats) |
| 82' | BVB | ·· | Bensebaini spielt den Ball ins Seitenaus. | 7 s |
| 83' | FCH | · | **Omar Traoré holt sich den Ball von Julian Ryerson.** | 7 s |
| 83' | FCH | ▲ | Hereingabe Leart Paçarada – im Strafraum lauert Adrian Beck. | 7 s |
| 83' | FCH | ▲ | Beck zieht ab, Ramy Bensebaini steht im Weg. | 14 s |
| 88' | FCH | ◇ | **Heidenheim will die Führung noch vor dem Abpfiff.** | — |
| 88' | FCH | · | **Julian Ryerson findet unter Druck keinen Abnehmer, Eren Dinkçi schnappt sich den Ball.** | 7 s |
| 88' | FCH | ·· | Ryerson stellt den Passweg zu, Heidenheim muss neu aufbauen. | 7 s |
| 90+2' |  | ·· | **Nach 90 Minuten steht es 1:1. Verlängerung.** | 14 s |
| 91' |  | ·· | **Verlängerung – 30 Minuten mehr.** | 11 s |
| 95' | BVB | · | **Carney Chukwuemeka bleibt im Duell mit Julian Niehues oben.** | 7 s |
| 95' | BVB | ▲ | Julian Brandt lässt Niehues stehen – freie Bahn Richtung Tor! | 7 s |
| 95' | BVB | ·· | Der Pass von Brandt kommt zu ungenau – Omar Traoré ist dazwischen. | 7 s |
| 100' | FCH | ◇ | **Heidenheim übernimmt zunehmend die Kontrolle.** | — |
| 100' | FCH | · | **Julian Niehues öffnet das Spiel auf Arijon Ibrahimovic.** | 15 s (2 Beats) |
| 100' | FCH | ·· | Niehues versucht es, Nico Schlotterbeck fälscht ab – Eckball Heidenheim. | 7 s |
| 100' | FCH | ·· | Ecke Niklas Dorsch – Julian Ryerson köpft heraus. | 14 s (2 Beats) |
| 104' | FCH | ▲ | **Ecke Arijon Ibrahimovic – Julian Niehues köpft knapp vorbei!** | 21 s (2 Beats) |
| 105' |  | ·· | **Seitenwechsel in der Verlängerung.** | 18 s |
| 106' |  | ◇ | **Das Spiel plätschert, beide Teams halten die Ordnung.** | — |
| 107' | FCH | ·· | **Arijon Ibrahimovic will vertikal spielen, Julian Brandt liest den Pass.** | 7 s (2 Beats) |
| 118' | FCH | ·· | **Budu Zivzivadze läuft Julian Brandt an, der Pass wird zu kurz – Ballgewinn 30 Meter vor dem Tor, Patrick Mainka bringt den Ball nach vorn.** | 15 s (2 Beats) |
| 118' | FCH | ·· | Zu weit von Mainka, Abstoß. | 7 s |
| 120' |  | ·· | **Abpfiff! Endstand 1:1.** | 14 s |
| 120' |  | ◇ | Fazit: 1:1. Dortmund: 5 Schüsse (2 aufs Tor), xG 2.39, Ballbesitz 42 Prozent; 5 Ballgewinne im Pressing. Heidenheim: 10 Schüsse (2 aufs Tor), xG 2.0, Ballbesitz 58 Prozent; 3 Ballgewinne im Pressing. | — |
| 120' |  | ·· | **Elfmeterschießen! Nach 120 Minuten steht es 1:1.** | 11 s |
| 120' | BVB | ·· | Ramy Bensebaini schießt vorbei! Es bleibt beim 0:0. | 14 s |
| 120' | FCH | ·· | Ramaj scheitert ebenfalls – 0:0. | 14 s |
| 120' | BVB | ·· | Kobel zeigt, wie es geht – 1:0. | 14 s |
| 120' | FCH | ·· | Sirlord Conteh verwandelt sicher. 1:1. | 14 s |
| 120' | BVB | ·· | Fábio Silva – oben rechts, keine Chance für Ramaj. 2:1. | 14 s |
| 120' | FCH | ·· | Arijon Ibrahimovic trifft, Kobel in der falschen Ecke. 2:2. | 14 s |
| 120' | BVB | ·· | Drin! Nico Schlotterbeck bleibt cool. 3:2. | 14 s |
| 120' | FCH | ·· | Eren Dinkçi verwandelt sicher. 3:3. | 14 s |
| 120' | BVB | ·· | Maximilian Beier trifft, Ramaj in der falschen Ecke. 4:3. | 14 s |
| 120' | FCH | ·· | Drin! Niklas Dorsch bleibt cool. 4:4. | 14 s |
| 120' | BVB | ·· | Serhou Guirassy setzt den Ball über das Tor. 4:4. | 14 s |
| 120' | FCH | ·· | Budu Zivzivadze zeigt, wie es geht – 4:5. | 14 s |
| 120' |  | ·· | Entschieden im Elfmeterschießen: 4:5. | 14 s |