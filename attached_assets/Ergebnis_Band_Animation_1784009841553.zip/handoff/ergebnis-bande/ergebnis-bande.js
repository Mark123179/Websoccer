/* ============================================================
   ERGEBNIS-BANDE — rendert den Ticker aus einem Daten-Array.
   Einbindung:
     <div id="ergebnis-bande"></div>
     <script src="ergebnis-bande.js"><\/script>
     <script>
       ErgebnisBande.mount('#ergebnis-bande', DATA, {
         ownClub: 'BVB', speed: 100, pauseOnHover: true, showAbbr: true,
       });
     <\/script>
   DATA-Format: siehe ErgebnisBande.demoData unten — im Backend
   (Django) einfach als JSON aus den letzten Spieltagen erzeugen.
   ============================================================ */
(function () {
  'use strict';

  function el(tag, className, text) {
    const n = document.createElement(tag);
    if (className) n.className = className;
    if (text != null) n.textContent = text;
    return n;
  }

  function teamNode(team, opts) {
    const frag = document.createDocumentFragment();
    if (team.crest) {
      const img = el('img', 'eb-crest');
      img.src = team.crest;
      img.alt = team.abbr;
      frag.appendChild(img);
    } else {
      frag.appendChild(el('span', 'eb-monogram', team.abbr));
    }
    return frag;
  }

  function scoreClass(match, ownClub) {
    if (!ownClub) return '';
    const isHome = match.home.abbr === ownClub;
    const isAway = match.away.abbr === ownClub;
    if (!isHome && !isAway) return '';
    const own = isHome ? match.homeGoals : match.awayGoals;
    const opp = isHome ? match.awayGoals : match.homeGoals;
    return own > opp ? 'eb-win' : own < opp ? 'eb-loss' : 'eb-draw';
  }

  function buildCopy(data, opts, hidden) {
    const copy = el('div', 'eb-copy');
    if (hidden) copy.setAttribute('aria-hidden', 'true');

    data.forEach(function (seg, si) {
      const segment = el('div', 'eb-segment');
      if (si > 0) segment.appendChild(el('span', 'eb-divider'));

      const comp = el('div', 'eb-comp');
      if (seg.logo) {
        const logo = el('img', 'eb-comp-logo');
        logo.src = seg.logo;
        logo.alt = seg.name;
        comp.appendChild(logo);
      }
      comp.appendChild(el('span', 'eb-comp-name', seg.name));
      comp.appendChild(el('span', 'eb-comp-round', '\u00b7 ' + seg.round));
      segment.appendChild(comp);

      seg.matches.forEach(function (m, mi) {
        const wrap = el('div', 'eb-match-wrap');
        if (mi > 0) wrap.appendChild(el('span', 'eb-match-divider'));

        const isOwn = opts.ownClub &&
          (m.home.abbr === opts.ownClub || m.away.abbr === opts.ownClub);
        const match = el('div', 'eb-match' + (isOwn && opts.highlightOwnClub !== false ? ' eb-own' : ''));

        match.appendChild(teamNode(m.home, opts));
        if (opts.showAbbr !== false && m.home.crest) {
          match.appendChild(el('span', 'eb-abbr', m.home.abbr));
        }

        const cls = opts.highlightOwnClub !== false ? scoreClass(m, opts.ownClub) : '';
        match.appendChild(el('span', 'eb-score' + (cls ? ' ' + cls : ''), m.homeGoals + ':' + m.awayGoals));

        if (opts.showAbbr !== false && m.away.crest) {
          match.appendChild(el('span', 'eb-abbr', m.away.abbr));
        }
        match.appendChild(teamNode(m.away, opts));

        wrap.appendChild(match);
        segment.appendChild(wrap);
      });

      copy.appendChild(segment);
    });

    return copy;
  }

  function mount(target, data, opts) {
    opts = opts || {};
    const root = typeof target === 'string' ? document.querySelector(target) : target;
    if (!root) throw new Error('ErgebnisBande: Ziel-Element nicht gefunden: ' + target);

    const bande = el('div', 'eb-bande');
    bande.dataset.pauseOnHover = String(opts.pauseOnHover !== false);
    bande.style.setProperty('--eb-duration', (opts.speed || 100) + 's');

    const cap = el('div', 'eb-cap');
    cap.appendChild(el('span', 'eb-cap-dot'));
    cap.appendChild(el('span', 'eb-cap-label', opts.label || 'Ergebnisse'));
    bande.appendChild(cap);

    const viewport = el('div', 'eb-viewport');
    const track = el('div', 'eb-track');
    track.appendChild(buildCopy(data, opts, false));
    track.appendChild(buildCopy(data, opts, true)); // 2. Kopie fuer nahtlosen Loop
    viewport.appendChild(track);
    bande.appendChild(viewport);

    root.innerHTML = '';
    root.appendChild(bande);
    return bande;
  }

  // ---- Demo-Daten (Struktur-Referenz fuer das Backend) ----
  const crest = function (id) { return 'assets/crests/' + id + '.png'; };
  const T = {
    FCB: crest(915), B04: crest(901), BVB: crest(907), SGE: crest(912),
    SCF: crest(944), M05: crest(918), VFB: crest(960), WOB: crest(961),
    BMG: crest(908), BOC: crest(905),
  };
  const team = function (abbr) { return { abbr: abbr, crest: T[abbr] || null }; };
  const m = function (h, hg, ag, a) {
    return { home: team(h), homeGoals: hg, awayGoals: ag, away: team(a) };
  };

  const demoData = [
    {
      name: '1. Bundesliga', round: '27. Spieltag',
      logo: 'assets/competitions/bundesliga.png',
      matches: [
        m('FCB', 2, 1, 'RBL'), m('SGE', 1, 3, 'BVB'), m('B04', 3, 0, 'BOC'),
        m('SCF', 1, 0, 'M05'), m('VFB', 2, 1, 'WOB'), m('BMG', 1, 1, 'FCU'),
        m('TSG', 0, 2, 'SVW'), m('FCA', 1, 2, 'STP'), m('FCH', 0, 0, 'KSV'),
      ],
    },
    {
      name: 'DFB-Pokal', round: 'Viertelfinale',
      logo: 'assets/competitions/dfb-pokal.png',
      matches: [
        m('BVB', 1, 0, 'RBL'), m('FCB', 3, 0, 'FCK'), m('B04', 2, 1, 'VFB'), m('SGE', 2, 1, 'SVW'),
      ],
    },
    {
      name: 'Champions League', round: 'Achtelfinale',
      logo: 'assets/competitions/champions-league.png',
      matches: [
        m('FCB', 2, 2, 'RMA'), m('BVB', 1, 0, 'PSG'), m('B04', 0, 1, 'ARS'), m('VFB', 1, 1, 'INT'),
      ],
    },
  ];

  window.ErgebnisBande = { mount: mount, demoData: demoData };
})();
