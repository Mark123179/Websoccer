# Ergebnis-Bande (Ticker)

Animierte Ergebnis-Bande mit den letzten Pflichtspielergebnissen —
Liga-Logo, Spieltag, alle Spiele mit Wappen + Ergebnis, nahtloser Loop.

## Dateien

- `index.html` — Demo-Seite (zeigt die Einbindung)
- `ergebnis-bande.css` — komplettes Styling (Praefix `eb-`, kollidiert nicht)
- `ergebnis-bande.js` — Renderer (`window.ErgebnisBande`) + Demo-Daten
- `assets/crests/` — Vereinswappen (PNG)
- `assets/competitions/` — Wettbewerbs-Logos

## Einbindung (Replit / Django / beliebig)

```html
<link rel="stylesheet" href="ergebnis-bande.css">
<div id="ergebnis-bande"></div>
<script src="ergebnis-bande.js"></script>
<script>
  ErgebnisBande.mount('#ergebnis-bande', DATA, {
    ownClub: 'BVB',
    speed: 100,
    pauseOnHover: true,
    showAbbr: true,
  });
</script>
```

Font: Inter (Google Fonts, siehe `index.html`) — faellt sonst auf Segoe UI/system-ui zurueck.

## Daten-Format (DATA)

Array von Wettbewerben; im Backend als JSON erzeugen:

```js
[
  {
    name: '1. Bundesliga',
    round: '27. Spieltag',
    logo: 'assets/competitions/bundesliga.png',
    matches: [
      {
        home: { abbr: 'FCB', crest: 'assets/crests/915.png' },
        homeGoals: 2,
        awayGoals: 1,
        away: { abbr: 'RBL', crest: null }   // crest: null => Monogramm-Fallback
      },
      // ...
    ]
  },
  // weitere Wettbewerbe ...
]
```

## Optionen

- `ownClub` (String) — Kuerzel des eigenen Vereins; sein Spiel bekommt eine
  Cyan-Pill, das Ergebnis wird gruen (Sieg) / gelb (Remis) / rot (Niederlage)
- `highlightOwnClub` (Bool, default true)
- `speed` (Zahl, Sekunden pro Durchlauf, default 100)
- `pauseOnHover` (Bool, default true)
- `showAbbr` (Bool, default true) — Kuerzel neben Wappen (nur bei Teams mit Wappen)
- `label` (String, default 'Ergebnisse') — Text der festen Kappe links

## Hinweise

- Der nahtlose Loop entsteht durch eine zweite, `aria-hidden` Kopie des
  Inhalts + CSS-Animation `translateX(-50%)`. Kein JS-Timer noetig.
- Teams ohne `crest` bekommen automatisch einen Monogramm-Kreis.
- Farben sind als `--eb-*` Custom-Properties am Anfang der CSS definiert
  und lassen sich zentral anpassen.
