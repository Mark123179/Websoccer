# Manager-Notizen Tablet — Handoff für Replit

Ein Tablet-Overlay (Apple-Style, ohne Logo), in dem der Manager Notizen mit
Checklisten anlegt. Von jedem Screen aufrufbar, gespeichert unterm Managerprofil.

## Dateien

- `notizen_tablet.html` — Markup-Partial (Overlay + Gerät). In `base.html` einbinden.
- `notizen_tablet.css` — alle Styles (Präfix `nt-`, nutzt die DS-Tokens mit Fallbacks).
- `notizen_tablet.js` — Logik, Vanilla JS. Speichert per localStorage ODER per API.
- `demo.html` — Standalone-Vorschau im Browser (localStorage-Modus).

## Einbindung in Django (3 Schritte)

1. **Partial einbinden** — in `game/templates/base.html` vor `</body>`:
   ```django
   {% include "game/notizen_tablet.html" %}
   <link rel="stylesheet" href="{% static 'game/css/notizen_tablet.css' %}">
   <script src="{% static 'game/js/notizen_tablet.js' %}"></script>
   ```
2. **Trigger platzieren** (z. B. in Sidebar oder Header, beliebig):
   ```html
   <button class="nt-trigger" data-nt-open>Notizen</button>
   ```
3. **Backend aktivieren** — vor dem JS-Include:
   ```html
   <script>window.NOTIZEN_API_URL = "/api/notizen/";</script>
   ```
   Ohne diese Zeile speichert das Tablet nur im Browser (localStorage).

## Backend (Speichern unterm Managerprofil)

Einfachste Variante: eine Notizsammlung als JSON pro Manager.

```python
# models.py
class ManagerNotes(models.Model):
    manager = models.OneToOneField(  # euer Manager-/Profilmodell
        "game.ManagerProfile", on_delete=models.CASCADE, related_name="notes")
    data = models.JSONField(default=list)   # [{id,title,content,todos:[{id,text,done}],updatedAt}]
    updated_at = models.DateTimeField(auto_now=True)

# views.py
import json
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required

@login_required
def notizen_api(request):
    obj, _ = ManagerNotes.objects.get_or_create(manager=request.user.managerprofile)
    if request.method == "PUT":
        payload = json.loads(request.body)
        obj.data = payload.get("notes", [])
        obj.save()
        return JsonResponse({"ok": True})
    return JsonResponse({"notes": obj.data})

# urls.py
path("api/notizen/", views.notizen_api, name="notizen_api"),
```

Das JS sendet `PUT` mit `{"notes": [...]}` (debounced, 600 ms) und liest beim
Öffnen per `GET`. CSRF-Token wird automatisch aus dem Cookie gelesen.

Alternativ normalisiert (relationale Tabellen `ManagerNote` + `NoteTodo` mit
ForeignKeys) — dann im JS `load()`/`persist()` entsprechend anpassen.

## Verhalten

- Öffnen: Element mit `data-nt-open` · Schließen: ✕, Klick auf Backdrop, Escape
- Neue Notiz / Notiz löschen, Titel + Freitext, Checkliste (abhaken, umbenennen,
  ✕ löschen, Enter fügt Punkt hinzu)
- Liste sortiert nach zuletzt bearbeitet, Checklisten-Badge „✓ 2/3"
- Uhr in der Statusleiste aktualisiert sich automatisch

## Design-Tokens

Das CSS nutzt `var(--line)`, `var(--panel)`, `var(--green)`, `var(--red)` usw.
aus dem Websoccer-Design-System (`tokens/colors.css`) und hat identische
Fallback-Werte, falls die Tokens nicht geladen sind.
