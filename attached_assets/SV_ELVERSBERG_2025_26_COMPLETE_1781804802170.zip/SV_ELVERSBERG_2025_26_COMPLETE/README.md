# SV Elversberg Websoccer Importpaket

Paket: SV_ELVERSBERG_2025_26_COMPLETE
Datenstand: 2026-06-18
Saison: 2025/26
Ziel-Liga im WS: 1. Bundesliga

## Inhalt
- 30 Spieler: 28 aktueller TM-Kader + Jason Çeka + Filimon Gerezgiher als Elversberger Leihabgänge
- TM-ID Verein: 64
- FM-Club-ID/FMI-ID: 121200
- FM26 Moneyball-Export: 30/30 Spieler mit Unique ID, CA, PA und FM-Attributen
- EA-FC26-Karriere-Save-Export: 25/30 Spieler mit EA-Werten
- 5 Spieler ohne EA-Datensatz im gelieferten EA-Export: Luis Seifert, Daniel Pantschenko, Patryk Dragon, Mohammad Mahmoud, Filimon Gerezgiher
- Für diese 5 Spieler ist ea_availability_status=NOT_IN_ACTIVE_EA_FC26_DATABASE gesetzt; Importer nutzt FMI_ONLY_X2-Fallback.
- Keine FC25-/EA25-/SoFIFA25- oder geschätzten Attributwerte.

## Wichtig
Dieses Paket ist für die aktuell vorhandene Websoccer-Importlogik gebaut:
Spieler mit ea_availability_status=NOT_IN_ACTIVE_EA_FC26_DATABASE erzeugen eine Warnung,
werden aber über FMI-only-Gewichtung importierbar.

## Stadion
Offizielle Vereinsdaten:
- 10.000 Gesamtplätze
- 6.320 Stehplätze
- 3.410 Sitzplätze auf Tribünen
- 270 Sitzplätze Oberrang für Logenbesucher
=> 3.680 Sitzplätze gesamt, 6.320 Stehplätze

Die Nord/Ost/Süd/West-Verteilung ist simuliert und validiert.
