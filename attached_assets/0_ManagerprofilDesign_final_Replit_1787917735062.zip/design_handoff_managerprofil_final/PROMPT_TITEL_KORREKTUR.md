# Prompt: Titel-System & XP-Werte im Managerprofil korrigieren

Kontext: Managerprofil-Redesign (siehe `PROMPT_REPLIT.md` / `design_reference/Managerprofil.dc.html`). Das dort enthaltene Titel-System ist ein veralteter Stand. Es gilt ab sofort das folgende, final entschiedene Konzept. Design-Tokens, Farben und Typografie aus dem bestehenden Handoff unverändert übernehmen.

---

## 1. Badges komplett entfernen

- Es gibt **keine Badges** und keine Zwischenstufe „Auszeichnung schaltet Titel frei" mehr. Der Titel ist selbst die Auszeichnung.
- Entfernen: die separate Kachel „Badges", jeden Text der Form „Gewinne den DFB-Pokal · schaltet Titel ‚Pokaljäger' frei", jede Referenz „durch Badge ‚Pokalheld'". Der Titel „Pokalheld" existiert nicht.
- Der Kasten heißt nur noch **„TITEL"**.

## 2. Zwei Sorten Titel

**Frei wählbar (13)** — reine Charaktersache, jederzeit wählbar, keine Bedingung, keine Prozentanzeige:

Quälix · Laptoptrainer · Taktikfuchs · Motivator · Kettenraucher · Zampano · Schleifer · Schlitzohr · Konzepttrainer · Grantler · Malocher · Menschenfänger · Schönwetter-Trainer

Gestrichen (aus dem Raster entfernen): Transferstratege, Offensivarchitekt, Underdog-Flüsterer, Konterkönig, Betonmischer, Mentalitätsmonster, Feuerwehrmann und Talentschmied als freie Titel (die letzten beiden sind freischaltbar, siehe unten).

**Freischaltbar (9)** — erspielt, mit Bedingung:

| Titel | Bedingung | Prüfzeitpunkt |
|---|---|---|
| Pokaljäger | Erster Pokalsieg (nur Pokal, keine Meisterschaft) | Nach dem Pokalfinale |
| Serienmeister | 3 Meisterschaften in Folge — Fortschritt setzt bei Saison ohne Titel auf 0/3 zurück | Saisonwechsel |
| Talentschmied | Ein Jugendspieler wurde zu den Profis verschoben | Bei der Kaderverschiebung |
| Weltenbummler | 3. Verein übernommen (0/3, nicht 0/6) | Beim Vereinswechsel |
| Aufstiegsheld | Ein Aufstieg mit einer Mannschaft (0/1, nicht 0/3) | Saisonwechsel |
| Feuerwehrmann | Verein während der laufenden Saison (ab Spieltag 1) auf einem Abstiegsplatz übernommen und Klassenerhalt am Saisonende | Saisonwechsel |
| Underdog | Meister mit einem Verein, dessen Saisonvorgabe des Präsidenten nicht Platz 1–4 war | Saisonwechsel |
| Trainer der Saison #N | Platz 1 der globalen Saisonrangliste (Saison-Score) | Saisonwechsel |
| Trainer der Liga #N | Platz 1 der Saisonrangliste innerhalb der eigenen Liga, mit Ligalogo am Titel | Saisonwechsel |

Datenbedarf: Bei Vereinsübernahme den Tabellenplatz zum Zeitpunkt der Übernahme speichern (Feuerwehrmann). Underdog prüft gegen die Präsidentenvorgabe (aus den Hintergrund-Stärken, nicht Marktwert).

## 3. Regeln

1. Freigeschaltete Titel gehören **dauerhaft dem Manager**, nicht dem Verein. Kein Entzug.
2. **Genau ein aktiver Titel**, frei oder freigeschaltet. Standard: **kein Titel**.
3. Abwahl über das Profil (kein „Kein Titel"-Button im Raster).
4. Titel steht überall, wo der Managername steht (Profil, Ligatabelle, Nachrichten). **Freigeschaltete Titel grün** (`#30f29c`), nicht gelb/gold.
5. Freischaltung wird **im Moment des Ereignisses** geprüft, mit Nachricht an den Manager.
6. „x % der Manager haben diesen Titel" — Basis: **alle existierenden Manager**. Nur für freischaltbare Titel.
7. Bedingungstext steht auf jeder freischaltbaren Karte.

## 4. Darstellung

- **Kasten „TITEL" auf der Profilseite:** links alle 13 freien Titel (zweispaltiges Buttongrid, aktiver Titel cyan gefüllt + Glow), rechts die **4 freischaltbaren mit dem höchsten Fortschritt**, freigeschaltete zuerst (grüner Rand + „✓ Freigeschaltet", sonst Fortschritt x/y + 4px-Progressbar). **Ohne Prozentzahl.**
- **„Alle ansehen":** Vollansicht mit allen 9 freischaltbaren Karten — Bedingungstext, Fortschrittsbalken und Prozentzahl je Karte.
- Prozentzahlen an den freien Titeln komplett entfernen.

## 5. XP-Werte korrigieren (Dummy-Werte ersetzen)

- **Login-Belohnungen:** Tag 1–7 = 5 · 10 · 15 · 20 · 25 · 30 · 50 XP, ab Tag 8 konstant 50. Tag 14 zusätzlich +100, Tag 30 zusätzlich +250 **und 1 Mio Spielgeld**. Die Kachel bei Streak 7 zeigt also „+50", nicht „+150". Serie reißt bei einem verpassten Tag, kein Joker.
- **Level-Kurve:** Level 2 kostet 800 XP, jedes weitere Level 100 XP mehr als das vorherige, kein Cap. Die KPI-Zelle MANAGERLEVEL zeigt echte Werte aus dieser Kurve statt „9.300 / 15.000".

## 6. Datenmodell (Django-Empfehlung)

- `ManagerTitle` (manager FK, title_key, unlocked_at) für freigeschaltete Titel; aktiver Titel als Feld am `ManagerProfile` (nullable = kein Titel).
- Fortschrittszähler je Manager (Serienmeister-Streak, Vereinszähler, Aufstiege) beim jeweiligen Ereignis fortschreiben; Prüfung + Benachrichtigung im Event-Handler des Prüfzeitpunkts.
- Prozentwerte serverseitig: Anzahl Manager mit Titel / alle Manager.

## Nicht anfassen

Sanktionssystem „Nicht aufgestellt" (2/5 Saison · 1/3 Folge), Urlaubsmodus, Saison-Score-KPI, Timeline, Vitrine, Tab Mannschaftsfotos — alles bleibt wie im Handoff. Einzige Ergänzung dort: **Unter dem Mannschaftsfoto die Namen der gezeigten Spieler anzeigen** (Reihenfolge wie im Bild, Reihe für Reihe).
