# Managerprofil, Inaktivitäts-Sanktion, Urlaubsmodus, Mannschaftsfotos — Konzeptstand

Stand: 28.08.2026 · **Entschieden.**

---

## Inaktivitäts-Sanktion („Nicht aufgestellt")

Zweck: Zu starke Inaktivität wird nicht geduldet, weil der Stärkemalus bei fehlender Aufstellung dem Verein schadet. Wer zu oft nicht aufstellt, ist offenbar inaktiv.

Zwei Zähler, beide im Profil-Kasten sichtbar („Saison 2/5 · in Folge 1/3"):

| Stufe | Auslöser | Folge |
|---|---|---|
| 1 | Jedes Pflichtspiel ohne eigene Aufstellung | Stärkemalus (bestehend) + Nachricht mit Zählerstand |
| 2 | 2 in Folge **oder** 3 in der Saison | Transfersperre bis zur nächsten eigenhändigen Aufstellung, Nachricht als letzte Warnung |
| 3 | 3 in Folge **oder** 5 in der Saison | Verein verloren, Eintrag in Karriere-Timeline als „Entlassung" |

- Folge-Zähler setzt bei jeder eigenen Aufstellung auf 0.
- Saisonzähler und Folge-Zähler setzen beim Saisonwechsel auf 0.
- Im Urlaubsmodus laufen beide Zähler nicht.

## Urlaubsmodus

Ort: Sicherheit & Einstellungen, Eintrag per Kalender.

- Budget: **14 Tage pro Saison**, aufteilbar in **max. 2 Blöcke à mindestens 5 Tage**.
- Muss **vor Beginn** eingetragen werden. Rückwirkend unmöglich (Spiel mit Malus ist bereits gespielt).
- Während des Blocks: kein Stärkemalus, Zähler laufen nicht. Die Aufstellung übernimmt das Spiel automatisch — **mitarbeiterunabhängig**, kein Co-Trainer nötig.
- Ein laufender Block kann vorzeitig beendet werden; Resttage bleiben erhalten, solange der zweite Block noch frei ist.

## Karriere-Timeline

- „Eintrag einreichen / Anträge / Admin" gilt **nur für manuelle Einträge**.
- Reguläre Ereignisse (Amtsantritt, Titel, Beförderung, Entlassung) kommen **automatisch aus dem Spiel**.

## Tab „Mannschaftsfotos"

Dritter Tab, zwischen Profil und Sicherheit & Einstellungen. **Heißt bewusst NICHT „Jahrbuch"** — der Begriff ist für eine spätere Saisonzusammenfassung reserviert.

- Saisonale **Momentaufnahme des 1. Kaders** als generiertes Teamfoto, erstellt **1× pro Saison zum Stichtag (1. Pflichtspieltag)**, gecacht.
- **Unter dem Foto: die Namen der gezeigten Spieler** (Reihe für Reihe, in Bildreihenfolge). Sonst wie im Design-Handoff abgenommen.

## Sonstiges

- „Manager-Duell" entfällt als eigener Ort; Vergleiche/Ranglisten später im Datencenter. Titel steht überall, wo der Managername steht.
- FC Porto ist eine reine Demo-Station (Ko-Fi/X), kein echter Inhalt.
- 2FA und IP-Listen (gegen Mehrfachvereine über dieselbe IP) separat; Geräteübersicht nicht erforderlich.
