# Titel & Auszeichnungen — Konzeptstand

Stand: 27.08.2026 · **Regeln entschieden.**

---

## Kernidee

Der Titel ist selbst die Auszeichnung. Es gibt keine Zwischenstufe „Auszeichnung schaltet Titel frei" mehr. Zwei Sorten: **frei wählbar** (Charakter) und **freischaltbar** (erspielt, mit Bedingung).

---

## Freischaltbare Titel (9)

| Titel | Bedingung | Prüfzeitpunkt |
|---|---|---|
| Pokaljäger | Erster Pokalsieg (nur Pokal, keine Meisterschaft) | Nach dem Pokalfinale |
| Serienmeister | 3 Meisterschaften in Folge — Balken setzt bei Saison ohne Titel auf 0/3 zurück | Saisonwechsel |
| Talentschmied | Ein Jugendspieler wurde zu den Profis verschoben | Bei der Kaderverschiebung |
| Weltenbummler | 3. Verein übernommen | Beim Vereinswechsel |
| Aufstiegsheld | Ein Aufstieg mit einer Mannschaft | Saisonwechsel |
| Feuerwehrmann | Verein **während der laufenden Saison** (ab Spieltag 1) auf einem Abstiegsplatz übernommen und Klassenerhalt am Saisonende | Saisonwechsel |
| Underdog | Meister mit einem Verein, dessen Saisonvorgabe des Präsidenten **nicht Platz 1–4** war | Saisonwechsel |
| Trainer der Saison #N | Platz 1 der globalen Saisonrangliste (Saison-Score) | Saisonwechsel |
| Trainer der Liga #N + Ligalogo | Platz 1 der Saisonrangliste innerhalb der eigenen Liga | Saisonwechsel |

Datenbedarf: Bei Vereinsübernahme den **Tabellenplatz zum Zeitpunkt der Übernahme** speichern (für Feuerwehrmann). Die Präsidentenvorgabe (aus den Hintergrund-Stärken, nicht Marktwert) existiert für die Liga bereits und wird für Underdog gegengeprüft.

Später können weitere freischaltbare Titel ergänzt werden.

## Frei wählbare Titel (13)

Quälix · Laptoptrainer · Taktikfuchs · Motivator · Kettenraucher · Zampano · Schleifer · Schlitzohr · Konzepttrainer · Grantler · Malocher · Menschenfänger · Schönwetter-Trainer

Gestrichen: Transferstratege, Offensivarchitekt, Underdog-Flüsterer (→ Underdog, freischaltbar), Konterkönig, Pokalheld (Zwischenstufe entfällt).

---

## Regeln

| # | Thema | Entscheidung |
|---|---|---|
| 1 | Besitz | Freigeschaltete Titel gehören **dauerhaft dem Manager**, nicht dem Verein. Kein Entzug |
| 2 | Aktiver Titel | **Genau einer**, frei oder freigeschaltet. Standard: **kein Titel** |
| 3 | Abwahl | Über das Profil, kein „Kein Titel"-Button im Raster |
| 4 | Sichtbarkeit | Überall wo der Managername steht (Profil, Ligatabelle, Nachrichten). Freigeschaltete Titel farblich abgesetzt (Grün) |
| 5 | Prüfung | **Im Moment des Ereignisses**, mit Nachricht an den Manager |
| 6 | Vergleich | Je freischaltbarem Titel: „x % der Manager haben diesen Titel" — Basis **alle existierenden Manager**, keine Unterscheidung aktiv/inaktiv |
| 7 | Rückwirkend | Entfällt — Spiel läuft noch nicht, alle starten bei 0 |
| 8 | Bedingungstext | Steht auf jeder Karte |

## Darstellung

- **Kasten auf der Seite:** links alle 13 freien Titel (zweispaltig), rechts die **4 freischaltbaren mit dem höchsten Fortschritt**, freigeschaltete zuerst. Ohne Prozentzahl.
- **„Alle ansehen":** Vollansicht mit allen 9 Karten, Bedingung, Fortschrittsbalken und Prozentzahl.

## Badges

**Badges gibt es nicht** (entschieden 27.08.). Der Kasten heißt nur noch „Titel".
