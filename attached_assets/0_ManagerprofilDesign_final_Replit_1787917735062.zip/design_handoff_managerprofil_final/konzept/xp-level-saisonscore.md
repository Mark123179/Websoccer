# XP, Managerlevel, Saison-Score, Login-Serie — Konzeptstand

Stand: 27.08.2026 · **Regeln entschieden, Startwerte simuliert.**

---

## Kernidee

**Der Highscore wird gestrichen.** Eine einzige Währung: XP. Daraus zwei Sichten:

- **Managerlevel** = Gesamt-XP, nur steigend. Misst Fleiß und Durchhaltevermögen. Fair über Vereinsstärke (Simulation: täglicher Manager ~7.700 XP/Saison, egal ob stark oder schwach).
- **Saison-Score** = nur Leistung gegen die Präsidentenvorgabe. Setzt sich jede Saison zurück. **Keine Aktivitätspunkte** — einzige Ausnahme: Aufstellungs-XP.

**Badges gibt es nicht** (entschieden 27.08.). Der Kasten heißt nur noch „Titel".

---

## XP-Quellen (Startwerte)

| Quelle | XP | Deckel | Level | Saison-Score |
|---|---|---|---|---|
| Login Tag 1–7 | 5 · 10 · 15 · 20 · 25 · 30 · 50 | ab Tag 8 konstant 50 | ✓ | — |
| Login Tag 14 / 30 | +100 / +250, Tag 30 zusätzlich **1 Mio Spielgeld** | je Serie | ✓ | — |
| Aufstellung abgegeben | 10 | einmal je Pflichtspiel | ✓ | ✓ |
| Pflichtspiel Niederlage / Remis / Sieg | 10 / 20 / 30 | — | ✓ | — |
| Forumsbeitrag | 5 | einmal pro Tag, ab 10 Zeichen | ✓ | — |
| Vereinsnews | 50 | einmal pro Woche, ab 100 Zeichen | ✓ | — |
| Reaktion auf Nachricht | 1 | max. 10 pro Tag | ✓ | — |
| Saisonziel erreicht | 500 | je Wettbewerb mit Vorgabe | ✓ | ✓ |
| je Platz/Runde über Vorgabe | +150, max. +2 | je Wettbewerb | ✓ | ✓ |
| 1 / 2 Plätze unter Vorgabe | 300 / 150, darunter 0 — **nie Abzug** | je Wettbewerb | ✓ | ✓ |
| Titel (Meister, Pokal, international) / Aufstieg | +300 | — | ✓ | ✓ |
| Trainer der Saison Top 10 global | 1000 · 800 · 600 · 500 · 400 · 300 · 250 · 200 · 150 · 100 | — | ✓ | — |
| Trainer der Liga Top 3 | 500 · 300 · 150 | je Liga | ✓ | — |

Login-Serie: **reißt bei einem verpassten Tag, kein Joker.**
Transfers, Training, Stadionausbau, Sponsoren, Mitarbeiter: **keine XP** (geldabhängig oder farmbar).
Likes/Antworten anderer: keine XP-Quelle.

## Präsidentenvorgabe

Basis für den Saison-Score. Heute nur Ligaplatz; **wird um Pokalrunde und internationale Runde erweitert**, abgeleitet aus der Hintergrund-Stärke (nicht Marktwert). Jeder Verein hat damit 2–3 Wettbewerbe, in denen er ±2 Schritte gegen seine Vorgabe machen kann.

## Saisonende

- **Trainer der Saison #N** — Platz 1 global (freischaltbarer Titel). Top 10 global bekommen XP-Bonus.
- **Trainer der Liga #N** + Ligalogo — Platz 1 je Liga (freischaltbarer Titel). Top 3 je Liga bekommen XP-Bonus.
- Ein Manager kann beide in einer Saison holen. Rangliste ist global, die Vorgabe normiert über Ligen.

## Level-Kurve

Level 2 kostet 800 XP, jedes weitere Level 100 XP mehr als das vorherige. Kein Cap.

| Level | XP gesamt | Täglicher | Regelmäßiger (~4 Tage/Woche) |
|---|---|---|---|
| 5 | 3.200 | Saison 1 | Saison 2 |
| 10 | 10.800 | Saison 2 | Saison 4 |
| 20 | 32.300 | ~1 Jahr | ~3 Jahre |
| 30 | 63.800 | ~2 Jahre | ~5 Jahre |
| 50 | 157.000 | ~5 Jahre | — |

## Umsetzungsreihenfolge (Vorschlag)

1. Titel-System (hängt an nichts)
2. Präsidentenvorgabe um Pokal/Europa erweitern
3. XP, Level, Login-Serie
4. Saison-Score und Saisonende-Auswertung
