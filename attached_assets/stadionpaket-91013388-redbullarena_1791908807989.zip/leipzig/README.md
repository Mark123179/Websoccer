# Red Bull Arena · RB Leipzig (FMI 91013388) — Fassung 1

Stand 13.10.2026 · Quelle `rbleipzig.bundle` (FM26 Stadium Megapack v3.0, 502 MB, SHA-256 `04c724110764053a3925ecc2dff6fbccdd8ab88eab14ddd31957929d24c3d3fe`) + `rbleipzig.json` (Sitzplätze), `_lightmaps.json`, `_lightprobes.json`.
assetVersion **`1c7f77b0c94aa077`**, geometrySha256 `49e7f07ba73d4ea7d7aa058196f805d439ad0d8d9a6e1ed5321964868f66db91`, 337 Meshes (425.432 Dreiecke), 120 Texturen, **121 Assets**, 20,25 MB, 142 quellgeprüfte Leuchten → 12 Laufzeitleuchten. Keine Live-Registrierung vorhanden; keine lokale Vereins-/Stadion-ID im Paket (Identität nur `clubFmiId 91013388`, Zuordnung macht die Registry).
**Voraussetzung:** Renderer-Patch `surroundingsAxes` aus dem Frankfurt-Paket Fassung 2 (liegt unter `patch/` nochmals bei). Ohne Patch registriert das Manifest, zeigt aber die Ortsplan-Enden vertauscht.

## Befund in einem Satz
Das Bundle ist ein vollständiges Stadtmodell: 939 Meshes, davon 428 Figuren/Requisiten (`SCARECROW`), 164 Kulissen-Meshes (Leipziger Stadt, Wall des alten Zentralstadions mit Brücken, Glow-Effekte; 4,2 Mio. Vertices) und 337 Stadion-Meshes — nur diese werden exportiert, per **gezielter Exportauswahl mit exakten Namen**; Choreo-/Event-Objekte gibt es nicht, die Fernkulisse ersetzt der Ortsplan.

## Vorgehen
1. Inventur aller 939 Meshes (`quellbelege/inventar_alle.json`: Wurzel, Pfad, Renderer-Status, GameObject-Aktivität, LOD (keine), Material, Textur-Alpha, Blend-Modus); Ausdehnungsanalyse gegen den Blaupausen-Umriss (x −104…109 / y −115…121 m).
2. Ausschluss mit **exakten Meshnamen** (`ausschluss_bericht.json`, 164 Einträge mit Hierarchie/Lage/Material): 155 Fernkulisse (`front1_demo_*` OSM-Stadt bis ±3,1 km, `center1_1x–3x.001` Wall-Gelände `Material.004` bis ±530 m, `map_2.osm_buildings.*`, `left2_nf_nr_*`, `st063_bg_floor001_3`), 9 Wall-/Brückenteile über 130 m (`center2_1` Grasring, `center1_58/58.002/147/149/155`, `concrete_bare_06_clean_2mx2m.005`, `front1_probe_5.001`, `MESH_st009_bg_audi001` Publikumsring auf dem Wall), 5 Glow-Effektflächen (`GLOW.002/.005`, `tunnel_glow_nf_lights.001`, `center2_probe_7.001/.002` — emissive FM-Nachteffekte, im Spielrenderer gelbe Flächen). `AD` (Banden/Banner) und `SCARECROW` nicht übernommen; `EXTRA` nur für die Glasdachstreifen `roof.001`.
3. Dachschalter nach Gruppen- und Einzelisolierung im Spielrenderer (`bilder/isolation/`: 196 Einzelbilder als 10 Blätter, Gruppenblatt Dach/Körper aus drei Winkeln, Ein-/Ausblend-Differenzblatt für Sonderfälle, Dachstützenblatt).
4. Bodenregeln (Heuristik → Sichtprüfung → `boden_91013388.json`), Ortsplan-Abgleich gegen OSM, Ansichten.

## Dachschalter
`roofMinHeight 15`, `roofMeshPrefixes` (23 Einträge, Volltext in `kalibrierung.json`): Membran `front3_*` (51) + `back3_0/1`, Glasstreifen `roof.001`, Flutlichtzeilen am Dachrand (`SL_Right_Light*`, `MESH_back3.002`, `MESH_front1_detail*`, `center3_probe_6`), Red-Bull-Dachbanner `Plane.013/.014` und Dachlogo Süd `passege_st002_50` (liegen auf dem Dach), **Videotafeln `MESH_ROOT.001`** (zwei Flächen an beiden Enden, y 21–28 m — Dachzustand-Regel aus dem Frankfurt-Review, 4/4 Dreiecke Dach), TV-/Pressekabine auf dem Haupttribünendach (`concrete_painted_mat_black`, `metal_painted_01_clean_1mx1m_black.003`, `parallax_broadcaster_mat`, `center1_101/102/103/104/112/114/115/117/119`), Dachstützen/Masten an den Enden (`front3_0`, `front3_1`, `front3_1.001`, ab 16 m — wie die Pylone in Leverkusen).
Nachrechnung über das Binary (`quellbelege/nachweise.json`): **Dachliste 94.813 / 94.813 Dreiecke Dach; Tribünen `center1_*` 0 / 214.476, übriger Körper 0 / 107.184, Boden 0 / 4.003, Crowd 0 / 338, Spielfeld 0 / 4.618**; kein Dachlisten-Mesh hat Dreiecke unter 15 m. Sichtprüfung: Dach aus zeigt alle Ränge, Oberrang-Rückwände, Sitzmosaik „RBL" und Gästeblock-Ecke vollständig (`bilder/02b`, `07`, `09`).

## Ortsplan und Achsen
- OSM-Abgleich (`quellbelege/umfeld_pruefung.json`): Quarterback-Arena (SO), Sportforum-Hauptgebäude (O), Fanshop (O), RB-Trainingszentrum (SW), Lauf-Halle (N) treffen die bg-Gebäude auf 4–32 m; Elsterbecken liegt im Ortsplan östlich → nordorientierte, nicht gespiegelte Karte; `axisTheta 110°` → Spielfeld +X = NNW (Stadion 230 m N–S × 210 m O–W laut Betreiber ✔).
- Blaupause (öffentlicher live-scene): **WEST = VIP-Blöcke** (Haupttribüne, WSW-Seite), **SUED = Stehplätze** (Heimblock Sektor B, SSO-Ende), OST = Gegengerade, NORD = Gästeblock-Ende (offizielle Sektorenfolge A/B/C/D). Modell: VIP-Interieur (`st042_*`, `st046_*`, `cm0*`), Dugout-Glas und Bänke bei −x → WEST; Stehplatz-Handläufe `right2_2/3/4` (`st011_hndr200`) bei +z → SUED; Gästeblock-Käfig (Netz `right1_probe_1`, Pfosten `right1_probe_0/.001`, Gitter `metal_galvanized_clean_1mx1m.004`, Glas `Glass.001`) in der Ecke +x/−z → OST/NORD ✔.
- `standAxes {+x OST, −x WEST, +z SUED, −z NORD}`, `surroundingsAxes {NORD: −z, WEST: −x}` (Längsachse wie Frankfurt gegenüber Bayern/Leverkusen gespiegelt). Beleg `bilder/umfeld-ausrichtung.jpg`: alter Adapter (Enden vertauscht) vs. Patch (alle vier Seiten passend). Ticker-Kamera gemeinsam (`tickerRotationY −90`, Bänke bei −x), `tickerFrontCut (1,0,0)/32`, Orbit 0,95/0,65/340.

## Bodenregeln (`boden_91013388.json`, Re-Export deterministisch)
Transparent 2 (`field_1` Markierung, `field_0` Coach-Linien); **Rasenangleichung 2** (`field_9`, `center1_0` — `st066_turf001`-Unterlagen im Spielfeldbereich → Spielfeldtextur + `uvProjection` aus `st081_pitch_0`, Bayern-Regel); transluzent 14 (Glasfronten `glass_mat.*`, Dugout-/Logenglas, Fensterrahmen 21–35 % Deckung); Alpha-Schnitt 35 (Seilnetz, Laufstege, Geländer, Handläufe, Fangnetz, Flutlicht-`basic`); unsichtbar 0.

## Sichtprüfung
`bilder/leipzig-ansichten.jpg` (zentraler Renderer, 3D 1000×560, Ticker 1000×500): Editor Dach an/aus, Ticker Dach an/aus, Ticker Nacht + Flutlicht, Draufsicht Dach an/aus, Dach aus von der Gegenseite. Spielfeld per Replits `pitch_validation`: **105,000 × 68,000 m** (`st081_pitch_1`, 000STADIUMLINE), zentriert, Geometrie-SHA = Manifest. Befunde: Dachbanner/Logo nur mit Dach sichtbar; Flutlicht aus den Dachrand-Leuchten (`light_fixture`, `st052_lght`, `st022_lght`); gelber Fleck in der OST/SUED-Ecke des Oberrangs = **Stern des Sitzmosaiks „RBL"** (Quelltextur `audi_seat_mat`, kein Fehler); Spielfeld-Rasentextur heißt in der Quelle `0002-Mainz` (generischer Rasen, Linien separat).

## Offene Entscheidungen (deine)
1. **Gästeblock-Netz** (`right1_probe_1`, 37–48 m hoch, Ecke OST/NORD, im Ticker links oben als dünnes Netz sichtbar, 0,15 % Pixel): Es steht nicht hinter dem Tor, sondern vor dem Gästesektor — Empfehlung **behalten** (reales Merkmal). Alternative: `skipMeshPrefixes ["right1_probe_"]` (Netz + Pfosten), Assets unverändert, Manifest neu.
2. **Wall und Brücken des Zentralstadions**: ausgeschlossen (Ortsplan zeigt den Wallring als Grünfläche, die Brückenstummel würden ohne Wall in der Luft enden, Wall-Gelände 300 k Dreiecke). Empfehlung so lassen. Alternative: Wall-Gelände `center1_1x–3x.001` + `center2_1` per Namensliste wieder aufnehmen (kollidiert mit dem flachen Ortsplan).
3. **Videotafeln** `MESH_ROOT.001` auf der Dachliste (Regel); in beiden Ansichten 0 Pixel sichtbar — kein Handlungsbedarf.

## Einspielen
1. Frankfurt-Patch integriert (`patch/README-PATCH.md`).
2. `scp -r stadium-models/91013388 root@49.13.5.151:/var/www/assets/stadium-models/`
3. `models/91013388.json` nach `stadium_editor/blueprints/v2/models/`, committen, pushen, `/push`.
4. `docker exec websoccer-web-1 python manage.py check_stadium_model --fmi 91013388 --assets` → `Assets OK: 121 Dateien`.
5. Abnahme im Livemodus des Vereins mit FMI 91013388: fünf Ansichten + Draufsicht, Umfeld (Sportforum-Gebäude an der OST-Seite, Trainingszentrum an der SUED/WEST-Ecke).

## Reproduktion
```sh
python3 -I werkzeuge/export_stadium_model.py --bundle rbleipzig.bundle --seats rbleipzig.json --fmi 91013388 --name "Red Bull Arena" \
  --out export --calibration kalibrierung.json --roots EXTRA --lamp-materials light_fixture,st052_lght,st022_lght \
  --ground boden_91013388.json --exclude-meshes "$(cat ausschluss_namen.txt)"
#  → assetVersion 1c7f77b0c94aa077
python3 -I werkzeuge/roof_inventory.py rbleipzig.bundle -100 inventar_alle.json
python3 -I werkzeuge/isolate.py export/manifest.json only_x.json only '^front3_1$'     # Harness &m=…
```
