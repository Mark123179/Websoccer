# Umfeld-Paket Dortmund (für Replit-Ticket #1055, Schritt „Geografische Merkmale ergänzen")

**Datei:** `osm/dortmund_umfeld.json` · **Quelle:** OpenStreetMap, `api.openstreetmap.org/api/0.6/map`, bbox 7.4422,51.4866,7.4612,51.4986 · **Stand:** 07.10.2026 · **Lizenz:** ODbL 1.0 — „© OpenStreetMap contributors" muss in der Ansicht oder im Impressum stehen.
Dieselben Daten hängen additiv in `scenes/bvb_v2.json` unter `surroundings.*` (Felder unten). Keine Live-Abfrage nötig.

## Koordinatenrahmen
Feldsystem wie `websoccer.stadium-live-scene` v1: Ursprung Feldmitte, +X Tor→Tor, +Y Seitenlinie→Seitenlinie, Meter.
`meta.frame`: `lat0/lon0` (OSM-Referenzpunkt), `pitchCenterLocal`, `thetaDeg` (Drehung der Feldachse), `northVector` = [-0.99, 0.139] → **Norden ≈ −X, Osten ≈ +Y**.
Kamera/Haupttribüne (WEST) liegt auf **−Y**; die Gegentribüne (OST) auf +Y. Hinter der Osttribüne folgen Stadion Rote Erde (Fußballplatz bei y≈164), Laufbahnen (y≈300), Helmut-Körnig-Halle (−96, 318) und 28.000 m² Parkfläche — keine Baumwand.

## Inhalt (alle Koordinaten in m, Polygone als `[[x,y],…]`)
| Feld | Anzahl | Bedeutung | Tags |
|---|---|---|---|
| `parking` | 20 | `amenity=parking` Flächen (surface/street_side; Parkhäuser/Dächer ausgeschlossen) | `parking`, `surface`, `capacity`, `access`, `name` |
| `trees` | 334 | **einzeln kartierte Bäume** `natural=tree`, Punkt `p` | `genus`/`species`/`height` wo vorhanden (hier: keine) |
| `treeRows` | 0 | `natural=tree_row` Linien | — |
| `forest` | 2 | Wald (`landuse=forest`/`natural=wood`), inkl. Multipolygon-Außenringe | `leaf_type` |
| `scrub` | 17 | Gebüsch `natural=scrub` | — |
| `grass` | 57 | Rasen/Wiese/Beet/Park (`kind`) | — |
| `sports` | 15 | Sportplätze, Laufbahnen, Tribünenbänke (`kind`, `sport`) — u. a. Rote Erde | `surface`, `name` |
| `water` | 1 | Gewässer | — |
| `landuse` | 7 | Kleingärten, Gewerbe, Bahn … (`kind`) | — |
| `buildingsTagged` | 20 | Gebäude mit Zusatzmerkmalen oder Typ (Messehallen, Hotel, Hallen) | `building`, `building:levels`, `roof:shape`, `name` … |

**Ausgeschlossen:** alles innerhalb der Tribünen-Bbox + 10 m (außer Parkflächen), Radius 420 m um die Feldmitte.

## Regeln für die Darstellung (aus dem Ticket, präzisiert)
- Bäume: zuerst die 334 kartierten Einzelbäume **exakt** setzen; in `forest`/`scrub` Repräsentanten deterministisch (Seed) nach Dichte des Flächentyps; in `grass` nichts erfinden.
- Autos: nur in `parking` (Typ `surface`), in Reihen entlang der längsten Polygonkante, 2,5 × 5 m Raster, 60–80 % Belegung mit Seed, Fahrgasse alle 2 Reihen, Bäume der Parkfläche freihalten (Kreis 2,5 m).
- Boden: `parking` → aerial_asphalt_01; `grass`/`sports`(pitch) → aerial_grass_rock/grass_ground; `sports`(track) → Tartanfarbe; alles Übrige neutraler Boden — keine Pflasterfläche ohne Nachweis.
- Gebäude: `buildingsTagged` liefert Typ/Geschosse; Messehallen = große Hallen (Wellblech/Putz als Annäherung kennzeichnen). Fassadenmaterial ist in OSM hier praktisch nicht gepflegt (1 von 804) — also neutral und als Annäherung.
- Spiegelung prüfen, **bevor** Umfeld und Modell zusammenkommen: Südtribüne (Stehrang, +X) muss auf der Seite liegen, die vom `northVector` weg zeigt; Westtribüne auf −Y. Stimmt das nicht, `model.mirror: true` in der Kalibrierung setzen — das ist ein Parameter, keine Modelländerung.

## Erweiterung des Paketschemas (Vorschlag)
`surroundings.sourceDetail` (Quelle, bbox, Datum, Lizenz, Rahmen) + die Felder oben. Für weitere Stadien denselben Export mit demselben Rahmen (Feldmitte, Feldachse) fahren; Skript `umfeld_build.py` liegt bei.
