# Asset-Manifest · natürliches Stadionumfeld (Ticket #1055)

Geprüft am 2026-10-07 über die öffentlichen APIs von Sketchfab und Poly Haven. Zahlen sind Anbieterangaben.

## Sketchfab (CC BY 4.0, Download mit kostenlosem Konto)

| Rolle | Modell | Autor | Lizenz | Faces | Texturen | Downloads | Link |
|---|---|---|---|---|---|---|---|
| Laubbäume, 7 Varianten (Hauptbestand) | Realistic Trees Collection | Jungle Jim | CC Attribution (by) | 127.660 | 21 | 12.831 | [fe67c886](https://sketchfab.com/3d-models/fe67c886eebf4bcb988d7c45e69995ad) |
| Birke/Eiche/Ahorn/Obstbäume/Sträucher (Variation) | Various Forest Assets Pack | Dari | CC Attribution (by) | 130.495 | 35 | 12.462 | [cf138b8e](https://sketchfab.com/3d-models/cf138b8eb2d340cda643ed59f824989c) |
| Eichen, sehr leicht (Fernstufe/Mobil) | oak trees | DJMaesen | CC Attribution (by) | 14.475 | 8 | 75.464 | [d841c3bc](https://sketchfab.com/3d-models/d841c3bcc5324daebee50f45619e05fc) |
| Fiktive Pkw für Parkflächen | Generic passenger car pack | Comrade1280 | CC Attribution (by) | 69.312 | 57 | 79.739 | [20f9af9b](https://sketchfab.com/3d-models/20f9af9b8a404d5cb022ac6fe87f21f5) |

## Poly Haven (CC0)

| Rolle | Asset | Auflösungen | Link |
|---|---|---|---|
| HDRI Tag (bevorzugt) | Kloofendal 48d Partly Cloudy (Pure Sky) | 1k, 2k, 4k, 8k, 16k | [kloofendal_48d_partly_cloudy_puresky](https://polyhaven.com/a/kloofendal_48d_partly_cloudy_puresky) |
| HDRI Tag (Alternative, lange Schatten) | Qwantani Afternoon (Pure Sky) | 1k, 2k, 4k, 8k, 16k, 24k | [qwantani_afternoon_puresky](https://polyhaven.com/a/qwantani_afternoon_puresky) |
| HDRI Abend/Flutlicht (bevorzugt) | Kloppenheim 07 (Pure Sky) | 1k, 2k, 4k, 8k, 16k, 24k | [kloppenheim_07_puresky](https://polyhaven.com/a/kloppenheim_07_puresky) |
| HDRI Nacht (Alternative) | Qwantani Night (Pure Sky) | 1k, 2k, 4k, 8k, 16k, 24k | [qwantani_night_puresky](https://polyhaven.com/a/qwantani_night_puresky) |
| Boden Grün, Fernansicht | Aerial Grass Rock | 1k, 2k, 4k, 8k | [aerial_grass_rock](https://polyhaven.com/a/aerial_grass_rock) |
| Boden Grün, mittlere Distanz | Grass Ground | 1k, 2k, 4k, 8k, 16k | [grass_ground](https://polyhaven.com/a/grass_ground) |
| Boden Vorplatz/Parkplatz | Aerial Asphalt 01 | 1k, 2k, 4k, 8k | [aerial_asphalt_01](https://polyhaven.com/a/aerial_asphalt_01) |
| Fassade Ziegel | Brick Wall 02 | 1k, 2k, 4k, 8k | [brick_wall_02](https://polyhaven.com/a/brick_wall_02) |
| Strauch (nur bei Nachweis) | Shrub 03 | 1k, 2k, 4k | [shrub_03](https://polyhaven.com/a/shrub_03) |

## Bibliotheken

- @three.ez/instanced-mesh — 0.3.16 MIT
- three — 0.186.1 MIT
- meshoptimizer — 1.3.0 MIT
- agargaro/octahedral-impostor —  MIT (laut Repo) WIP — als Vorlage für Impostor-Baking, nicht als Blackbox

## Hinweise

- Sketchfab-Downloads setzen ein kostenloses Konto voraus (Web-Download oder Download-API mit Token). Format glTF wählen.
- CC-BY 4.0: Autor + Titel + Lizenzlink + Änderungsvermerk in Credits/Impressum. Vorlage: "<Titel>" von <Autor> (sketchfab.com/…), lizenziert unter CC BY 4.0, bearbeitet (Dezimierung, Impostor-Baking).
- Poly Haven CC0: keine Pflichten; Nennung erwünscht.
- Texturen für den Browser auf 1k–2k begrenzen und als KTX2/Basis komprimieren; Fahrzeugpaket (57 Texturen) auf 1–2 Atlanten zusammenführen.
- OSM-Daten (dortmund_umfeld.json): ODbL — Quellenangabe "© OpenStreetMap contributors" in der Ansicht oder im Impressum; getrennt von der Grafikbibliothek führen.