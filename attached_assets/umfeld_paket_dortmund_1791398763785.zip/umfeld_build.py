import sys, json, math, xml.etree.ElementTree as ET
sys.path.insert(0, '/home/claude/stage')
from shapely.geometry import Polygon, Point, LineString
from blueprint_v2 import to_m, OSM
j = json.load(open(OSM / 'dortmund.json')); els = j['elements']
stad = next(e for e in els if e.get('tags', {}).get('leisure') == 'stadium')
ref = stad['geometry'][0]; lat0, lon0 = ref['lat'], ref['lon']
P = lambda geom: [to_m(g['lat'], g['lon'], lat0, lon0) for g in geom]
outline = Polygon(P(stad['geometry']))
pitches = [e for e in els if e['type'] == 'way' and e.get('tags', {}).get('leisure') == 'pitch' and e['tags'].get('sport') == 'soccer']
pitch = min(pitches, key=lambda e: Polygon(P(e['geometry'])).centroid.distance(outline.centroid))
pp = P(pitch['geometry']); pp = pp[:-1] if pp[0] == pp[-1] else pp
cx = sum(p[0] for p in pp) / len(pp); cy = sum(p[1] for p in pp) / len(pp)
L, th = max(((math.hypot(b[0]-a[0], b[1]-a[1]), math.atan2(b[1]-a[1], b[0]-a[0])) for a, b in zip(pp, pp[1:] + pp[:1])), key=lambda t: t[0])
cs, sn = math.cos(-th), math.sin(-th)
def rot(p): return ((p[0]-cx)*cs - (p[1]-cy)*sn, (p[0]-cx)*sn + (p[1]-cy)*cs)
def ll2xy(lat, lon): return rot(to_m(lat, lon, lat0, lon0))
north = rot((cx, cy + 1))
print('frame: lat0 lon0', lat0, lon0, 'pitch c', round(cx,1), round(cy,1), 'theta deg', round(math.degrees(th),2), 'north vec', [round(v,3) for v in north])
root = ET.parse(sys.argv[1]).getroot()
nodes = {}; ntags = {}
for n in root.iter('node'):
    nodes[n.get('id')] = (float(n.get('lat')), float(n.get('lon')))
    t = {tg.get('k'): tg.get('v') for tg in n.findall('tag')}
    if t: ntags[n.get('id')] = t
ways = {}
for w in root.iter('way'):
    ways[w.get('id')] = ({tg.get('k'): tg.get('v') for tg in w.findall('tag')}, [nd.get('ref') for nd in w.findall('nd')])
rels = [(r.get('id'), {tg.get('k'): tg.get('v') for tg in r.findall('tag')}, [(m.get('type'), m.get('ref'), m.get('role')) for m in r.findall('member')]) for r in root.iter('relation')]
R = 420
def xy_of(nds):
    pts = [ll2xy(*nodes[n]) for n in nds if n in nodes]; return [[round(x,1), round(y,1)] for x, y in pts]
def near(pts): return any(math.hypot(x, y) < R for x, y in pts)
def keep(t, keys): return {k: t[k] for k in keys if k in t}
out = {'parking': [], 'trees': [], 'treeRows': [], 'forest': [], 'scrub': [], 'grass': [], 'water': [], 'buildingsTagged': [], 'landuse': [], 'sports': []}
stands_bbox = Polygon([(-114.7,-95.9),(118.6,-95.9),(118.6,95.9),(-114.7,95.9)]).buffer(10)
for wid, (t, nds) in ways.items():
    if len(nds) < 2: continue
    pts = xy_of(nds)
    if not pts or not near(pts): continue
    closed = nds[0] == nds[-1] and len(pts) >= 4
    poly = Polygon(pts) if closed else None
    if poly is not None and (not poly.is_valid or poly.intersects(stands_bbox)):
        if t.get('amenity') != 'parking': continue
    if t.get('amenity') == 'parking' and poly is not None and t.get('parking') not in ('multi-storey', 'rooftop', 'underground'):
        out['parking'].append({'id': int(wid), 'poly': pts, **keep(t, ['parking', 'surface', 'capacity', 'access', 'name'])})
    elif t.get('natural') == 'tree_row':
        out['treeRows'].append({'id': int(wid), 'line': pts, **keep(t, ['genus', 'species', 'leaf_type'])})
    elif poly is not None and (t.get('landuse') == 'forest' or t.get('natural') == 'wood'):
        out['forest'].append({'id': int(wid), 'poly': pts, **keep(t, ['leaf_type', 'leaf_cycle', 'genus'])})
    elif poly is not None and t.get('natural') == 'scrub':
        out['scrub'].append({'id': int(wid), 'poly': pts})
    elif poly is not None and (t.get('landuse') in ('grass', 'meadow', 'flowerbed') or t.get('natural') == 'grassland' or t.get('leisure') in ('park', 'garden')):
        out['grass'].append({'id': int(wid), 'poly': pts, 'kind': t.get('landuse') or t.get('natural') or t.get('leisure')})
    elif poly is not None and (t.get('leisure') in ('pitch', 'track', 'stadium', 'sports_centre', 'bleachers')):
        out['sports'].append({'id': int(wid), 'poly': pts, 'kind': t['leisure'], **keep(t, ['sport', 'surface', 'name'])})
    elif poly is not None and t.get('natural') == 'water':
        out['water'].append({'id': int(wid), 'poly': pts})
    elif poly is not None and t.get('landuse') in ('allotments', 'commercial', 'residential', 'railway', 'construction', 'industrial', 'retail'):
        out['landuse'].append({'id': int(wid), 'poly': pts, 'kind': t['landuse']})
    if 'building' in t and poly is not None:
        attrs = keep(t, ['building', 'building:levels', 'building:material', 'building:colour', 'roof:shape', 'roof:material', 'roof:colour', 'height', 'name'])
        rich = any(k in attrs for k in ('building:levels','building:material','building:colour','roof:shape','roof:material','roof:colour','height','name'))
        if rich or t.get('building') in ('civic','public','retail','train_station','sports_centre','stadium','grandstand','garages','commercial','industrial','warehouse','office','hotel','school'):
            out['buildingsTagged'].append({'id': int(wid), 'poly': pts, **attrs})
for nid, t in ntags.items():
    if t.get('natural') == 'tree' and nid in nodes:
        x, y = ll2xy(*nodes[nid])
        if math.hypot(x, y) < R and not stands_bbox.contains(Point(x, y)):
            out['trees'].append({'id': int(nid), 'p': [round(x,1), round(y,1)], **keep(t, ['genus', 'species', 'leaf_type', 'height', 'circumference', 'diameter_crown'])})
for rid, t, ms in rels:
    kind = 'forest' if (t.get('landuse') == 'forest' or t.get('natural') == 'wood') else ('grass' if t.get('landuse') in ('grass','meadow') or t.get('leisure') == 'park' else None)
    if not kind: continue
    for mt, mref, role in ms:
        if mt == 'way' and role == 'outer' and mref in ways:
            pts = xy_of(ways[mref][1])
            if len(pts) >= 4 and near(pts) and Polygon(pts).is_valid and not Polygon(pts).intersects(stands_bbox):
                rec = {'id': int(rid), 'member': int(mref), 'poly': pts}
                if kind == 'grass': rec['kind'] = t.get('landuse') or t.get('leisure')
                out[kind].append(rec)
summary = {k: len(v) for k, v in out.items()}
print(summary)
print('parking types', sorted(set(p.get('parking','?') for p in out['parking'])), 'capacity known', sum(1 for p in out['parking'] if 'capacity' in p))
import collections
print('tree genus', collections.Counter(t.get('genus','?') for t in out['trees']).most_common(12))
side = collections.Counter()
for p in out['parking']:
    c = Polygon(p['poly']).centroid; side['x+' if abs(c.x) > abs(c.y) and c.x > 0 else 'x-' if abs(c.x) > abs(c.y) else 'y+' if c.y > 0 else 'y-'] += Polygon(p['poly']).area
print('parking area by side (m²):', {k: round(v) for k, v in side.items()}, '| north vector', [round(v,3) for v in north])
meta = {'source': 'OpenStreetMap, api.openstreetmap.org/api/0.6/map', 'bbox': [7.4422, 51.4866, 7.4612, 51.4986], 'fetched': '2026-10-07',
        'licence': 'ODbL 1.0 — © OpenStreetMap contributors', 'frame': {'origin': 'pitch-center', 'xAxis': 'goal-to-goal', 'yAxis': 'touchline-to-touchline', 'unit': 'm',
        'lat0': lat0, 'lon0': lon0, 'pitchCenterLocal': [round(cx,2), round(cy,2)], 'thetaDeg': round(math.degrees(th), 3), 'northVector': [round(north[0],4), round(north[1],4)]},
        'radius_m': R, 'excluded': 'alles innerhalb Tribünen-Bbox + 10 m (außer Parkflächen)', 'counts': summary}
json.dump({'meta': meta, **out}, open('/home/claude/stage/osm/dortmund_umfeld.json', 'w'), separators=(',', ':'))
sc = json.load(open('/home/claude/stage/scenes/bvb_v2.json'))
sc['surroundings'].update({'sports': out['sports'], 'parking': out['parking'], 'trees': out['trees'], 'treeRows': out['treeRows'], 'forest': out['forest'], 'scrub': out['scrub'], 'grassTagged': out['grass'], 'water': out['water'], 'buildingsTagged': out['buildingsTagged'], 'landuse': out['landuse'], 'sourceDetail': meta})
json.dump(sc, open('/home/claude/stage/scenes/bvb_v2.json', 'w'), separators=(',', ':'))
print('written osm/dortmund_umfeld.json', round(len(json.dumps({'meta': meta, **out}))/1024), 'KB')
