# Freundschaftsspiele — der neue Bereich in Websoccer

Ab sofort planst du Testspiele komplett selbst — für Profis und U21, umschaltbar mit einem Klick.

**Spiel ansetzen.** Du bestimmst alles: Heim- und Gastmannschaft, Spielort (eigenes Stadion, beim Gegner oder neutral), Datum und Uhrzeit, dazu die Regeln — mit oder ohne Verlängerung, Elfmeterschießen, auf Wunsch direkt nach 90 Minuten. Anfragen an Manager-Vereine bleiben bis zum Spieltermin gültig; KI-Vereine ohne Manager nehmen sofort an — Anfrage raus, Spiel steht.

**Spielbörse.** Keinen konkreten Gegner im Kopf? Schreib eine Partie offen aus: Rolle, Termin, Ort, Regeln — und jeder Manager kann zugreifen. Wer zuerst annimmt, spielt.

**Offene Anfragen.** Eingehende Anfragen mit allen Rahmenbedingungen auf einen Blick — annehmen oder ablehnen, fertig. Ausgehende behältst du daneben im Auge.

**Community-Turniere.** Erstelle eigene Wettbewerbe als Liga (Hin-/Rückrunde), Pokal oder Gruppenphase + K.o. — mit Teilnehmerlimit, freiem Beitritt, Einladungscode oder Bewerbung. Als Ersteller planst du alle Termine bis zum Finale durch und kannst sie jederzeit anpassen. Admins können eine Prämie ausloben — komplett an den Sieger oder verteilt auf die Top 3. Im Turnier warten Pokalbaum, Tabelle, Spielplan und Teilnehmerverwaltung.

**Historie.** Alle Freundschaftsspiele — geplant und gespielt — an einem Ort, mit Filter und Spielbericht. Der Spielkalender bleibt frei.

---

## Kurzfassung (Changelog-Teaser)

> **Neu: Freundschaftsspiele!** Setze Testspiele gegen Manager- und KI-Vereine an, schreibe Partien in der Spielbörse aus oder starte dein eigenes Community-Turnier — als Liga, Pokal oder Gruppenphase, auf Wunsch mit Prämie. Auch für deine U21.
