# Context Pack — Websoccer: Bereich „Freundschaftsspiele"

**Stand:** 10.09.2026
**Projekt:** Websoccer (MatchEngine) — Django-Browsergame, Fußballmanager, UI komplett deutsch
**Repo:** github.com/Mark123179/Websoccer (branch `main`)
**Design System:** Websoccer Design System „MatchEngine" (dark, Glass-Panels, Cyan als funktionales Licht, Grün = positiv/Sport)
**Artefakt:** `Freundschaftsspiele Tabs.dc.html` (klickbarer Prototyp), Standalone im Paket

---

## 1. Auftrag

Oberfläche für den neuen Bereich **Freundschaftsspiele** entwerfen: Spiele ansetzen, Spiele anfragen, offene Anfragen verwalten, Community-Turniere (Liga & Pokal) — und das Ganze zusätzlich für die U21.

---

## 2. Festgelegte Entscheidungen

### Struktur
- **Reiter auf einer Seite** (Variante „Tabs"), nicht Dashboard + Dialoge. Beide Varianten wurden gebaut und verglichen; Tabs war übersichtlicher, Dashboard-Variante wurde gelöscht.
- Reiter-Reihenfolge: **Spiel ansetzen** (Start-Reiter) · **Spielbörse** · **Offene Anfragen · N** (Zähler grün) · **Turniere** · **Historie**
- **U21 ist kein eigener Reiter**, sondern ein **Modus-Umschalter** oben (Profis / U21). Im U21-Modus zeigt ein grünes Badge „U21-MODUS" im Header eindeutig den Zustand; alle Reiter arbeiten dann mit U21-Daten.
- Die eigene Sidebar wurde bewusst entfernt — der Bereich wird in die bestehende Websoccer-Navigation eingebettet.

### Spiel ansetzen (gerichtete Anfrage)
- Felder: Heimmannschaft, Gastmannschaft, Spielort, Datum, Uhrzeit, Regeln, Kommentar
- **Spielort:** Heimstadion · Stadion des Gegners · Neutraler Platz (mit Stadionauswahl)
- **Regeln:** mit/ohne Verlängerung · mit/ohne Elfmeterschießen · Elfmeterschießen direkt nach 90 Minuten (schließt Verlängerung aus; nur wählbar, wenn Elfmeterschießen aktiv)
- **Datum/Uhrzeit frei wählbar**, keine festen Slots
- Live-Hinweis unter der Gegnerwahl: KI-Verein → nimmt sofort an, Spiel wird direkt geplant. Manager-Verein → muss annehmen, gültig bis zum Spieltermin.
- Rechts eine **Vorschau-Karte** (Wappen, VS, Termin, Spielort, Regel-Chips, Kommentar)
- Nach dem Absenden: KI → Erfolgsmeldung „Spiel geplant", erscheint in der Historie als *Geplant*. Manager → „Anfrage gesendet", erscheint unter Offene Anfragen (Ausgehend).

### Spielbörse (ehem. „Spiel anfragen")
- Ursprünglicher Entwurf („Anfrage an einzelne Vereine senden") war redundant zu „Spiel ansetzen" und wurde ersetzt.
- **Partie ausschreiben:** Rolle (Heim-/Gastmannschaft), Spielort, Datum, Uhrzeit, Regeln, Kommentar → Inserat für alle Manager sichtbar, **wer zuerst annimmt, spielt**.
- **Spielort in der Börse:** Mein Stadion · Stadion des Annehmenden · Neutraler Platz — immer alle drei wählbar, unabhängig von der Rolle.
- **Offene Partien:** Inserate anderer Manager annehmen; eigenes Inserat ist markiert („Dein Inserat") und zurückziehbar.
- Inserate laufen ab, wenn der Spieltermin erreicht ist.

### Offene Anfragen
- Zwei Spalten: **Eingehend** / **Ausgehend**
- Rahmenbedingungen als **farbige Chips**, damit die Kernpunkte sofort erkennbar sind: Termin = cyan, Spielort = grün, Regeln = neutral
- Eingehend: **nur Annehmen/Ablehnen**, kein Gegenvorschlag
- Ausgehend: Status „Ausstehend" (gelb) + Zurückziehen
- **Ablauf: bis zum Spieltermin** (kein 24/48h-Fenster)
- Zähler im Reiter-Label in **Grün**

### Turniere (Community)
- Formate: **Liga** (Hin-/Rückrunde wählbar) · **Pokal** (K.o. mit Auslosung) · **Gruppenphase + K.o.**
- **Teilnehmerlimit** je Format (Liga 4–16, Pokal 4/8/16, Gruppen 8/16)
- **Zugang:** Offen für alle · Einladungscode/-link · Bewerbung (Ersteller bestätigt)
- **Ersteller legt alle Termine fest** — der Wizard erzeugt den Spielplan passend zum Format und zur Teilnehmerzahl und führt ihn **bis zum letzten Spieltag bzw. bis zum Finale** durch (Liga: (n−1)×2 Spieltage bei Rückrunde; Pokal: Achtel→Viertel→Halb→Finale; Gruppen: 3 Gruppenspieltage + K.o.-Runden). Termine sind später am Turnier änderbar.
- **Prämie:** Community-Turniere grundsätzlich ohne. **Nur Admins** können eine Prämie vergeben — im Wizard **und** nachträglich am Turnier, aber **nur bis zum ersten gespielten Spieltag**, danach gesperrt.
- **Prämien-Verteilung:** nur der Sieger · Top 3 (50/30/20) · eigene Verteilung in % (Summenprüfung, rot wenn ≠ 100)

### Turnier-Detailansicht
- Erreichbar über „Zum Turnier" bei angemeldeten Turnieren, zurück über „← Alle Turniere"
- **Tabelle** (Liga/Gruppen): Platz, Verein, Sp, S, U, N, Tore, Punkte — **ohne Form-Spalte**; eigener Verein hervorgehoben
- **Pokalbaum**: Viertelfinale → Halbfinale → Finale mit Terminen; Ergebnisse **klickbar zu Spielberichten** (Verlinkung derzeit leer, da keine Spielberichte vorhanden)
- **Spielplan**: Runden-/Spieltagsauswahl, gespielte Runden mit Ergebnis + Spielbericht-Link, künftige Runden mit **vom Ersteller änderbarem Termin**
- **Teilnehmerliste** mit **Entfernen** (nur vor Turnierstart)
- **Prämie (Admin)** direkt in der Detailansicht: Betrag + Verteilung + Speichern; nach dem 1. Spieltag gesperrt mit Hinweis

### Historie
- **Eine Liste mit Status-Filter** (Alle / Geplant / Gespielt)
- **10 Spiele pro Seite**, danach Blättern (Zurück/Weiter + „Seite X von Y · N Spiele")
- Zeigt geplante und gespielte Freundschaftsspiele, Ergebnis-Badge S/U/N, Spielbericht-Link
- **Freundschaftsspiele erscheinen NICHT im Spielkalender** — nur hier; Turniere unter „Turniere"

### Bewusst ausgeschlossen
- **Keine Belastung/Frische-Auswirkung** durch Freundschaftsspiele
- **Keine Einnahmen** (keine Zuschauer-/Prämienerlöse außer Admin-Turnierprämie)
- **Kein Limit** an Freundschaftsspielen pro Woche/Saison
- **Kein Gegenvorschlag** bei Anfragen
- Keine Kalendereinträge

### Optik
- Design System „MatchEngine": Glass-Panels, Cyan-Hairlines, Grün für Positives, Inter, 8px Radius, 16px Gaps
- Stadion-Foto als Seitenhintergrund mit dunklem Verlauf darüber (`assets/backgrounds/stadion-bg.png`)
- Vereinswappen aus `assets/crests/<fm_inside_id>.png`

---

## 3. Offene Punkte
- Spielbericht-Links sind Platzhalter, bis Spielberichte existieren
- Benachrichtigungen (Posteingang) bei Anfrage/Annahme/Terminänderung sind noch nicht designt
- Auslosungs-Ansicht für Pokal-Turniere (Moment der Auslosung) noch offen
- U21-Datenmodell (eigener Kader, eigene Turniere) fachlich noch nicht durchgesprochen
- Abgleich mit den bestehenden Django-Templates im Repo noch nicht erfolgt

---

## 4. Dateien im Paket
- `Freundschaftsspiele-Standalone.html` — kompletter Prototyp als eine Datei, offline lauffähig
- `Replit-Prompt.md` — Umsetzungs-Prompt für die Entwicklung
- `Praesentationstext.md` — Ankündigungstext für Community/Changelog
- `Gespraechsverlauf-Context-Pack.md` — dieses Dokument
