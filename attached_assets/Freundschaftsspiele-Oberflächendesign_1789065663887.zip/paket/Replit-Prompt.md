# Replit-Prompt — Websoccer: Bereich „Freundschaftsspiele"

Kopiere den folgenden Block als Aufgabenbeschreibung in Replit. Lege zusätzlich `Freundschaftsspiele-Standalone.html` als visuelle Referenz und `Gespraechsverlauf-Context-Pack.md` als Spezifikation bei.

---

## Prompt

Du arbeitest am bestehenden Django-Projekt **Websoccer** (Repo `Mark123179/Websoccer`, Branch `main`) — ein deutschsprachiges Fußballmanager-Browsergame. App-Struktur: `core/` (Config), `game/` (Logik, Templates, Static). Frontend ist **Django-Templates + plain HTML/CSS**, kein React, kein Build-Step. Die Design-Tokens liegen in `game/static/game/css/global-dashboard/*`; benutze ausschließlich die vorhandenen CSS-Variablen (`--cyan`, `--green`, `--line`, `--panel`, `--text`, `--muted`, `--faint`, `--radius`, `--shadow` …). Alle UI-Texte auf **Deutsch**, Ansprache **du/Chef**. Zahlen im deutschen Format (`500.000 €`).

Implementiere den neuen Bereich **Freundschaftsspiele**. Die beiliegende Datei `Freundschaftsspiele-Standalone.html` ist der abgenommene Design-Prototyp — übernimm Layout, Reihenfolge, Farbcodierung und Texte daraus 1:1. Sie ist Referenz, nicht Code zum Kopieren (der Prototyp läuft auf React; du baust Django-Templates).

### Seitenstruktur

Eine Seite, in die bestehende Websoccer-Navigation eingebettet (keine eigene Sidebar). Kopfzeile mit Modus-Umschalter **Profis / U21** — im U21-Modus ein deutlich sichtbares grünes Badge „U21-MODUS". Der Modus gilt für alle Reiter.

Reiter in dieser Reihenfolge:
1. **Spiel ansetzen** (Standard)
2. **Spielbörse**
3. **Offene Anfragen · N** (N = Anzahl offener Anfragen, in Grün)
4. **Turniere**
5. **Historie**

### 1. Spiel ansetzen — gerichtete Anfrage an einen Verein

Formular: Heimmannschaft, Gastmannschaft (Auswahl), Spielort, Datum, Uhrzeit, Regeln, Kommentar.

- **Spielort:** `Heimstadion` | `Stadion des Gegners` | `Neutraler Platz` (+ Stadionauswahl)
- **Regeln (Checkboxen):** `Mit Verlängerung`, `Mit Elfmeterschießen`, `Elfmeterschießen direkt nach 90 Minuten`
  - „Elfmeterschießen direkt nach 90 Minuten" ist nur aktivierbar, wenn „Mit Elfmeterschießen" gesetzt ist, und schließt „Mit Verlängerung" aus (und umgekehrt).
- Datum und Uhrzeit **frei wählbar**, keine festen Slots. Heim ≠ Gast validieren.
- Unter der Gegnerwahl ein **Live-Statushinweis**:
  - Gegner ist KI-Verein (kein Manager) → grün: „… ist ein KI-Verein — nimmt sofort an, das Spiel wird direkt geplant"
  - Gegner hat einen Manager → neutral: „Manager X muss die Anfrage annehmen — gültig bis zum Spieltermin"
- Rechts eine **Vorschau** mit Wappen, VS, Termin, Spielort, Regel-Chips, Kommentar.
- **Absenden:**
  - KI-Verein → Spiel wird sofort mit Status *geplant* erstellt, Erfolgsmeldung, erscheint in der Historie.
  - Manager-Verein → Anfrage mit Status *ausstehend* erstellen, erscheint beim Absender unter Ausgehend, beim Empfänger unter Eingehend. Gültig **bis zum Spieltermin**, danach automatisch abgelaufen.
- Hinweis auf der Seite: „Freundschaftsspiele erscheinen nicht im Kalender. Geplante und gespielte Partien findest du im Reiter Historie."

### 2. Spielbörse — offenes Inserat

Linke Spalte **Partie ausschreiben**:
- Rolle: `Heimmannschaft` | `Gastmannschaft`
- Spielort: `Mein Stadion` | `Stadion des Annehmenden` | `Neutraler Platz` — **immer alle drei wählbar**, unabhängig von der Rolle
- Datum, Uhrzeit, Regeln (wie oben), Kommentar
- Absenden erzeugt ein Inserat, sichtbar für alle Manager. **Wer zuerst annimmt, spielt** — beim Annehmen wird das Spiel als *geplant* erstellt und das Inserat geschlossen.

Rechte Spalte **Offene Partien**:
- Inserate anderer Manager mit Wappen, Rollen-Zeile („Spielt als Heimmannschaft — du wärst zu Gast"), Chips für Termin/Ort/Regeln und Button **Annehmen**
- Eigene Inserate sind mit „Dein Inserat" markiert und haben **Zurückziehen** statt Annehmen
- Inserate laufen ab, wenn der Spieltermin erreicht ist

### 3. Offene Anfragen

Zwei Spalten: **Eingehende Anfragen** und **Ausgehende Anfragen**.

- Jede Anfrage zeigt die Rahmenbedingungen als **farbige Chips**: Termin = cyan, Spielort = grün, Regeln = neutral. Darunter „Gültig bis zum Spieltermin".
- Eingehend: **Annehmen** / **Ablehnen** — kein Gegenvorschlag, keine Terminänderung. Annehmen erstellt das Spiel als *geplant*.
- Ausgehend: Status „Ausstehend" (gelb, mit Punkt) + **Zurückziehen**

### 4. Turniere

Übersicht als Karten-Grid: Name, Format-Badge, Teilnehmer (x/y), Start, Ersteller, Zugang (grün „Offen für alle" / neutral „Nur Einladung" / gelb „Bewerbung"), ggf. Prämien-Badge (orangener Gradient), CTA (`Beitreten` / `Code eingeben` / `Bewerben`) bzw. „Angemeldet" + `Zum Turnier`.

**Erstellen-Wizard (4 Schritte, Schritte anklickbar):**
1. **Format:** `Liga` (+ `Hin- & Rückrunde` / `Nur Hinrunde`) | `Pokal` (K.o. mit Auslosung) | `Gruppen + K.o.`
2. **Teilnehmer & Zugang:** Teilnehmerlimit je Format (Liga 4/6/8/10/16, Pokal 4/8/16, Gruppen 8 = 2 Gruppen / 16 = 4 Gruppen) · Zugang `Offen für alle` | `Nur Einladung` (Code/Link) | `Bewerbung` (Ersteller bestätigt)
3. **Spielplan:** Der Ersteller legt **alle Termine** fest. Die Rundenliste wird **aus Format + Teilnehmerzahl** erzeugt und geht **bis zum Ende**:
   - Liga: `(n−1)` Spieltage, bei Rückrunde `(n−1)×2`
   - Pokal: `Achtelfinale → Viertelfinale → Halbfinale → Finale` (je nach Teilnehmerzahl)
   - Gruppen + K.o.: 3 Gruppenspieltage, dann `Viertelfinale` (ab 16) `→ Halbfinale → Finale`
   Jede Runde mit Datum + Uhrzeit, Vorbelegung im Wochenrhythmus.
4. **Prämie (nur für Admins sichtbar):** Betrag in € + Verteilung `Nur der Sieger` | `Top 3 (50/30/20)` | `Eigene Verteilung` (Prozente pro Platz, Summe muss 100 % ergeben — sonst rot). Auszahlungsvorschau je Platz.

**Prämien-Regel (wichtig):** Community-Turniere haben grundsätzlich keine Prämie. Nur Admins können eine vergeben — im Wizard **und nachträglich** an einem bereits erstellten Turnier —, aber **nur solange kein Spiel gespielt wurde**. Ab dem ersten gespielten Spieltag ist die Prämie gesperrt (mit Hinweis „Gesperrt — der 1. Spieltag ist gespielt").

**Turnier-Detailansicht** (aus „Zum Turnier", zurück über „← Alle Turniere"):
- Kopf: Name, Format-Badge, Status („Läuft · Spieltag X von Y" bzw. „Anmeldung · Start TT.MM.JJJJ"), Prämien-Badge
- **Tabelle** bei Liga/Gruppen: `#`, Verein (mit Wappen), `Sp`, `S`, `U`, `N`, `Tore`, `Pkt.` — **keine Form-Spalte**; eigener Verein hervorgehoben (cyan Wash + 3px Inset-Bar)
- **Pokalbaum** bei K.o.: Spalten je Runde (Viertelfinale/Halbfinale/Finale) mit Paarungen und Termin; Ergebnisse verlinken auf den Spielbericht (Link vorerst leer/deaktiviert, bis Spielberichte existieren)
- **Spielplan**: Runden-Chips zur Auswahl; gespielte Runde → Ergebnis + „Spielbericht"-Link + Badge „Gespielt"; kommende Runde → Datum/Uhrzeit **vom Ersteller änderbar** („Als Ersteller änderbar — Teilnehmer werden benachrichtigt")
- **Teilnehmer**: Liste mit Wappen, Vereinsname, Manager bzw. „KI-Verein"; Button **Entfernen** pro Team, aber **nur vor Turnierstart** (danach Hinweis „Entfernen nur vor Turnierstart möglich"); Zähler „x / y Teams"
- **Prämie (Admin)**: Betrag + Verteilung + Speichern, wenn noch nicht gestartet; sonst schreibgeschützte Anzeige mit Sperr-Hinweis

### 5. Historie

- **Eine Liste** mit Status-Filter `Alle` | `Geplant` | `Gespielt`
- **10 Einträge pro Seite**, darunter Blättern: „Seite X von Y · N Spiele" + `Zurück` / `Weiter` (deaktiviert am Rand)
- Zeile: Datum/Uhrzeit · Heim (Wappen) · Ergebnis oder `– : –` · Gast (Wappen) · rechts Badge „Geplant" (cyan) bzw. Ergebnis-Kreis **S** (grün) / **U** (gelb) / **N** (rot) + Link „Spielbericht anzeigen"
- Enthält geplante **und** gespielte Freundschaftsspiele

### Fachliche Regeln (verbindlich)

- Freundschaftsspiele **erzeugen keine Belastung/Frische-Auswirkung**
- Freundschaftsspiele **erzeugen keine Einnahmen** (keine Zuschauer-, keine Siegprämien) — einzige Ausnahme: die vom Admin ausgelobte Turnierprämie
- **Kein Limit** an Freundschaftsspielen pro Woche oder Saison
- Freundschaftsspiele erscheinen **nicht im Spielkalender**, nur in der Historie; Turniere nur unter „Turniere"
- Anfragen und Inserate haben **kein eigenes Ablaufdatum** — sie verfallen mit dem Spieltermin
- **Kein Gegenvorschlag**: der Empfänger kann nur annehmen oder ablehnen
- KI-Vereine (Vereine ohne Manager) nehmen Anfragen **automatisch und sofort** an
- Der U21-Modus spiegelt **alle** Reiter (Ansetzen, Börse, Anfragen, Turniere, Historie) mit U21-Kader und eigenen U21-Turnieren

### Datenmodell (Vorschlag)

```
Friendly            home_team, away_team, kickoff (datetime), venue_type
                    (home|away|neutral), neutral_venue, extra_time (bool),
                    penalties (bool), penalties_after_90 (bool), comment,
                    status (planned|played), is_u21 (bool), result_home,
                    result_away, match_report (FK, nullable)

FriendlyRequest     from_team, to_team, kickoff, venue_type, neutral_venue,
                    rules…, comment, status (pending|accepted|declined|expired),
                    is_u21
                    -> beim Annehmen: Friendly(status=planned) erzeugen

FriendlyOffer       creator_team, role (home|away), venue_type
                    (own|acceptor|neutral), kickoff, rules…, comment,
                    status (open|matched|withdrawn|expired), is_u21
                    -> beim Annehmen: Friendly erzeugen, Offer schließen

Tournament          name, format (league|cup|groups_ko), double_round (bool),
                    max_teams, access (open|invite|application), invite_code,
                    creator, is_u21, prize_total, prize_distribution
                    (winner|top3|custom), prize_custom (JSON), started (bool)

TournamentRound     tournament, index, label, kickoff (datetime)
TournamentMatch     round, home_team, away_team, result_home, result_away,
                    status, match_report (FK, nullable)
TournamentEntry     tournament, team, status (joined|applied|invited)
```

Regel im Backend: `Tournament.prize_*` ist nur schreibbar, solange kein `TournamentMatch` den Status *gespielt* hat, und nur für Admins.

### Abnahmekriterien

- Alle fünf Reiter funktionieren, Start-Reiter ist „Spiel ansetzen"
- Profis/U21-Umschalter wirkt auf alle Reiter und ist im Header eindeutig erkennbar
- Anfrage an KI-Verein erzeugt sofort ein geplantes Spiel; Anfrage an Manager landet bei beiden Seiten korrekt in Offene Anfragen
- Börsen-Inserat kann von einem anderen Manager angenommen werden und erzeugt das Spiel
- Turnier-Wizard erzeugt für alle drei Formate einen vollständigen Spielplan bis zum Finale bzw. letzten Spieltag
- Admin-Prämie ist vor dem ersten Spieltag setzbar (Wizard und Detailansicht) und danach gesperrt
- Teilnehmer können vor Turnierstart entfernt werden, danach nicht mehr
- Historie blättert in 10er-Seiten und filtert nach Geplant/Gespielt
- Kein Freundschaftsspiel und kein Turnierspiel erscheint im Spielkalender
- Optik entspricht dem Prototyp und nutzt ausschließlich bestehende Design-Tokens
