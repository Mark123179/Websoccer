# Replit-Auftrag: Bereich „Freundschaftsspiele"

**Projekt:** Websoccer / BLUEPRINT · Repo `Mark123179/Websoccer` (main) · Django, App `game/`
**Vorlagen:** `Freundschaftsspiele-Standalone.html` (Prototyp, separat gesendet) + `SPEC_Freundschaftsspiele.md` (Entscheidungsgrundlage)
**Sprache:** deutsche UI, Ansprache „du". Kein React — Django-Templates + plain CSS/JS.

> **Rangfolge bei Widersprüchen:** Die Spec schlägt den Prototyp. Der Prototyp entstand vor dem Entscheidungsinterview und enthält an fünf Stellen Lücken, die unten ausdrücklich benannt sind.

---

## 0. Rahmen

- Neuer Sidebar-Eintrag **„Freundschaftsspiele"** (Pokal-Outline, 24 px, `currentColor`)
- Fester Shell-Vertrag **1440 × 900**. Header, Sidebar, Kalender und globale Navigation bleiben unangetastet. Keine eigenen Artboard-Breiten, kein `100vw`, keine eigenen Scaler
- Seitenkopf: Umschalter **Profis / U21**, aktiver U21-Modus mit grünem Badge „U21-MODUS". Alle Listen und Formulare filtern auf `squad_scope`
- Reiter: **Spiel ansetzen** (Default) · **Spielbörse** · **Offene Anfragen** (Anzahl grün) · **Turniere** · **Historie**
- **Freundschaftsspiele erscheinen NICHT im Spielkalender.** `_build_global_calendar()` in `game/context_processors.py` wird nicht angefasst
- Kein Frischeverlust, keine Verletzungen, keine Einnahmen, kein Limit

---

## 1. Datenmodell

### 1.1 Neu: `FriendlyFixture`

Ein Objekt für Anfrage, Inserat, angesetztes Spiel und Turnierpartie. Bei Zusage entsteht **kein** zweites Objekt.

```python
squad_scope        # 'pro' | 'u21'
sender_club        # FK Club
target_club        # FK Club, null=True  → null = offenes Inserat
offered_role       # 'heim' | 'gast', blank  (nur Inserat)
venue_type         # 'heim' | 'gast' | 'neutral'
neutral_stadium    # FK NeutralVenue, null=True
kickoff_at         # DateTimeField
extra_time         # Boolean
penalties          # Boolean
penalties_after_90 # Boolean
comment            # CharField(200), blank
tournament         # FK CommunityTournament, null=True
tournament_round   # FK TournamentRound, null=True
status             # ANGEFRAGT | GEPLANT | SIMULIERT_LAEUFT | GESPIELT
                   # ABGELEHNT | ZURUECKGEZOGEN | VERFALLEN | NICHT_AUSGETRAGEN
simulated_match    # FK SimulatedMatch, null=True
created_at, resolved_at
```

**Constraints:**
- `penalties_after_90=True` ⇒ `penalties=True` **und** `extra_time=False`
- `sender_club != target_club`
- `neutral_stadium` gesetzt genau dann, wenn `venue_type='neutral'`
- Index auf `(status, kickoff_at)`

### 1.2 Neu: `NeutralVenue`

`name`, `city`, `capacity`, `is_active`. Startdaten: Olympiastadion Berlin, Volksparkstadion Hamburg, RheinEnergieStadion Köln. Pflege im Creator-Mode. **Stadien anderer Vereine stehen nicht zur Auswahl.**

### 1.3 Neu: Turniermodelle

```python
CommunityTournament
  name, creator(FK ManagerProfile), squad_scope
  format          # 'liga' | 'pokal' | 'gruppen_ko'
  double_round    # Boolean (nur liga)
  max_teams, access ('offen'|'code'|'bewerbung'), invite_code
  extra_time, penalties, penalties_after_90   # gelten für ALLE Partien
  venue_type
  prize_total(Decimal,null), prize_split ('sieger'|'top3'|'custom'), prize_custom(JSON)
  is_official     # Admin-Turnier
  status          # 'anmeldung'|'laufend'|'abgeschlossen'|'abgesagt'
  started_at, finished_at, winner_club

TournamentParticipant   # tournament, club, is_ai, group_label, seed, joined_at
                        # unique(tournament, club)
TournamentRound         # tournament, order, label, kickoff_at, stage('liga'|'gruppe'|'ko'), is_played
TournamentStanding      # tournament, club, group_label, played, won, drawn, lost,
                        # goals_for, goals_against, points
```

`TournamentStanding.group_label` und `TournamentParticipant.group_label` von Anfang an anlegen, auch wenn die einfache Liga sie leer lässt — spart den Umbau bei Gruppen + K.-o.

### 1.4 Änderung: `TacticSetup` bekommt `context`

```python
context = models.CharField(max_length=12, default='pflicht',
    choices=[('pflicht','Pflichtspiel'), ('freundschaft','Freundschaftsspiel')])
```

Unique-Constraint `unique_club_tactic_setup_scope` von `(club, squad_scope)` auf **`(club, squad_scope, context)`** erweitern. Migration setzt bei allen bestehenden Zeilen `context='pflicht'`. Der Freundschafts-Datensatz entsteht beim ersten Aufruf als Kopie des Pflichtsatzes.

> **Das ist die wichtigste Änderung des ganzen Auftrags.** Ohne sie ist die Testaufstellung dieselbe Zeile wie die Pflichtspielaufstellung, und eine mittags getestete Dreierkette läuft nachmittags in der Liga auf.

### 1.5 Keine Änderung an `SimulatedMatch`

`match_type='freundschaft'` und `referee` existieren bereits. Ergebnisse werden über `SimulatedMatch.create_numbered(season=…)` angelegt.

---

## 2. Reiter „Spiel ansetzen"

Formular: Heimmannschaft · Gastmannschaft (eigener Verein muss eine Seite sein, Heim ≠ Gast) · Spielort (Heimstadion / Stadion des Gegners / Neutraler Platz → Auswahl aus `NeutralVenue`) · Datum · Uhrzeit (frei) · Kommentar (optional, für den Gegner sichtbar).

**Regeln als Checkbox-Zeilen:** „Mit Verlängerung" · „Mit Elfmeterschießen" · „Elfmeterschießen direkt nach 90 Minuten" (nur wählbar wenn Elfmeterschießen an; schließt Verlängerung gegenseitig aus).

**Verhalten nach Gegnerauswahl** — Live-Hinweis unter dem Feld:

| Gegner | Hinweis | Folge |
|---|---|---|
| **mit Manager** | „Manager {Name} muss die Anfrage annehmen" (grau) | `status=ANGEFRAGT`, erscheint beim Gegner unter Eingehend, beim Sender unter Ausgehend. **Nur Annehmen/Ablehnen — kein Gegenvorschlag.** Gültig bis zum Spieltermin |
| **KI-Verein** | „KI-Verein — nimmt sofort an" (grün) | `status=GEPLANT` direkt beim Absenden. **Kein Eintrag in der Anfrageliste.** Bestätigung „Spiel angesetzt" mit Termin |

**Terminkollision:** Ein Verein hat nie zwei Spiele zur selben Uhrzeit im selben `squad_scope`. Geprüft **bei der Zusage** (bei KI direkt beim Absenden), nicht beim Anlegen der Anfrage.

**Mindestbesetzung:** Bei der Zusage prüfen, ob beide Seiten ≥ 11 einsatzfähige Spieler stellen. Fehlermeldung mit konkreter Zahl.

---

## 3. Reiter „Spielbörse"

Formular **„Partie ausschreiben"**: Ich spiele als (Heim/Gast) · Spielort (Mein Stadion / Stadion des Annehmenden / Neutraler Platz — immer alle drei) · Datum/Uhrzeit · Regeln · Kommentar. Erzeugt `FriendlyFixture` mit `target_club=None`.

Liste **„Offene Partien"**: Inserate aller Manager (Verein, Rolle, Termin-Chip cyan, Ort-Chip grün, Regel-Chips). Button **Annehmen** — wer zuerst annimmt, spielt.

**Annahme in `transaction.atomic()` mit `select_for_update()` auf der Zeile.** Ein zweiter, gleichzeitiger Klick erhält „Diese Partie wurde bereits vergeben".

Eigene Inserate markiert („Dein Inserat") + **Zurückziehen**. Verfall zum Spieltermin.

**KI-Vereine nehmen keine Inserate an.**

---

## 4. Reiter „Offene Anfragen"

Zwei Abschnitte: **Eingehend** (Chips für Termin/Ort/Regeln, Kommentar, „Gültig bis zum Spieltermin", Annehmen/Ablehnen) und **Ausgehend** (Status „Ausstehend", Zurückziehen). Anzahl eingehender Anfragen grün am Reiter.

---

## 5. Simulation

### 5.1 Engine erweitern

`game/match_engine.py:2845` `simulate_match()` bekommt zwei neue Keyword-Argumente, die `is_cup` ablösen. **Rückwärtskompatibel:** `is_cup=True` ⇒ `extra_time=True, penalties=True`.

| `extra_time` | `penalties` | Verhalten |
|---|---|---|
| False | False | Unentschieden möglich |
| True | False | Verlängerung, danach Unentschieden möglich |
| True | True | wie Pokal — Step 7 unverändert |
| **False** | **True** | **Neu:** `_simulate_extra_time_minutes()` überspringen, direkt `_simulate_penalty_shootout()`. `decided_by='penalties'`, `home_goals_et == home_goals_90` |

**Die eingefrorenen Konstanten des KO-Modus (Freeze 14.06.2026) und der Match-Engine V2 werden nicht verändert.** Kein neues Balancing.

### 5.2 Minutentick

Neues Management-Command `run_friendly_tick`, eingehängt in `CELERY_BEAT_SCHEDULE` nach dem Muster von `showauction-tick-minuetlich`, Intervall 60 s. Aufruf über `game.tasks.run_management_command` (fängt `SystemExit` ab — zwingend).

Ein Durchlauf:
1. `status=ANGEFRAGT` und `kickoff_at <= now` → `VERFALLEN`
2. `status=GEPLANT` und `kickoff_at <= now` → simulieren
3. Turnierrunden mit vollständig gespielten Partien → Tabelle bzw. nächste K.-o.-Runde fortschreiben

**Idempotent:** Jede Zeile per bedingtem UPDATE (`GEPLANT` → `SIMULIERT_LAEUFT`) claimen, bevor gerechnet wird.

Zusätzlich **Lazy-Pfad** in der Übersicht: fällige, noch nicht gespielte Partie beim Seitenaufruf sofort abarbeiten.

### 5.3 Was beim Speichern NICHT passiert

| Nicht aufrufen | Modul |
|---|---|
| `apply_match_freshness_losses()` | `game/freshness_service.py` |
| Verletzungswürfel (`chosen_days`) | `match_engine.py` — Ergebnis verwerfen |
| `PlayerSeasonStat`-Schreibpfad | keine Zeilen mit `competition='Freundschaft'` |
| `record_matchday_revenue()` / `booking.book()` | keine `MatchdayRevenue`, keine Buchung |
| Sperren-/Kartenkonto | Karten fallen im Bericht, erzeugen keine Sperre |
| `matchday_xi.py` | keine Elf des Spieltags |

**Frische wird gelesen, nicht geschrieben:** Die Engine nutzt `PlayerStrengthProfile.freshness` wie immer als Eingang. Nur der Abzug danach entfällt.

---

## 6. Aufstellung — Anbindung an den Taktik-Bereich

**Es gibt kein eigenes Aufstellungsformular in diesem Bereich.** Aufgestellt wird im bestehenden Taktik-Bereich, der immer das **nächste zeitlich anstehende Spiel** zeigt — ist das ein Freundschaftsspiel, wird dafür aufgestellt.

- Der Taktik-Bereich lädt `TacticSetup` mit `context='freundschaft'`, wenn das nächste Spiel ein FS ist, sonst `context='pflicht'`
- Im Kopf der Seite steht wie gewohnt, um welches Spiel es geht (Wettbewerb, Gegner, Anstoß) — bei FS zusätzlich als solches gekennzeichnet
- **Bestätigung und Stärkemalus wie im Pflichtspiel.** Für FS tritt an die Stelle von `lineup_confirmed_matchday` die ID des `FriendlyFixture`. Vorbild für die Malus-Felder: `SeasonFixture.home_lineup_set` / `home_lineup_malus`
- **Verletzte können nicht aufgestellt werden** (`ws_injury_days_remaining > 0` ⇒ nicht in der Auswahl). Kein Ausnahmeschalter
- **Gesperrte Spieler dürfen auflaufen**
- KI-Vereine stellen über `default_tactics.py` auf, mit `squad_scope` als Parameter

---

## 7. Spielbericht und Kulisse

**Der Spielbericht ist identisch zu jedem anderen Spielbericht.** Bestehender Berichts-Screen aus `SimulatedMatch.report_data` — nichts nachbauen, nichts weglassen. Die leeren Links im Prototyp waren nur dessen Reichweitengrenze; hier werden sie verdrahtet.

**Alle Berichte sind öffentlich einsehbar**, auch die anderer Vereine.

- **Schiedsrichter:** zufällig aus dem **gesamten Pool aller 463**, ohne Nations- oder Stufenfilter. Die `domestic_tier`-Zuordnung gilt weiterhin nur für Pflichtspiele
- **Wetter:** wie am echten Tag am echten Ort über das bestehende System. Bei `venue_type='neutral'` gilt der Ort des `NeutralVenue`
- **Zuschauer:** `game/economy/stadium.py:147` `compute_demand(club, stadium, opponent_club=…)` **vollständig rechnen und anzeigen**, aber weder `MatchdayRevenue` anlegen noch `book()` aufrufen

**Zuschauer-Aufschlüsselung im Bericht** (nicht nur die Endzahl): Basisnachfrage · Beliebtheitsfaktor · **Gegnerfaktor** · je Kategorie Steh/Sitz/VIP: Kapazität, Preis, Preisfaktor, Zuschauer · Auslastung gesamt in Prozent.

> Der Gegnerfaktor **muss** sichtbar sein: Ein Testspiel gegen einen schwachen Gegner zieht weniger Zuschauer als das nächste Heimspiel gegen den Tabellenführer. Ohne den Faktor senkt ein Manager seine Preise grundlos. Gerechnet wird mit den **echten** Preisen aus dem Stadionbereich, kein separates Testfeld.

**Heimvorteil** wirkt normal, bei `venue_type='neutral'` für beide Seiten nicht.

---

## 8. Reiter „Turniere"

### 8.1 Liste

Karten mit Name, Format-Chip, Teilnehmer x/y, Start, Ersteller, Zugang, ggf. Orange-Gradient-Prämien-Badge; CTA je nach Zugang „Beitreten" / „Code eingeben" / „Bewerben" bzw. „Angemeldet" + „Zum Turnier". Admin-Turniere zusätzlich mit „Offizielles Turnier".

**Jeder Manager darf erstellen, ohne Anzahlbegrenzung. Der Ersteller muss nicht selbst mitspielen.**

### 8.2 Erstellen-Wizard, 4 Schritte

**1 · Format**
- Liga (Hin-/Rückrunde wählbar)
- Pokal (K.-o., Auslosung)
- Gruppenphase + K.-o.

**2 · Teilnehmerlimit + Zugang**
- Liga 4/6/8/10/16 · Pokal 4/8/16 · Gruppen 8 (2 Gruppen) / 16 (4 Gruppen)
- Zugang: Offen für alle / Nur Einladung (Code, Link) / Bewerbung (Ersteller bestätigt)

**3 · Spielplan**
Rundenzahl aus Format und Feldgröße errechnen und als Zeilenliste anlegen (Liga `(n−1)×(Rückrunde?2:1)`; Pokal Achtel/Viertel/Halbfinale/Finale; Gruppen 3 Gruppenspieltage + K.-o.). **Der Ersteller muss jede Runde mit Datum und Uhrzeit belegen — ohne vollständige Terminierung lässt sich das Turnier nicht starten.**
Darüber ein **Takt-Helfer** (Startzeitpunkt + Abstand), der alle Zeilen auf einen Klick vorbelegt; jede Zeile bleibt einzeln änderbar.

**4 · Prämie — nur für Admins sichtbar**
Gesamtbetrag € + Verteilung „Nur der Sieger" / „Top 3 (50/30/20)" / „Eigene Verteilung" (Platz 1–3 in %, Summe = 100 validieren).

### 8.3 ⚠ Fehlt im Prototyp: Starten und KI-Auffüllung

**Ohne diesen Punkt kommt bei zwei aktiven Managern kein einziges Turnier zustande.**

- In der Detailansicht gehört ein Knopf **„Turnier starten"** für Ersteller und Admin
- Ist das Feld nicht voll, öffnet sich ein **Pop-up mit allen verfügbaren KI-Vereinen** (Wappen, Name, Liga, Kader-Marktwert als Orientierung). Der Ersteller **wählt selbst aus**, welche Vereine die freien Plätze füllen. Eintrag als `TournamentParticipant` mit `is_ai=True`, Zusage sofort
- Alternativ **Feld verkleinern**: im Pokal entstehen Freilose in Runde 1, in der Liga eine kleinere Tabelle
- KI-Teilnehmer sind in der Teilnehmerliste erkennbar gekennzeichnet
- **Automatische Absage:** 14 Tage nach dem Erstellen ohne Start und ohne bestätigte Teilnehmer außer dem Ersteller → `status='abgesagt'`, verschwindet aus der Liste

### 8.4 Auslosung und Spielplan

- **Reine Zufallsauslosung, keine Setzliste**
- Der **K.-o.-Baum wird beim Turnierstart vollständig ausgelost**, nicht Runde für Runde
- **Keine Auswärtstorregel.** Bei Hin-/Rückspiel entscheidet das Gesamtergebnis, bei Gleichstand die Turnierregeln
- **Alle Partien eines Turniers laufen mit demselben Regelsatz** aus dem Wizard. Kein Spiel hat eigene Schalter
- Heimrecht: Pokal einfach → Los · Hin-/Rückspiel → getauscht · Liga → Spielplan · Endrunde → Los. `venue_type='neutral'` gilt dann für alle Partien
- Vorbild für Baumerzeugung und Freilose: `game/cup_service.py`

### 8.5 Detailansicht

- **Liga:** Tabelle (# / Verein / Sp / S / U / N / Tore / Pkt.), ohne Formkurve, eigener Verein cyan hervorgehoben
- **Pokal:** Pokalbaum VF → HF → Finale, gespielte Partien mit Ergebnis, klickbar zum Spielbericht
- **Gruppen + K.-o.:** Gruppentabellen nebeneinander, darunter der Baum
- **Spielplan:** Rundenauswahl als Chips; gespielte Runden mit Ergebnis + Spielbericht-Link; künftige Runden mit vom Ersteller änderbarem Termin (Teilnehmer benachrichtigen)
- **Teilnehmerliste** mit „Entfernen" (nur Ersteller/Admin, **nur vor Turnierstart**)
- **Prämien-Panel** (siehe 8.6)

### 8.6 Prämie

Vergeben oder ändern ist möglich **bis zum ersten gespielten Spiel** — auch nachträglich am laufenden Turnier. Sobald eine Partie `status='GESPIELT'` hat: gesperrt, gelber Hinweis „Gesperrt — der 1. Spieltag ist gespielt".

> **Die Sperre in der View hart prüfen, nicht nur ausblenden.** Sonst ließe sich ein Turnier erst laufen lassen und dann rückwirkend versüßen.

**Auszahlung nach Turnierende** über `game/economy/booking.py:89`:

```python
book(club, typ='TURNIER_PRAEMIE', betrag=anteil,
     beschreibung=f'Prämie {tournament.name} — Platz {platz}',
     referenz_typ='turnier_praemie', referenz_id=tournament.id,
     pflicht=True)
```

Neuer Typ in `FinanceTransaction.TYP_CHOICES`. **Idempotenz:** vor der Buchung prüfen, ob für diesen Verein bereits eine Zeile mit `referenz_typ='turnier_praemie'` + `referenz_id=tournament.id` existiert. **Alle Buchungen eines Turniers gemeinsam in `transaction.atomic()`** — sonst markiert ein Teilfehler das Turnier als ausgezahlt und der Rest geht bei einem Neulauf verloren.

---

## 9. Reiter „Historie"

Eine Liste aus geplanten **und** gespielten Spielen, Filter-Chips Alle / Geplant / Gespielt.

Zeile: Datum · Heim (Wappen) Ergebnis Gast (Wappen) · Status „Geplant" (cyan Pill) oder S/U/N-Kreis (grün/gelb/rot) + „Spielbericht anzeigen".

**Blättern: max. 10 Spiele pro Seite**, „Zurück/Weiter" + „Seite x von y · n Spiele".

---

## 10. U21

Alle fünf Reiter gelten für beide Kader; umgeschaltet wird über den globalen Umschalter. Technisch ist die Trennung ausschließlich `squad_scope` an `FriendlyFixture`, `CommunityTournament` und `TacticSetup`.

**Der U21-Kader gehört nicht zu diesem Auftrag** — er entsteht im Jugendmodul.

**Anschluss über genau eine Funktion:**

```python
get_squad(club, scope='u21') -> list[Player]
```

Solange das Jugendmodul fehlt, liefert sie eine **leere Liste**. Der U21-Bereich zeigt dann den Leerzustand:

> „Die U21 hat noch keinen Kader — der Jugendspielbetrieb ist in Arbeit."

**Kein gesperrter Reiter, keine Fehlermeldung, kein toter Klick.** Sobald das Feld existiert, wird eine Funktion umgestellt und der Bereich ist ohne weitere Arbeit lebendig.

Die Terminkollisionsprüfung gilt **pro Kader**, nicht pro Verein.

---

## 11. Grenzfälle

| Fall | Verhalten |
|---|---|
| Manager verlässt den Verein | Spiele und Turnierteilnahmen bleiben **beim Verein**; Nachfolger erbt sie |
| Ersteller verlässt das Spiel mitten im Turnier | Turnier läuft weiter (Termine stehen fest); nur Verschieben und Prämienänderung fallen aus |
| Verein umbenannt | nur der Name ändert sich |
| Verein gelöscht | Anfragen verfallen, Spiele abgesagt, im Turnier **Freilos** — kein Abbruch |
| < 11 einsatzfähige Spieler beim Anpfiff | `NICHT_AUSGETRAGEN`; im Turnier **Niederlage** der betroffenen Seite, damit der Baum weiterläuft |
| Zwei gleichzeitige Annahmen | `select_for_update()`, zweiter erhält „Diese Partie wurde bereits vergeben" |

---

## 12. Saison-Rollover

Der manuelle Rollover bekommt einen zusätzlichen Schritt zwischen `finance_season_close` und dem Hochsetzen von `GameSeasonState.current_season`:

**Freundschaftsspiele der Altsaison löschen** — alle `FriendlyFixture` und die zugehörigen `SimulatedMatch` mit `match_type='freundschaft'`. Turniere der Altsaison ebenfalls.

---

## 13. Gestaltung

CSS-Variablen des bestehenden Systems aus `game/static/game/css/global-dashboard/` (`--panel`, `--line`, `--cyan`, `--green`, `--radius: 8px`). Inter 700/900. UPPERCASE-Micro-Labels 12 px / 900 / +0,7 px. Chips: Termin cyan-soft, Ort grün-soft, Regeln neutral. Prämie immer Orange-Gradient-Badge. Buttons: primär Cyan-Gradient, sekundär Glass, ghost. Stadion-Foto als Seitenhintergrund, dunkel überlagert (`assets/backgrounds/stadion-bg.png`). **Keine Emojis in der Daten-Oberfläche.**

---

## 14. Reihenfolge

| Stufe | Inhalt |
|---|---|
| **1** | Migrationen (`FriendlyFixture`, `NeutralVenue`, `TacticSetup.context`) · Engine-Flags · Reiter „Spiel ansetzen" inkl. KI-Sofortzusage · `run_friendly_tick` + Lazy-Pfad · Taktik-Bereich auf `context` · Spielbericht + Zuschauer-Aufschlüsselung · Reiter „Historie" |
| **2** | Reiter „Offene Anfragen" · Reiter „Spielbörse" |
| **3** | Turniermodelle + Wizard · Auslosung, Spielplan, Tabelle, Baum · Detailansicht · **Startknopf mit KI-Auswahl-Pop-up** · Prämien inkl. Sperre und Auszahlung |
| **4** | `get_squad(club, scope)` gegen den echten U21-Kader tauschen (nach dem Jugendmodul) |

**Nach Stufe 1 ist das Modul benutzbar:** Ein Manager kann gegen jeden KI-Verein testen und seine Eintrittspreise erproben.

---

## 15. Die fünf Lücken des Prototyps — Checkliste

Der Prototyp entstand vor dem Entscheidungsinterview. Diese fünf Punkte fehlen dort und sind **nicht optional**:

1. **KI-Vereine als Turnierteilnehmer + Startknopf mit Auswahl-Pop-up** (§ 8.3) — sonst kommt kein Turnier zustande
2. **Aufstellung über den Taktik-Bereich mit `TacticSetup.context`** (§ 1.4, § 6) — sonst zerstört ein Testspiel die Pflichtspiel-Taktik
3. **Spielbericht verdrahten** inkl. Weltpool-Schiedsrichter, echtes Wetter und Zuschauer-Aufschlüsselung (§ 7) — die leeren Links im Prototyp waren nur dessen Reichweitengrenze
4. **Datenmodell `FriendlyFixture` statt `FriendlyRequest` + `FriendlyMatch`** (§ 1.1) — Ergebnis gehört in `SimulatedMatch`, sonst wird der Spielbericht ein zweites Mal gebaut
5. **U21-Leerzustand** statt funktionsloser Kopie (§ 10)

---

## 16. Agent-Empfehlung

| | |
|---|---|
| **Modus** | Power |
| **Primäres Modell** | Claude Opus (Datenmodell, Engine-Erweiterung, Turnierlogik) · Economy für reine Template-Arbeit |
| **Aufwandsstufe** | hoch bei Stufe 1 und 3, mittel bei Stufe 2 |
| **Aufteilung** | **Vier getrennte Aufträge entlang der Stufen aus § 14.** Stufe 1 und Stufe 3 nicht in einem Lauf zusammenlegen — Stufe 3 allein umfasst fünf neue Modelle, den Wizard, die Auslosung und die Buchungslogik |
| **Zuerst prüfen lassen** | Ob die Migration der `TacticSetup`-Unique-Constraint auf dem Produktivstand sauber durchläuft (bestehende Zeilen bekommen `context='pflicht'`) — das ist der einzige Eingriff in ein Modell, an dem bereits Daten hängen |
