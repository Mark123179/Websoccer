# Gesprächsverlauf — Entscheidungsinterview „Freundschaftsspiele"

**Datum:** 26.08.2026 · **Projekt:** BLUEPRINT · Online-Fußballmanager (playwebsoccer.de)
**Format:** Strukturiertes Entscheidungsinterview, eine Frage pro Runde, Claudes Empfehlung vor Marks Entscheidung
**Ergebnis:** 24 Entscheidungen (F01–F24), `SPEC_Freundschaftsspiele.md`, `Replit-Prompt_Freundschaftsspiele.md`

---

## Ausgangslage

Mark forderte die Oberfläche für den Bereich „Freundschaftsspiele" an: Spiele austragen und anfragen, offene Anfragen, Turniere, dazu dasselbe für die U21. Beim Ansetzen sollten Heim-/Gastmannschaft, Spielort, Verlängerung, Elfmeterschießen (auch direkt nach 90), Datum, Uhrzeit und Kommentar wählbar sein. Ausdrücklicher Wunsch: **Freundschaftsspiele gegen KI-Vereine**, die sofort zusagen. Community-Turniere als Tabelle oder Pokal waren als „vielleicht schaffen wir das auch" formuliert.

---

## Was vorab im Code nachgeschlagen wurde

Statt zu fragen, wurde das öffentliche Repo geklont und geprüft:

| Fund | Folge |
|---|---|
| `SimulatedMatch.match_type` kennt bereits `'freundschaft'` | Nur Testablage, kein Feature — grüne Wiese, aber das Feld ist da |
| KO-Modus V1 fertig: `simulate_match(is_cup=True)` liefert `decided_by`, 6. Wechsel in der Verlängerung, eingefrorene Konstanten (Freeze 14.06.2026) | Marks Toggles „Verlängerung / Elfmeterschießen" sind nahezu geschenkt. Neu ist nur „Elfmeter direkt nach 90" |
| Frische: −9,0/Spiel, gestaffelte Erholung 2/3/4 pro Tag, Verletzungsrisiko 0,008/90 | Wäre die natürliche Bremse gewesen — durch F01 entfallen |
| Kalender läuft auf echten Daten, `fixtures_by_date` ist ein Dict → nur ein Spiel pro Tag darstellbar | Motivierte ursprünglich eine Pflichtspieltag-Sperre; durch den Kalenderausschluss hinfällig |
| Minutentick per Celery Beat existiert (`showauction-tick-minuetlich`) | Anpfiff auf die Minute ist technisch vorhanden |
| U21 existiert nur als `InactivityRecord.squad_scope`; am `Player` kein Kaderfeld | Der U21-Kader musste als eigener Auftrag ausgeklammert werden |
| **`TacticSetup` ist unique je `(club, squad_scope)`** — ein Datensatz pro Verein, nicht pro Spiel | Der wichtigste Fund des Gesprächs. Ohne Trennung hätte ein Testspiel die Pflichtspiel-Taktik überschrieben |
| `compute_demand()` rechnet Nachfrage aus Kader-MW × Beliebtheit × Gegner × **Preisfaktor** | Grundlage der Preisprobe |
| Ruhmeshalle-Spec filtert `match_type='freundschaft'` hart aus allen Rekorden | Gesetzt, nicht verhandelbar |

---

## Verlauf der Entscheidungen

### Block A — Fundament

**F01 · Was ist ein Freundschaftsspiel mechanisch?**
Claude empfahl „echtes Spiel ohne Kasse" (volle Frische- und Verletzungskosten als Selbstregulierung). **Mark entschied: Sandkasten** — keine Frische, keine Verletzungen, kein Geld, keine Statistik. Damit war das Modul wirtschaftlich vollständig entkoppelt und Community-Turniere risikofrei; im Gegenzug fiel die eingebaute Bremse weg.

**F02 · Spiegel oder Labor?**
Mark wählte Spiegel mit Verletzten-Schalter. *Später korrigiert:* Verletzte können während ihrer Verletzung nicht aufgestellt werden, der Schalter entfällt. Frische wirkt als Eingang, wird aber nicht verbraucht. Gesperrte dürfen auflaufen.

**F03 · Terminierung**
Zunächst geparkt („erkläre ich später"), am Ende durch den Prototyp aufgelöst: Datum und Uhrzeit frei wählbar, Anfrage gilt bis zum Anpfiff.

**F04 · Aufstellung**
Claude empfahl einen eigenen Datensatz je Freundschaftsspiel neben dem Taktik-Bereich. **Mark korrigierte grundlegend:** Der Taktik-Bereich zeigt immer das nächste zeitlich anstehende Spiel — ist das ein FS, wird dort aufgestellt. Ohne Aufstellung greift der übliche Stärkemalus. Das führte direkt zu F23.

**F05 · Nachlese**
Voller Spielbericht, öffentlich, **ohne eigene Historie** („das regelt der Bereich schon"), Löschung beim Saison-Reset.

**F06 · Bremse**
Claude empfahl Limits auf offene Anfragen (10 gesamt, 3 je Verein). Zunächst angenommen, **später von Mark gestrichen**: „Kein Limit will ich erstmal so lassen, mal schauen ob es notwendig wird serverseitig, ich glaube allerdings nicht."

### Block B — Anfragen

**F07 · Anfrageablauf**
Anfrager bestimmt alles. Claude schlug zusätzlich einen Gegenvorschlag-Knopf vor; **Mark strich ihn**: „Coole Idee, aber zu viel des Guten. Hab ich bewusst weggelassen." Die Spielbörse deckt den Bedarf ab.

**F08 · KI-Verhalten**
Sofortige Zusage mit Terminschutz. Die Sperre „kein FS am Tag eines Pflichtspiels" entfiel später, weil Freundschaftsspiele gar nicht im Kalender erscheinen.

### Block C/D — Turniere

**F09 · Wer darf erstellen**
Claude empfahl „ein Turnier gleichzeitig je Manager". **Mark entschied: keine Begrenzung.**

**F10 · Formate**
Claude empfahl K.-o. zuerst, Liga danach. **Mark forderte alles:** Liga (einfache Runde oder Hin- und Rückrunde), Pokal ab 4 Mannschaften, Liga mit anschließendem K.-o.

**F11 · Feldgröße** — freie Teilnehmerzahl mit Freilosen; im Abgleich mit dem Prototyp auf dessen feste Auswahlwerte zurückgeführt.

**F12 · Zugang**
Claude schlug eine gemischte Mechanik aus offenen, eingeladenen und KI-Plätzen vor. **Mark vereinfachte:** Der Modus wird beim Erstellen gewählt — offen für alle, nur Einladung, oder Bewerbung.

**F13 · Unvolles Feld**
Ersteller startet manuell. **Marks Präzisierung:** Beim Start mit unvollem Feld öffnet sich ein Pop-up mit den KI-Vereinen, aus dem er die Auffüller selbst aussucht.

**F14 · Terminierung**
Claude empfahl einen Rhythmus beim Erstellen. **Mark entschied strenger:** Der Ersteller muss alle Runden vorab fest terminieren. Als Kompromiss wurde ein Takt-Helfer als Ausfüllhilfe ergänzt, Verschieben bleibt bis zum Anpfiff möglich.

**F15 · Ertrag**
Claude empfahl einen Eintrag im Managerprofil. **Mark entschied: nichts** — behielt sich aber vor, als Admin eine €-Prämie auszuloben, ausschließlich bevor das erste Spiel gespielt wurde. Der Prototyp ergänzte die Verteilung (Sieger / Top 3 / eigene Prozente).

### Block E — U21

**F16 · Was ist die U21?**
Claude empfahl einen Altersfilter ohne eigenen Kader. **Mark korrigierte: eigener Kader**, Spieler mit 21 oder jünger.

**F17 · Verhältnis zu den Profis** — getrennte Welten, globaler Umschalter.

**F18 · Zuständigkeit**
Der U21-Kader existiert nicht und gehört nicht zu diesem Auftrag; er kommt mit dem Jugendmodul, das Mark als nächsten Task anging. Daraus entstand der Anschlussvertrag `get_squad(club, scope)` mit definiertem Leerzustand.

### Block F/G — Kulisse, Oberfläche, Grenzfälle

**F19 · Kulisse**
Volle Kulisse. **Marks Erweiterung:** Schiedsrichter aus dem gesamten Pool aller 463, ohne Nations- oder Stufenfilter. Wetter wie am echten Tag.

**F20 · Oberfläche**
Claude schlug vier Reiter vor. **Marks entscheidender Zusatz:** „So kann man auch seine Eintrittspreise testen." Damit wurde die **Preisprobe** zum zweiten Hauptzweck des Moduls — und die Zuschauer-Aufschlüsselung im Bericht zur Pflicht.

**F21 · Grenzfälle** — vier Fälle in einem Zug bestätigt.

---

## Abgleich mit dem Claude-Design-Prototyp

Mark lieferte einen bereits fertigen, klickbaren Prototyp (`Freundschaftsspiele-Standalone.html`) nebst Context Pack und eigenem Replit-Prompt. Der Abgleich ergab:

**Deckungsgleich:** F01, F07, F08, F09, F10, F12, F14, F15, F17.

**Neu im Design, übernommen:**

| | |
|---|---|
| **Spielbörse** | Offenes Inserat statt gerichteter Anfrage — der stärkste Zusatz. Löst das Problem, das Claude umständlich über Einladungen gelöst hatte, und macht den Gegenvorschlag entbehrlich |
| **Kein Kalendereintrag** | Räumte das Kollisionsproblem aus F06/F08 vollständig aus |
| **Prämienverteilung** | Sieger / Top 3 / eigene Prozente |
| **Neutrale Stadien als kuratierte Liste** | Berlin, Hamburg, Köln |
| **Teilnehmer entfernen vor Start**, **Historie mit Blättern** | |

**Widersprüche, alle zugunsten des Designs aufgelöst:** kein Gegenvorschlag · feste Feldgrößen statt freier Zahl · keine Anfragenlimits · U21-Umschalter zunächst als Kopie.

**Fünf Lücken, die ergänzt werden mussten:**

1. **KI-Vereine in Turnieren und die Startmechanik** — der Prototyp kannte nur „Beitreten". Bei zwei aktiven Managern auf 26 Vereine wäre kein einziges Turnier zustande gekommen
2. **Aufstellung** — kam im gesamten Prototyp nicht vor
3. **Verletzten-Schalter** — durch Marks Korrektur ersatzlos gestrichen
4. **Spielbericht** — die leeren Links waren nur die Reichweitengrenze von Claude Design, keine Designentscheidung
5. **Datenmodell** — der Design-Prompt schlug `FriendlyRequest` + `FriendlyMatch` vor; das Ergebnis muss aber in `SimulatedMatch` landen, sonst wird der fertige Spielbericht ein zweites Mal gebaut

---

## Die beiden folgenreichsten Erkenntnisse

**1 · `TacticSetup` ist ein Datensatz je Verein, nicht je Spiel.**
Aus Marks Vorgabe, die Aufstellung über den bestehenden Taktik-Bereich laufen zu lassen, folgte eine Falle: Ein mittags getestetes System wäre nachmittags in der Liga aufgelaufen. Gelöst über ein neues Feld `context` und eine erweiterte Unique-Constraint (**F23**). Für den Nutzer unsichtbar, für die Datenbank eine Spalte — und die Voraussetzung dafür, dass im Sandkasten überhaupt etwas riskiert wird.

**2 · Das Testspiel ist die Preisprobe.**
Marks Nebenbemerkung zur Oberfläche gab dem Modul seinen zweiten Zweck. In einem Spiel, in dem der Manager die Nachfrageformel nicht kennt, war der einzige Weg zur richtigen Preisgestaltung bisher: raten, ein Heimspiel abwarten, in zwei Wochen korrigieren. Jetzt: Testspiel gegen einen KI-Verein, Zahl ablesen, anpassen. Bedingung ist, dass der **Gegnerfaktor** im Bericht ausgewiesen wird — sonst zieht man aus der Zahl den falschen Schluss.

---

## Offene Punkte nach diesem Gespräch

- **U21-Kader** — eigener Auftrag, nächster Task. Anschluss über `get_squad(club, scope)` ist definiert
- **Spielbericht-Verdrahtung** — im Prototyp bewusst leer, in der Spec spezifiziert
- **Einladungscode- und Bewerbungs-Flow** — im Prototyp nur als Knöpfe angedeutet
- **Abgleich der Prototyp-Klassen mit den echten Django-Templates** — steht aus, gehört in den Replit-Lauf
