# SPEC_Freundschaftsspiele.md

**Projekt:** BLUEPRINT · Online-Fußballmanager (playwebsoccer.de)
**Modul:** Freundschaftsspiele, Spielbörse und Community-Turniere
**Stand:** 26.08.2026 · **Status:** entscheidungsreif, implementierungsfertig
**Vorlage Oberfläche:** `Freundschaftsspiele-Standalone.html` (Claude Design, separat an Replit)
**Entscheidungslog:** Anhang A (F01–F24)

---

## 1. Zweck und Abgrenzung

Der Bereich erlaubt Managern, außerhalb des Pflichtspielbetriebs Spiele anzusetzen: gegen andere Manager, gegen KI-Vereine, als offenes Inserat oder als selbst erstellter Wettbewerb.

**Freundschaftsspiele sind ein Sandkasten.** Sie erzeugen keinen Frischeverlust, keine Verletzungen, keine Sperren, keine Einnahmen und keine Pflichtspielstatistik. Sie sind damit vollständig von der Simulationswirtschaft entkoppelt und können weder Rekorde noch Bilanzen noch den Transfermarkt beeinflussen.

**Was sie dafür leisten:**

1. **Erkenntnis über die eigene Mannschaft.** In BLUEPRINT sind Spielerstärken geheim. Das Testspiel ist das einzige Instrument, mit dem ein Manager gefahrlos herausfindet, was eine Aufstellung leistet.
2. **Preisprobe.** Zuschauerzahlen werden vollständig berechnet und im Spielbericht ausgewiesen, ohne dass Geld fließt. Ein Manager kann damit seine Eintrittspreise erproben, statt sie über echte Heimspiele zu erraten.
3. **Community.** Selbst erstellte Turniere geben Managern einen Anlass, miteinander zu spielen, statt nebeneinander zu klicken.

**Ausdrücklich nicht Gegenstand dieses Moduls:**

- Der **U21-Kader**. Er entsteht im Jugendmodul. Dieses Modul konsumiert ihn nur (Kap. 13).
- Der **Echtzeit-Live-Ticker**. Freundschaftsspiele werden simuliert und erzeugen den vorhandenen Spielbericht.
- Jede Form von **Wertung, Rangliste oder Statistikseite** über Freundschaftsspiele.

---

## 2. Begriffe

| Begriff | Bedeutung |
|---|---|
| **Freundschaftsspiel (FS)** | Ein Spiel außerhalb von Liga, Pokal und internationalen Wettbewerben |
| **Gerichtete Anfrage** | FS-Angebot an einen konkreten Verein (Reiter „Spiel ansetzen") |
| **Inserat** | FS-Angebot ohne Gegner, offen für alle Manager (Reiter „Spielbörse") |
| **Turnier** | Von einem Manager erstellter Wettbewerb aus mehreren FS |
| **Kader-Kontext** (`squad_scope`) | `pro` oder `u21` — trennt zwei vollständig getrennte Welten |
| **Regelsatz** | Kombination aus Verlängerung, Elfmeterschießen und Elfmeter-nach-90 |

---

## 3. Datenmodell

### 3.1 `FriendlyFixture` — trägt den gesamten Lebenslauf

Ein einziges Objekt für Anfrage, Inserat, angesetztes Spiel und Turnierpartie. Bei der Zusage entsteht kein neues Objekt, es ändert sich nur der Zustand (F24).

| Feld | Typ | Bemerkung |
|---|---|---|
| `squad_scope` | CharField | `pro` \| `u21` |
| `sender_club` | FK Club | Ersteller der Anfrage bzw. des Inserats |
| `target_club` | FK Club, null | `null` = offenes Inserat (Spielbörse) |
| `offered_role` | CharField, blank | `heim` \| `gast` — nur bei Inserat: welche Rolle der Ersteller einnimmt |
| `venue_type` | CharField | `heim` \| `gast` \| `neutral` |
| `neutral_stadium` | FK NeutralVenue, null | nur bei `venue_type='neutral'` |
| `kickoff_at` | DateTimeField | Datum + Uhrzeit, frei wählbar |
| `extra_time` | Boolean | Verlängerung |
| `penalties` | Boolean | Elfmeterschießen |
| `penalties_after_90` | Boolean | Elfmeter direkt nach 90 — schließt `extra_time` aus |
| `comment` | CharField(200), blank | für die Gegenseite sichtbar |
| `tournament` | FK CommunityTournament, null | leer bei Einzelspiel |
| `tournament_round` | FK TournamentRound, null | leer bei Einzelspiel |
| `status` | CharField | siehe Kap. 4 |
| `simulated_match` | FK SimulatedMatch, null | leer bis zum Anpfiff |
| `created_at`, `resolved_at` | DateTime | |

**Constraints:**

- `penalties_after_90=True` erfordert `penalties=True` und `extra_time=False` (CheckConstraint).
- `sender_club != target_club` (CheckConstraint).
- `neutral_stadium` gesetzt genau dann, wenn `venue_type='neutral'`.
- Index auf `(status, kickoff_at)` — der Minutentick liest ausschließlich darüber.

### 3.2 `NeutralVenue` — kuratierte neutrale Spielorte

| Feld | Typ |
|---|---|
| `name` | CharField — z. B. „Olympiastadion Berlin" |
| `city` | CharField |
| `capacity` | PositiveInteger |
| `is_active` | Boolean |

Gepflegt im Creator-Mode. Startbestand: Berlin, Hamburg, Köln (wie im Prototyp). **Stadien anderer Vereine stehen nicht zur Auswahl** — nur die beiden Beteiligten und die kuratierte Liste.

### 3.3 `CommunityTournament`

| Feld | Typ | Bemerkung |
|---|---|---|
| `name` | CharField | |
| `creator` | FK ManagerProfile | |
| `squad_scope` | CharField | `pro` \| `u21` — gemischte Felder gibt es nicht |
| `format` | CharField | `liga` \| `pokal` \| `gruppen_ko` |
| `double_round` | Boolean | nur bei `liga`: Hin- und Rückrunde |
| `max_teams` | PositiveSmallInteger | feste Auswahl je Format (Kap. 11.2) |
| `access` | CharField | `offen` \| `code` \| `bewerbung` |
| `invite_code` | CharField, blank | nur bei `access='code'` |
| `extra_time`, `penalties`, `penalties_after_90` | Boolean | gelten für **alle** Partien des Turniers |
| `venue_type` | CharField | wie 3.1; `neutral` gilt dann für alle Partien |
| `prize_total` | Decimal, null | nur durch Admin (Kap. 12) |
| `prize_split` | CharField | `sieger` \| `top3` \| `custom` |
| `prize_custom` | JSON | `{1: 50, 2: 30, 3: 20}` bei `custom` |
| `is_official` | Boolean | Kennzeichnung „Offizielles Turnier" bei Admin-Turnieren |
| `status` | CharField | `anmeldung` \| `laufend` \| `abgeschlossen` \| `abgesagt` |
| `started_at`, `finished_at` | DateTime, null | |
| `winner_club` | FK Club, null | |

**Constraint:** `prize_total` darf nicht mehr geändert werden, sobald ein `FriendlyFixture` des Turniers `status='gespielt'` hat (Kap. 12.2).

### 3.4 `TournamentParticipant`

| Feld | Typ | Bemerkung |
|---|---|---|
| `tournament` | FK | |
| `club` | FK Club | |
| `is_ai` | Boolean | vom Ersteller eingesetzter KI-Verein |
| `group_label` | CharField, blank | `A`, `B`, … — leer bei einfacher Liga |
| `seed` | PositiveSmallInteger, null | Auslosungsposition, beim Start vergeben |
| `joined_at` | DateTime | |

**Unique:** `(tournament, club)`.

### 3.5 `TournamentRound`

| Feld | Typ | Bemerkung |
|---|---|---|
| `tournament` | FK | |
| `order` | PositiveSmallInteger | 1, 2, 3 … |
| `label` | CharField | „1. Spieltag", „Viertelfinale", „Finale" |
| `kickoff_at` | DateTime | vom Ersteller festgelegt, änderbar bis zum Anpfiff |
| `stage` | CharField | `liga` \| `gruppe` \| `ko` |
| `is_played` | Boolean | |

### 3.6 `TournamentStanding` — Tabelle, von Anfang an gruppenfähig

| Feld | Typ |
|---|---|
| `tournament`, `club` | FK |
| `group_label` | CharField, blank |
| `played`, `won`, `drawn`, `lost` | PositiveSmallInteger |
| `goals_for`, `goals_against`, `points` | Integer |

Das Feld `group_label` existiert von Beginn an, auch wenn die einfache Liga es leer lässt. Es kostet heute eine Spalte und spart bei Gruppen + K.-o. den Umbau.

### 3.7 Änderungen an bestehenden Modellen

**`TacticSetup`** — neues Feld `context` (F23):

```python
context = models.CharField(max_length=12, default='pflicht',
                           choices=[('pflicht','Pflichtspiel'),
                                    ('freundschaft','Freundschaftsspiel')])
```

Die Unique-Constraint `unique_club_tactic_setup_scope` wird von `(club, squad_scope)` auf `(club, squad_scope, context)` erweitert. Migration legt für jeden bestehenden Datensatz `context='pflicht'` fest; der Freundschafts-Datensatz entsteht beim ersten Aufruf als Kopie des Pflichtsatzes.

**Begründung:** Ohne Trennung ist die Testaufstellung dieselbe Zeile wie die Pflichtspielaufstellung. Ein Manager, der mittags eine Dreierkette testet, liefe nachmittags in der Liga in derselben Dreierkette auf. Zwei Datensätze machen die Pflichtspiel-Taktik unzerstörbar — die Voraussetzung dafür, dass im Sandkasten überhaupt etwas riskiert wird.

**`SimulatedMatch`** — keine Strukturänderung. `match_type='freundschaft'` und `referee` existieren bereits.

---

## 4. Zustandsautomat `FriendlyFixture`

```
                    ┌──────────────┐
   gerichtete       │  ANGEFRAGT   │  Gegner mit Manager
   Anfrage      ───►└──────┬───────┘
                           │ annehmen
   Inserat      ───►┌──────▼───────┐
   (erste Annahme)  │   GEPLANT    │◄─── KI-Gegner (sofort)
                    └──────┬───────┘◄─── Turnierstart
                           │ kickoff_at erreicht
                    ┌──────▼───────┐
                    │   GESPIELT   │  simulated_match gesetzt
                    └──────────────┘
```

**Endzustände neben `GESPIELT`:**

| Status | Auslöser |
|---|---|
| `ABGELEHNT` | Empfänger lehnt ab |
| `ZURUECKGEZOGEN` | Ersteller zieht Anfrage oder Inserat zurück (nur solange `ANGEFRAGT`) |
| `VERFALLEN` | `kickoff_at` erreicht, ohne dass jemand angenommen hat |
| `NICHT_AUSGETRAGEN` | Beim Anpfiff stehen auf einer Seite weniger als 11 einsatzfähige Spieler |

**Regeln:**

- Ab `GEPLANT` ist nichts mehr änderbar und nichts mehr absagbar. Wer nicht aufstellt, spielt mit der übernommenen Aufstellung und Stärkemalus (Kap. 9).
- Es gibt **keinen Gegenvorschlag** (F07 korrigiert). Wer andere Bedingungen will, stellt eine eigene Anfrage oder nutzt die Spielbörse.
- Es gibt **keine Anfragenlimits** (F06 gestrichen). Sollte Missbrauch auftreten, wird serverseitig nachgesteuert — nicht vorgebaut.

---

## 5. Spiel ansetzen — gerichtete Anfrage

**Formularfelder** (Reihenfolge wie im Prototyp):

1. Heimmannschaft, Gastmannschaft — der eigene Verein muss eine der beiden Seiten sein, Heim ≠ Gast
2. Spielort: Heimstadion · Stadion des Gegners · Neutraler Platz (dann Auswahl aus `NeutralVenue`)
3. Datum, Uhrzeit — frei wählbar
4. Regeln: „Mit Verlängerung" · „Mit Elfmeterschießen" · „Elfmeterschießen direkt nach 90 Minuten"
5. Kommentar (optional, für den Gegner sichtbar)

**Regelabhängigkeiten in der Oberfläche:**

- „Elfmeterschießen direkt nach 90" ist nur wählbar, wenn „Mit Elfmeterschießen" an ist.
- „Elfmeterschießen direkt nach 90" und „Mit Verlängerung" schließen sich gegenseitig aus.

**Verhalten nach Gegnerauswahl** (Live-Hinweis unter dem Feld):

| Gegner | Hinweis | Folge |
|---|---|---|
| Verein **mit** Manager | „Manager {Name} muss die Anfrage annehmen" (grau) | `FriendlyFixture` mit `status=ANGEFRAGT`. Erscheint beim Gegner unter Eingehend, beim Sender unter Ausgehend |
| Verein **ohne** Manager (KI) | „KI-Verein — nimmt sofort an" (grün) | `status=GEPLANT` direkt beim Absenden. **Kein Eintrag in der Anfrageliste**, keine Wartezeit. Bestätigung: „Spiel angesetzt" mit Termin |

**Terminkollision:** Ein Verein hat nie zwei Spiele zur selben Uhrzeit im selben Kader-Kontext. Geprüft wird **bei der Zusage**, nicht bei der Anfrage — zwei Anfragen dürfen auf dieselbe Uhrzeit zeigen, die zweite Zusage schlägt mit klarer Meldung fehl. Bei KI-Gegnern wird direkt beim Absenden geprüft.

**Keine Pflichtspieltag-Sperre.** Da Freundschaftsspiele nicht im Kalender erscheinen (Kap. 14.4), kann ein FS ein Pflichtspiel nicht aus der Anzeige verdrängen. Die ursprünglich vorgesehene Regel „kein FS am Tag eines Pflichtspiels" entfällt ersatzlos.

---

## 6. Spielbörse — offenes Inserat

Ein `FriendlyFixture` ohne `target_club`.

**Formular „Partie ausschreiben":** Ich spiele als (Heim/Gast) · Spielort (Mein Stadion / Stadion des Annehmenden / Neutraler Platz — immer alle drei wählbar) · Datum · Uhrzeit · Regeln · Kommentar.

**Liste „Offene Partien":** Inserate aller Manager mit Verein, Rolle, Termin-Chip (cyan), Ort-Chip (grün) und Regel-Chips (neutral).

**Annahme:** Wer zuerst annimmt, spielt. Beim Annehmen wird `target_club` gesetzt, `status` auf `GEPLANT` und das Inserat verschwindet aus der Liste. Die Annahme läuft in `transaction.atomic()` mit `select_for_update()` auf der Zeile — ein zweiter, gleichzeitiger Klick bekommt „Diese Partie wurde bereits vergeben".

**Eigene Inserate** sind markiert („Dein Inserat") und zurückziehbar.

**Verfall:** Zum Spieltermin, automatisch durch denselben Minutentick, der die Anpfiffe abarbeitet.

**KI-Vereine nehmen keine Inserate an.** Die Börse ist eine Manager-zu-Manager-Einrichtung; wer gegen die KI spielen will, nutzt „Spiel ansetzen", wo es sofort funktioniert.

---

## 7. Offene Anfragen

Zwei Abschnitte nebeneinander:

**Eingehend** — Verein, Rahmenbedingungen als Chips (Termin cyan, Ort grün, Regeln neutral), Kommentar, Frist-Hinweis „Gültig bis zum Spieltermin". Aktionen: **Annehmen** · **Ablehnen**.

**Ausgehend** — Status „Ausstehend", Aktion **Zurückziehen**.

Der Reiterkopf trägt die Anzahl eingehender Anfragen in Grün.

---

## 8. Simulation und Anpfiff

### 8.1 Der Tick

Neuer Celery-Beat-Eintrag nach dem Muster von `showauction-tick-minuetlich`:

```python
'friendly-tick-minuetlich': {
    'task': 'game.tasks.run_management_command',
    'schedule': 60,
    'args': ('run_friendly_tick',),
},
```

Der Command arbeitet in einem Durchlauf:

1. Alle `FriendlyFixture` mit `status=ANGEFRAGT` und `kickoff_at <= now` → `VERFALLEN`.
2. Alle mit `status=GEPLANT` und `kickoff_at <= now` → simulieren (8.2).
3. Turnierrunden, deren Partien alle gespielt sind → Tabelle bzw. nächste K.-o.-Runde fortschreiben (Kap. 11.5).

Idempotent: Jede Zeile wird per bedingtem UPDATE (`status=GEPLANT` → `SIMULIERT_LAEUFT`) geclaimt, bevor gerechnet wird. Zwei parallele Ticks können dieselbe Partie nicht doppelt spielen.

Zusätzlich ein **Lazy-Pfad** in der Übersicht: Wer die Seite öffnet und eine fällige, noch nicht gespielte Partie hat, löst denselben Code für genau diese Partie aus. Der Tick ist damit die Absicherung, nicht die einzige Quelle.

### 8.2 Aufruf der Engine

```python
report = simulate_match(
    home_club, away_club,
    home_strength_malus=..., away_strength_malus=...,
    is_cup=False,                 # ersetzt durch explizite Flags, siehe unten
    weather=weather_for(venue, kickoff_at),
)
```

`simulate_match` bekommt zwei neue Schlüsselwortargumente, die `is_cup` ablösen (rückwärtskompatibel: `is_cup=True` ⇒ `extra_time=True, penalties=True`):

| `extra_time` | `penalties` | Ergebnis |
|---|---|---|
| False | False | Unentschieden möglich. Standard für Liga-Turniere und Einzelspiele |
| True | False | Verlängerung, danach Unentschieden möglich |
| True | True | Wie Pokal — Step 7 unverändert |
| False | True | **Elfmeterschießen direkt nach 90** — Verlängerungsphase wird übersprungen |

Der vierte Fall ist die einzige echte Neuerung an der Engine: `_simulate_extra_time_minutes()` wird ausgelassen, `_simulate_penalty_shootout()` direkt aufgerufen. `decided_by='penalties'`, `home_goals_et == home_goals_90`.

**Die eingefrorenen Balancing-Konstanten des KO-Modus und der Match-Engine V2 werden nicht angefasst.**

### 8.3 Was beim Speichern passiert — und was nicht

**Wird geschrieben:**

- `SimulatedMatch` über `create_numbered(season=…)` mit `match_type='freundschaft'`, `report_data=report`, `referee=…`
- `FriendlyFixture.simulated_match` und `status='GESPIELT'`
- Bei Turnierpartien: `TournamentStanding` bzw. Fortschreibung des K.-o.-Baums

**Wird ausdrücklich nicht aufgerufen:**

| Nicht aufrufen | Modul |
|---|---|
| `apply_match_freshness_losses()` | `freshness_service.py` |
| Verletzungswürfel (`match_engine.py`, `chosen_days`) | Ergebnis wird verworfen |
| `PlayerSeasonStat`-Schreibpfad | keine Zeilen mit `competition='Freundschaft'` |
| `record_matchday_revenue()` / `book()` | keine `MatchdayRevenue`-Zeile, keine Buchung |
| Sperren- und Kartenkonto | Karten fallen im Bericht, erzeugen aber keine Sperre |
| `matchday_xi.py` (Elf des Spieltags) | |
| Ruhmeshallen-Recompute | greift ohnehin nicht, da `match_type` gefiltert wird |

**Frische wirkt als Eingang, nicht als Ausgang** (F02): Die Engine liest `PlayerStrengthProfile.freshness` wie immer, also spielt eine müde Mannschaft auch im Testspiel müde. Nur der Abzug danach entfällt. So ist das Ergebnis eine Aussage über die Mannschaft, die man tatsächlich hat.

---

## 9. Aufstellung und Taktik

**Die Aufstellung erfolgt im bestehenden Taktik-Bereich** (F04). Dieser zeigt immer das nächste zeitlich anstehende Spiel — steht um 15:30 ein Freundschaftsspiel an, ist das die Partie, für die dort aufgestellt wird.

**Auswahl des Datensatzes:** Der Taktik-Bereich lädt `TacticSetup` mit `context='freundschaft'`, wenn das nächste Spiel ein FS ist, sonst mit `context='pflicht'`. Für den Nutzer ist der Wechsel unsichtbar; im Kopf der Seite steht wie gewohnt, um welches Spiel es geht — Wettbewerb, Gegner, Anstoß.

**Bestätigung und Malus:** Wie im Pflichtspiel. Wird nicht bestätigt, läuft die gespeicherte Aufstellung mit **Stärkemalus** auf, identisch zum bestehenden Verhalten (`lineup_malus`). Für Freundschaftsspiele tritt an die Stelle von `lineup_confirmed_matchday` die ID des `FriendlyFixture`.

**Verletzte** (F02 korrigiert): Gesperrt wie überall. Ein Spieler mit `ws_injury_days_remaining > 0` erscheint nicht in der Aufstellung. Einen Ausnahmeschalter gibt es nicht.

**Gesperrte Spieler** dürfen im FS auflaufen. Eine Sperre gilt für den Wettbewerb, in dem sie ausgesprochen wurde.

**KI-Vereine** stellen über `default_tactics.py` auf, mit `squad_scope` als Parameter.

**Mindestbesetzung:** Bei der Zusage wird geprüft, ob beide Seiten mindestens 11 einsatzfähige Spieler stellen. Meldung mit konkreter Zahl („Du hast 7 spielberechtigte Spieler"). Fällt zwischen Zusage und Anpfiff jemand aus, füllt `default_tactics.py` auf; reicht es dann nicht mehr, endet die Partie als `NICHT_AUSGETRAGEN` (im Turnier: Niederlage der betroffenen Seite, Kap. 15).

---

## 10. Spielbericht und Kulisse

**Der Spielbericht eines Freundschaftsspiels ist identisch zu jedem anderen Spielbericht.** Er entsteht aus `report_data` über den bestehenden Berichts-Screen — es wird nichts nachgebaut, nichts vereinfacht und nichts weggelassen.

**Alle Berichte sind öffentlich** (F05). Wer wissen will, wie ein möglicher Gegner spielt, darf dessen Testspiele lesen. In einem Spiel mit geheimen Spielerstärken ist das eine echte Währung — und es macht das Testspiel zu einer Abwägung.

### 10.1 Schiedsrichter

Zufällige Ziehung aus dem **gesamten Pool aller 463 Schiedsrichter**, ohne Nations- oder Stufenfilter (F19). Die Zuordnungsformel mit `domestic_tier` gilt weiterhin ausschließlich für Pflichtspiele.

Das ist die einzige Stelle im Spiel, an der ein Manager einen Schiedsrichter aus Uruguay oder Japan zu sehen bekommt — für einen Spielerkreis, der Schiedsrichter-Tendenzen liest, ein eigener kleiner Anreiz.

### 10.2 Wetter

Wie am echten Tag am echten Ort, über das bestehende Wettersystem. Der nächtliche Tick würfelt sieben Tage im Voraus; für Termine darüber hinaus greift der normale Nachfüllmechanismus zum Anpfiff.

Bei `venue_type='neutral'` gilt der Ort des `NeutralVenue`.

### 10.3 Zuschauer und Preisprobe

`compute_demand(club, stadium, opponent_club=…)` wird **vollständig gerechnet** und im Bericht ausgewiesen, aber weder gebucht noch als `MatchdayRevenue` gespeichert.

Der Bericht zeigt die **Aufschlüsselung**, nicht nur die Gesamtzahl:

| | |
|---|---|
| Basisnachfrage | aus Kader-Marktwert |
| Beliebtheitsfaktor | |
| **Gegnerfaktor** | zwingend sichtbar |
| Je Kategorie (Steh / Sitz / VIP) | Kapazität · Preis · Preisfaktor · Zuschauer |
| Auslastung gesamt | in Prozent |

**Warum der Gegnerfaktor ausgewiesen werden muss:** Ein Testspiel gegen einen schwachen Gegner zieht weniger Zuschauer als das nächste Heimspiel gegen den Tabellenführer. Wer nur die Endzahl liest, zieht den falschen Schluss und senkt seine Preise grundlos. Die Aufschlüsselung macht aus einer Zahl ein Werkzeug.

**Gerechnet wird mit den echten Preisen** aus dem Stadionbereich. Es gibt kein separates Testpreisfeld — sonst testet man etwas anderes, als man später einstellt.

Bei `venue_type='neutral'` entfällt die Zuschauerberechnung; es wird die Kapazität des neutralen Spielorts mit einer pauschalen Auslastung angezeigt.

### 10.4 Heimvorteil

Wirkt normal wie im Pflichtspiel. Bei `venue_type='neutral'` für beide Seiten nicht. Damit ist die Wahl von Heim und Gast eine Entscheidung mit Wirkung und keine Formularangabe ohne Folgen.

---

## 11. Community-Turniere

### 11.1 Wer darf erstellen

**Jeder Manager, ohne Anzahlbegrenzung** (F09). Der Ersteller muss nicht selbst mitspielen. Turniere, die ein Admin erstellt, tragen die Kennzeichnung „Offizielles Turnier" (`is_official`).

### 11.2 Formate und Feldgrößen

| Format | Feldgrößen | Besonderheit |
|---|---|---|
| **Liga** | 4 · 6 · 8 · 10 · 16 | Hin- und Rückrunde wählbar |
| **Pokal** | 4 · 8 · 16 | reines K.-o. |
| **Gruppen + K.-o.** | 8 (2 Gruppen) · 16 (4 Gruppen) | 3 Gruppenspieltage, danach Endrunde |

Bei ungerader Teilnehmerzahl in der Liga setzt pro Spieltag ein Verein aus.

### 11.3 Zugang und Teilnehmer

Der Zugangsmodus wird beim Erstellen gewählt (F12):

| Modus | Ablauf |
|---|---|
| **Offen für alle** | Turnier steht in der Liste, Manager treten bei, Platz weg = weg |
| **Einladungscode** | Beitritt nur mit Code bzw. Link |
| **Bewerbung** | Manager bewerben sich, der Ersteller bestätigt oder lehnt ab |

**Teilnehmer entfernen** ist dem Ersteller und Admins möglich, aber **nur vor dem Turnierstart**.

Ein Verein darf in mehreren Turnieren gleichzeitig antreten. Terminkonflikte fängt die Uhrzeitprüfung aus Kap. 5 ab.

### 11.4 Start und KI-Auffüllung

**Der Startknopf gehört dem Ersteller.** Er startet, wann er will — auch mit unvollständigem Feld (F13).

Ist das Feld beim Start nicht voll, öffnet sich ein **Auswahl-Pop-up mit allen verfügbaren KI-Vereinen** (F22). Der Ersteller sucht sich die Auffüller selbst aus; sie werden als `TournamentParticipant` mit `is_ai=True` eingetragen und sagen sofort zu.

Alternativ kann er das Feld verkleinern; im Pokal entstehen dann Freilose in Runde 1.

**Diese Mechanik ist nicht optional.** Bei zwei aktiven Managern auf 26 Vereine käme sonst kein einziges Turnier zustande.

**Automatische Absage:** 14 Tage nach dem Erstellen ohne Start und ohne einen einzigen bestätigten Teilnehmer außer dem Ersteller → `status='abgesagt'`, verschwindet aus der Liste.

### 11.5 Auslosung und Spielplan

- **Reine Zufallsauslosung, keine Setzliste** (F11). In einem Spiel mit geheimen Stärken wäre jede Setzliste eine Auskunft über Spielstärken.
- Der **K.-o.-Baum wird beim Turnierstart vollständig ausgelost**, nicht Runde für Runde. Jeder sieht sofort seinen möglichen Weg bis ins Finale.
- **Keine Auswärtstorregel.**
- Bei Hin- und Rückspiel im K.-o. entscheidet das Gesamtergebnis, bei Gleichstand greifen die Turnierregeln (Verlängerung / Elfmeter).
- **Alle Partien eines Turniers laufen mit demselben Regelsatz**, der beim Erstellen gesetzt wurde. Kein Spiel hat eigene Schalter.

**Heimrecht:** Pokal in einem Spiel → per Los. Hin- und Rückspiel → getauscht. Liga → nach Spielplan. Endrunde nach Gruppenphase → Los. Neutraler Platz ist als Turniereinstellung wählbar und gilt dann für alle Partien.

### 11.6 Terminierung

**Der Ersteller terminiert alle Runden vorab** (F14). Das Turnier lässt sich erst starten, wenn jede Runde bzw. jeder Spieltag Datum und Uhrzeit trägt.

Im Wizard-Schritt 3 wird die Rundenzahl aus Format und Feldgröße errechnet und als Zeilenliste angelegt:

- Liga: `(n − 1) × (Rückrunde ? 2 : 1)` Spieltage
- Pokal: Achtel- / Viertel- / Halbfinale / Finale je nach Feldgröße
- Gruppen + K.-o.: 3 Gruppenspieltage + Endrunde

Ein **Takt-Helfer** über der Liste (Startzeitpunkt + Abstand) füllt alle Zeilen auf einen Klick vor. Jede Zeile bleibt danach einzeln änderbar — der Helfer ist eine Ausfüllhilfe, keine Automatik.

**Verschieben** ist möglich, solange die betroffene Runde nicht angepfiffen ist. Teilnehmer werden benachrichtigt.

### 11.7 Detailansicht

- **Liga:** Tabelle (# / Verein / Sp / S / U / N / Tore / Pkt.), ohne Formkurve, eigener Verein cyan hervorgehoben
- **Pokal:** Pokalbaum (Achtel → Viertel → Halbfinale → Finale), gespielte Partien mit Ergebnis, klickbar zum Spielbericht
- **Gruppen + K.-o.:** Gruppentabellen nebeneinander, darunter der Baum
- **Spielplan:** Rundenauswahl als Chips; gespielte Runden mit Ergebnis und Bericht-Link, künftige mit änderbarem Termin
- **Teilnehmerliste** mit „Entfernen" (nur vor Start), KI-Teilnehmer erkennbar gekennzeichnet
- **Prämien-Panel** (Kap. 12)

---

## 12. Prämien

### 12.1 Wer und wie viel

**Nur Admins** können eine Prämie ausloben (F15). Für normale Community-Turniere gibt es keinen automatischen Ertrag: keine Preisgelder, keine Titel, keine Wirkung auf Level, Highscore oder Präsidentenzufriedenheit.

Eingabe: Gesamtbetrag in € plus Verteilung.

| Verteilung | |
|---|---|
| **Nur der Sieger** | 100 % |
| **Top 3** | 50 / 30 / 20 |
| **Eigene Verteilung** | Platz 1–3 in Prozent, Summe muss 100 ergeben (validiert) |

Die Prämie steht öffentlich in der Turnierausschreibung, sobald sie gesetzt ist — wer beitritt, weiß, worum es geht. Darstellung als Orange-Gradient-Badge.

### 12.2 Die Sperre

Prämie vergeben oder ändern ist möglich **bis zum ersten gespielten Spiel** — auch nachträglich am laufenden Turnier. Sobald eine Partie `status='GESPIELT'` hat, ist das Feld gesperrt.

**Die Sperre wird in der View hart geprüft, nicht nur ausgeblendet.** Sonst ließe sich ein Turnier erst laufen lassen und dann rückwirkend versüßen.

Anzeige nach der Sperre: gelber Hinweis „Gesperrt — der 1. Spieltag ist gespielt".

### 12.3 Auszahlung

Nach Turnierende über `booking.book()`:

```python
book(club, typ='TURNIER_PRAEMIE', betrag=anteil,
     beschreibung=f'Prämie {tournament.name} — Platz {platz}',
     referenz_typ='turnier_praemie', referenz_id=tournament.id,
     pflicht=True)
```

**Idempotenz:** Vor der Buchung wird geprüft, ob für diesen Verein bereits eine Zeile mit `referenz_typ='turnier_praemie'` und `referenz_id=tournament.id` existiert. Alle Buchungen eines Turniers laufen gemeinsam in `transaction.atomic()` — sonst markiert ein Teilfehler das Turnier als ausgezahlt und der Rest geht bei einem erneuten Lauf verloren (bekanntes Muster aus `economy-design-principles.md`).

Neuer Typ in `FinanceTransaction.TYP_CHOICES`.

### 12.4 Wirtschaftliche Einordnung

Dies ist die **einzige Stelle im Modul, an der neues Geld entsteht.** Solange ausschließlich der Admin den Hahn öffnet, ist es eine bewusste Ausschüttung wie ein Sponsorenbonus, kein Systemleck.

Die Beträge erscheinen im selben Bericht wie die Prämien der Pflichtwettbewerbe, damit über eine Saison nachvollziehbar bleibt, wie viel eingespeist wurde.

---

## 13. U21

**Profis und U21 sind getrennte Welten** (F17). Getrennt sind die Daten, nicht die Oberfläche: Alle fünf Reiter gelten für beide, umgeschaltet wird über den globalen Umschalter im Seitenkopf. Der aktive U21-Modus wird durch ein deutlich sichtbares grünes Badge „U21-MODUS" angezeigt.

Technisch ist die Trennung das Feld `squad_scope` an `FriendlyFixture`, `CommunityTournament` und `TacticSetup`. Alle Listen und Formulare filtern darauf.

**Der U21-Kader gehört nicht zu diesem Auftrag** (F18). Er entsteht im Jugendmodul.

**Anschlussvertrag:**

```python
get_squad(club, scope='u21') -> list[Player]
```

Solange das Jugendmodul fehlt, liefert die Funktion eine **leere Liste**. Der U21-Bereich zeigt dann seinen Leerzustand:

> „Die U21 hat noch keinen Kader — der Jugendspielbetrieb ist in Arbeit."

Kein gesperrter Reiter, keine Fehlermeldung, kein toter Klick. Sobald das Feld existiert, wird eine Funktion umgestellt und der gesamte Bereich ist ohne weitere Arbeit lebendig — Anfragen, Börse, Turniere, Termine und Berichte sind bereits fertig, weil es dieselben Objekte mit `squad_scope='u21'` sind.

**Die Kollisionsprüfung gilt pro Kader, nicht pro Verein.** Sonst blockiert die Zweite die Erste.

---

## 14. Oberfläche

Verbindliche Vorlage ist `Freundschaftsspiele-Standalone.html`. Layout, Klassenlogik und Wording werden daraus übernommen. Diese Spec ergänzt nur, was aus den Entscheidungen fehlt.

### 14.1 Einbindung

- Neuer Sidebar-Eintrag „Freundschaftsspiele" (Pokal-Outline, 24 px, `currentColor`)
- Fester Shell-Vertrag: 1440 × 900 px. Header, Sidebar, Kalender und globale Navigation bleiben unangetastet. Keine eigenen Artboard-Breiten, kein `100vw`, keine eigenen Scaler
- Stadion-Foto als Seitenhintergrund, dunkel überlagert (`assets/backgrounds/stadion-bg.png`)

### 14.2 Kopfzeile

Umschalter **Profis / U21** rechts oben, Auswahl wird in der Sitzung gemerkt.

### 14.3 Reiter

| Reiter | Inhalt |
|---|---|
| **Spiel ansetzen** (Start) | Formular nach Kap. 5, mit Live-Vorschau der Partie |
| **Spielbörse** | Inserat aufgeben + Liste offener Partien (Kap. 6) |
| **Offene Anfragen** | Eingehend / Ausgehend, Anzahl in Grün am Reiter (Kap. 7) |
| **Turniere** | Liste, Erstellen-Wizard, Detailansicht (Kap. 11) |
| **Historie** | Geplante und gespielte Partien, Filter Alle/Geplant/Gespielt, 10 pro Seite mit Blättern |

### 14.4 Kalender

**Freundschaftsspiele erscheinen nicht im Spielkalender im Header.** Geplante und gespielte Partien stehen ausschließlich in der Historie. Hinweiszeile im Ansetzen-Formular:

> „Freundschaftsspiele erscheinen nicht im Kalender. Geplante und gespielte Partien findest du im Reiter Historie."

Damit bleibt der Kalender dem Pflichtspielbetrieb vorbehalten, und das bekannte Verhalten von `_build_global_calendar` (ein Eintrag je Datum) wird nicht gestört.

### 14.5 Gestaltung

CSS-Variablen des bestehenden Systems (`--panel`, `--line`, `--cyan`, `--green`, `--radius: 8px`). Inter 700/900, Micro-Labels 12 px / 900 / +0,7 px, Großbuchstaben. Chips: Termin cyan-soft, Ort grün-soft, Regeln neutral. Prämie immer Orange-Gradient. Buttons: primär Cyan-Gradient, sekundär Glass, ghost. Keine Emojis in der Daten-Oberfläche. Deutsche Ansprache mit „du".

---

## 15. Grenzfälle

| Fall | Verhalten |
|---|---|
| **Manager verlässt den Verein** | Angesetzte Spiele und Turnierteilnahmen bleiben **beim Verein**. Der Nachfolger erbt sie, ein vereinsloser Manager verliert sie |
| **Ersteller verlässt das Spiel mitten im Turnier** | Das Turnier läuft weiter — alle Termine stehen fest. Nur Verschieben und Prämienänderung fallen aus. Nach der letzten Runde schließt es normal ab |
| **Verein wird umbenannt** | Nur der Name ändert sich, alles läuft weiter |
| **Verein wird gelöscht** | Laufende Anfragen verfallen, angesetzte Spiele werden abgesagt, im Turnier wird der Verein zum Freilos — **kein Abbruch des Wettbewerbs** |
| **Weniger als 11 einsatzfähige Spieler** | Prüfung bei der Zusage mit konkreter Zahl. Zwischen Zusage und Anpfiff: Auffüllen per `default_tactics.py`; reicht es nicht, endet die Partie als `NICHT_AUSGETRAGEN`. **Im Turnier zählt das als Niederlage** der betroffenen Seite, damit der Baum weiterläuft |
| **Zwei gleichzeitige Annahmen desselben Inserats** | `select_for_update()`, der zweite bekommt „Diese Partie wurde bereits vergeben" |
| **Saisonwechsel** | Alle `FriendlyFixture` und die zugehörigen `SimulatedMatch` der Altsaison werden beim Reset gelöscht (Kap. 17.3) |

---

## 16. Bewusst verworfen

| Verworfen | Begründung |
|---|---|
| **Gegenvorschlag zu einer Anfrage** | Zu viel des Guten. Die Spielbörse deckt den Bedarf ab; wer andere Bedingungen will, stellt eine eigene Anfrage |
| **Anfragen- oder Spielelimits** | Nicht vorbauen. Sollte Missbrauch auftreten, wird serverseitig nachgesteuert |
| **Frischeverlust und Verletzungsrisiko** | Der Sandkasten soll risikofrei sein — nur dann wird darin etwas Interessantes ausprobiert |
| **Einnahmen aus Freundschaftsspielen** | Unbegrenzte Einnahmequelle ohne Gegenkosten. Zwei befreundete Manager spielen sich sonst reich |
| **Freundschaftsspiele in Rekorden und Statistiken** | Ein beliebig herstellbarer Rekord ist keiner. Gilt bereits per Ruhmeshalle-Spec |
| **Trophäen oder Pokalschrank für Community-Titel** | Würde die Trennung zur Ruhmeshalle von hinten aufweichen |
| **Verletzten-Schalter** | Verletzte sind gesperrt wie überall sonst |
| **Kalendereintrag für FS** | Der Kalender bleibt dem Pflichtspielbetrieb vorbehalten |
| **Setzlisten bei der Auslosung** | Wäre eine Auskunft über Spielstärken, die sonst hinter dem Scouting liegen |
| **KI-Vereine in der Spielbörse** | Die Börse ist Manager-zu-Manager. Wer gegen KI spielen will, nutzt „Spiel ansetzen" |
| **Statistikseite oder Rangliste über FS** | Wäre eine Wertung — und es gibt keine |

---

## 17. Umsetzungsreihenfolge

### 17.1 Stufe 1 — Einzelspiel

1. Migrationen: `FriendlyFixture`, `NeutralVenue`, `TacticSetup.context`
2. `simulate_match` um `extra_time` / `penalties` erweitern (inkl. „Elfmeter direkt nach 90")
3. Reiter „Spiel ansetzen" inkl. KI-Sofortzusage
4. Minutentick `run_friendly_tick` + Lazy-Pfad
5. Taktik-Bereich auf `context` umstellen
6. Spielbericht anbinden, Zuschauer-Aufschlüsselung ergänzen
7. Reiter „Historie"

**Nach Stufe 1 ist das Modul benutzbar** — ein Manager kann gegen jeden KI-Verein testen und seine Preise erproben.

### 17.2 Stufe 2 — Manager gegen Manager

8. Reiter „Offene Anfragen"
9. Reiter „Spielbörse"

### 17.3 Stufe 3 — Turniere

10. Turniermodelle + Wizard (4 Schritte)
11. Auslosung, Spielplanerzeugung, Tabelle, Baum
12. Detailansicht
13. Startknopf mit KI-Auswahl-Pop-up
14. Prämien inkl. Sperre und Auszahlung

### 17.4 Anschluss ans Jugendmodul

15. `get_squad(club, scope)` gegen den echten U21-Kader tauschen

### 17.5 Eintrag in den Saison-Rollover

Der manuelle Rollover bekommt einen Schritt: **Freundschaftsspiele der Altsaison löschen** (`FriendlyFixture` + zugehörige `SimulatedMatch` mit `match_type='freundschaft'`), nach `finance_season_close` und vor dem Hochsetzen von `GameSeasonState.current_season`.

---

## Anhang A — Entscheidungslog

| # | Entscheidung | Begründung |
|---|---|---|
| **F01** | Sandkasten: kein Frischeverlust, keine Verletzungen, kein Geld, keine Pflichtstatistik | Ein risikofreier Raum ist die Voraussetzung dafür, dass darin etwas ausprobiert wird |
| **F02** | Echte Frische wirkt als Eingang, wird nicht verbraucht. Gesperrte spielen, Verletzte nicht | Nur so ist das Ergebnis eine Aussage über die Mannschaft, die man hat |
| **F03** | Datum und Uhrzeit frei wählbar, Anfrage gilt bis zum Anpfiff | Der Termin ist die natürliche Frist; eine zweite wäre Ballast |
| **F04** | Aufstellung über den bestehenden Taktik-Bereich (nächstes anstehendes Spiel), ohne Aufstellung Stärkemalus | Ein Ort für Aufstellungen, kein zweiter Mechanismus |
| **F05** | Voller Spielbericht, öffentlich, Löschung beim Saison-Reset | Der Bericht ist fertig und wird geschenkt; öffentlich macht das Testen zur Abwägung |
| **F06** | *gestrichen* — keine Anfragenlimits | Erst messen, dann bremsen |
| **F07** | Anfrager bestimmt alles, nur Annehmen/Ablehnen, nach Zusage fest | Kein Verhandlungszustand, kein Zustandsautomat, keine ausfallenden Spiele |
| **F08** | KI nimmt sofort an, überspringt die Anfrageliste | Macht das Modul bei 2 Managern ab Tag eins benutzbar |
| **F09** | Jeder darf Turniere erstellen, kein Limit, Ersteller muss nicht mitspielen | Unterscheidet „Wettbewerb" von „mein Turnier, das ich gewinne" |
| **F10** | Liga (einfach / Hin-Rück) · Pokal · Gruppen + K.-o. | K.-o. ist über `cup_service.py` nahezu geschenkt |
| **F11** | Feste Feldgrößen, Zufallslos ohne Setzliste, keine Auswärtstorregel | Setzliste wäre Auskunft über geheime Stärken |
| **F12** | Zugang beim Erstellen: offen · Einladungscode · Bewerbung | |
| **F13** | Ersteller startet manuell; bei unvollem Feld Pop-up zur KI-Auswahl | Eine Pflichtfrist löst ein Problem, das es nicht gibt, und erzeugt eines, das es gibt |
| **F14** | Alle Runden vorab terminiert, Takt-Helfer, Verschieben bis Anpfiff | Der Terminplan ist vor der Anmeldung öffentlich — man weiß, worauf man sich einlässt |
| **F15** | Kein automatischer Ertrag; Admin-Prämie nur bis zum ersten gespielten Spiel | Einzige Geldquelle des Moduls, bewusst und allein durch den Admin geöffnet |
| **F16** | U21 = eigener Kader | |
| **F17** | Profis und U21 getrennt, globaler Umschalter | Mannschaft als Kontext, nicht als Formularfeld |
| **F18** | U21-Kader gehört nicht zu diesem Auftrag; Anschluss über `get_squad()` | Nicht an ein Modul bei 20 % ketten |
| **F19** | Volle Kulisse; Schiedsrichter aus dem Weltpool aller 463; Zuschauer wirken ohne Buchung | Ein Bericht ohne Schiedsrichter und Wetter wird als Fehler gelesen, nicht als Absicht |
| **F20** | Fünf Reiter; FS nicht im Kalender; Testspiel ist die **Preisprobe** | |
| **F21** | Grenzfälle nach Kap. 15 | Jede Runde muss von selbst zu Ende gehen |
| **F22** | KI-Vereine sind vollwertige Turnierteilnehmer | Ohne sie käme bei 2 Managern kein Turnier zustande |
| **F23** | Zwei Taktik-Datensätze über `TacticSetup.context` | Die Pflichtspiel-Taktik muss unzerstörbar sein |
| **F24** | `FriendlyFixture` trägt den Lebenslauf, Ergebnis in `SimulatedMatch` | Eine Tabelle statt zwei; der fertige Spielbericht wird geschenkt |

---

## Anhang B — Anschlusspunkte im bestehenden Code

| Was | Wo | Bemerkung |
|---|---|---|
| Simulation | `game/match_engine.py:2845` `simulate_match(home_club, away_club, home_strength_malus, away_strength_malus, is_cup, weather)` | wird um `extra_time` / `penalties` erweitert |
| K.-o.-Logik | `simulate_ko_match()` = `simulate_match(is_cup=True)`, Step 7 | Konstanten eingefroren (Freeze 14.06.2026), nicht anfassen |
| Ergebnisablage | `SimulatedMatch.create_numbered(season, …)`, `match_type='freundschaft'` | existiert bereits |
| Schiedsrichter | `SimulatedMatch.referee`, Modell `Referee` | nullable, hier immer gefüllt |
| Frische | `game/freshness_service.py` — `apply_match_freshness_losses()` **nicht** aufrufen | Frische wird gelesen, nicht geschrieben |
| Zuschauer | `game/economy/stadium.py:147` `compute_demand(club, stadium, *, opponent_club=…)` | rechnen, anzeigen, **nicht** buchen |
| Buchung Prämie | `game/economy/booking.py:89` `book(club, typ, betrag, *, referenz_typ, referenz_id, pflicht)` | neuer Typ in `FinanceTransaction.TYP_CHOICES` |
| Aufstellung | `TacticSetup` (`game/models.py:1265`), Unique `(club, squad_scope)` → `(club, squad_scope, context)` | |
| Automatik-Aufstellung | `game/default_tactics.py`, `game/match_readiness.py` | scope-parametrierbar |
| Malus-Muster | `SeasonFixture.home_lineup_set` / `home_lineup_malus` (`game/models.py:1580 ff.`) | Vorbild für die FS-Entsprechung |
| Kalender | `game/context_processors.py:46` `_build_global_calendar()` | bleibt unangetastet, FS erscheinen dort nicht |
| Pokalbaum | `game/cup_service.py` | Vorbild für die Turnier-Auslosung, inkl. Freilose |
| Tick-Muster | `CELERY_BEAT_SCHEDULE` in `core/settings.py`, Eintrag `showauction-tick-minuetlich` | |
| Task-Wrapper | `game/tasks.py` `run_management_command` — fängt `SystemExit` ab | zwingend verwenden |
| Rekord-Filter | Ruhmeshalle: harter Filter auf `match_type='freundschaft'` | bereits vorhanden, hier nichts zu tun |
