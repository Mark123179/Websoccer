# Stadionpaket · Allianz Arena · FC Bayern München (FMI 915)

Stand 11.10.2026 · Quelle: BassyBoy FM26 3D Stadium Megapack v3.0 (`allianzarena.bundle`, SHA-256 `52c0d091…c0b3`) · Freigabe durch Mark für den gesamten Megapack.
Erzeugt mit der lokalen Fassung von `scripts/export_stadium_model.py` (Stand Registry-Ticket 11.10.2026) nach `docs/stadium/model-manifest.md`.

## Inhalt
- `models/915.json` – Manifest (Registry-Datei), assetVersion **89dc57a1ff9208e2**, geometrySha256 `07869ec9…7eda`
- `stadium-models/915/89dc57a1ff9208e2/` – `geometry.bin` (34,1 MB) + 109 Texturen (WebP ≤ 1024 px)
- `kalibrierung.json` – der calibration-Block, Begründung unten
- `bilder/` – Vorab-Ansichten (lokal mit Replits `unity_stadium_scene.js` gerendert, Software-WebGL)
- `werkzeuge/` – Exportskript + Validator (Kopie) + Render-Harness zur Reproduktion
- `PRUEFSUMMEN.sha256`

Kennzahlen: 418 Meshes, 109 Texturen, 65 quellgeprüfte Flutlichter → 12 Laufzeitleuchten, 72.410 Sitze in der Sitzdatei, 137 Lightmaps, 140 Lightprobes (als sourceEvidence erfasst).

## Einspielen (drei Schritte, Replit-Agent nicht nötig)
1. **Assets auf Hetzner** (Zielordner = `<assets_root()>/stadium-models/915/89dc57a1ff9208e2/`; auf dem Server der Ordner, der im Container `/app/assets` ist, laut Projektstand `/var/www/assets`):
   ```sh
   scp -r stadium-models/915 root@49.13.5.151:/var/www/assets/stadium-models/
   ```
2. **Manifest ins Repo**: `models/915.json` per Datei-Upload nach `stadium_editor/blueprints/v2/models/915.json` in Replit legen, committen, nach GitHub pushen.
3. **`/push`** auf Hetzner (enthält `up -d --force-recreate web` → Worker-Neustart, den die Registry braucht). Danach prüfen:
   ```sh
   docker exec websoccer-web-1 python manage.py check_stadium_model --fmi 915
   docker exec websoccer-web-1 python manage.py check_stadium_model --fmi 915 --assets
   ```
   Erwartung: `Manifest OK: 915 · Allianz Arena · 89dc57a1ff9208e2` und `Assets OK: 110 Dateien`.
4. Abnahme live: `/stadion/2/live/` (Ticker), Editor als Bayern-Manager/Admin (2D, 3D). Die hier beigelegten Bilder sind Vorab-Nachweise, keine Abnahme.

Kein DB-Import, keine Änderung an Kapazität, Manager, Finanzen, Geometrie oder Design.

## Kalibrierung (gegen das Modell geprüft, nicht von Gladbach kopiert)
| Feld | Wert | Begründung |
|---|---|---|
| roofMinHeight | 36 | Dachschale/Membran beginnt bei 36,1 m (center3 wall101/clng101, Membran 36,9–52,8 m). Oberrang-Sitzflächen (C_*3, bis 39,8 m) sind durch crowdPrefix ausgenommen. Nebenwirkung: die obersten ~3 m der Oberrang-Stufenmeshes (26,7–39,5 m) gelten als Dach und verschwinden mit „Dach aus"; die Sitzflächen bleiben. Mit 40 bliebe stattdessen der innere Dachring (36–40 m) als schwebendes Band stehen – schlechter. |
| skipMeshPrefixes | Couvercle_, notdemo_, center3_probe_21. | `Couvercle_1` = Tifo-Banner (131.880 Dreiecke, weißes Tuch, Event-Inhalt). `notdemo_probe_1` (Vinyl) und `center3_probe_21` (Stahlrahmen, Alpha-Textur) liegen **deckungsgleich** auf `cover_1` (Nachweis: Nächste-Punkt-Abstand 0,000 m) → ohne Skip Z-Fighting; behalten wird `cover_1` (vollständige, helle Membran). |
| crowdPrefix / pitchPrefix | C_ / st081_pitch_ | wie Gladbach, im Bundle verifiziert (27 Crowd-Meshes, st081_pitch_0/1). |
| tickerRotationY | −90 | Kamera auf der Bankseite: BENCH_BAYERN_HOME/AWAY liegen bei x ≈ −42 (front1), Modell-Längsachse ist z. −90° setzt die approved-elversberg-Kamera auf x = −110 → Blick auf die Gegentribüne („Mia san mia"). Gleiche Konvention wie Gladbach (dort Bänke ebenfalls bei x ≈ −40). |
| tickerFrontCut | normal (1,0,0), constant 32 | Rasen x ±34,1 (identisches PES-Rasenmesh wie Gladbach) → Schnitt bei x < −32 blendet nur die Nahtribüne aus; Rasen ist per pitchPrefix ausgenommen. |
| standAxes | +x OST, −x WEST, +z NORD, −z SUED | Aus dem Ortsadapter (`editorPointToDortmund`: Szene +x → Unity +z, Szene +y → Unity −x) und der Prod-Szene (homeStand SUED bei Szene −x, WEST bei +y): Unity −z = SUED (Modell: `C_right1_C2-UltraHome` = Südkurve ✔), +z = NORD (Gästeblöcke `left3_*Away` ✔), −x = WEST (Bänke/Haupttribüne ✔), +x = OST. |
| orbitDefault | 0,95 / 0,65 / 360 | Azimut/Elevation wie Gladbach; Distanz 310 → 360, weil das Modell größer ist (x ±114, z ±130 m). |

## Befunde und Abweichungen
1. **Exportskript, eine Zeile**: Der Rasen `0002-Botafogo` (Shader-Graph) hat seine Albedo unter `_Base_Texture`, nicht unter `baseColorTexture/_BaseMap/_MainTex`. Ohne Ergänzung bleibt der Rasen weiß. Patch für `scripts/export_stadium_model.py`:
   `if key in ("baseColorTexture", "_BaseMap", "_MainTex", "_Base_Texture") and value.m_Texture:`
   Für Gladbach ändert das nichts (dort `_BaseMap`). Reproduktion mit gepatchtem Skript ergibt exakt diese geometrySha256 und assetVersion.
2. **Größe**: 34 MB Geometrie (Gladbach 11 MB) – die Sitze sind hier einzeln modelliert (Crowd 15,5 MB). Das Tifo-Mesh (3,8 MB) wird zur Laufzeit übersprungen, liegt aber vertragsgemäß im Binary. Mögliche Verbesserung: Export lässt skipMeshPrefixes schon beim Schreiben aus.
3. **„Ticker ohne Dach" sieht aus wie „mit Dach"**: Das Dach (36–53 m) liegt bei dieser Kamera oberhalb des Bildrands; es verdeckt nichts. Der Schalter wirkt sichtbar nur im 3D-Editor (Bild 02/02b).
4. **Nacht**: Quell-Leuchten haben Intensität 25–40 (Gladbach 70) → Flutlicht wirkt dunkler. Der Vertrag hat keinen Helligkeitsregler; Kandidat für ein Feld `floodlightGain` in einer Kalibrierung v2.
5. **Sitzfarben**: Das Standard-Design (Palette Index 0) färbt nichts um, deshalb zeigen die Ränge die Modellfarben (rot/grau, „Mia san mia", „FC BAYERN MÜNCHEN", Wappen). Ein gespeichertes Manager-Design mit Index > 0 färbt tribünenweise um – wie bei Gladbach.
6. **Gladbach-Nachtrag (nur Daten)**: Nach demselben Adapter sind die standAxes in `models/908.json` um 90° verdreht (dort +x SUED/−x NORD/+z OST/−z WEST; korrekt wäre +x OST, −x WEST, +z NORD, −z SUED – Nordkurve `left1 UltraHome` liegt bei +z, Bänke bei −x). Wirkt nur auf die Zuordnung der Design-Farben je Tribüne. Korrektur = Feld im Manifest ändern, assetVersion unverändert lassen (Assets bleiben gültig).
7. **2D-Editor** hängt nicht am Modell (Geometrie/OSM wie heute) und wurde deshalb nicht neu gerendert.
8. Material-/Texturnamen folgen Konami-PES-Konventionen (st011_…, _bsm/_srm/_nrm); Nutzung laut Marks Freigabe (BassyBoy-Erlaubnis für den gesamten Megapack).

## Reproduktion
```sh
python3 -I werkzeuge/export_stadium_model.py --bundle allianzarena.bundle --seats allianzarena.json \
  --fmi 915 --name "Allianz Arena" --out export --calibration kalibrierung.json
```
Bilder: `werkzeuge/render/harness.html` + `shoot.py` neben Replits `static/stadium_editor/` (unity_stadium_scene.js, unity_calibration.js, study_camera.js, dortmund_surroundings.js, stage/) und einer `presentation_915.json` (presentation wie `unity_presentation()` + Live-Scene) – Chromium mit `--use-gl=angle --use-angle=swiftshader`.
