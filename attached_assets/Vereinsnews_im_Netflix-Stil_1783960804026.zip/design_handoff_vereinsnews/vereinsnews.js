/* ============================================================
   VEREINSNEWS — Netflix-Stil · Vanilla JS (kein Framework)
   Views: home (Übersicht) · article (Detail) · editor (Regie-Modus)
   ============================================================ */
'use strict';

var SEASON = 2; // laufende Saisonnummer -> Chip "S2" (aus dem Spielstand befüllen)

var KATS = [
  { n: 'Transfer-News', c: '#22e6ff' }, { n: 'Spielbericht', c: '#30f29c' }, { n: 'Interview', c: '#ffd166' },
  { n: 'Vereinsstatement', c: '#e50914' }, { n: 'Pressemitteilung', c: '#9fb6c4' }, { n: 'Jugend/Akademie', c: '#7ef0c2' },
  { n: 'Fans', c: '#ff5570' }, { n: 'Finanzen', c: '#ff9f1c' }, { n: 'Rekorde', c: '#f6c945' }, { n: 'Sonstiges', c: '#8fa8b8' }
];
var OUTLETS = [
  { n: 'Vereinsredaktion', d: '#e50914', m: 'VR' }, { n: 'Kicker', d: '#d31419', m: 'KIC' }, { n: 'Sky Sport', d: '#0072c9', m: 'SKY' },
  { n: 'Spox', d: '#ff6600', m: 'SPX' }, { n: 'Transfermarkt', d: '#00a35a', m: 'TM' }, { n: '90min', d: '#14d95c', m: '90M' },
  { n: 'The Athletic', d: '#e8e2d6', m: 'TA' }, { n: 'Magenta Sport', d: '#e20074', m: 'MS' }, { n: 'OneFootball', d: '#8fd0ff', m: 'OF' }, { n: '90PLUS', d: '#ffd166', m: '90+' }
];
var P = {
  kane:    { n: 'Harry Kane',      pos: 'ST',  img: 'assets/players/2000069555.png', meta: '32 Jahre · England',     mw: '110.000.000 €', tore: '41', note: '1,84', fit: '96%' },
  olise:   { n: 'Michael Olise',   pos: 'RA',  img: 'assets/players/2000121585.png', meta: '24 Jahre · Frankreich',  mw: '140.000.000 €', tore: '17', note: '2,04', fit: '92%' },
  musiala: { n: 'Jamal Musiala',   pos: 'OM',  img: 'assets/players/2000147056.png', meta: '23 Jahre · Deutschland', mw: '135.000.000 €', tore: '14', note: '2,11', fit: '88%' },
  neuer:   { n: 'Manuel Neuer',    pos: 'TW',  img: 'assets/players/2000171034.png', meta: '40 Jahre · Deutschland', mw: '4.000.000 €',   tore: '0',  note: '2,45', fit: '85%' },
  kimmich: { n: 'Joshua Kimmich',  pos: 'ZDM', img: 'assets/players/2000180861.png', meta: '31 Jahre · Deutschland', mw: '65.000.000 €',  tore: '6',  note: '2,31', fit: '94%' }
};
var MOM = [0.6, 0.3, -0.2, 0.8, 1, 0.4, -0.5, -0.3, 0.7, 0.9, 0.2, -0.6, 0.5, 1, 0.8, 0.3, -0.2, 0.6];

function T(t) { return { k: 'text', text: t }; }
function H(t) { return { k: 'head', text: t }; }
function Q(t, a) { return { k: 'quote', text: t, autor: a }; }
function PL(pid, f) { return { k: 'player', pid: pid, f: Object.assign({ portrait: true, mw: true, tore: true, note: false, fit: false }, f || {}) }; }
function M(f) { return { k: 'match', f: Object.assign({ crests: true, score: true, scorers: true, momentum: false, zuschauer: false }, f || {}) }; }
function IMG(src, cap) { return { k: 'image', src: src, cap: cap }; }

var ART = [
  { id: 'a1', kat: 'Transfer-News', outlet: 'Vereinsredaktion', title: 'Kane verlängert bis 2028', sub: 'Der Kapitän bleibt: 41 Tore, ein Versprechen — und eine Ausstiegsklausel weniger.', date: '12.07.2026', views: 12600, img: 'assets/players/2000069555.png', imgH: 130, blocks: [
    T('Es ist das Zeichen, auf das die Säbener Straße gewartet hat: Harry Kane hat seinen Vertrag vorzeitig bis 2028 verlängert. Die vieldiskutierte Ausstiegsklausel für die Premier League? Ersatzlos gestrichen.'),
    Q('Ich bin nicht hierhergekommen, um Zweiter zu werden. Wir fangen gerade erst an.', 'Harry Kane'),
    PL('kane', { fit: true }),
    H('Was der Deal für die Planung bedeutet'),
    T('Mit der Verlängerung sichert der Verein nicht nur seine 41 Saisontore, sondern auch Planungssicherheit im teuersten Mannschaftsteil. Das Gehaltsbudget bleibt laut Management unangetastet — möglich macht es eine neue Staffelung der Prämien.'),
    IMG('assets/backgrounds/fc-bayern-stadium.jpg', 'Die Arena am Abend der Bekanntgabe')
  ] },
  { id: 'a2', kat: 'Spielbericht', outlet: 'Kicker', title: '5:0! Gala-Abend unterm Flutlicht', sub: 'Mainz kam mit Mut — und ging mit fünf Gegentoren. Der Matchbericht zum 33. Spieltag.', date: '10.07.2026', views: 9800, img: 'assets/crests/918.png', imgH: 100, blocks: [
    T('Von der ersten Minute an lief der Ball, wie man es sich an einem perfekten Heimspielabend wünscht. Nach zwölf Minuten stand es 1:0, zur Pause 3:0 — und Mainz fand auf keine einzige Frage eine Antwort.'),
    M({ momentum: true, zuschauer: true }),
    Q('So stellt man sich einen Heimspielabend vor. Boah, was für eine Energie im Stadion!', 'KI-Kloppo'),
    PL('olise', { note: true, mw: false })
  ] },
  { id: 'a3', kat: 'Interview', outlet: 'Sky Sport', title: 'Olise: „Ich fange gerade erst an"', sub: 'Der Flügelspieler über seinen Lauf, den Rekordwert — und warum er noch lange nicht fertig ist.', date: '08.07.2026', views: 8400, img: 'assets/players/2000121585.png', imgH: 128, blocks: [
    T('140 Millionen Euro Marktwert, 17 Saisontore, und trotzdem wirkt Michael Olise, als hätte er noch eine Rechnung offen. Wir trafen ihn nach dem Training zum Gespräch.'),
    Q('Die Zahlen sind schön. Aber ich spiele nicht für Zahlen, ich spiele für Titel.', 'Michael Olise'),
    T('Auf die Frage nach seinem Vertrag lacht er nur — und verweist auf den Sportvorstand. Intern gilt eine Verlängerung als Formsache.'),
    Q('Dieser Verein will immer gewinnen. Genau deshalb bin ich hier.', 'Michael Olise')
  ] },
  { id: 'a4', kat: 'Vereinsstatement', outlet: 'Vereinsredaktion', title: 'Statement zum Pokal-Aus', sub: 'Der Vorstand nimmt Stellung: Analyse statt Ausreden.', date: '06.07.2026', views: 4300, img: 'assets/crests/915.png', imgH: 96, blocks: [
    T('Das Ausscheiden im DFB-Pokal schmerzt — sportlich wie emotional. Der Verein wird die Partie intern aufarbeiten und die richtigen Schlüsse ziehen.'),
    Q('Wir stellen uns der Kritik — intern wie extern. Dieser Verein bewertet sich an Titeln, nicht an Ausreden.', 'Der Vorstand'),
    T('Bereits am Wochenende bietet sich in der Liga die Gelegenheit zur Reaktion. Die Mannschaft weiß, was auf dem Spiel steht.')
  ] },
  { id: 'a5', kat: 'Jugend/Akademie', outlet: '90min', title: 'U19 macht das Double perfekt', sub: 'Meisterschaft und Pokal: Der Nachwuchs liefert — drei Talente trainieren ab sofort oben mit.', date: '05.07.2026', views: 7700, img: 'assets/players/12038706.png', imgH: 126, blocks: [
    T('Mit einem 3:1 im Finale krönt die U19 ihre Saison und holt nach der Meisterschaft auch den Pokal. Es ist das erste Double des Nachwuchses seit neun Jahren.'),
    T('Drei Spieler des Jahrgangs werden in der Saisonvorbereitung fest bei den Profis mittrainieren — die Namen gibt der Verein kommende Woche bekannt.'),
    Q('Diese Jungs haben sich das verdient. Jetzt zeigt mal den Großen, was ihr könnt!', 'KI-Kloppo')
  ] },
  { id: 'a6', kat: 'Rekorde', outlet: 'OneFootball', title: 'Zuschauerrekord: 75.024', sub: 'Neuer Bestwert: Noch nie war die Arena in dieser Saison so voll.', date: '03.07.2026', views: 3900, img: 'assets/crests/915.png', imgH: 96, blocks: [
    T('75.024 Zuschauer — neuer Saisonrekord. Die Dauerkarten-Warteliste wächst damit auf über 40.000 Einträge.'),
    T('Der Verein prüft für die kommende Saison eine Erweiterung des Stehplatzbereichs in der Südkurve.')
  ] },
  { id: 'a7', kat: 'Finanzen', outlet: 'The Athletic', title: 'Quartalszahlen: +12,4 Mio €', sub: 'Merchandising und internationale TV-Gelder treiben das beste Quartal der Vereinsgeschichte.', date: '01.07.2026', views: 5200, blocks: [
    T('Der Verein schließt das Quartal mit einem Plus von 12,4 Millionen Euro ab — Bestwert der Vereinsgeschichte. Haupttreiber: Trikotverkäufe und die neuen internationalen TV-Verträge.'),
    T('Der Vereinswert steigt damit auf 938,9 Millionen Euro. Für das Transferbudget des Sommers stehen laut Management zusätzliche Mittel bereit.')
  ] },
  { id: 'a8', kat: 'Fans', outlet: 'Vereinsredaktion', title: 'Südkurve plant Derby-Choreo', sub: 'Die aktive Fanszene ruft auf: Alle in Vereinsfarben — Einlass ab 15 Uhr.', date: '29.06.2026', views: 2900, blocks: [
    T('Für das anstehende Derby plant die Südkurve die größte Choreografie der Saison. Der Verein unterstützt die Aktion und öffnet die Tore bereits um 15 Uhr.'),
    Q('Daheim. Zusammen. Unschlagbar.', 'Südkurve')
  ] },
  { id: 'a9', kat: 'Pressemitteilung', outlet: 'Spox', title: 'Neues Leistungszentrum genehmigt', sub: 'Baubeginn 2027: Der Verein investiert 85 Millionen in den Campus der Zukunft.', date: '27.06.2026', views: 3400, blocks: [
    T('Der Stadtrat hat die Pläne für das neue Leistungszentrum einstimmig genehmigt. Auf 12 Hektar entstehen acht Plätze, ein Internat und ein Reha-Zentrum.'),
    T('Baubeginn ist für das Frühjahr 2027 geplant, die Eröffnung für die Saison 2029/30. Die Finanzierung erfolgt vollständig aus Eigenmitteln.')
  ] },
  { id: 'a10', kat: 'Transfer-News', outlet: 'Transfermarkt', title: 'Wirtz-Poker: Absage an die Insel?', sub: 'Leverkusens Zehner soll eine Anfrage aus England abgelehnt haben — mit Verweis auf die Bundesliga.', date: '25.06.2026', views: 6100, img: 'assets/crests/901.png', imgH: 96, blocks: [
    T('Nach übereinstimmenden Berichten hat Florian Wirtz eine lukrative Anfrage aus der Premier League abgelehnt. Sein Berater dementiert nicht.'),
    Q('Florian entscheidet sportlich. Und sportlich spricht vieles für die Bundesliga.', 'Beraterkreise'),
    T('Für den Verein wäre ein Verbleib des Ausnahmespielers in der Liga auch mit Blick auf die direkten Duelle eine gute Nachricht.')
  ] }
];

var SOCIAL = [
  { id: 's1', kat: 'Social', outlet: 'Kicker', title: '„Titelfavorit Nr. 1" — dein Verein im Kicker', sub: 'Die Redaktion kürt deinen Verein nach dem 5:0 zum Topfavoriten der Liga.', date: '11.07.2026', views: 15200, blocks: [
    T('Nach dem 5:0 gegen Mainz führt der Kicker deinen Verein als Titelfavoriten Nr. 1. Besonders hervorgehoben: die Systemumstellung auf die Doppel-Acht.'),
    Q('So dominant hat in dieser Saison noch niemand gespielt.', 'Kicker-Redaktion')
  ] },
  { id: 's2', kat: 'Social', outlet: 'Sky Sport', title: 'Sky-Runde: Kane-Verlängerung schlägt Wellen', sub: 'In der Sky-Expertenrunde ist dein Verein Gesprächsthema Nummer eins.', date: '12.07.2026', views: 11900, blocks: [
    T('Die gestrichene Ausstiegsklausel von Harry Kane war das Topthema der Sky-Expertenrunde. Tenor: ein Statement an die Konkurrenz.'),
    Q('Dieser Deal macht die Liga für zwei Jahre planbar — für alle anderen leider auch.', 'Sky-Expertenrunde')
  ] },
  { id: 's3', kat: 'Social', outlet: 'Transfermarkt', title: 'TM-Forum: Wirtz-Gerücht heiß diskutiert', sub: '4.200 Kommentare in 24 Stunden — dein Verein trendet auf Transfermarkt.', date: '10.07.2026', views: 9400, blocks: [
    T('Das angebliche Interesse deines Vereins an Florian Wirtz ist der meistdiskutierte Thread der Woche — 4.200 Kommentare in 24 Stunden.'),
    Q('Wenn einer den Deal stemmen kann, dann die.', 'User FCB_Ultra04')
  ] }
];

/* ── State ── */
var state = {
  view: 'home', art: null, edPrev: 'artikel', published: [],
  ed: {
    titel: 'Musiala zurück im Mannschaftstraining',
    sub: 'Nach sechs Wochen Pause steht der Zauberfuß wieder auf dem Rasen — früher als geplant.',
    kat: 'Pressemitteilung', outlet: 'Vereinsredaktion',
    card: { motiv: 'spieler', pid: 'musiala', accent: '#22e6ff', customSrc: null },
    blocks: [
      T('Sechs Wochen nach seiner Verletzung im Pokal steht Jamal Musiala wieder auf dem Trainingsplatz — zwei Wochen früher als prognostiziert. Die medizinische Abteilung gibt grünes Licht für eine volle Belastung.'),
      PL('musiala', { fit: true, tore: false }),
      Q('Ich habe jeden Tag dafür gearbeitet. Jetzt will ich der Mannschaft im Titelrennen helfen.', 'Jamal Musiala'),
      IMG(null, 'Trainingsauftakt an der Säbener Straße')
    ]
  }
};

/* ── Helpers ── */
function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function katC(n) { var k = KATS.find(function (k) { return k.n === n; }); return k ? k.c : '#22e6ff'; }
function outletOf(n) { return OUTLETS.find(function (o) { return o.n === n; }) || OUTLETS[0]; }
function ha(h, a) { var x = parseInt(h.slice(1), 16); return 'rgba(' + (x >> 16 & 255) + ',' + (x >> 8 & 255) + ',' + (x & 255) + ',' + a + ')'; }
function markTc(hex) { var x = parseInt(hex.slice(1), 16); var l = .299 * (x >> 16 & 255) + .587 * (x >> 8 & 255) + .114 * (x & 255); return l > 150 ? '#03141b' : '#fff'; }
function fmtViews(v) { if (!v) return 'Neu'; return v >= 1000 ? (v / 1000).toFixed(1).replace('.', ',') + 'k Aufrufe' : v + ' Aufrufe'; }
function ALL() { return state.published.concat(ART); }
function findArt(id) { return ALL().concat(SOCIAL).find(function (a) { return a.id === id; }); }
function bgFor(a) {
  var hue = (a.card && a.card.accent) || katC(a.kat);
  return 'linear-gradient(178deg,rgba(3,7,12,.05) 28%,rgba(3,7,12,.92) 82%),radial-gradient(circle at 74% 10%,' + ha(hue, .38) + ',transparent 62%),linear-gradient(140deg,#0e2130,#050b12)';
}
function cardArt(a) {
  var cd = a.card;
  if (cd && cd.motiv === 'eigenes') return { custom: cd.customSrc, img: null, imgH: 0 };
  if (cd && cd.motiv === 'wappen') return { custom: null, img: 'assets/crests/915.png', imgH: 100 };
  if (cd && cd.motiv === 'spieler') { var p = P[cd.pid] || P.kane; return { custom: null, img: p.img, imgH: 124 }; }
  return { custom: null, img: a.img || null, imgH: a.imgH || 120 };
}
function markChip(name, big) {
  var o = outletOf(name);
  var s = big ? 'min-width:17px;height:16px;font-size:8px;padding:0 4px' : '';
  return '<i class="mark" style="background:' + o.d + ';color:' + markTc(o.d) + ';' + s + '">' + o.m + '</i>';
}

/* ── Karten ── */
function cardHTML(a) {
  var art = cardArt(a);
  var h = '<div class="news-card" style="background:' + bgFor(a) + '" onclick="App.open(\'' + a.id + '\')">';
  if (art.custom) h += '<img class="card-custom" src="' + art.custom + '" alt="">';
  else if (art.img) h += '<img class="card-motif" src="' + art.img + '" alt="" style="height:' + art.imgH + 'px">';
  if (a.isNew) h += '<span class="badge-neu card-neu">NEU</span>';
  h += '<div class="card-overlay">' +
    '<span class="card-kat" style="color:' + katC(a.kat) + '">' + esc(a.kat) + '</span>' +
    '<strong class="card-title">' + esc(a.title) + '</strong>' +
    '<span class="meta-line">' + esc(a.date) + ' · ' + markChip(a.outlet) + esc(a.outlet) + '</span>' +
    '</div></div>';
  return h;
}
function topHTML(a, rank) {
  var art = cardArt(a);
  var h = '<div class="top-item" onclick="App.open(\'' + a.id + '\')"><span class="top-rank">' + rank + '</span>' +
    '<div class="top-card" style="background:' + bgFor(a) + '">';
  if (art.custom) h += '<img class="card-custom" src="' + art.custom + '" alt="">';
  else if (art.img) h += '<img class="card-motif" src="' + art.img + '" alt="">';
  if (a.isNew) h += '<span class="badge-neu card-neu" style="top:6px;left:6px;font-size:8px;padding:2px 5px">NEU</span>';
  h += '<div class="card-overlay"><strong class="card-title">' + esc(a.title) + '</strong>' +
    '<span class="views">' + fmtViews(a.views) + '</span></div></div></div>';
  return h;
}

/* ── Übersicht ── */
function homeHTML() {
  var all = ALL();
  var feat = all[0];
  var fa = cardArt(feat);
  var top = all.concat(SOCIAL).slice().sort(function (x, y) { return (y.views || 0) - (x.views || 0); }).slice(0, 10);
  var fans = all.filter(function (a) { return a.kat === 'Fans'; }).concat(SOCIAL);

  var h = '<div class="vn-billboard">' +
    '<img class="bb-bg" src="assets/backgrounds/fc-bayern-stadium.jpg" alt="">';
  if (fa.custom) h += '<img class="card-custom bb-bg" src="' + fa.custom + '" alt="">';
  h += '<div class="bb-shade"></div>';
  if (!fa.custom && fa.img) h += '<img class="bb-motif" src="' + fa.img + '" alt="">';
  if (feat.isNew) h += '<span class="badge-neu" style="position:absolute;top:16px;left:16px;font-size:10px;padding:4px 9px">NEU</span>';
  h += '<div class="bb-body">' +
    '<div class="bb-kicker">' + N_SVG + '<span>GERADE ERSCHIENEN · ' + esc(feat.kat.toUpperCase()) + '</span></div>' +
    '<h2>' + esc(feat.title) + '</h2>' +
    '<p>' + esc(feat.sub) + '</p>' +
    '<span class="meta-line" style="font-size:11px;font-weight:800;color:rgba(244,251,255,.6)">' + esc(feat.date) + ' · ' + markChip(feat.outlet, true) + esc(feat.outlet) + '</span>' +
    '<div style="display:flex;gap:10px;margin-top:4px">' +
    '<button class="btn-red" style="font-size:14px;padding:12px 22px" onclick="App.open(\'' + feat.id + '\')">' + PLAY_SVG + 'Jetzt lesen</button>' +
    '<button class="btn-hero-soft" onclick="App.open(\'' + feat.id + '\')">Mehr Infos</button>' +
    '</div></div>' +
    '<span class="bb-season">S' + SEASON + '</span></div>';

  h += '<h3 class="vn-row-title">Neu im Verein</h3><div class="vn-row">' + all.slice(0, 7).map(cardHTML).join('') + '</div>';
  h += '<h3 class="vn-row-title">Top 10 nach Klicks</h3><div class="vn-row top10">' + top.map(function (a, i) { return topHTML(a, i + 1); }).join('') + '</div>';
  h += '<h3 class="vn-row-title" style="margin-bottom:4px">Fans &amp; Medien</h3>' +
    '<span class="vn-row-sub">Beiträge deiner Fans und Social News, in denen dein Verein erwähnt wird</span>' +
    '<div class="vn-row">' + fans.map(cardHTML).join('') + '</div>';
  return h;
}

/* ── Artikel-Blöcke ── */
function blocksHTML(blocks) {
  return '<div class="art-blocks">' + blocks.map(function (b) {
    if (b.k === 'text') return '<p>' + esc(b.text) + '</p>';
    if (b.k === 'head') return '<h3>' + esc(b.text) + '</h3>';
    if (b.k === 'quote') return '<div class="blk-quote"><span class="bar"></span><div><p>„' + esc(b.text || '…') + '"</p><span class="autor">— ' + esc(b.autor || 'Unbekannt') + '</span></div></div>';
    if (b.k === 'player') {
      var p = P[b.pid] || P.kane, f = b.f || {};
      var stats = [];
      if (f.mw) stats.push(['Marktwert', p.mw, '#30f29c']);
      if (f.tore) stats.push(['Saisontore', p.tore, '#22e6ff']);
      if (f.note) stats.push(['Ø-Note', p.note, '#30f29c']);
      if (f.fit) stats.push(['Fitness', p.fit, '#30f29c']);
      return '<div class="blk-player">' +
        (f.portrait !== false ? '<img src="' + p.img + '" alt="">' : '') +
        '<div style="display:flex;flex-direction:column;gap:8px;min-width:0">' +
        '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap"><strong style="font-size:17px;font-weight:900">' + p.n + '</strong><span class="pos-badge">' + p.pos + '</span><span style="font-size:12px;font-weight:700;color:rgba(244,251,255,.5)">' + p.meta + '</span></div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap">' + stats.map(function (s) { return '<span class="stat-chip"><em>' + s[0] + '</em><b style="color:' + s[2] + '">' + s[1] + '</b></span>'; }).join('') + '</div>' +
        '</div></div>';
    }
    if (b.k === 'match') {
      var f2 = b.f || {};
      var h = '<div class="blk-match"><div class="m-meta"><img src="assets/competitions/bundesliga.png" alt="" style="height:14px">1. Bundesliga · 33. Spieltag · Novum Arena</div>' +
        '<div class="m-grid"><div class="m-team">' + (f2.crests !== false ? '<img src="assets/crests/915.png" alt="">' : '') + '<span>FC Bayern</span></div>' +
        (f2.score !== false ? '<span class="m-score">5:0</span>' : '<span></span>') +
        '<div class="m-team">' + (f2.crests !== false ? '<img src="assets/crests/918.png" alt="">' : '') + '<span>Mainz 05</span></div></div>';
      if (f2.scorers) h += '<div class="m-scorers">' + [['12', 'H. Kane'], ['27', 'M. Olise'], ['45+2', 'H. Kane'], ['61', 'J. Musiala'], ['78', 'L. Sané']].map(function (g) { return '<span><i class="m-min">' + g[0] + '′</i>' + g[1] + '</span>'; }).join('') + '</div>';
      if (f2.momentum) h += '<div style="border-top:1px solid rgba(44,231,255,.14);padding-top:10px"><div class="micro-label" style="text-align:center;margin-bottom:6px">Matchmomentum</div><div class="m-momentum">' +
        MOM.map(function (v) { return '<span style="height:' + Math.round(6 + Math.abs(v) * 20) + 'px;background:' + (v > 0 ? ha('#30f29c', .35 + .5 * Math.abs(v)) : ha('#ff5570', .35 + .5 * Math.abs(v))) + ';align-self:' + (v > 0 ? 'flex-start' : 'flex-end') + '"></span>'; }).join('') + '</div></div>';
      if (f2.zuschauer) h += '<div style="border-top:1px solid rgba(44,231,255,.14);padding-top:8px;text-align:center;font-size:12px;font-weight:800;color:rgba(244,251,255,.6)">Zuschauer <b style="color:#22e6ff">75.024</b></div>';
      return h + '</div>';
    }
    if (b.k === 'image') {
      return '<figure class="blk-image" style="margin:0">' +
        (b.src ? '<img src="' + b.src + '" alt="">' : '<div class="img-placeholder">Bild-Platzhalter</div>') +
        '<figcaption>' + esc(b.cap || '') + '</figcaption></figure>';
    }
    return '';
  }).join('') + '</div>';
}

/* ── Artikel-Ansicht ── */
function articleHTML(a) {
  var art = cardArt(a);
  var kc = katC(a.kat), o = outletOf(a.outlet);
  var bigH = Math.min(250, Math.round((art.imgH || 120) * 1.9));
  return '<a class="back-link" onclick="App.goHome()">‹ Zurück zur Übersicht</a>' +
    '<div class="art-hero" style="background:' + bgFor(a).replace('.38', '.4') + '">' +
    (art.custom ? '<img class="card-custom" src="' + art.custom + '" alt=""><div class="bb-shade"></div>' : '') +
    (!art.custom && art.img ? '<img class="art-motif" src="' + art.img + '" alt="" style="height:' + bigH + 'px">' : '') +
    '<div class="art-body">' +
    '<div style="display:flex;gap:10px;flex-wrap:wrap">' +
    '<span class="pill" style="border:1px solid ' + kc + ';color:' + kc + ';text-transform:uppercase;letter-spacing:.8px;font-weight:900">' + esc(a.kat) + '</span>' +
    '<span class="pill" style="border:1px solid rgba(255,255,255,.14);color:rgba(244,251,255,.75)"><i style="width:7px;height:7px;border-radius:999px;background:' + o.d + '"></i>Erschienen bei ' + esc(a.outlet) + '</span>' +
    '</div><h2>' + esc(a.title) + '</h2></div></div>' +
    '<div class="art-content">' +
    '<p class="art-lead">' + esc(a.sub) + '</p>' +
    '<div class="art-meta"><span>' + esc(a.date) + '</span><span>·</span><span>' + fmtViews(a.views) + '</span><span>·</span><span style="color:#e50914">Vereinsredaktion FCB</span></div>' +
    blocksHTML(a.blocks || []) + '</div>';
}

/* ── Editor (Regie-Modus) ── */
var LBL = { text: 'Fließtext', head: 'Zwischentitel', quote: 'Zitat', player: 'Spielerkarte', match: 'Spielkarte', image: 'Bild' };
var PTOG = [['portrait', 'Portrait'], ['mw', 'Marktwert'], ['tore', 'Tore'], ['note', 'Ø-Note'], ['fit', 'Fitness']];
var MTOG = [['crests', 'Wappen'], ['score', 'Ergebnis'], ['scorers', 'Torschützen'], ['momentum', 'Matchmomentum'], ['zuschauer', 'Zuschauer']];

function blockEdHTML(b, i) {
  var h = '<div class="panel" style="padding:12px 14px"><div class="blk-head">' +
    '<span class="blk-tag">' + (i + 1) + ' · ' + LBL[b.k] + '</span><span style="flex:1"></span>' +
    '<button class="blk-btn" onclick="App.moveB(' + i + ',-1)">↑</button>' +
    '<button class="blk-btn" onclick="App.moveB(' + i + ',1)">↓</button>' +
    '<button class="blk-btn del" onclick="App.delB(' + i + ')">✕</button></div>';
  if (b.k === 'text' || b.k === 'head') {
    h += '<textarea class="inp" placeholder="Text schreiben…" oninput="App.updB(' + i + ',\'text\',this.value)">' + esc(b.text) + '</textarea>';
  } else if (b.k === 'quote') {
    h += '<textarea class="inp quote" placeholder="Zitat…" oninput="App.updB(' + i + ',\'text\',this.value)">' + esc(b.text) + '</textarea>' +
      '<input class="inp small" placeholder="Wer sagt das?" value="' + esc(b.autor) + '" oninput="App.updB(' + i + ',\'autor\',this.value)">';
  } else if (b.k === 'player') {
    h += '<div class="chips">' + Object.keys(P).map(function (pid) {
      return '<button class="chip' + (b.pid === pid ? ' on-cyan' : '') + '" onclick="App.updB(' + i + ',\'pid\',\'' + pid + '\')">' + P[pid].n + '</button>';
    }).join('') + '</div><span class="micro-label">Infos aus dem Spielerprofil</span><div class="chips">' + PTOG.map(function (t) {
      return '<button class="chip pill-t' + (b.f[t[0]] ? ' on-green' : '') + '" onclick="App.togB(' + i + ',\'' + t[0] + '\')">' + t[1] + '</button>';
    }).join('') + '</div>';
  } else if (b.k === 'match') {
    h += '<div style="display:flex;align-items:center;gap:8px;font-size:12px;font-weight:800;color:rgba(244,251,255,.7)"><img src="assets/crests/915.png" style="height:22px" alt="">FCB<span style="color:rgba(244,251,255,.4)">5:0</span>M05<img src="assets/crests/918.png" style="height:22px" alt=""><span style="font-size:10px;color:rgba(244,251,255,.35)">· Letztes Spiel, 33. Spieltag</span></div>' +
      '<span class="micro-label">Infos aus dem Spielbericht</span><div class="chips">' + MTOG.map(function (t) {
        return '<button class="chip pill-t' + (b.f[t[0]] ? ' on-green' : '') + '" onclick="App.togB(' + i + ',\'' + t[0] + '\')">' + t[1] + '</button>';
      }).join('') + '</div>';
  } else if (b.k === 'image') {
    h += '<div class="dropzone" onclick="App.pickImg(' + i + ')" ondragover="event.preventDefault();this.classList.add(\'over\')" ondragleave="this.classList.remove(\'over\')" ondrop="App.dropImg(event,' + i + ')">' +
      (b.src ? '<img src="' + b.src + '" alt="">' : 'Bild hierher ziehen oder klicken') + '</div>' +
      '<input class="inp small" placeholder="Bildunterschrift…" value="' + esc(b.cap || '') + '" oninput="App.updB(' + i + ',\'cap\',this.value)">';
  }
  return h + '</div>';
}

function editorHTML() {
  var ed = state.ed;
  var h = '<div class="ed-top"><span class="ed-label">NEWS-STUDIO · REGIE-MODUS</span><div style="display:flex;gap:10px">' +
    '<button class="btn-ghost" onclick="App.goHome()">Entwurf speichern</button>' +
    '<button class="btn-red" onclick="App.publish()">' + PLAY_SVG + 'Veröffentlichen</button></div></div>' +
    '<div class="ed-grid"><div style="display:flex;flex-direction:column;gap:14px">';

  h += '<div class="panel"><span class="panel-label">Schlagzeile</span>' +
    '<input class="inp" placeholder="Überschrift…" value="' + esc(ed.titel) + '" oninput="App.setEd(\'titel\',this.value)">' +
    '<input class="inp sub" placeholder="Untertitel…" value="' + esc(ed.sub) + '" oninput="App.setEd(\'sub\',this.value)"></div>';

  h += '<div class="panel"><span class="panel-label">Kategorie</span><div class="chips">' + KATS.map(function (k) {
    var on = ed.kat === k.n;
    return '<button class="chip" style="' + (on ? 'background:' + ha(k.c, .14) + ';border-color:' + ha(k.c, .55) + ';color:' + k.c : '') + '" onclick="App.setEd(\'kat\',\'' + k.n + '\')">' + k.n + '</button>';
  }).join('') + '</div></div>';

  h += '<div class="panel"><span class="panel-label">Ausstrahlung über</span><div class="chips">' + OUTLETS.map(function (o) {
    var on = ed.outlet === o.n;
    return '<button class="chip" style="' + (on ? 'background:' + ha(o.d, .14) + ';border-color:' + ha(o.d, .6) + ';color:#f4fbff' : '') + '" onclick="App.setEd(\'outlet\',\'' + o.n + '\')"><i class="dot" style="background:' + o.d + '"></i>' + o.n + '</button>';
  }).join('') + '</div><span class="hint">Deine News erscheint als Beitrag der Vereinsredaktion — das gewählte Blatt greift sie auf und zitiert den Verein.</span></div>';

  // Karten-Designer
  h += '<div class="panel" style="border-color:rgba(44,231,255,.28)"><div class="blk-head"><span class="panel-label cyan">News-Karte gestalten</span><span style="flex:1"></span>' +
    '<button class="chip on-cyan" onclick="App.setPrev(\'karte\')">Vorschau</button></div>' +
    '<span class="micro-label">Motiv</span><div class="chips">' + [['wappen', 'Wappen'], ['spieler', 'Spielerbild'], ['eigenes', 'Eigenes Bild']].map(function (m) {
      return '<button class="chip' + (ed.card.motiv === m[0] ? ' on-cyan' : '') + '" onclick="App.setCard(\'motiv\',\'' + m[0] + '\')">' + m[1] + '</button>';
    }).join('') + '</div>';
  if (ed.card.motiv === 'spieler') {
    h += '<div class="chips">' + Object.keys(P).map(function (pid) {
      return '<button class="chip' + (ed.card.pid === pid ? ' on-cyan' : '') + '" onclick="App.setCard(\'pid\',\'' + pid + '\')">' + P[pid].n + '</button>';
    }).join('') + '</div>';
  }
  if (ed.card.motiv === 'eigenes') {
    h += '<div class="dropzone" onclick="App.pickImg(-1)" ondragover="event.preventDefault();this.classList.add(\'over\')" ondragleave="this.classList.remove(\'over\')" ondrop="App.dropImg(event,-1)">' +
      (ed.card.customSrc ? '<img src="' + ed.card.customSrc + '" alt="">' : 'Hintergrundbild hierher ziehen oder klicken') + '</div>';
  }
  h += '<span class="micro-label">Akzentfarbe</span><div style="display:flex;gap:8px">' + ['#22e6ff', '#e50914', '#30f29c', '#ffd166'].map(function (c) {
    return '<button class="swatch' + (ed.card.accent === c ? ' on' : '') + '" style="background:' + c + ';box-shadow:0 0 10px ' + c + '" onclick="App.setCard(\'accent\',\'' + c + '\')"></button>';
  }).join('') + '</div></div>';

  // Bausteine
  h += '<span class="panel-label" style="padding:0 2px">Bausteine</span>' +
    ed.blocks.map(blockEdHTML).join('') +
    '<div class="panel add-panel"><span class="micro-label">+ Block hinzufügen</span><div class="chips">' +
    [['text', 'Fließtext', 'T'], ['head', 'Zwischentitel', 'H2'], ['quote', 'Zitat', '„"'], ['player', 'Spielerkarte', 'SP'], ['match', 'Spielkarte', 'VS'], ['image', 'Bild', 'IMG']].map(function (p) {
      return '<button class="chip add-chip" onclick="App.addB(\'' + p[0] + '\')"><b>' + p[2] + '</b>' + p[1] + '</button>';
    }).join('') + '</div></div>';

  h += '</div>'; // linke Spalte Ende

  // Vorschau rechts
  h += '<div class="prev-wrap"><div class="prev-head"><span class="prev-title">LIVE-VORSCHAU</span>' +
    '<div class="prev-toggle"><button class="' + (state.edPrev === 'artikel' ? 'on' : '') + '" onclick="App.setPrev(\'artikel\')">Artikel</button>' +
    '<button class="' + (state.edPrev === 'karte' ? 'on' : '') + '" onclick="App.setPrev(\'karte\')">News-Karte</button></div>' +
    '<span class="prev-live"><i></i>LIVE</span></div><div id="prevPane">' + previewHTML() + '</div></div>';

  return h + '</div><input type="file" id="imgInput" accept="image/*" style="display:none">';
}

function previewHTML() {
  var ed = state.ed;
  if (state.edPrev === 'karte') {
    var pa = { id: '_pv', kat: ed.kat, outlet: ed.outlet, title: ed.titel || 'Ohne Titel', date: '13.07.2026', isNew: true, card: ed.card };
    var art = cardArt(pa);
    return '<div class="prev-cardstage"><span class="prev-title" style="text-transform:uppercase">So erscheint deine News in den Reihen</span>' +
      '<div class="prev-bigcard" style="background:' + bgFor(pa) + '">' +
      (art.custom ? '<img class="card-custom" src="' + art.custom + '" alt="">' : '') +
      (!art.custom && art.img ? '<img class="card-motif" src="' + art.img + '" alt="" style="position:absolute;right:-4px;bottom:0;height:' + Math.round(art.imgH * 1.35) + 'px;object-fit:contain">' : '') +
      '<span class="badge-neu" style="position:absolute;top:10px;left:10px">NEU</span>' +
      '<div class="card-overlay"><span class="card-kat" style="color:' + katC(ed.kat) + '">' + esc(ed.kat) + '</span>' +
      '<strong class="card-title">' + esc(ed.titel || 'Ohne Titel') + '</strong>' +
      '<span class="meta-line" style="font-size:11px">13.07.2026 · ' + markChip(ed.outlet, true) + esc(ed.outlet) + '</span></div></div>' +
      '<span class="hint" style="text-align:center;max-width:340px">Motiv, Spieler und Akzentfarbe stellst du links unter „News-Karte gestalten" ein.</span></div>';
  }
  var kc = katC(ed.kat), o = outletOf(ed.outlet);
  return '<div class="prev-body">' +
    '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
    '<span class="pill" style="border:1px solid ' + kc + ';color:' + kc + ';font-size:10px;font-weight:900;text-transform:uppercase;letter-spacing:.8px;background:transparent">' + esc(ed.kat) + '</span>' +
    '<span class="pill" style="border:1px solid rgba(255,255,255,.14);color:rgba(244,251,255,.7);font-size:10px;background:transparent"><i style="width:7px;height:7px;border-radius:999px;background:' + o.d + '"></i>' + esc(ed.outlet) + '</span></div>' +
    '<h2>' + esc(ed.titel) + '</h2><p class="prev-sub">' + esc(ed.sub) + '</p><div class="prev-sep"></div>' +
    blocksHTML(ed.blocks) + '</div>';
}

/* ── SVGs ── */
var N_SVG = '<svg viewBox="0 0 34 60"><path d="M0 0h10v60H0z" fill="#8f070e"/><path d="M24 0h10v60H24z" fill="#8f070e"/><path d="M0 0h10l24 60H24z" fill="#e50914"/></svg>';
var N_SVG_BIG = '<svg viewBox="0 0 34 60" style="width:24px;height:42px"><path d="M0 0h10v60H0z" fill="#8f070e"/><path d="M24 0h10v60H24z" fill="#8f070e"/><path d="M0 0h10l24 60H24z" fill="#e50914"/></svg>';
var PLAY_SVG = '<svg viewBox="0 0 24 24" style="width:13px;height:13px" fill="currentColor"><path d="M6 4l14 8-14 8z"/></svg>';

/* ── Render ── */
function render() {
  var total = ALL().length;
  var h = '<div class="vn-head"><div class="vn-brand">' + N_SVG_BIG +
    '<div><h1 class="vn-title">VEREINS<b>N</b>EWS</h1>' +
    '<span class="vn-sub">' + total + ' Beiträge · Saison ' + SEASON + ' · Ausstrahlung über ' + OUTLETS.length + ' Blätter</span></div></div>';
  if (state.view === 'home') h += '<button class="btn-red" onclick="App.goEditor()">+ Neue News</button>';
  h += '</div>';
  if (state.view === 'home') h += homeHTML();
  if (state.view === 'article') h += articleHTML(state.art);
  if (state.view === 'editor') h += editorHTML();
  document.getElementById('vereinsnews-app').innerHTML = h;
}

/* ── App-API ── */
window.App = {
  open: function (id) { var a = findArt(id); if (a) { state.view = 'article'; state.art = a; render(); window.scrollTo(0, 0); } },
  goHome: function () { state.view = 'home'; render(); window.scrollTo(0, 0); },
  goEditor: function () { state.view = 'editor'; render(); window.scrollTo(0, 0); },
  setEd: function (k, v) { state.ed[k] = v; if (k === 'kat' || k === 'outlet') render(); else this.sync(); },
  setCard: function (k, v) { state.ed.card[k] = v; render(); },
  setPrev: function (p) { state.edPrev = p; render(); },
  updB: function (i, k, v) { state.ed.blocks[i][k] = v; if (k === 'pid') render(); else this.sync(); },
  togB: function (i, k) { var b = state.ed.blocks[i]; b.f[k] = !b.f[k]; render(); },
  moveB: function (i, d) { var bl = state.ed.blocks, j = i + d; if (j < 0 || j >= bl.length) return; var t = bl[i]; bl[i] = bl[j]; bl[j] = t; render(); },
  delB: function (i) { state.ed.blocks.splice(i, 1); render(); },
  addB: function (k) {
    var defs = { text: T(''), head: H(''), quote: Q('', ''), player: PL('kane'), match: M(), image: IMG(null, '') };
    state.ed.blocks.push(JSON.parse(JSON.stringify(defs[k]))); render();
  },
  pickImg: function (i) {
    var inp = document.getElementById('imgInput');
    inp.onchange = function () { if (inp.files[0]) App.readImg(inp.files[0], i); inp.value = ''; };
    inp.click();
  },
  dropImg: function (e, i) { e.preventDefault(); var f = e.dataTransfer.files[0]; if (f) App.readImg(f, i); },
  readImg: function (file, i) {
    var r = new FileReader();
    r.onload = function () {
      if (i < 0) state.ed.card.customSrc = r.result;
      else state.ed.blocks[i].src = r.result;
      render();
    };
    r.readAsDataURL(file);
  },
  publish: function () {
    var e = state.ed;
    state.published.unshift({
      id: 'p' + Date.now(), kat: e.kat, outlet: e.outlet,
      title: e.titel || 'Ohne Titel', sub: e.sub || '', date: '13.07.2026',
      views: 0, isNew: true,
      card: JSON.parse(JSON.stringify(e.card)),
      blocks: JSON.parse(JSON.stringify(e.blocks))
    });
    state.view = 'home'; render(); window.scrollTo(0, 0);
  },
  sync: function () { var p = document.getElementById('prevPane'); if (p) p.innerHTML = previewHTML(); }
};

render();
