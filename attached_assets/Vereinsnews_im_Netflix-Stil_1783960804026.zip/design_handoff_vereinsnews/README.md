# Handoff: Vereinsnews im Netflix-Stil (Websoccer)

## Overview
„Vereinsnews" ist ein neues Modul für den Football-Manager **Websoccer** (Django, deutsches UI):
Jeder Manager kann für seinen Verein eigene News erstellen und veröffentlichen. Die News-Übersicht
ist bewusst als **Netflix-Hommage** gestaltet (Billboard-Hero, horizontale Reihen, Top-10-Ranking,
rote Akzente, „N"-Logo als Anspielung auf Vereins**N**ews) — eingebettet in das dunkle
Websoccer-Design-System („MatchEngine": Stadion-Dunkel, Cyan-Hairlines, Glas-Panels).

Drei Ansichten in einem Modul:
1. **Übersicht** — Billboard + 3 Reihen
2. **Artikel** — Detailansicht einer News mit Content-Blöcken
3. **News-Studio (Regie-Modus)** — Editor mit Formular links und Live-Vorschau rechts

**Bewusst NICHT enthalten:** die Websoccer-Sidebar und der Kalender-Header. Das Modul ist ein
reiner Content-Bereich und wird in die bestehende App-Shell eingesetzt.

## About the Design Files
Die Dateien in diesem Bundle sind **lauffähige Design-Referenzen in purem HTML/CSS/JS** —
kein Framework, kein Build-Step. Da Websoccer auf Django-Templates + plain HTML/CSS läuft,
können Markup, CSS und JS **nahezu 1:1 übernommen** werden:

- `vereinsnews.html` → Grundgerüst; Inhalt des `<div id="vereinsnews-app">` wird clientseitig gerendert.
  Für Django: das Modul als Template-Include in den Content-Bereich der App-Shell einsetzen.
- `vereinsnews.css` → komplettes Stylesheet, nutzt die Token des Websoccer-Design-Systems als CSS-Variablen (`:root`).
- `vereinsnews.js` → Rendering + Interaktion + **Demo-Daten** (`ART`, `SOCIAL`, `P`). In Produktion
  ersetzt ihr die Demo-Arrays durch Server-Daten (Django-Context als JSON oder Fetch-Endpoint).
  Die Render-Funktionen bleiben unverändert.

⚠️ Wichtig für die Umsetzung: **Nichts neu erfinden.** Farben, Abstände, Schriftgrößen, Texte und
Layout exakt aus diesen Dateien übernehmen. Bei Abweichungen gilt der Code in diesem Bundle.

## Fidelity
**High-fidelity.** Pixel-genaue Vorlage: finale Farben, Typografie, Abstände, Hover-Zustände,
Copy (deutsch, Du-Form). Bitte 1:1 nachbauen.

## Screens / Views

### 1) Übersicht (`state.view === 'home'`)
- **Modul-Kopf**: Netflix-„N"-SVG (24×42, rot #e50914 mit Glow) + Titel `VEREINSNEWS`
  (25px/900, letter-spacing 2.5px, das zweite „N" rot) + Subline (11.5px/700, 38% weiß):
  `{n} Beiträge · Saison {SEASON} · Ausstrahlung über 10 Blätter`.
  Rechts: roter Button **„+ Neue News"** (öffnet Editor). KEINE Tabs.
- **Billboard** (Netflix-Hero): 400px hoch, radius 10px. Stadionfoto als Hintergrund
  (`object-position: center 30%`), Verlauf von links (96% schwarz → transparent), Motiv-Bild
  rechts (300px hoch). Inhalt links unten: Mini-„N" + Kicker `GERADE ERSCHIENEN · {KATEGORIE}`
  (12px/900, tracking 3px) → Titel 48px/900 → Untertitel 15px/600 → Meta-Zeile
  (Datum · Blatt-Logo + Blattname) → Buttons „▶ Jetzt lesen" (rot) und „Mehr Infos" (grau, blur).
  Rechts unten: **Saison-Chip** `S{n}` (roter linker Balken, dunkler Glas-Hintergrund).
  Zeigt IMMER die neueste News (`ALL()[0]`). Frisch veröffentlichte News → rotes NEU-Badge oben links.
- **Reihe „Neu im Verein"**: chronologisch, 7 Karten à 236×132px, radius 6px,
  Border `rgba(255,255,255,.08)`, Hover: `scale(1.05)` + Border `rgba(229,9,20,.75)`.
  Karten-Aufbau: Gradient-Hintergrund (Akzentfarbe), Motiv-Bild rechts unten, NEU-Badge,
  Overlay unten mit Kategorie (9px/900/uppercase, Kategoriefarbe), Titel (13.5px/800),
  Meta-Zeile `{Datum} · {Blatt-Logo}{Blattname}`.
- **Reihe „Top 10 nach Klicks"**: absteigend nach `views` sortiert (inkl. Social News).
  Netflix-Top-10-Look: riesige Ranking-Ziffer (132px/900, Füllung #03070c,
  `-webkit-text-stroke: 4px rgba(229,9,20,.8)`, überlappt die Karte um -14px) + Hochkant-Karte
  112×158px. In der Karte: Titel + Klick-Zähler in Cyan (Format `12,6k Aufrufe`, deutsch mit Komma).
- **Reihe „Fans & Medien"** (+ Subline „Beiträge deiner Fans und Social News, in denen dein
  Verein erwähnt wird"): Fan-Beiträge (Kategorie `Fans`) + `SOCIAL`-Einträge (Erwähnungen durch
  Kicker/Sky/Transfermarkt). Gleiches Kartenformat wie „Neu im Verein".

### 2) Artikel (`state.view === 'article'`)
- Back-Link „‹ Zurück zur Übersicht" (Hover rot).
- Hero-Banner 280px: Gradient in Kategoriefarbe, Motiv rechts, unten zwei Pills
  (Kategorie-Pill in Kategoriefarbe; „Erschienen bei {Blatt}" mit Farbpunkt) + Titel 38px/900.
- Content-Spalte max. 780px zentriert: Lead (18px/700) → Meta-Zeile
  (Datum · Aufrufe · „Vereinsredaktion FCB" in Rot) → **Content-Blöcke**:
  - **Fließtext**: 16px, line-height 1.75, 84% weiß
  - **Zwischentitel**: 22px/900
  - **Zitat**: roter Glow-Balken links (4px), Text 22px/800 kursiv, Autor uppercase 12px
  - **Spielerkarte**: Glas-Panel mit Cyan-Border, Portrait 84×84, Name + Positions-Badge (grün)
    + Meta, darunter Stat-Chips (Marktwert/Tore/Ø-Note/Fitness — je nach Toggle)
  - **Spielkarte**: Panel mit Bundesliga-Logo-Zeile, Wappen + `5:0` (38px/900), optional
    Torschützen (Minuten in Mono-Pills, cyan), Matchmomentum (Balkendiagramm grün/rot um
    Mittellinie), Zuschauerzahl
  - **Bild**: 300px cover, radius 8px, Bildunterschrift 11px; ohne Bild → gestreifter Platzhalter

### 3) News-Studio / Regie-Modus (`state.view === 'editor'`)
Grid `470px | 1fr`, Kopfzeile: Label `NEWS-STUDIO · REGIE-MODUS`, Buttons „Entwurf speichern"
(ghost → zurück) und „▶ Veröffentlichen" (rot).
- **Links (Formular)**, alles Glas-Panels (`rgba(9,23,34,.82)`, Cyan-Border, radius 8px):
  1. Schlagzeile (Input 16px/900) + Untertitel
  2. **Kategorie**-Chips (10 Kategorien, aktive in Kategoriefarbe)
  3. **Ausstrahlung über** — 10 Blätter-Chips mit Farbpunkt + Hinweistext („Deine News erscheint
     als Beitrag der Vereinsredaktion — das gewählte Blatt greift sie auf und zitiert den Verein.")
  4. **News-Karte gestalten** (Cyan-Label + „Vorschau"-Button): Motiv `Wappen | Spielerbild |
     Eigenes Bild` (Spielerbild → Spieler-Chips; Eigenes Bild → Dropzone mit Drag&Drop/Dateiwahl),
     Akzentfarbe: 4 Swatches (#22e6ff, #e50914, #30f29c, #ffd166)
  5. **Bausteine**: je Block ein Panel mit Tag (`1 · Fließtext`), ↑ ↓ ✕; Block-spezifische Felder
     (Spielerkarte: Spieler-Auswahl + Info-Toggles Portrait/Marktwert/Tore/Ø-Note/Fitness;
     Spielkarte: Info-Toggles Wappen/Ergebnis/Torschützen/Matchmomentum/Zuschauer;
     Bild: Dropzone + Bildunterschrift). Darunter gestrichelt: „+ Block hinzufügen".
- **Rechts (Live-Vorschau, sticky)**: Kopf mit `LIVE-VORSCHAU`, Umschalter **Artikel |
  News-Karte** und rotem LIVE-Punkt. Artikel-Modus: gerenderte Blöcke live bei jeder Eingabe.
  Karten-Modus: die News-Karte in groß (340×190) exakt wie in den Reihen, inkl. NEU-Badge.

## Interactions & Behavior
- Karte/Billboard-Klick → Artikel; Back-Link → Übersicht; „+ Neue News" → Editor.
- „Veröffentlichen" → News wird mit `isNew: true` und `views: 0` VOR alle Beiträge gesetzt →
  erscheint als Billboard + mit rotem NEU-Badge in den Reihen; zurück zur Übersicht.
- Karten-Hover: `transform: scale(1.05)`, Border wird rot, `transition .18s ease`, `z-index: 2`.
- Buttons: rot `#e50914` → Hover `#f6121d`, active `translateY(1px)`.
- Editor-Eingaben aktualisieren NUR die Vorschau (`#prevPane`), kein Full-Rerender
  (sonst verliert das Input den Fokus!). Chips/Toggles dürfen voll rerendern.
- Dropzone: `dragover` → Cyan-Border + Glow; Drop/Dateiwahl → FileReader-DataURL.
- Reihen scrollen horizontal (`overflow-x: auto`, Cyan-Scrollbar).

## State Management
```
state = {
  view: 'home' | 'article' | 'editor',
  art:   aktuell geöffneter Artikel,
  edPrev: 'artikel' | 'karte',        // Vorschau-Modus im Editor
  published: [Article],               // vom Manager veröffentlicht (vor ART)
  ed: { titel, sub, kat, outlet,
        card: { motiv: 'wappen'|'spieler'|'eigenes', pid, accent, customSrc },
        blocks: [Block] }
}
Article = { id, kat, outlet, title, sub, date, views, isNew?, img?, imgH?, card?, blocks }
Block   = { k:'text'|'head'|'quote'|'player'|'match'|'image', ... }  // siehe vereinsnews.js
```
In Produktion: `published`/`ART` aus der Datenbank (Django-Model je News mit JSON-Feld für
`blocks` + `card`), `views` serverseitig zählen, `SEASON` aus dem Spielstand.

## Design Tokens
- Basis `#03070c` · Glas-Panel `rgba(9,23,34,.82)` · Text `#f4fbff` (muted 64%, faint 38%)
- Cyan (funktional) `#22e6ff` · Grün (positiv) `#30f29c` · **Netflix-Rot `#e50914`** (Hover `#f6121d`)
- Hairline `rgba(44,231,255,.18)` → stark `.38` · Kategorie-Farben: siehe `KATS` in vereinsnews.js
- Blatt-Farben + Logo-Kürzel: siehe `OUTLETS` (VR, KIC, SKY, SPX, TM, 90M, TA, MS, OF, 90+);
  Kürzel-Chip: 16×15px, radius 3px, Textfarbe automatisch nach Luminanz (hell → dunkle Schrift)
- Font: **Inter** (400–900), Zahlen/Minuten: **JetBrains Mono** · Radius: 8px (Karten 6px, Pills 999px)
- Seitenhintergrund: Websoccer-Gradient (Cyan-Flutlicht oben, grüner Pitch-Glow unten links)

## Assets
Alle im Ordner `assets/` (aus dem Websoccer-Repo, Pfade beibehalten):
`backgrounds/fc-bayern-stadium.jpg` (Billboard), `crests/915.png` (FCB), `918.png` (Mainz),
`901.png` (Leverkusen), `competitions/bundesliga.png`, `players/*.png` (Kane, Olise, Musiala,
Neuer, Kimmich, U19-Talent). Das Netflix-„N" ist ein Inline-SVG (siehe `N_SVG` in vereinsnews.js).

## Files
- `vereinsnews.html` — Einstieg / Grundgerüst (im Browser öffnen zum Ansehen)
- `vereinsnews.css` — komplettes Stylesheet mit Tokens
- `vereinsnews.js` — Rendering, Interaktion, Demo-Daten
- `assets/` — Bilder

## Integration in Websoccer (Django) — Empfehlung
1. `vereinsnews.css`/`vereinsnews.js` nach `game/static/game/...`, Assets liegen dort bereits.
2. Neues Template `game/templates/game/vereinsnews.html`, das die App-Shell erweitert
   (Sidebar + Kalender kommen von der Shell) und nur `<div id="vereinsnews-app">` + die beiden
   Static-Includes einbindet.
3. Demo-Arrays `ART`/`SOCIAL` durch `{{ news_json|safe }}` aus dem View-Context ersetzen.
4. „Veröffentlichen" per `fetch('POST /api/vereinsnews/')` an ein Django-Endpoint anschließen.
