Harness-Mock für das Zielbild der Geländeanforderung (Augsburg, 14.10.2026). Kopie des Replit-Stands
`static_replit` mit EINER Änderung in `stadium_editor/dortmund_surroundings.js` (Block „MOCK"): optionale
`surroundings.groundLevel` (Meter, hebt die gesamte Umfeldgruppe) und `surroundings.groundCutout`
(Polygon in Modellkoordinaten x,z, spart den Umfeldboden innerhalb des Stadionkörpers aus).
Kein Renderer-Patch für Replit, keine Änderung an static_replit; dient nur den Vorher-/Zielbildern
der Anforderung `GELAENDE-ANFORDERUNG.md`.
