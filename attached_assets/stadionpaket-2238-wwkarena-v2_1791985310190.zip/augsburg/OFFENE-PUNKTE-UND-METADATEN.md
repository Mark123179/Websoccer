# WWK ARENA (FMI 2238) — Fassung 2: offene Punkte und Metadaten

Getrennte Liste. Nichts davon ist im Paket umgesetzt; Entscheidung und Freigabe liegen beim Betreiber. Kapazitäten, Blocktypen, Reihen, Plätze, RLE, Designs, Ausbauten und wirtschaftliche Stadionfelder werden **nicht** vorgeschlagen oder verändert.

## A · Entscheidungen zum Modell (Empfehlung jeweils zuerst)
1. **Dachtrennung per Export-Aufbereitung** (`DACH_`-Präfix für 59 nach Funktion bestimmte Quellmeshes, `roofMinHeight −1`): 96.252 / 96.252 Dachdreiecke, 0 falsch entfernte Körperdreiecke, 0 verbliebene Dachteile. Alternative: Vertragsvorschlag `roofMeshNames` (`DACH-VERTRAG-VORSCHLAG.md` §2) — dann ohne Umbenennung, Umsetzung in Replit gesondert.
2. **Fassadenstützen `front3_27`/`front3_27.001` bleiben Körper** (Beton-Kolonnade 7,7–22,1/26,2 m, Fußpunkt Umlaufniveau, reale Außenerscheinung; 720 Dreiecke). Alternative: in `dach_namen.json` aufnehmen → schaltet mit dem Dach (Re-Export, neue assetVersion).
3. **Innere Dachstützen `front3_2`/`front3_2.001` (metal_a, 14–23 m, hinter dem Oberrang) schalten mit dem Dach** (Tragwerk; Präzedenz Wolfsburg/Freiburg). Alternative: Körper → stünden bei „Dach aus" als Metallstiele auf dem Oberrang.
4. **Fassadengitter aus der AD-Wurzel exportiert** (`ad_st009_normal_02/08/10/12`, galvanisiertes Rohrgitter bzw. diffuseTexture_171 mit 25 % Deckung → Alpha-Schnitt; nach Funktion Fassade, nicht Werbung; reale Aluminiumrohr-Fassade seit 2017). Banden, LED-Platzhalter, Choreo-Banner und Logos der AD-Wurzel bleiben per exakten Namen ausgeschlossen. Alternative: AD-Wurzel ganz weglassen wie in Fassung 1 (optisch kaum Unterschied, `isolation/ad-wurzel-probe.jpg`).
5. **Lichtfaktor 1 beibehalten** (Fixtures 60, 12 Laufzeit- für 50 Quellleuchten); keine globale Verstärkung für die Ränge. Bildvergleiche in `bilder/licht/` sind keine unabhängige Prüfung physikalischer Abschattung.
6. Kulisse `center2_0…10` + Bäume/Stadtrand ausgeschlossen; Vorplatzplatten `center2_1/4` **nicht** wieder eingeblendet (nicht abgenommen). Geländeanschluss → §C.

## B · Lokale Tribünenzuordnung (verbindlich nach Augsburg-Review, bereits lokal korrigiert)
`meta.homeStand = NORD`, `scene_meta.mainStand = WEST`, `scene_meta.farStand = OST` (lokal vorher SUED/SUED/NORD — alle drei falsch; die Vorschau-Aussage „Heimkurve war bereits richtig" galt nur für den öffentlichen Stand). Rahmenlabels: NORD = Ulrich-Biesinger-Tribüne (Heimbereich K–O), WEST = Haupttribüne D–H mit VIP E/F/G, OST = Gegengerade R–V, SUED = Südtribüne mit Gästen W/X in der Südost-Ecke. Modellachsen `+x OST, −x WEST, +z NORD, −z SUED`, Umfeldachsen `{NORD +z, WEST −x}`; nicht gedreht/gespiegelt. Nichts davon im Paket; alte Vorschaudaten (`werkzeuge/render/livescene_2238_vorschau.json`: homeStand NORD, mainStand NORD, farStand SUED) beschreiben **nicht** den lokalen Stand und ersetzen die Korrektur nicht.

## C · Geländeanschluss — **offen** (Anforderung geliefert, keine Lösung behauptet)
Spielfeld y 0, Umlauf/Vorplatz y 7,7 (real: Spielfeld 8 m unter dem ursprünglichen Gelände), Renderer-Umfeldboden y −0,35 → Umlauf und Fassadenfußpunkte stehen 7,7 m über dem Umfeld, Sockelwände 0…7,7 m sichtbar. Mit den verfügbaren Quellen (nur flache Kulissenplatten, keine Böschungen/Rampen) ist ohne Renderer-Funktion kein belastbarer Anschluss möglich. `GELAENDE-ANFORDERUNG.md` liefert Quellbefund (Meshes, Hierarchie, Material, Bounds, Funktion), die generische Anforderung `surroundings.groundLevel` + `surroundings.groundCutout` (Polygon = konvexe Hülle der Umlaufplatte `center1_28`, `quellbelege/gelaende_umlaufplatte.json`), die Validierung, den betroffenen OSM-Eintrag (`bg.green[3]` = Spielfeldpolygon, entfällt in der Aussparung) sowie Vorher-/Zielbilder aus identischen Kameras (vier Seiten tief, Übergänge nah, Draufsicht; Mock nur im Harness `werkzeuge/render/mock_gelaende/`, Diff `MOCK-DIFF.patch`). Keine stillschweigende Bodenhöhenänderung, keine anderen Stadien betroffen. Umsetzung in Replit = gesonderter Auftrag.

## D · Schutzdaten (lesend, keine Korrektur)
Lokale Kapazität 30.660; wirtschaftliche Stehplätze lokal NORD 5.366, SUED 1.150, OST/WEST 0. Öffentliche Renderzellen (NORD 8.256 Steh, SUED UNTER 3.250 Steh, WEST 2.232 VIP), Bundle-Kapazität 31.302 und 22.852 Quell-Sitzplatzeinträge sind keine Importwerte. Crowd-Bezeichnungen (`C_right1_C3-UltraHome` am −z-Ende neben `C_right1_C1-UltraAway`) sind Vorlagenzuordnungen; keine Neuverortung.

## E · Hinweise ohne Handlungsbedarf
- Quasi unsichtbare Meshes `center1_46` (Drähte/Pfosten, y 0…24,6) und `center1_1` (y 0…28,9) bleiben Körper (`isolation/unsichtbare-meshes-rot.jpg`).
- `field_3` (Kunstrasenstreifen vor der Haupttribüne) bleibt Quellmaterial; keine Rasenunterlage unter dem Spielfeld.
- Umfeld vollständig und gültig (26 Gebäude, 189 Straßen, 47 Grün, 0 Wasser), keine Ausnahme, kein Gebäudefilter; Anker Bürgermeister-Ulrich-Straße NORD, B 17 OST, XXXLutz Südost, Trainingsplatz/Kurt-Bösch-Straße WEST bestätigt.
- Fassung-1-Bilder liegen als historischer Stand in `bilder/historisch_fassung1/` (Dachkompromiss roofMinHeight 22, Plattenvariante).
- Replits `editor.js` (v65) nicht lesbar (> 100 KB); 2D-Ansicht mit produktivem `editor.js` (playwebsoccer.de, 14.10.). Produktion hatte am 13.10. noch keinen Unity-Renderer deployt.
