# WWK ARENA · FC Augsburg (FMI 2238) — Fassung 2 (nach dem Augsburg-Review)

Stand 14.10.2026 · Quelle `augsburg.bundle` (FM26 Stadium Megapack v3.0, 142 MB, SHA-256 `d45c4049174100a2dd7b191f9a155ebe3734d9b6768848800c3beb52b5e560a0`) + `augsburg.json` (22.852 Sitzplatzeinträge), `_lightmaps.json`, `_lightprobes.json` (Prüfsummen in `models/2238.json` → `sourceEvidence`).
assetVersion **`7718595a38dc4253`** (Fassung 1: `2e3fd6a59307b6ea`), geometrySha256 `6c9c6d7a39f8035834661655bdcab71d8368f05e827e09993929a70280b6e06c` (Fassung 1: `7fedb4c8…e029` — geändert durch die vier Fassadenmeshes der AD-Wurzel, sonst identische Quellgeometrie), Manifestrevision `fab55d5485e3f8ce` (Lichtfaktor 1 = keine Änderung), 217 Meshes (261.939 Dreiecke), 67 Texturen, **68 Assets**, 14,5 MB, 50 quellgeprüfte Leuchten → 12 Laufzeitleuchten.
Identität nur über `clubFmiId 2238` + Vereins-/Stadionname; keine lokale Vereins-/Stadion-ID, keine Kapazität im Paket. Geprüft gegen den Replit-Stand vom 13.10.2026 (`unity_stadium_scene.js` mit `dortmund_surroundings.js?v=52`, `unity_calibration.js?v=2`, Registry mit `validate_surroundings_axes`, `pitch_validation` boundary-cross-sections-v1); **kein Renderer-Patch, keine neuen Manifestfelder vorausgesetzt**. Beide Manifestkopien (`models/2238.json`, `stadium-models/2238/7718595a38dc4253/manifest.json`) sind byteidentisch.

## Was sich gegenüber Fassung 1 geändert hat
| Punkt | Fassung 1 (nicht abgenommen) | Fassung 2 |
|---|---|---|
| Dachtrennung | Präfixe `front3_`/`faros`/`center3_df_`/`center1_2`/`center1_3` + `roofMinHeight 22`: 95.069 Dach, **6 Körperdreiecke falsch entfernt**, **1.853 Dachdreiecke verblieben** | 59 Dachmeshes **nach Funktion mit exakten Quellnamen** bestimmt, im Export mit `DACH_`-Präfix aufbereitet (Quellgeometrie/Transformation/Material/Reihenfolge unverändert, `pathId` + `hierarchy[0]` = Quellname), `roofMeshPrefixes ["DACH_"]`, `roofMinHeight −1`: **96.252 / 96.252 Dach, 0 / 0 Fehler** |
| Fassade | AD-Wurzel nicht exportiert | Fassadengitter `ad_st009_normal_02/08/10/12` nach Funktion exportiert; Banden/Banner/Logos/LED-Platzhalter der AD-Wurzel per Namen ausgeschlossen |
| Gelände | Kulisse raus, Plattenvariante geprüft | unverändert Vorzustand; **Anforderung `GELAENDE-ANFORDERUNG.md`** mit Quellbefund, generischem Vertrag (`groundLevel` + `groundCutout`), Vorher-/Zielbildern (Mock nur im Harness) |
| Tribünenmetadaten | Vorschau NORD/NORD/SUED | lokal verbindlich **NORD / WEST / OST** (bereits korrigiert); Paket enthält nichts davon |
| Bilder | Paketbelege Fassung 1 | neu gerendert (Endstand `fab55d5485e3f8ce`), Dach an/aus aus identischen Kameras inkl. Sitzkamera; Fassung-1-Bilder in `bilder/historisch_fassung1/` |

## Befund in einem Satz
Vollständiges FM-Bundle (331 Objekte: 84 Figuren, 18 AD, 16 Kulissenmeshes, 8 EXTRA, 221 Stadion-/Crowd-/Spielfeldmeshes) einer **eingesenkten Schüssel** (Spielfeld y 0, Umlauf/Vorplatz y 7,7) mit Dachfamilie `front3_*` + Hauptdach `center1_2`/`center1_3.003` + Haupttribünendach `faros.001` + Membran `center3_df_*`, **ohne Fangnetze**; 16 Kulissen- und 14 Werbemeshes per exakten Namen ausgeschlossen, Rest unverändert.

## 1 · Kurvenlage: vier unabhängige Ebenen
| Ebene | Befund | Beleg |
|---|---|---|
| **Reales Stadion** | Offizieller Blockplan (fcaugsburg.de, Nord links): Ulrich-Biesinger-Tribüne = Heimbereich K–O (Steh, Stadionordnung 6.1), Kurve Nord-Ost P/Q, Gegengerade R–V, Gästebereich W/X = Kurve Süd/Ost (6.2), Tribüne Süd X/Y/Z/A, Kurve Süd-West B/C, Haupttribüne D–H mit VIP E/F/G (Eingang 1/VIP), Familienblock I/J (NW). Umfeld (OSM/Nominatim): Bürgermeister-Ulrich-Straße **nördlich**, B 17 **östlich**, XXXLutz **südöstlich**, Kurt-Bösch-Straße/Trainingsplatz 1 **westlich**. Gelände: „the playing field is 8 metres lower than the original terrain" (Titus Bernhard Architekten). | `quellbelege/blockplan_wwk_arena.png`, `anker_augsburg.json`, `umfeld_pruefung.json`, `osm_*.json` |
| **Quellmodell (native Bounds)** | Bänke `center1_probe_0…35` x −40,7…−40,0, Presse `center1_67`, VIP `center1_26`, Glas `center1_69/69.001` x −68…−56 → **−x Haupttribüne**. Gästezaun 9,3 m `center1_41.001`/`center1_64.001` x 40,3…50,6 / z −62,1…−55,7 → **Ecke −z/+x = Südost** = Gäste W/X; `C_right1_C1-UltraAway` ebendort. Choreo-Banner (AD, nicht exportiert) und `C_left1_C3-UltraHome` am **+z-Ende = Heimkurve**. Spielfeldachse z. Crowd-Namen sind Vorlagenzuordnungen (`C_right1_C3-UltraHome` zusätzlich am −z-Ende) — keine Neuverortung. | `quellbelege/inventar_alle.json`, `bilder/isolation/*` |
| **Blaupause** | `axisTheta 92,5°` → gerichtetes **NORD-Ende 357,5°** (geografisch Nord), SUED 177,5°, OST 87,5°, WEST 267,5°; `fieldC [0,6, 3,5]`; WEST mit 3 VIP-Blöcken. Rahmenlabels = Rahmenkonvention (fallen hier zufällig mit realen Namen zusammen). | `bilder/00-2d-editor.jpg` |
| **Wirtschaft (lesend)** | **Lokal verbindlich:** Kapazität 30.660, Stehplätze NORD 5.366 / SUED 1.150 / OST, WEST 0; Zuordnung homeStand NORD, mainStand WEST, farStand OST (lokal korrigiert). Öffentliche Renderzellen (NORD 8.256 Steh, SUED UNTER 3.250 Steh, WEST 2.232 VIP), Bundle 31.302, Quelle 22.852 — keine Importwerte. | `OFFENE-PUNKTE-UND-METADATEN.md` §B/§D |

**Ergebnis:** `standAxes {+x: OST, −x: WEST, +z: NORD, −z: SUED}`, `surroundingsAxes {NORD: +z, WEST: −x}`; nicht gedreht/gespiegelt. Gegenprobe (`bilder/12`, `13`): Bürgermeister-Ulrich-Straße (NORD) 0,7/1,8 m, B 17 (OST) 0,1 m, Forschungsallee (OST) 1,7 m, XXXLutz (SUED/OST) 0,0 m, Weg Richtung Inningen (SUED) 3,2 m, Kurt-Bösch-Straße (WEST) 0,4 m, Trainingsplatz 1 (WEST) in bg-Grünfläche; OSM-Spielfeldachse 177,9° vs. 177,5°. Ticker gemeinsam (`tickerRotationY −90`, Bänke bei −x), `tickerFrontCut (1,0,0)/32`, Orbit 0,95/0,65/340, Sitzkamera Haupttribüne (−x, 16,5 m).

## 2 · Vorgehen (Fassung 2)
1. Vollinventar aller 331 Objekte inkl. Zusatzwurzeln SCARECROW/AD/EXTRA (`quellbelege/inventar_alle.json`: Name, Pfad/Hierarchie, Dreiecke, Bounds, Materialien, Alpha).
2. Funktionsprüfung jedes Bauteils ≥ 20 m durch Isolierung/Rotfärbung im aktuellen Renderer (`bilder/isolation/funktionspruefung-dachrand-stuetzen-gelaender.jpg`, `unsichtbare-meshes-rot.jpg`, `gruppen-isolation-uebersicht.jpg`, `ad-wurzel-probe.jpg`).
3. Zuordnung nach Funktion (`dach_namen.json`, 59 Einträge mit Funktionstext): Dachhaut `front3_7/9/23/25` (+`.001`), Membran `center3_df_0/1`, Dachunterseiten `front3_7.002…005` (EXTRA), Hauptdach `center1_2`, Dachplatte `center1_3.003`, Haupttribünendach `faros.001`, Tragwerk `front3_0/3/5/13/15…21/24/26/28` (+`.001`), innere Dachstützen `front3_2/2.001`, Dachrandgeländer/-leitern `front3_4/22/22.001`, Dachkanten `front3_1/11.001/12`, Seil-/Firstrahmen `front3_11/14/14.001`, Flutlichtzeilen `front3_6/6.001` (light_e) und `front3_10/10.001` (lights_a), Dachaufbauten `center1_56/57/68`. **Körper:** Fassadenstützen `front3_27/27.001` (begründet), Haupttribünenkörper der Szene front3 (`center1_4.001/5.002/10.001/11.001/12.001/15.001/18.001/22…26/28.001/34.001/62.001/65/67/69`), Oberrang-Abschluss/Geländer/Pfosten `center1_15/18/36`, Drähte `center1_46/1`, Fassadengitter `ad_st009_normal_02/08/10/12`.
4. Export Fassung 7 mit `--roof-names` (Aufbereitung) und `--roots EXTRA,AD` + exakten Ausschlüssen (`ausschluss_namen.txt`: 16 Kulisse + 14 Werbung/Banner), Bodenregeln `boden_2238.json`, Lichtprüfung Faktor 1, Nachrechnung, Abnahmeserie.

## 3 · Dachschalter
`roofMeshPrefixes ["DACH_"]`, `roofMinHeight −1`. Nachrechnung über das Binary, Regel identisch zum Renderer (`quellbelege/nachweise.json`): **Dach 96.252 / 96.252** (front3-Familie 60.880, Hauptdach 23.573, Haupttribünendach 11.623, Membran 120, Aufbauten 56); Körper: `center1_*` 0 / 157.413, Fassadenstützen 0 / 720, Fassadengitter 0 / 1.634, Crowd 0 / 394, Spielfeld/Boden 0 / 5.500 — **kein gelistetes Mesh mit Körperdreiecken, kein ungelistetes mit Dachdreiecken, keine Stummel**. Dach an/aus aus identischen Kameras: Editor `01/02`, Ticker `03/04`, Draufsicht `06/07`, Gegenseite `09/08`, **Sitzkamera `10/10b`**, tief `isolation/dach-an-aus-identische-kameras.jpg`. Umbenennungsnachweis `dach_aufbereitung_bericht.json` (Quellname, Exportname, pathId, Hierarchie, Material, Bounds, Funktion). Vertragsvorschlag für exakte Namen ohne Umbenennung: `DACH-VERTRAG-VORSCHLAG.md`.

## 4 · Spielfeld, Boden, Licht, Gelände
- Spielfeld (`pitch_validation`, Linienmittelachsen, Mesh `st081_pitch_1`): **105,000 × 68,000 m**, Längsachse z, Geometriehash = Manifest.
- `boden_2238.json` (override): transparent 2 (`field_0` Trainerzonen, `center1_1.001` Schachtdeckel), Rasenangleichung 0, Alpha-Schnitt 13 (Geländer, Zäune, Leitern, Presse, Fassadengitter), transluzent 2 (VIP-Glas 26 %, Bankglas 23 %), unsichtbar 0; `field_3` Kunstrasenstreifen bleibt Quelle.
- **Licht:** 50 Spots an der Traufe (y 26,8, `front3_6/10`, ≤ 1,2 m) → 12 Laufzeitleuchten, **Faktor 1, Intensität 60**, Montageorte/Richtungen/Winkel/Farben/Reichweiten/Gruppen quellgeprüft (`lichtkalibrierung_beleg.json`, Revision vorher = nachher `fab55d5485e3f8ce`, Renderer-Hash `b1790564…69fb`). Nacht ×1: Rasen 97 / Gegentribüne 30 / Sitzfläche 35 / Seitenränge 50 (Referenzen Freiburg ×8 86/71/95/98, Wolfsburg ×1,5 89/75/98/110, Bremen ×2,5 84/42/53/112); ×1,5 = 124 (Rasen blass). Keine globale Verstärkung; `bilder/licht/` sind Bildvergleiche, keine Prüfung physikalischer Abschattung.
- **Gelände:** offen — `GELAENDE-ANFORDERUNG.md` (Quellbefund, Anforderung `groundLevel 7,7` + `groundCutout` = Umlaufplatte `center1_28`, Validierung, Vorher-/Zielbilder `bilder/gelaende/`, Mock nur `werkzeuge/render/mock_gelaende/` mit `MOCK-DIFF.patch`). Keine Böschungen/Platten erfunden, Modell nicht angehoben, keine anderen Stadien verändert.

## 5 · Umfeld
Vollständig (26 Gebäude, 189 Straßen, 47 Grünflächen, 0 Wasserflächen), ungefiltert, keine ungültigen Flächen, keine Ausnahme (`quellbelege/umfeldbericht.json`). Hinweis für die Geländefunktion: `bg.green[3]` ist das OSM-Spielfeldpolygon (x ±34 / z ±53 innerhalb der Aussparung).

## 6 · Abnahmeserie (`bilder/`)
`00-2d-editor.jpg` (+ roh) · `01/02` 3D-Editor Dach an/aus · `03/04` Ticker an/aus · `05` Nacht mit Flutlicht · `05b` Nacht ohne · `05c` Tag mit Flutlicht · `06/07` Draufsicht an/aus · `08/09` Gegenseite aus/an · `10/10b` **Sitzkamera an/aus** · `11` Editor Nacht · `12/13` verortete Draufsicht · `14-seite-{nord,sued,ost,west}-tief` (vier Seiten, el 10°) · `gelaende/` (Vorher/Ziel, vier Seiten, Übergänge nah, Draufsicht; `vorher-ziel.jpg`, `vorher-ziel-boden-aufgehellt.jpg`) · `isolation/` · `licht/` · `historisch_fassung1/` (klar als Vorzustand bezeichnet). Alle neuen Bilder mit dem Endstand `fab55d5485e3f8ce`.

## 7 · Paketinhalt
`models/2238.json` · `stadium-models/2238/7718595a38dc4253/` (geometry.bin + 67 Texturen + identische Manifestkopie) · `PRUEFSUMMEN.sha256` · `kalibrierung.json`, `boden_2238.json`, `ausschluss_namen.txt`, `dach_namen.json`, `ausschluss_bericht.json`, `bodenregeln_bericht.json`, `dach_aufbereitung_bericht.json`, `lichtkalibrierung_beleg.json` · `quellbelege/` (inkl. `nachweise.json` Fassung 2, `nachweise_fassung1_roofMinHeight22.json`, `gelaende_umlaufplatte.json`) · `bilder/` · `OFFENE-PUNKTE-UND-METADATEN.md` · `GELAENDE-ANFORDERUNG.md` · `DACH-VERTRAG-VORSCHLAG.md` · `werkzeuge/` (Export Fassung 7, Nachweise, Lichtprüfung, 2D-Beschriftung, Harness 3D + 2D mit unverändertem Replit-Renderer-Stand `static_replit`, Mock `mock_gelaende` getrennt). Keine Backups, keine Secrets, keine Sitzungen, kein Original-Bundle.

## 8 · Einspielen (Replit — zunächst nur Prüfung; Kontrolle ist keine Freigabe)
1. Lokale Identität (FMI 2238, FC Augsburg, WWK Arena) lesend prüfen; Freigabe für Dachaufbereitung/Stützen (§3, OFFENE-PUNKTE §A), Fassadengitter, Lichtfaktor 1, Geländeanforderung einholen.
2. Vorher-Backup Verein/Stadium/Geometrie/Design/Ausbauten (privat, nicht ins Paket).
3. `scp -r stadium-models/2238 root@49.13.5.151:/var/www/assets/stadium-models/`; zurückladen und gegen `PRUEFSUMMEN.sha256` prüfen.
4. `models/2238.json` nach `stadium_editor/blueprints/v2/models/`, committen, `/push`; `python manage.py check_stadium_model --fmi 2238 --assets` → `Assets OK: 68 Dateien`. **Kein Lichtfaktor anzuwenden.**
5. Metadaten sind lokal bereits NORD/WEST/OST — nicht durch Vorschaudaten ersetzen; Nachher-Abgleich: Kapazitäten, Blöcke, Designs, Ausbauten identisch.
6. Abnahme im Livemodus mit echten Zielassets: Dach an/aus aus Editor, Ticker, Draufsicht, Gegenseite, Sitzkamera; Anker Bürgermeister-Ulrich-Straße NORD, B 17 OST, XXXLutz Südost, Trainingsplatz/Kurt-Bösch-Straße WEST.
**Nicht erfolgt:** Registrierung, Assetupload, externe Serverübertragung, Veröffentlichung.

## Reproduktion
```sh
python3 -I werkzeuge/export_stadium_model.py --bundle augsburg.bundle --seats augsburg.json --fmi 2238 --name "WWK ARENA" \
  --out export --calibration kalibrierung.json --roots EXTRA,AD --lamp-materials light_e,lights_a --ground boden_2238.json \
  --exclude-meshes "$(cat ausschluss_namen.txt)" --roof-names dach_namen.json          # → assetVersion 7718595a38dc4253
python3 -I werkzeuge/licht_kalibrieren.py export augsburg.bundle 1.0 lichtkalibrierung_beleg.json \
  --renderer werkzeuge/render/static_replit/stadium_editor/unity_stadium_scene.js     # Faktor 1 = keine Änderung, Quellprüfung/Beleg
python3 -I werkzeuge/dach_nachweis.py export nachweise.json 'dach=^DACH_' 'stuetzen_koerper=^front3_27' 'koerper_center1=^center1_'
python3 -I werkzeuge/build_presentation.py 2238 "WWK ARENA" export/manifest.json 7718595a38dc4253 livescene_13.json stadium_data_all.js.gz render/presentation_ab_v2.json
cd werkzeuge/render && python3 shoot.py '[["editor_an","r=static_replit&p=presentation_ab_v2.json&mode=orbit",1000,560],["editor_aus","r=static_replit&p=presentation_ab_v2.json&mode=orbit&roof=0",1000,560]]' ../../bilder
python3 shoot.py '[["ziel","r=mock_gelaende&p=presentation_ab_v2_mock.json&mode=orbit&az=315&el=8",1000,560]]' ../../bilder/gelaende   # Zielbild-Mock
```
Quellen (14.10.2026): Blockplan https://www.fcaugsburg.de/page/ticket-heimspiele-15 · Stadionordnung https://www.fcaugsburg.de/stadionordnung · Geländelage https://architizer.com/projects/wwk-arena/ („8 metres lower than the original terrain") · OSM/Nominatim (ODbL) Stadion way 38532924, Spielfeld way 181899832.
