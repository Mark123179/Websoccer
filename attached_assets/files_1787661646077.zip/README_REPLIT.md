# STADION-EDITOR · Vollständiges Replit-Paket

Stand: 25.08.2026 · Projekt: BLUEPRINT Fußballmanager (playwebsoccer.de) · Django 6.0.7

---

## 0. Für den Agent in einem Satz

Der Stadion-Editor ist **fertig entwickelt und getestet** und liegt als lauffähiger Prototyp
bei. Deine Aufgabe ist **Verdrahtung in das bestehende Django-Projekt** — kein Neubau von
Editor-Logik, kein Redesign, keine Änderungen an Shell, Navigation, Kalender oder den
bestehenden Modellen `Stadium` / `StadiumExpansion` außer den hier genannten Stellen.

---

## 1. Was das Feature ist

Manager gestalten das Stadion ihres Vereins: **Sitzschalenfarben** dauerhaft, später
**Choreografien** pro Spiel. Kernprinzip (Idee von BΛDCП / Artificial, Credit ist Pflicht):
**nicht malen, sondern pressen** — Bild oder Text wird als Ganzes aufs Sitzraster projiziert
und auf die Palette quantisiert. Ein Codepfad für Bild und Text.

Die Blöcke sind die Objekte, nicht das Stadion: `Block = Array[reihen][plätze]` mit Farbindex.

---

## 2. Was in dieser Session entstanden ist (Chronologie)

1. **Editor-Prototyp** — 2D-Bearbeitung, 3D-Ansicht, Press-Operation, Palette, Objekte
2. **Import-Pipeline V1–V21** — 21 Iterationen Härtung an 19 echten Bundesligastadien
3. **Blueprint-Schicht** — deklarative Stadionbeschreibung pro Tribüne/Ecke
4. **PoC** — Olympiastadion Berlin, San Siro, Wembley + BVB als Bundesliga-Muster

### Warum 21 Iterationen? (jede erzwungen durch ein echtes Stadion)
- Multipolygon-Relationen (BayArena hat keinen einzelnen Umriss-Way)
- Gelände-Polygone statt Tribünen (Union Berlin, Mainz)
- Zackige OSM-Umrisse (Bremen, St. Pauli, Kiel)
- Rechteckstadien wurden rundgeschliffen (Bochum, Heidenheim, Freiburg)
- Ungemappte moderne Schüssel im alten Wall (RB Leipzig)
- Kleine Stadien wurden vom multiplikativen Flächenmodell erdrückt (Heidenheim)

---

## 3. Architektur der Pipeline (Endstand, in `geometry_pipeline.py`)

```
OSM (Position, Footprint, Pitch-Polygon, Umgebung)
   ↓  Way-Scoring: Kapazitäts-Flächenband + Kompaktheit + Tags + Nominatim-Distanz
   ↓  Multipolygon-Auflösung (outer-Way)
   ↓  Pol der Unzugänglichkeit → Ausreißerkappung → Douglas-Peucker → Spike-/Kerbenfilter
   ↓  Doppel-Median-Radiussignal (Ecken bleiben, Zacken sterben)
   ↓  Hüllen-Qualitätsmetrik → bei Müll: Archetyp-Automatik (Superellipse n3/n5/n8)
   ↓  Feldachse + Zentrum aus dem OSM-Pitch (18/19 exakt, sonst Maximin-Fit)
   ↓  Blueprint (optional, pro Tribüne/Ecke) ODER Automatik-Ränge
   ↓  Kapazitäts-Zwei-Pass (Reihen-Deckel 42 bzw. 46)
StadiumGeometry (JSON: meta, outline, blocks, bg)
```

**Additives Flächenmodell:** `A_erwartet = 9.400 m² (Feldkern) + Kapazität × 0,55`.
Das war der Schlüssel für kleine Stadien — m²-pro-Platz allein ist falsch.

### Blueprint-Schema (siehe `BLUEPRINT_Schema.md` für Details)
```json
{"bp": {
  "track": false,
  "stands": {"NORD": {"tiers":[26,24], "gate": false, "type": "STEH"}},
  "corners": {"NO":"filled","NW":"open","SO":"filled","SW":"open"},
  "roof": {"type":"ring|arc|flat4", "depth":1.35, "bright":0.0, "bulge":0.0,
           "spokes":false, "diamond":false, "girders":null, "pylons":null,
           "level":"uniform"},
  "exterior": {"towers": 11, "arch": true}
}}
```

### Aktuelles Register (Stadien mit Sonderbehandlung)
| Verein | Eintrag | Grund |
|---|---|---|
| Mainz | `synth` | OSM-Way enthält Parkdeck |
| Leipzig | `keep_osm` + Speichendach | OSM-Oval **ist** die Dachkante |
| Bochum | `clover` | Sichelbinder-Silhouette |
| Freiburg | `synth_n:9` | scharfkantiger Kasten |
| Dortmund | Blueprint | Südtribüne = 46-Reihen-Stehrang |
| 3× PoC | Blueprint | Olympiastadion, San Siro, Wembley |

Alle übrigen 14 Vereine: **vollautomatisch, kein Eintrag nötig.**

---

## 4. Beschlusslage (22 Entscheidungen, gültig)

1. Ausbau erzeugt graue Blöcke (Beton), keine Farbe
2. Eine persistente Farbebene (SeatColor); Choreo/CardColor später
3. Nur der Vereinsmanager gestaltet
4. Zauberstab = Blockauswahl, kein Flood-Fill
5. Expliziter Speichern-Button, kein Autosave
6. Blöcke persistent: `StadiumGeometry` (Bauwerk) und `StadiumDesign` (Farbe) getrennt
7. OSM-Import ist Pflichtschritt, **keine Laufzeit-Fallbacks**
8. Kosmetik ohne Spielwirkung
9. Moderation: Melden + Reset, Sperre am Managerprofil
10. Importierte Bilder nur als quantisierte Kopie ≤ 480 px speichern
11. Kapazitätsdeckel 120.000 hart
12. 3D ist reine Ansicht, keine Bearbeitung
13. OSM-Attribution „Blaupause: OpenStreetMap-Daten (ODbL)" in der Statuszeile
14. Credit für BΛDCП / Artificial im Editor
15. Ausbau-Simulator nur für Admins (`user.is_staff`)
16. Vier-Referenzen-Regel bei jedem visuellen Merkmal (Luftbild, Außen, Innen/Plan,
    EA-FC/FM-Screenshot) — **nur ansehen, niemals Dateien/Assets übernehmen**
17. Keine EA-/FM-Assets auf eigenem Server (Ko-Fi-Risiko)
18. Import meldet Lücken statt sie zu kaschieren
19. Platzarten datengetrieben aus den 12 `Stadium`-Zählern
20. Blueprint und Automatik koexistieren
21. Rote Linie: nichts, was als echtes Spielmaterial durchgehen könnte
22. Ausbau läuft weiter über die bestehende Ausbau-Seite, nicht über den Editor

---

## 5. Tickets

### TICKET 1 — Fundament
**Beiliegend:** `editor.html`, `editor.js`, `stadium_data_all.js` (nur zum Testen),
`geometry_pipeline.py`

1. App `stadium_editor` anlegen, in `INSTALLED_APPS`
2. Modelle:
   - `StadiumGeometry` — OneToOne zu `game.Stadium`; `blocks` (JSON), `bg` (JSON),
     `meta` (JSON), `created_at`, `updated_at`
   - `StadiumDesign` — OneToOne zu `game.Stadium`; `base_data` (JSON, RLE je Block),
     `pressings` (JSON), `palette` (JSON), `cache_image` (ImageField), `updated_at`
3. Views/URLs:
   - `GET /stadion/editor/` — nur Manager des Vereins
   - `GET /api/stadion/<id>/geometrie/` — `{meta, blocks, bg}`, 404 mit klarer Meldung
   - `GET /api/stadion/<id>/design/` — Design oder leeres Default
4. **Umbau am Editor (Claude liefert vor Dispatch als ZIP):** Dropdown raus, Daten per
   `fetch` statt Inline-Block, Speichern per POST statt Download, CSRF-Token
5. Ein Link „Stadion-Editor" auf der bestehenden Stadionseite
**Agent:** Economy · Sonnet · Effort mittel · ein Run

### TICKET 2 — Speichern, Cache-Bild, Gates
1. `POST /api/stadion/<id>/design/` — `{base_data, pressings, palette, cache_png}`;
   Payload ≤ 4 MB; Bildquellen serverseitig auf ≤ 480 px prüfen (sonst 400)
2. `cache_image` am Vereinsprofil als Stadionbild anzeigen
3. `stadium_editor_banned` (Boolean) am Managerprofil → 403 mit Hinweistext
4. Simulator-Panel nur bei `user.is_staff` rendern
   (**Im Prototyp ist es zu Testzwecken hart sichtbar: `const isAdmin = true;` in
   `editor.js` — im Django-Template durch das echte Gate ersetzen!**)
5. CSRF verdrahten
**Agent:** Economy · Sonnet · Effort mittel · ein Run

### TICKET 3 — Import-Pipeline
1. `geometry_pipeline.py` als Management-Command einhängen:
   `import_stadium_geometry --all | --club <id> | --way-id <osm>`
2. Ablauf pro Verein: `map_lat/map_lng` → Nominatim/Overpass → Way-Scoring →
   Geometrie → Platzarten aus den 12 `Stadium`-Zählern → `StadiumGeometry`
3. Register (`stadium_config.json`) für die 6 Sonderfälle aus Abschnitt 3
4. Warnungs-Report für Vereine ohne brauchbaren Umriss — **kein Fallback erzeugen**
5. Hook in `game/club_import/club_reconcile.py` nach der Stadium-Erzeugung
**Agent:** Economy · Sonnet · Effort mittel-hoch · zwei Stages (erst 1 Verein, dann `--all`)

### TICKET 4 — Ausbau-Hook & Moderation
1. Python-Port der Wachstumsmechanik (`expandStand` in `editor.js`, Zeilen ~1391):
   Reihen an den äußersten sortengleichen Rang bis max. 42/46, dann neuer Rang,
   neue Sitze Farbindex 0, Deckel 120.000
2. Hook beim Anwenden einer `StadiumExpansion` — bestehende Preise/Logik unangetastet
3. Moderation: `POST /api/stadion/<id>/melden/` → `DesignReport`; Admin-Action
   „Design zurücksetzen"; Sperre setzen
**Agent:** Economy · Sonnet · Effort mittel · ein Run, nach Ticket 3

**Reihenfolge:** 1 → 2 → 3 → 4, jeweils eigener Run. Vor jedem Dispatch liefert Claude
das Datei-ZIP; ohne ZIP nicht starten.

---

## 6. Bekannte offene Punkte (ehrlicher Stand)

| # | Punkt | Schwere |
|---|---|---|
| 1 | **Ausbau-Geometrie an Tribünenecken:** Ein neuer Rang wird an der Ecke noch nicht sauber in den Baukörper verzahnt — es entsteht eine „lose Klappe", Fassade darunter fehlt. Betrifft jedes Stadion. **Vor Ticket 4 zu lösen.** | hoch |
| 2 | Signal Iduna Park: Masten hängen jetzt an echten Eckblock-Ecken, Ausführung (Fachwerk-Wucht, X-Verbände) noch nicht abgenommen | mittel |
| 3 | 19er-Blueprint-Durchgang nach Vier-Referenzen-Verfahren steht aus | mittel |
| 4 | BVB-Kapazität 73.798 statt 81.365 (Reihen-Feintuning) | niedrig |
| 5 | LoD2/CityGML-Layer (reale Gebäudehöhen; Bayern CC BY 4.0, NRW dl-de/zero, Berlin offen) | später |
| 6 | Kurven-Pressung (polare Bildabbildung auf gebogene Ränge) | später |
| 7 | San-Siro-Türme: Spiralrampen; Wembley-Arch real nach Nord geneigt | Detail |

---

## 7. Dateien in diesem Paket

| Datei | Zweck |
|---|---|
| `README_REPLIT.md` | dieses Dokument |
| `BLUEPRINT_Schema.md` | Blueprint-Format + PoC-Register |
| `geometry_pipeline.py` | komplette Import-Pipeline (Ticket 3) |
| `editor.html` / `editor.js` | Editor-Quellen (Ticket 1) |
| `stadium_data_all.js` | 22 vorgenerierte Stadien (nur zum Testen, nicht ausliefern) |
| `stadion-editor-bundesliga.html` | lauffähiges Gesamtbundle zum Anschauen |

**Prototyp starten:** `stadion-editor-bundesliga.html` lokal im Browser öffnen.
Dropdown = 19 Bundesligisten + Basel + 3 PoC. Ausbau-Simulator: linke Sidebar unten.
