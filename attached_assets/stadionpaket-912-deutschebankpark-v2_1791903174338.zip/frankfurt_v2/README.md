# Deutsche Bank Park · Eintracht Frankfurt (FMI 912) — Fassung 2: Korrektur vor Übernahme

Stand 13.10.2026 · Quelle `eintrachtfrankfurt.bundle` (FM26 Stadium Megapack v3.0, SHA-256 `5c64fcac68b03a224f50f727a2f201e35cdf3fcccab07aa96a880fcbc88aa04d`) + `eintrachtfrankfurt.json`, `_lightmaps.json`, `_lightprobes.json`.
Ausgangspunkt Fassung 1 assetVersion `f00014f2a6dd940f` (nicht registriert). Diese Fassung: assetVersion **`9c08b68dd9daacda`**, geometrySha256 `9d50f160938b78d5b820da07d1c5fb5ce69e1c1c9ec6d727aed6d82b049a2551`, 285 Meshes, 104 Texturen, **105 Assets**, 16,42 MB, 169 → 12 Leuchten.
**Status: korrigiert unter Vorbehalt — Punkt 2 (Umfeld) ist erst wirksam, wenn der beiliegende Renderer-Patch (`patch/`) integriert ist.** Ohne Patch registriert das Manifest (unbekanntes Kalibrierfeld wird ignoriert), zeigt aber weiter das vertauschte Umfeld.

## 1 · IDs und Bestandsdaten
- Das Paket enthält **keine lokale Vereins-, Stadion- oder sonstige Datenbank-ID**. Identität nur über `clubFmiId: 912` (Manifest) und den Vereinsnamen; die Zuordnung zum lokalen Club und Stadion macht die Registry (`unity_presentation`: `manifest.clubFmiId == stadium.club.fm_inside_id`, sonst Abbruch) — nichts davon steht im Paket.
- Geprüfte Quellidentität: Bundle `eintrachtfrankfurt`, Seat-Datei und Lightmaps gehören zusammen (SHA im Manifest `sourceEvidence`); im öffentlichen live-scene nennt der Bestand zu FMI 912 „Eintracht Frankfurt / Deutsche Bank Park“ — eindeutig, kein Raten nötig.
- Kapazität, Ausbau, Design, Vereinsdaten: nicht im Paket. `werkzeuge/render/presentation_912_v2.json` ist nur die Vorschau für den Render-Harness (ohne IDs, ohne Kapazität, ohne Blockdaten; Tribünenfarben nur als abgeleitete Hex-Werte für die Bilder) — **nichts daraus übernehmen**.
- Entfernt gegenüber Fassung 1: Vereins-ID und Kapazität aus der Vorschau, `/stadion/<id>/`-Pfade aus README und Werkzeug (`build_presentation.py` nimmt nur noch FMI + live-scene-Datei und bricht ab, wenn FMI von live-scene, Manifest und Aufruf nicht übereinstimmen).

## 2 · Umfeld-Ausrichtung (Ortsplan)
**Befund, nachgemessen an realen Ortsmerkmalen** (`quellbelege/umfeld_pruefung.json`, OSM/Overpass 13.10.): Die bg-Karte der Blaupause ist eine nicht gespiegelte, nordorientierte Karte in Metern Ost/Nord vom Stadionmittelpunkt — fünf OSM-Trainingsplätze treffen die bg-Grünflächen auf 10–18 m, das Stadionbad (NO) und Landessportbund/Sporthallen (W/SW) liegen an derselben Stelle (3–58 m). `axisTheta 142,5°` dreht die Spielfeld-+X-Achse nach **Nordwest**: das NORD-Ende des Ortsplans ist die reale Nordwestkurve, die WEST-Seite die Südwest-Längsseite (Haupttribüne). Rahmenkonvention aller 22 Blaupausen (nachgerechnet): NORD bei +X, WEST bei +Y.
Modell: Bänke/VIP bei −x = WEST ✔, Heimkurve (`C_right*_UltraHome`) bei −z, Gästeblock bei +z → `standAxes {−z: NORD, +z: SUED, −x: WEST, +x: OST}`. Der bisherige Adapter legt Ortsplan-NORD fest auf +z → **beide Enden vertauscht, Längsseiten richtig** (`bilder/umfeld-ausrichtung-vorher-nachher.jpg`, oben).
**Korrektur:** neues optionales Kalibrierfeld `surroundingsAxes: {NORD: "-z", WEST: "-x"}` im Manifest (aus den tatsächlichen Modellachsen abgeleitet und vom Validator gegen `standAxes` geprüft) + Renderer-Patch, der den Ortsplan auf diese Achsen legt. Ergebnis (`…nachher`, unten): Trainingsplatz NW und Landessportbund am Heimkurven-Ende/der Bänke-Seite, Stadionbad und Trainingsplätze N/NO an der OST-Seite, Sporthallen SW an der WEST-Seite, SUED-Ende am Gästeblock — **beide Enden und beide Längsseiten geprüft**. Modell, standAxes, Schriftzüge, Tribünenfarben/Blockzählung, Spielfeld und gemeinsame Tickerkamera unverändert (Ticker v1↔v2 0,02–0,07 % Pixel). Patch, Tests und Integrationshinweise: `patch/README-PATCH.md`.

## 3 · `center2_14` — nicht Sockelring, sondern Außenhülle
- Isoliert gerendert (`bilder/sockel-aussenhuelle-vorher-nachher.jpg`, `bilder/v2_10c-sockel-nur-c14.png`): `center2_14` (`MAIN`, `concrete_standard_color.001`, 795 Dreiecke, 1.536 Vertices) ist die **geschlossene Betonaußenhülle des Stadionkörpers samt Sockel**: x ±99,6 / z ±119,8 m (= Umriss der Tribünen `center1_*` ±99,2/±119,3), y −9,2 … 33,9 m; 1.224 Vertices liegen über 4 m, Normalen zeigen nach außen (53 % Flächenanteil, Rest waagerecht), Textur mittelgrau. Ohne sie zeigt die Außenseite den offenen Unterbau (Treppen, Ränge von außen), mit ihr ist die Fassade geschlossen wie beim realen Stadion.
- Ortsplan-Überlagerung: Grundriss der Hülle deckt sich mit dem Stadionumriss der Blaupause (Unity x −99,1…101,1 / z −119,2…120,0); innerhalb liegen nur die Spielfeld-Grünfläche `green[0]` und drei Fußwege (`roads 226/248/259`, Breite 1), die ohnehin unter dem Stadionkörper liegen — **keine Kollision** mit Gebäuden, Straßen oder Wasser.
- Daher **gezielt erhalten**. Umsetzung: neue Exportoption `--exclude-meshes` mit **exakten Namen** (`center2_0 … center2_13`, bewusst kein Präfix); die Fernkulisse (Bodenplatte ±445 m, Bergpanorama, Bäume, Fernbauten) und die beiden 116-m-Gittermasten `center2_4–8` kommen nicht mehr in die Assets (`ausschluss_bericht.json`: 14 Meshes mit Hierarchie, Lage, Material). `skipMeshPrefixes` nur noch `["MESH_ROOT"]` (beide Fangnetze hinter den Toren). Folge: 14 Meshes und 9 Kulissentexturen weniger; die **285 verbleibenden Meshes sind byte-identisch** zu Fassung 1 (Positionen, UVs, Indizes, Materialfelder je Mesh geprüft), alle 104 Texturen hash-gleich, Leuchten und Sitzansicht identisch.
- Hinweis zur Optik: Die Hülle ist im Spielrenderer eine schattige Betonfläche (Hemisphären-/Sonnenlicht ohne Lightmap); im Ticker ist sie durch die Schnittebene nie im Bild. Wer sie nicht will: eine Zeile mehr in `--exclude-meshes` (`center2_14`), Assets dann neu versionieren.

## 4 · Videowürfel und Dachschalter
Regel bestätigt und belegt: `roofMeshPrefixes ["front3_"]`, `roofMinHeight 3` → **Würfel `front3_7–17`, `front3_df_0/5/7`: 2.236 / 2.236 Dreiecke Dach** — Dach an = sichtbar, Dach aus = vollständig weg, einschließlich Seilnetz und Aufhängung, im Editor (`v2_02/02b`) und im Ticker (`v2_03/04`). Das graue Rechteck in der Draufsicht (`v2_06`) ist der hängende Würfel über dem Anstoßpunkt, kein Fehler im Spielfeld; bei Dach aus (`v2_07`) ist es weg. Keine Tafel erfunden: alle 14 Würfel-Meshes sind Quellmeshes (Einzelbilder `bilder/isolation/iso_blatt_*.jpg`). Für künftige Pakete als Prüfpunkt in den Regelsatz aufgenommen (siehe unten).

## Nachweise
- **Tribünen beim Dachschalter** (Renderer-Regel über das Binary, `quellbelege/nachweise.json`): Dachliste `front3_` 102.524 / 102.524 Dreiecke Dach; Tribünen/Körper `center1_*` **0 / 206.269**, Außenhülle `center2_14` 0 / 795, Glasfronten 0 / 662, Boden 0 / 6.764, Crowd 0 / 1.326, Spielfeld 0 / 4.618.
- **Spielfeld 105 × 68 m**: Replits `pitch_validation.measure_pitch` (Linienmaterial `000STADIUMLINE`, Mesh `st081_pitch_1`, Querschnitte an 6 Schnitten je Achse) ergibt Länge **105,000 m** (Randlinien z −52,5 / +52,5), Breite **68,000 m** (x −34,0 / +34,0), zentriert, Toleranz 0,02 m eingehalten, Geometrie-SHA = Manifest.
- **Ansichten, identisch aufgenommen** (gleiche Kamera, Licht, Fenster; 3D 1000×560, Ticker 1000×500): `bilder/frankfurt-v2-ansichten-vorher-nachher.jpg` = Editor Dach an/aus, Ticker Dach an/aus, Ticker Nacht + Flutlicht, Draufsicht Dach an/aus; links Fassung 1 + Renderer 12.10., rechts Fassung 2 + Patch. Einzelbilder `v1_*`/`v2_*.png`. Umfeld: `umfeld-ausrichtung-vorher-nachher.jpg` (weite Draufsicht, Ortsmerkmale aus OSM in Bildkoordinaten eingezeichnet), `v1/v2_09-umfeld-schraeg.png`. Hülle: `sockel-aussenhuelle-vorher-nachher.jpg`. Gegenprobe: Fassung-2-Manifest mit **altem** Renderer liefert dieselbe Umfeldlage wie Fassung 1 (0,001 % Pixel) — die Umfeldkorrektur kommt allein aus dem Patch, die Modellkorrektur allein aus dem Export.
- Bodenregeln unverändert (`boden_912.json`: 3 transparent, 0 Rasen, 10 transluzent, 33 Alpha-Schnitt; Re-Export byte-identisch).

## Regelsatz für künftige Pakete (ergänzt)
Videotafeln/-würfel und alle dachgehängten Teile gehören zum Dachzustand: je Mesh einzeln isolieren, der Dachliste zuordnen, Nachrechnung „Würfel n / n Dreiecke Dach“ und Sichtprüfung Ticker Dach an/aus; keine Tafel erfinden. Kulisse per exakten Meshnamen ausschließen, nie per Präfix, das Stadionteile mitnimmt. Ortsplan je Modell gegen reale Ortsmerkmale an beiden Enden und beiden Längsseiten prüfen; weicht die Modellachse ab, `surroundingsAxes` setzen statt drehen/spiegeln. Keine lokalen IDs im Paket.

## Einspielen
1. `patch/` integrieren (vier Dateien + zwei Testdateien, `patch/README-PATCH.md`), Tests grün.
2. `scp -r stadium-models/912 root@49.13.5.151:/var/www/assets/stadium-models/` (Ordner `912/9c08b68dd9daacda`; der nicht registrierte Ordner `f00014f2a6dd940f` kann weg).
3. `models/912.json` nach `stadium_editor/blueprints/v2/models/912.json`, committen, pushen, `/push`.
4. `docker exec websoccer-web-1 python manage.py check_stadium_model --fmi 912 --assets` → `Assets OK: 105 Dateien`.
5. Abnahme im Livemodus des Vereins mit FMI 912: fünf Ansichten + Draufsicht, Umfeld an beiden Enden (Trainingsplatz NW an der Heimkurve, Stadionbad an der Ost-Seite).

## Reproduktion (byte-identisch geprüft)
```sh
python3 -I werkzeuge/export_stadium_model.py --bundle eintrachtfrankfurt.bundle --seats eintrachtfrankfurt.json \
  --fmi 912 --name "Deutsche Bank Park" --out export --calibration kalibrierung.json \
  --roots EXTRA --lamp-materials light_e_color,light_fixture --ground boden_912.json \
  --exclude-meshes center2_0,center2_1,center2_2,center2_3,center2_4,center2_5,center2_6,center2_7,center2_8,center2_9,center2_10,center2_11,center2_12,center2_13
#  → assetVersion 9c08b68dd9daacda; Bilder: werkzeuge/render/shoot.py "$(cat werkzeuge/render/shots.json)" bilder
```
