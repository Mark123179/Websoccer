"""Erzeugt Manifest-Varianten mit gefilterter Meshliste (für isolierte Ein-/Ausblend-Renders)."""
import json, sys, re
src, out, mode, pattern = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
m=json.load(open(src)); rx=re.compile(pattern)
if mode=="only": m["meshes"]=[e for e in m["meshes"] if rx.search(e["name"])]
elif mode=="without": m["meshes"]=[e for e in m["meshes"] if not rx.search(e["name"])]
json.dump(m,open(out,"w"),separators=(",",":")); print(out, len(m["meshes"]), "Meshes")
