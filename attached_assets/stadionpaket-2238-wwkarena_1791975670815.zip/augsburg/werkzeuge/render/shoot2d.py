import asyncio, sys, subprocess, time
from playwright.async_api import async_playwright
PORT=8766
async def main(params,out):
    srv=subprocess.Popen([sys.executable,"-m","http.server",str(PORT),"--bind","127.0.0.1"],cwd="render",stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
    try:
        async with async_playwright() as p:
            b=await p.chromium.launch(); pg=await b.new_page(viewport={"width":1400,"height":960},device_scale_factor=1)
            logs=[]; pg.on("console",lambda m:logs.append(m.text)); pg.on("pageerror",lambda e:logs.append("PAGEERROR "+str(e)))
            await pg.goto(f"http://127.0.0.1:{PORT}/harness2d.html?{params}&nocache={time.time()}",wait_until="load",timeout=60000)
            await pg.wait_for_timeout(4000)
            err=await pg.evaluate("window.__error2d||null")
            print("Fehler:",err); print("Konsole:",[l for l in logs if 'font' not in l.lower()][:10])
            await pg.locator("#stage").screenshot(path=out); await b.close()
    finally: srv.terminate()
asyncio.run(main(sys.argv[1], sys.argv[2]))
