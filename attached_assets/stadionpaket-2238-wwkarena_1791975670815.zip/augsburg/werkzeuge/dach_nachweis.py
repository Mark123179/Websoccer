"""Dach-/Körper-Nachweis: zählt je Mesh die Dreiecke, die der zentrale Renderer (unity_stadium_scene.js) als Dach
bzw. Körper einstuft – exakt dieselbe Regel: Kandidat = nicht crowdPrefix UND (roofMeshPrefixes leer ODER startsWith);
Dach = Kandidat UND alle drei Eckpunkte y >= roofMinHeight. Zusätzlich Spielfeldmaß nach Replits pitch_validation
und Prüfsummen aller Assets. Aufruf: dach_nachweis.py <exportordner> <out.json> [gruppe=regex ...]"""
import sys, json, re, hashlib, struct
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from stadium_editor.pitch_validation import validate_pitch_geometry
from stadium_editor.model_registry import validate_model_manifest

src = Path(sys.argv[1]); out = sys.argv[2]
groups = [a.split("=", 1) for a in sys.argv[3:]]
m = json.loads((src / "manifest.json").read_text()); binary = (src / "geometry.bin").read_bytes()
validate_model_manifest(m)
c = m["calibration"]; prefixes = c.get("roofMeshPrefixes") or []
per_mesh = {}
for e in m["meshes"]:
    n = e["vertexCount"]; pos = struct.unpack_from("<%df" % (n * 3), binary, e["positionOffset"])
    y = pos[1::3]
    candidate = (not e["name"].startswith(c["crowdPrefix"])) and (not prefixes or any(e["name"].startswith(p) for p in prefixes))
    roof = body = 0
    for p in e["parts"]:
        idx = struct.unpack_from("<%dI" % p["indexCount"], binary, p["indexOffset"])
        for i in range(0, len(idx), 3):
            if candidate and all(y[k] >= c["roofMinHeight"] for k in idx[i:i + 3]): roof += 1
            else: body += 1
    per_mesh[e["name"]] = {"dach": roof, "koerper": body, "listed": any(e["name"].startswith(p) for p in prefixes), "yMin": round(min(y), 2), "yMax": round(max(y), 2)}
summary = {}
for name, rx in groups:
    r = re.compile(rx); hit = {k: v for k, v in per_mesh.items() if r.search(k)}
    summary[name] = {"meshes": len(hit), "dach": sum(v["dach"] for v in hit.values()), "koerper": sum(v["koerper"] for v in hit.values()),
                     "gesamt": sum(v["dach"] + v["koerper"] for v in hit.values())}
rest = {k: v for k, v in per_mesh.items() if not any(re.compile(rx).search(k) for _, rx in groups)}
summary["_uebrige"] = {"meshes": len(rest), "dach": sum(v["dach"] for v in rest.values()), "koerper": sum(v["koerper"] for v in rest.values()), "namen": sorted(rest)}
listed_with_body = sorted(k for k, v in per_mesh.items() if v["listed"] and v["koerper"])
unlisted_with_roof = sorted(k for k, v in per_mesh.items() if not v["listed"] and v["dach"])
pitch = validate_pitch_geometry(m, binary)
sha = {n: hashlib.sha256((src / n).read_bytes()).hexdigest() == m["assetSha256"][n] for n in ["geometry.bin", *m["textures"]]}
result = {"assetVersion": m["assetVersion"], "geometrySha256": m["geometrySha256"], "roofMinHeight": c["roofMinHeight"], "roofMeshPrefixes": prefixes,
          "gruppen": summary, "dachliste_mit_koerperdreiecken": listed_with_body, "nicht_gelistet_mit_dachdreiecken": unlisted_with_roof,
          "spielfeld": pitch if isinstance(pitch, dict) else str(pitch), "assetSha256_ok": all(sha.values()), "assets": len(sha),
          "leuchten": {"laufzeit": len(m["fixtures"]), "quellgeprueft": m["verifiedFixtureCount"], "repraesentiert": sum(len(f["representedIds"]) for f in m["fixtures"]), "meshDistanceMax": max(f["meshDistance"] for f in m["fixtures"])},
          "proMesh": per_mesh}
json.dump(result, open(out, "w"), indent=1, ensure_ascii=False)
print(json.dumps({k: v for k, v in result.items() if k != "proMesh"}, indent=1, ensure_ascii=False))
