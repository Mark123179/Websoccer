"""Verortete Umfeldansicht: projiziert OSM-Anker (Nominatim-Geometrie, in bg-Meter Ost/Nord) über den Blaupausen-Rahmen
(fieldC, axisTheta) und calibration.surroundingsAxes in den Modellrahmen und zeichnet sie in einen Harness-Screenshot
der Orbitkamera (gleiche Kamera wie unity_stadium_scene.js: fov 42°, lookAt (0,12,0), Position aus az/el/distance).
Aufruf: umfeld_beschriften.py <screenshot.png> <anker.json> <umfeld_pruefung.json> <bundle.js.gz> "<Name>" <manifest.json> <azGrad> <elGrad> <distance> <out.jpg> [--standaxes]"""
import sys, json, gzip, math, numpy as np
from PIL import Image, ImageDraw, ImageFont
shot, ankerjson, pruefjson, bundle, name, manifest, az, el, dist, out = sys.argv[1:11]
az, el, dist = math.radians(float(az)), math.radians(float(el)), float(dist)
raw = gzip.open(bundle, "rt", encoding="utf-8").read(); data = json.loads(raw[raw.index("["):raw.rindex("]")+1])
g = next(s for s in data if s["meta"]["name"] == name); m = g["meta"]; fx, fy = m["fieldC"]; th = m["axisTheta"]
cal = json.load(open(manifest))["calibration"]; axes = cal.get("surroundingsAxes") or {"NORD": "+z", "WEST": "-x"}
UNIT = {"+x": (0, 1), "-x": (0, -1), "+z": (1, 1), "-z": (1, -1)}
pruef = json.load(open(pruefjson)); o = pruef["bgUrsprung"]; lat0, lon0 = o["lat"], o["lon"]; K = 111320*math.cos(math.radians(lat0))
def bg_to_model(p):
    dx, dy = p[0]-fx, p[1]-fy; u = dx*math.cos(th)+dy*math.sin(th); v = -dx*math.sin(th)+dy*math.cos(th)
    r = [0.0, 0.0]; n, w = UNIT[axes["NORD"]], UNIT[axes["WEST"]]; r[n[0]] = n[1]*u; r[w[0]] = w[1]*v; return r  # (x, z)
img = Image.open(shot).convert("RGB"); W, H = img.size
cam = np.array([dist*math.sin(az)*math.cos(el), 12+dist*math.sin(el), dist*math.cos(az)*math.cos(el)])
target = np.array([0., 12., 0.]); f = target-cam; f /= np.linalg.norm(f); up = np.array([0., 1., 0.])
r = np.cross(f, up); r /= np.linalg.norm(r); u_ = np.cross(r, f)
fl = (H/2)/math.tan(math.radians(42)/2)
def project(x, y, z):
    d = np.array([x, y, z])-cam; zc = d@f
    if zc <= 1: return None
    return (W/2 + fl*(d@r)/zc, H/2 - fl*(d@u_)/zc)
def xy(lon, lat): return ((lon-lon0)*K, (lat-lat0)*110574)
dr = ImageDraw.Draw(img)
try: font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 15)
except Exception: font = ImageFont.load_default()
colors = ["#ffd400", "#ff7a00", "#00e5ff", "#ff4fd8", "#9dff00", "#ffffff", "#ff5050", "#8ab4ff", "#ffb3ff", "#c8ff8a", "#ffe08a", "#80ffea"]
legend = []
for i, a in enumerate(json.load(open(ankerjson))):
    geo = a["geojson"]; kind = geo["type"]
    coords = [geo["coordinates"]] if kind == "Point" else geo["coordinates"] if kind == "LineString" else geo["coordinates"][0] if kind == "Polygon" else geo["coordinates"][0][0]
    pts = [project(*(lambda mz: (mz[0], 0.0, mz[1]))(bg_to_model(xy(*c)))) for c in coords]
    pts = [p for p in pts if p]
    if not pts: continue
    col = colors[i % len(colors)]
    if kind == "Point": x, y = pts[0]; dr.ellipse([x-7, y-7, x+7, y+7], outline=col, width=3)
    else: dr.line(pts if len(pts) > 1 else pts*2, fill=col, width=3)
    inside = [p for p in pts if 0 <= p[0] < W and 0 <= p[1] < H]
    cx, cy = (np.mean(inside, axis=0) if inside else np.mean(pts, axis=0))
    cx = min(max(cx, 10), W-10); cy = min(max(cy, 10), H-10)
    label = f"{i+1}"; dr.ellipse([cx-11, cy-11, cx+11, cy+11], fill=col); dr.text((cx-5, cy-8), label, fill="black", font=font)
    legend.append((col, f"{i+1} {a['name']}"))
# Modellachsen-Beschriftung (Tribünenseiten)
for axis, lab in cal["standAxes"].items():
    v = {"+x": (150, 0), "-x": (-150, 0), "+z": (0, 150), "-z": (0, -150)}[axis]
    p = project(v[0], 0, v[1])
    if p: dr.text((min(max(p[0]-20, 4), W-70), min(max(p[1]-8, 4), H-20)), lab, fill="#ffffff", font=font)
y = 8
for col, text in legend:
    dr.rectangle([8, y, 22, y+14], fill=col); dr.text((28, y-2), text, fill="#ffffff", font=font); y += 19
dr.text((8, H-20), f"Kamera az {math.degrees(az):.0f}° el {math.degrees(el):.0f}° d {dist:.0f} m · Blaupause axisTheta {math.degrees(th):.1f}° · surroundingsAxes {axes}", fill="#ffffff", font=font)
img.save(out, quality=88); print(out, len(legend), "Anker gezeichnet")
