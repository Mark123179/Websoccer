"""Lichtkalibrierung genau einmal anwenden: fixtures[].intensity = Quellintensität (Unity Light) × Faktor (Fassung 2, 14.10.2026).
Vor dem Schreiben wird jede Laufzeitleuchte gegen die Quelle geprüft: stabile ID (Unity path_id), Montageort (Welt-Position),
Richtung (Welt-Vorwärtsachse), Farbe, Reichweite, Winkel und Gruppierung (representedIds: nur Quell-Spots, eigene ID enthalten,
Summe = verifiedFixtureCount, jede Quell-ID genau einmal). Erkennt einen bereits kalibrierten Stand (Manifest == Quelle × Faktor
→ keine Änderung) und bricht bei jeder Abweichung ab. Assets bleiben unverändert → assetVersion bleibt; die Manifestrevision
(sha256 des Manifests, wie unity_presentation()) unterscheidet den neuen Inhalt. Schreibt einen Prüfbeleg.
Aufruf: licht_kalibrieren.py <exportordner> <bundle> <faktor> <beleg.json> [--renderer <unity_stadium_scene.js>]"""
import sys, json, hashlib
from pathlib import Path
import numpy as np
import UnityPy
from scipy.spatial.transform import Rotation
sys.path.insert(0, str(Path(__file__).resolve().parent))
from stadium_editor.model_registry import validate_model_manifest

src, bundle, factor, out = Path(sys.argv[1]), sys.argv[2], float(sys.argv[3]), sys.argv[4]
renderer = Path(sys.argv[sys.argv.index("--renderer") + 1]) if "--renderer" in sys.argv else None
path = src / "manifest.json"; m = json.loads(path.read_text())
before_revision = hashlib.sha256(json.dumps(m, sort_keys=True).encode()).hexdigest()[:16]

def matrix(t):
    p, q, s = t.m_LocalPosition, t.m_LocalRotation, t.m_LocalScale
    r = np.eye(4); r[:3, :3] = Rotation.from_quat([q.x, q.y, q.z, q.w]).as_matrix() @ np.diag([s.x, s.y, s.z]); r[:3, 3] = [p.x, p.y, p.z]; return r
cache = {}
def world(t):
    k = t.m_GameObject.path_id
    if k not in cache:
        par = world(t.m_Father.read()) if t.m_Father else np.eye(4)
        cache[k] = par @ matrix(t)
    return cache[k]
env = UnityPy.load(bundle)
source = {}
for obj in env.objects:
    if obj.type.name != "Light": continue
    light = obj.read()
    go = light.m_GameObject.read(); t = next(c.read() for c in go.m_Components if c.type.name == "Transform"); w = world(t)
    d = w[:3, :3] @ np.array([0., 0., 1.]); d = d / np.linalg.norm(d)
    source[str(obj.path_id)] = {"name": go.m_Name, "type": light.m_Type, "enabled": bool(light.m_Enabled), "intensity": float(light.m_Intensity),
                                "range": float(light.m_Range), "spotAngle": float(light.m_SpotAngle),
                                "color": [float(light.m_Color.r), float(light.m_Color.g), float(light.m_Color.b)],
                                "position": w[:3, 3].tolist(), "direction": d.tolist()}
def close(a, b, tol=1e-3): return all(abs(x - y) <= tol for x, y in zip(a, b))
rows, state, problems, seen = [], set(), [], []
for f in m["fixtures"]:
    s = source.get(f["id"])
    if s is None: problems.append(f"Leuchte {f['id']} nicht in der Quelle"); continue
    if s["type"] != 0 or not s["enabled"]: problems.append(f"{f['id']} ({s['name']}): Quelle ist kein aktiver Spot")
    if not close(s["position"], f["position"]): problems.append(f"{f['id']} ({s['name']}): Montageort weicht ab {s['position']} ≠ {f['position']}")
    if not close(s["direction"], f["direction"]): problems.append(f"{f['id']} ({s['name']}): Richtung weicht ab")
    if not close(s["color"], f["color"], 1e-6): problems.append(f"{f['id']} ({s['name']}): Farbe weicht ab")
    if abs(s["range"] - f["range"]) > 1e-6 or abs(s["spotAngle"] - f["angle"]) > 1e-6: problems.append(f"{f['id']} ({s['name']}): Reichweite/Winkel weichen ab")
    group = f["representedIds"]
    if f["id"] not in group: problems.append(f"{f['id']}: eigene ID fehlt in representedIds")
    for g in group:
        if g not in source or source[g]["type"] != 0: problems.append(f"{f['id']}: representedIds enthält Nicht-Spot/Unbekannt {g}")
    seen.extend(group)
    cur = float(f["intensity"]); orig = s["intensity"]
    if abs(cur - orig) < 1e-6: state.add("quelle")
    elif abs(cur - orig * factor) < 1e-6: state.add("kalibriert")
    else: problems.append(f"{f['id']} ({s['name']}): Intensität {cur} ist weder Quelle {orig} noch Quelle×{factor} = {orig*factor}")
    rows.append({"id": f["id"], "name": s["name"], "quellIntensitaet": orig, "browserIntensitaet": round(orig * factor, 6),
                 "range": f["range"], "angle": f["angle"], "color": f["color"], "position": f["position"], "direction": f["direction"],
                 "representedIds": len(group), "meshDistance": f["meshDistance"]})
if len(seen) != len(set(seen)): problems.append("representedIds: eine Quell-ID ist mehrfach zugeordnet")
if len(seen) != m["verifiedFixtureCount"]: problems.append(f"representedIds: {len(seen)} Zuordnungen ≠ verifiedFixtureCount {m['verifiedFixtureCount']}")
if problems: sys.exit("ABBRUCH (keine Änderung geschrieben):\n  " + "\n  ".join(problems))
if len(state) != 1: sys.exit(f"ABBRUCH: gemischter Zustand {state}")
already = state == {"kalibriert"}
if not already:
    for f, r in zip(m["fixtures"], rows): f["intensity"] = r["browserIntensitaet"]
    validate_model_manifest(m)
    path.write_text(json.dumps(m, separators=(",", ":")))
after_revision = hashlib.sha256(json.dumps(m, sort_keys=True).encode()).hexdigest()[:16]
beleg = {"stadion": m["stadiumName"], "clubFmiId": m["clubFmiId"], "assetVersion": m["assetVersion"], "geometrySha256": m["geometrySha256"],
         "faktor": factor, "zustandVorher": "bereits kalibriert (keine Änderung)" if already else "Quellwerte",
         "manifestRevisionVorher": before_revision, "manifestRevisionNachher": after_revision,
         "quellpruefung": "ID, Montageort, Richtung, Farbe, Reichweite, Winkel, Gruppierung je Leuchte gegen das Unity-Bundle geprüft (Toleranz 1e-3 m / 1e-6)",
         "rendererDatei": str(renderer) if renderer else None,
         "rendererSha256": hashlib.sha256(renderer.read_bytes()).hexdigest() if renderer else None,
         "rendererFormel": "onIntensity = fixture.intensity * 8 * min(4, sqrt(representedIds.length)) (unity_stadium_scene.js, unverändert)",
         "regel": "Faktor nur in fixtures[].intensity, genau einmal; nicht zusätzlich im Renderer oder beim Einspielen anwenden. Faktor gilt nur für dieses Stadion.",
         "quellgeprueft": m["verifiedFixtureCount"], "laufzeitleuchten": len(rows), "leuchten": rows}
json.dump(beleg, open(out, "w"), indent=1, ensure_ascii=False)
print(json.dumps({k: v for k, v in beleg.items() if k != "leuchten"}, indent=1, ensure_ascii=False))
