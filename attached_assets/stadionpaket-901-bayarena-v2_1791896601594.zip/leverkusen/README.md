# BayArena · Bayer 04 Leverkusen (FMI 901) — Fassung 2: Dachdeckung geprüft und korrigiert

Stand 13.10.2026 · Quelle `bayarena.bundle` (FM26 Stadium Megapack v3.0, SHA-256 `9bd73626e8ac636675e4ebf01fe06bc0e6995e6c6f35e6aa89a4e7e8f334e226`).
Ausgangspunkt: Zwischenstand assetVersion `ed7527940bb8ec5b` (v1). Diese Fassung: assetVersion **`ba8884cabbb4462c`** (v2), geometrySha256 `fe54273fc4146676ffe36b116a343cbfe9df198eb2d07a647fa2d6b07cad75d5`. Die Live-Registrierung wurde nicht angefasst.

## Befund in einem Satz
Die Makrolon-Dachhaut ist im Original-Bundle vorhanden; sie ging **beim Export** verloren, weil sie — zusammen mit Innenring, Dachrand-Schriftzug und Glasfronten — unter der Wurzel `EXTRA` liegt und der Export-Standard nur `MAIN`, `AUDIAREA`, `PITCH2021`, `MESH_CROWD` übernimmt. Keine fehlende Quelle, keine Rekonstruktion nötig.

## Nachweis (Auftrag 1–2)
Inventur **aller** 744 Meshes im Bundle (alle Wurzeln, Renderer-Status, GameObject-Aktivität, LOD-Gruppen: keine vorhanden; `quellbelege/dach_inventar.json` = alle 35 Meshes mit y ≥ 25 m). Isoliertes Ein-/Ausblenden je Gruppe im Spielrenderer (`bilder/isolation/isolation_uebersicht.jpg`, `front3_einzeln.jpg` = jedes `front3_*`-Mesh einzeln, `FG_videowall.jpg`).

| Mesh (Quelle) | Lage | Material | v1 | v2 | Dachschalter |
|---|---|---|---|---|---|
| `front3_df_0` · `EXTRA/scenes\front3_df/MESH_ROOT.003/` | **Dachhaut**: geschlossener Ring x/z ±106,6 m, y 29,1–32,8 m, Feldöffnung frei; 5.900 Dreiecke | `roof_plastic_corrugated_translucence_leverkusen_color`; Textur 512², Alpha gleichmäßig 148–204 (Ø 72 % Deckung), RGB hellgrau; Renderer aktiv, GameObject aktiv | **nicht exportiert** (Wurzel EXTRA) | exportiert, `transparent:true`, `alphaTest:0` (Transluzenz wie Quelle) | Dach |
| `front3_df_1` · EXTRA | Innenring-Profil um die Feldöffnung x ±36,9 / z ±57,6, y 32,7–33,4; 8.064 Dreiecke | `metalpainted_metal_clean_line_color`, opak | nicht exportiert | exportiert, opak | Dach |
| `MESH_ROOT.002` · `EXTRA/scenes\center3_df/` | BayArena-Schriftzug + Bayer-Kreuz am Dachrand Ost, x 107–113, y 27–42; 12.250 Dreiecke | `diffuseTexture_93`, opak | nicht exportiert | exportiert, opak | Dach |
| `front_df_0` · EXTRA | Glasfront Logenebene (Ring), y 14,5–16,8 | `glass_color`, Alpha 46/255 (18 %) | nicht exportiert | exportiert, `transparent:true` | Körper |
| `front_df_1` · EXTRA | Glasfront Südende, y 7–17 | `glass_color`, 18 % | nicht exportiert | exportiert, `transparent:true` | Körper |
| `front3_1/10/12/15/16/17/8` · MAIN | Dachrand-Ring, Seilnetz-Ringe und vier Seilnetz-Quadranten, y 28,6–32,8 | `metal_painted_white`, `concrete_standard` | exportiert | unverändert | Dach |
| `front3_11` · MAIN | Außenring-Fachwerk + Pylone, y 3,4–40,2 | `metal_painted_white` | exportiert | unverändert | Dach (mit Pylonen, wie im Zwischenstand) |
| `front3_13/19/7/14/5/9/18/0` · MAIN | Leuchten, Lautsprecher, Wandträger, Innenring, Betonringe, Pylonverankerung | div. | exportiert | unverändert | Dach |
| `front3_2/3/4/6` + `MESH_ROOT.001` · MAIN | **zwei Videowände** mit Rahmen, Leiter, Geländer auf Nord- und Südkurve, y 14–29 | `plastic_black`, `metal_steel`, `tex_bm_26` | exportiert, in v1 als Dach geschaltet | unverändert, **jetzt Körper** (Anbau) | bleibt |
| `front1_probe_1*` · MAIN | Pressebox-Glas, Alpha 47 % | `glass_clear_color` | in v1 durch Alpha-Schnitt 0,5 **komplett verschwunden** | `transparent:true` (sichtbar) | Körper |

Was **nicht** übernommen wird (wie bei Bayern/Gladbach): Wurzel `AD` (LED-Banden, Banner, Platzhalter-Turnierbanner), `SCARECROW` (Figuren), `center2_` (Fernkulisse; der Ortsplan ersetzt sie). Keine erfundene Fläche, keine Weißfärbung: Material und Textur der Dachhaut kommen 1:1 aus dem Bundle; die Transluzenz entspricht dem Textur-Alpha der Quelle.

## Was sich am Export geändert hat (Auftrag 3)
- Neue Option `--roots EXTRA` im Exportwerkzeug: zusätzliche Wurzeln je Bundle, nach Inventur, nicht pauschal. Für Bayern/Gladbach nicht angewandt (dort liegen unter EXTRA nur Fanbanner bzw. Fensterrahmen/Glasflächen — Information, keine Änderung).
- Neue Regel „transluzent": gleichmäßig teildurchsichtige Texturen (Alpha zwischen 2 % und 97 %, kein Ausschnitt) → `transparent:true`, `alphaTest:0`. Trifft hier Dachhaut (72 %), Glasfronten (18 %), Pressebox-Glas (47 %). Reihenfolge vor dem Alpha-Schnitt, damit Glas mit 47 % nicht mehr weggeschnitten wird.
- Unverändert: die 265 Meshes aus v1 sind geometrisch byte-identisch (je Mesh geprüft), alle 80 gemeinsamen Textur-Hashes identisch, 3 Texturen neu. Spielfeld `st081_pitch_0` ±43,6 × ±60,6 m, Linienrasen ±34,1 × ±53,0 m, Kamera, Kalibrierung der Achsen, Flutlichter (203 → 12), Bodenregeln (3 Decals transparent, keine Rasenangleichung nötig, 20 Alpha-Schnitte) — alles wie v1.

## Dachschalter (Auftrag 4)
Präfixliste nach Einzelisolierung, keine Höhentrennung allein: `roofMeshPrefixes = ["front3_0","front3_1","front3_5","front3_7","front3_8","front3_9","front3_df_","MESH_ROOT.002"]`, `roofMinHeight 3` (Pylone gehen mit). Nachrechnung mit der Renderer-Regel über das Binary: **Crowd 0 / 31.654, Tribünen `center1_*` 0 / 192.488, Boden 0 / 6.074 Dach-Dreiecke** — Ränge, Treppen, Sitzflächen, Unterbauten und beide Videowände bleiben vollständig. Pixelvergleich Dach-aus v1 ↔ v2 bei identischer Kamera: 0,08–0,18 % abweichend (nur Videowand-Rahmen und Glas).

## Bilder (Auftrag „Nachweis")
`bilder/bayarena-dach-vorher-nachher.jpg`: 7 Zeilen × vorher/nachher, identische Kamera, Licht, Fenster (3D 1000×560, Ticker 1000×500): 3D Dach an/aus, Ticker Dach an/aus, Nacht + Flutlicht, Draufsicht Dach an (Deckung + freie Feldöffnung), Draufsicht Dach aus. Einzelbilder `v1_*`/`v2_*.png` daneben. Zentraler Renderer Stand 12.10. (roofMeshPrefixes, transparent/alphaTest/uvProjection).

## Verbleibende Lücken (ausdrücklich)
- Transluzenz im Spielrenderer ist Alpha-Blending ohne Lichtstreuung; die reale Makrolon-Deckung wirkt matter/weißer. Keine Materialänderung vorgenommen, Quelle maßgeblich.
- 2D-Editor-Bild nur in der App; Umfeld im Produktivbestand wurde von Replit bereits korrigiert — hier nur für die Vorschaudaten geometrisch geprüft (keine festen Listenindizes).
- Replits zentrales `scripts/export_stadium_model.py` kennt `--roots`, `--lamp-materials` und die Transluzenz-Regel noch nicht; für eine byte-gleiche Reproduktion ist `werkzeuge/export_stadium_model.py` dieser Fassung nötig.

## Einspielen
1. `scp -r stadium-models/901 root@49.13.5.151:/var/www/assets/stadium-models/` (neuer Versionsordner `ba8884cabbb4462c` neben dem alten).
2. `models/901.json` nach `stadium_editor/blueprints/v2/models/901.json` (ersetzt den Zwischenstand), committen, pushen, `/push`.
3. `docker exec websoccer-web-1 python manage.py check_stadium_model --fmi 901 --assets` → `Assets OK: 84 Dateien`.
4. Fünf Ansichten live abnehmen (`/stadion/4/live/`).

## Reproduktion
```sh
python3 -I werkzeuge/export_stadium_model.py --bundle bayarena.bundle --seats bayarena.json --fmi 901 --name "BayArena" \
  --out export --calibration kalibrierung.json --lamp-materials light_fixture,light_01 --roots EXTRA
python3 -I werkzeuge/roof_inventory.py bayarena.bundle 25 dach_inventar.json     # Inventur
python3 -I werkzeuge/isolate.py export/manifest.json manifest_only.json only '^front3_df_0$'   # Isolierung für den Harness (&m=…)
```
