"""2D-Editoransicht beschriften: Blaupausen-Enden/-Seiten mit realen Tribünennamen und Peilungen, Nordpfeil, OSM-Anker
(Ankertexte in einer Randspalte mit Verbindungslinien, damit nichts die Ansicht verdeckt).
Aufruf: beschrifte_2d.py <2d.png> <umfeld_pruefung.json> <beschriftung.json> <out.jpg>"""
import sys, json, math, textwrap
from PIL import Image, ImageDraw, ImageFont
src, pruef, besch, out = sys.argv[1:5]
P = json.load(open(pruef)); B = json.load(open(besch))
im = Image.open(src).convert("RGB"); W, H = im.size
F = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13); FB = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 14); FS = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
cx, cy = B["zentrumPx"]; s = B["pxProMeter"]; th = math.radians(B["axisThetaGrad"]); fc = B["fieldC"]
def frame_to_px(u, v):
    e = u*math.cos(th) - v*math.sin(th); n = u*math.sin(th) + v*math.cos(th); return cx + e*s, cy - n*s
def bg_to_px(e, n): return cx + (e - fc[0])*s, cy - (n - fc[1])*s
def bearing(u, v):
    e = u*math.cos(th) - v*math.sin(th); n = u*math.sin(th) + v*math.cos(th); return (math.degrees(math.atan2(e, n)) + 360) % 360
SIDE = 400; PAD = 170
canvas = Image.new("RGB", (W + SIDE, H + PAD), (18, 22, 26)); canvas.paste(im, (0, 0)); d = ImageDraw.Draw(canvas)
def box(x, y, lines, fill, font, clamp=True):
    w = max(d.textlength(l, font=font) for l in lines) + 12; h = 17*len(lines) + 8
    x0, y0 = x - w/2, y - h/2
    if clamp: x0 = min(max(x0, 4), W - w - 4); y0 = min(max(y0, 30), H - h - 4)
    d.rectangle([x0, y0, x0 + w, y0 + h], fill=fill, outline=(0, 0, 0))
    for i, l in enumerate(lines): d.text((x0 + 6, y0 + 4 + 17*i), l, fill=(0, 0, 0), font=font)
    return x0, y0, w, h
# Anker: Marker im Bild, Text in der Randspalte
ank = P.get("anker", []); slot_h = (H - 40) / max(1, len(ank)); y_slot = 40
for a in ank:
    e, n = a["bgZentrum"]; x, y = bg_to_px(e, n)
    dist = a.get("bgStrasse_abstandMeter_median", a.get("bgGebaeude_abstandMeter_median"))
    inside = 0 <= x < W and 0 <= y < H
    lines = [a["merkmal"], f"{a['osm']} · Blaupausenseite {a['seite']}", f"Abstand zum Umfeldelement {dist} m"]
    if not inside: lines.append(f"außerhalb: {abs(e-fc[0]):.0f} m {'O' if e>fc[0] else 'W'} / {abs(n-fc[1]):.0f} m {'N' if n>fc[1] else 'S'} der Spielfeldmitte")
    mx = min(max(x, 12), W - 12); my = min(max(y, 32), H - 12)
    if inside: d.ellipse([mx-6, my-6, mx+6, my+6], outline=(0, 200, 255), width=3)
    else: d.rectangle([mx-6, my-6, mx+6, my+6], outline=(0, 200, 255), width=3)
    ty = y_slot + 4; d.line([mx, my, W + 8, ty + 8], fill=(0, 200, 255), width=1)
    for i, l in enumerate(lines): d.text((W + 12, ty + 16*i), l, fill=(200, 240, 255), font=FS)
    y_slot += slot_h
# Tribünen
for key, (u, v) in {"NORD": (96, 0), "SUED": (-96, 0), "OST": (0, -92), "WEST": (0, 92)}.items():
    x, y = frame_to_px(u, v); x2, y2 = frame_to_px(u*0.7, v*0.7)
    d.line([x2, y2, x, y], fill=(255, 220, 0), width=2)
    box(x, y, [f"Blaupause {key} · Peilung {bearing(u, v):.1f}°", B["tribuenen"][key]], (255, 240, 160), FB)
# Nordpfeil
nx, ny = W - 40, 75; d.line([nx, ny + 40, nx, ny - 30], fill="white", width=3); d.polygon([(nx, ny - 40), (nx - 8, ny - 22), (nx + 8, ny - 22)], fill="white"); d.text((nx - 6, ny + 44), "N", fill="white", font=FB); d.text((nx - 45, ny + 62), "(geografisch)", fill="white", font=FS)
d.rectangle([0, 0, W + SIDE, 26], fill=(0, 0, 0)); d.text((8, 5), B["titel"], fill="white", font=FB)
d.text((W + 12, 30 - 2), "OSM-Anker (ODbL, Nominatim 13.10.2026)", fill="white", font=FB) if False else None
y = H + 8
for l in B.get("legende", []) + B.get("fusszeile", []):
    for wl in textwrap.wrap(l, 215): d.text((8, y), wl, fill=(230, 230, 230), font=FS); y += 15
    y += 3
canvas.save(out, quality=88); print(out, canvas.size)
