"""presentation_<fmi>.json für den Render-Harness – wie unity_presentation()/runtime_presentation() im Projekt (Fassung 3, 14.10.2026).
Aufruf: build_presentation.py <fmi> "<Stadionname im Blueprint-Bundle>" <manifest.json> <assetVersion> <livescene.json> <bundle.js.gz> <out> [--ausnahmen <datei.json>]
Keine lokalen IDs: der Verein wird nur über clubFmiId identifiziert; clubId/capacity werden nicht geschrieben.
Umfeld: vollständiger Bestand, KEIN automatischer Gebäudefilter (Überlappungen werden nur gemeldet).
Ungültige Polygone (< 3 verschiedene Punkte) führen zum Abbruch – es sei denn, sie stehen mit exaktem Inhalt in der
Ausnahmedatei (je Stadion, mit Quelle/Grund/Freigabe). Jede andere Abweichung bricht ab; keine allgemeine Bereinigung."""
import sys, json, gzip, collections
args = [a for a in sys.argv[1:] if not a.startswith("--")]
fmi, name, manifest_path, version, livescene, bundle, out = int(args[0]), args[1], args[2], args[3], args[4], args[5], args[6]
exceptions_path = sys.argv[sys.argv.index("--ausnahmen") + 1] if "--ausnahmen" in sys.argv else None
if "--ohne-korrektur" in sys.argv:
    sys.exit("ABBRUCH: --ohne-korrektur gibt es nicht mehr – das Umfeld wird immer vollständig übernommen; Ausnahmen nur über --ausnahmen.")
raw = gzip.open(bundle, "rt", encoding="utf-8").read(); data = json.loads(raw[raw.index("["):raw.rindex("]")+1])
geo = next(s for s in data if s["meta"]["name"] == name)
scene = json.load(open(livescene)); man = json.load(open(manifest_path))
assert scene["club"]["fmInsideId"] == fmi == man["clubFmiId"], "live-scene, Manifest und Aufruf nennen verschiedene FMI-IDs"
legacy = geo.get("bg") or {}; live = geo.get("surroundings") or {}
buildings = legacy.get("buildings") or live.get("buildings") or []
surr = {"source": live.get("source") or legacy.get("source") or "OpenStreetMap/BLUEPRINT-Bundle (ODbL)", "treeSource": "",
        "green": list(legacy.get("green") or []), "water": list(legacy.get("water") or []), "roads": list(legacy.get("roads") or []),
        "buildings": [b if isinstance(b, list) else b["poly"] for b in buildings],
        "buildingHeights": [None if isinstance(b, list) else b.get("h") for b in buildings],
        "buildingIds": [None if isinstance(b, list) else b.get("id") for b in buildings],
        "trees": list(legacy.get("trees") or []), "heightQuality": "schematic"}
# Ausnahmen: nur exakt freigegebene Einträge dürfen entfernt werden
exceptions = json.load(open(exceptions_path)) if exceptions_path else {"ausnahmen": []}
approved = [e for e in exceptions.get("ausnahmen", []) if e.get("clubFmiId") == fmi]
removed = []
for ex in approved:
    layer, index = ex["ebene"], ex["index"]
    poly = surr[layer][index] if index < len(surr[layer]) else None
    if poly != ex["inhalt"]:
        sys.exit(f"ABBRUCH: Ausnahme {layer}[{index}] passt nicht zum Bundle-Inhalt (erwartet {ex['inhalt']}, gefunden {poly}) – bereits korrigierte oder abweichende Eingabe")
    if ex.get("freigabe") not in ("freigegeben", "beantragt"):
        sys.exit(f"ABBRUCH: Ausnahme {layer}[{index}] ohne Freigabestatus")
    removed.append({"ebene": layer, "index": index, "inhalt": poly, "status": ex["freigabe"], "quelle": ex.get("quelle"), "grund": ex.get("grund")})
for layer in sorted({r["ebene"] for r in removed}):
    for index in sorted([r["index"] for r in removed if r["ebene"] == layer], reverse=True):
        del surr[layer][index]
        if layer == "buildings":
            del surr["buildingHeights"][index]; del surr["buildingIds"][index]
# Verbleibende ungültige Polygone → Abbruch (keine allgemeine Bereinigung)
degenerate = {k: [i for i, poly in enumerate(surr[k]) if len({tuple(p[:2]) for p in poly}) < 3] for k in ("green", "water", "buildings")}
degenerate = {k: v for k, v in degenerate.items() if v}
if degenerate:
    detail = {k: [surr[k][i] for i in v] for k, v in degenerate.items()}
    sys.exit(f"ABBRUCH: ungültige Umfeldpolygone ohne freigegebene Ausnahme: {json.dumps(detail)} – melden, nicht still entfernen")
# Überlappungen nur melden
def inside(poly, x, y):
    n = len(poly); c = False
    for i in range(n):
        x1, y1 = poly[i][:2]; x2, y2 = poly[(i+1) % n][:2]
        if (y1 > y) != (y2 > y) and x < (x2-x1)*(y-y1)/(y2-y1+1e-12)+x1: c = not c
    return c
outline = geo.get("outline") or []
overlaps = [{"index": i, "zentrum": [round(sum(p[0] for p in poly)/len(poly), 1), round(sum(p[1] for p in poly)/len(poly), 1)],
             "bounds": [[round(min(p[0] for p in poly), 1), round(min(p[1] for p in poly), 1)], [round(max(p[0] for p in poly), 1), round(max(p[1] for p in poly), 1)]],
             "hoehe": surr["buildingHeights"][i], "quelle": "Blaupausen-bg (OSM)"}
            for i, poly in enumerate(surr["buildings"])
            if outline and (inside(outline, sum(p[0] for p in poly)/len(poly), sum(p[1] for p in poly)/len(poly)) or any(inside(outline, p[0], p[1]) for p in poly))]
tot = collections.defaultdict(collections.Counter)
for bl in scene["blocks"]:
    for cnt, idx in bl.get("rle") or []:
        if idx > 0: tot[bl["stand"]][idx] += cnt
pal = scene["palette"]; dc = {st: pal[max(c, key=c.get)] for st, c in tot.items() if c}
pres = {"renderer": "unity-spatial", "modelUrl": f"/models/{fmi}/{version}/manifest.json", "stadium": scene["stadium"], "clubFmiId": fmi,
        "sourceSha256": man["sourceSha256"], "frame": {k: v for k, v in (geo.get("meta") or {}).items() if k in ("axisTheta", "fieldC", "maxR")},
        "surroundings": surr, "calibration": man["calibration"], "designColors": dc,
        "_hinweis": "Vorschau für den Render-Harness; Umfeld vollständig aus dem Blaupausen-Bundle, Gestaltungsfarben aus dem öffentlichen live-scene, keine lokalen IDs, nichts davon übernehmen"}
json.dump({"presentation": pres}, open(out, "w"))
report = {"umfeld": {k: len(surr[k]) for k in ("buildings", "roads", "green", "water", "trees")}, "entfernt_per_freigabe": removed,
          "gebaeude_im_stadionumriss_nur_gemeldet": overlaps, "designColors": dc}
json.dump(report, open(out.replace(".json", "_umfeldbericht.json"), "w"), indent=1, ensure_ascii=False)
print("presentation", scene["stadium"], "| Umfeld", report["umfeld"], "| per Freigabe entfernt:", [(r["ebene"], r["index"], r["status"]) for r in removed], "| Gebäude im Umriss (nur gemeldet):", len(overlaps))
