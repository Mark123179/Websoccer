# Weserstadion (FMI 948) — offene Punkte und notwendige Metadatenkorrekturen

Getrennte Liste. Nichts davon ist im Paket umgesetzt; Entscheidung und Freigabe liegen beim Betreiber.

## A · Entscheidungen zum Modell (Empfehlung jeweils zuerst)
1. **Lichtfaktor 2,5** (Quelle 80/25 → Browser 200/62,5, genau einmal in `fixtures[].intensity`). Gemessen im Ticker bei identischer Kamera/Exposure (Rasenfeld / Gegentribüne inkl. Dachunterseite / Sitzfläche Gegentribüne / seitliche Ränge): ×1 42/23/–/–, ×2 72/37/47/99, **×2,5 84/43/54/112**, ×3 95/49/61/122, ×4 114/58. Referenzen: Freiburg ×8 (abgenommen) 86/71/95/98, Wolfsburg ×1,5 (abgenommen) 89/75/98/110. Rasen und seitliche Ränge liegen bei ×2,5 auf Referenzniveau; die Gegentribüne bleibt in Bremen bauartbedingt dunkler (tiefes Dach, Spots an der Traufe aufs Spielfeld gerichtet, 4 Mastköpfe nach innen). Alternative: Faktor 3 (Rasen 95, leicht überstrahlt) — `licht_kalibrieren.py` auf dem unkalibrierten Export erneut ausführen, Assets/assetVersion bleiben, neue Manifestrevision.
2. **Vier Flutlichtmasten gehen mit dem Dach** (`front3_17/18/19/29/36/45/46/47`, y 21,5…67,8 m). Die Masten stehen im Modell auf den Dachecken (kein Fußpunkt unter 21,5 m) — ohne Dach schwebten sie. Real stehen die vier Masten bis heute (Flutlicht seit 2025 zusätzlich unter dem Dach, Masten bleiben; 90min/Deichstube 28.11.2024). Alternative: Masten aus der Dachliste nehmen → bleiben bei Dach aus freistehend auf 21,5 m Höhe hängen.
3. **Gästeblock-Fangnetz `MESH_ROOT.008` ausgeschlossen** (`scenes\left1_probe`, plastic_netting_02, x −1,3…54,6 / y 12,5…29,0 / z 80,0…105,2 m über dem Gästeblock `C_left2_C1-UltraAway`). Regel „Fangnetze ausblenden"; keine Abspannung im Bundle. Alternative: Netz behalten (Re-Export, neue assetVersion).
4. **Kulisse `center2_*` ausgeschlossen, Glasfassade `center2_2` behalten.** `center2_0` (Betonrampe x −83…−44 / z −110…−58, bis 8,8 m) und `center2_16` (Betonplatte x −128…−36 / z −153…−22) sind Bodenkulisse außerhalb des Stadionkörpers (Westkurven-/Südtribünen-Vorfeld), nicht Stadion → ausgeschlossen wie Panorama/Boden/Bäume/Nachbargebäude. Alternative: `center2_0/16` behalten (dann liegen sie über den OSM-Flächen).
5. Videotafeln an beiden Enden (`MESH_ROOT.003` + Halterungen `front3_37…44/48/49/50`, x ±9, y 24,7…31, z ±79) auf der Dachliste (Regel); kein Handlungsbedarf.
6. `front3_0…9` (Beton-Oberrang-Abschluss/Rückwände/Stützenring y 4,9…25,1) bleiben **Körper**; nur die zweistelligen `front3_10…50` sind Dach. Kein Handlungsbedarf, nur zur Kenntnis (Bilder 02/04/07/08).

## B · Metadatenkorrekturen in der Anwendung (nicht Teil des Manifests, gesondert freizugeben)
Der öffentliche live-scene liefert abgeleitet `homeStand: OST`, `mainStand: OST`, `farStand: WEST`. Belegt (offizieller Stadionplan, Modell, Rohblaupause, Umfeld):

```json
{
  "meta": {"homeStand": "SUED"},
  "scene_meta": {"mainStand": "WEST", "farStand": "OST"}
}
```

- Blaupausenrahmen: NORD-Ende = **Westkurve** (Peilung 287,5°), SUED-Ende = **Ostkurve** (107,5°), OST-Seite = **Nordtribüne** (17,5°), WEST-Seite = **Südtribüne** (197,5°). Die Blaupausenbezeichnungen sind also um 90° gegen die realen Tribünennamen verdreht — das ist Rahmenkonvention, keine Fehlorientierung; Modell und Umfeld sind mit `standAxes {+x OST, −x WEST, +z NORD, −z SUED}` deckungsgleich.
- `homeStand` muss **SUED** sein (Ostkurve: Haake-Beck-Fankurve, Stehblöcke 122–142; Modell `C_right1_C3-UltraHome`/`C_right2_C1-UltraHome` bei −z = SUED).
- `mainStand` muss **WEST** sein (Südtribüne: Trainerbänke/Spielerbänke, Presse 44/46, VIP-Logen Süd, VIP-Rang Gold; Modell Bänke `center1_probe_*` bei x −42,6, Fensterfronten `front_df_0/2/3` bei x −70…−60), `farStand` **OST** (Nordtribüne: VIP-Logen Nord, VIP-Rang Platin, Evergreen; Modell Platin-Glasfront `front_df_4` bei x 76…82).
- Teilansicht der zu ergänzenden Schlüssel; Geometrie, Blöcke, Kapazitäten, Designs, Ausbauten bleiben unberührt; Ergänzung unter Zeilensperre mit Backup und Nachher-Abgleich.

## C · Widerspruch zwischen den Ebenen (gemeldet, nicht korrigiert — Vorschlag einer engen Korrektur)
**Wirtschaftliche Zuteilung (öffentlicher live-scene 12, lesend):** die einzige Stehplatzfläche ist Block 2, `OST OBER`, 240 Reihen × 43 = **10.320 Stehplätze** (Blaupausenseite OST = **Nordtribüne**, Zentrum x −51 / y −82 im Spielfeldrahmen, direkt beim Wuseum-Anker); SUED (= Ostkurve) ist komplett Sitzplatz (8.890). Die **Rohblaupause** führt dagegen **8 Stehblöcke `STEH` im SUED-Unterrang** (Block-IDs 28, 29, 50–55 = Ostkurve, real Blöcke 122–142), die der live-scene als Sitzplatz (14 Reihen) ausgibt; Block 2 ist in der Rohblaupause `SITZ` mit 21 Reihen. Modell und Stadionplan bestätigen die Rohblaupause (Stehplätze Ostkurve = SUED). Die aus `rows*seats` abgeleitete `homeStand OST` ist kein Beleg (Regel), sondern Folge dieser Zuteilung.
**Vorschlag (enge Korrektur, nur nach Freigabe, lokal zu prüfen):** Stehplatzzuteilung OST → SUED verlagern (Block 2 zurück auf Sitz, die 8 SUED-Unterrangblöcke auf Steh) und `homeStand SUED` setzen. **Keine Blöcke/Kapazitäten wurden vertauscht**, das Paket enthält dazu nichts; Kapazitäten bleiben lokal (öffentlicher live-scene 41.800 = Betreiberangabe, kein Importwert; Bundle-`capacity 42.294` nicht übernommen; weserstadion.de nennt 42.100).

## D · Prüfpunkte an der lokalen Geometrie (lesend prüfen, nichts ändern)
1. **`bg.water[2]` der Weserstadion-Blaupause hat nur 2 Punkte** (`[-159,1, -491,1]`, `[-137,3, -447,5]`, ≈ 490 m SSO). `buildDortmundSurroundings` wirft bei < 3 Punkten. Für die Harness-Vorschau wurde allein dieser Eintrag über `umfeld_ausnahmen.json` mit Status **`beantragt`** (nicht freigegeben) weggelassen — Quelle, exakter Inhalt, Grund und Datenebenen stehen dort; die Freigabe für Wolfsburg `water[5]` gilt hier **nicht**. Bitte lokalen Bestand prüfen und entscheiden (Eintrag korrigieren oder entfernen, mit Backup); danach Status in `umfeld_ausnahmen.json` auf `freigegeben` setzen oder Eintrag streichen. Keine Renderer-Änderung durch mich.
2. Gästeblock: Modell `C_left2_C1-UltraAway` liegt im **nördlichen Oberrang der Westkurve** (+z/+x) = Stand bis Sommer 2024; real seit 2024/25 in der **Südwest-Ecke** (Steh 114/116/118, Sitz 115/117/119/35; Stadionwelt 06.05.2024). Kein Modellthema (Crowd-Zuordnung), nur zur Kenntnis.
3. **Block 53 (Oberrang, Ecke Ost/Süd) ist seit 8.7.2026 nach einem Teileinsturz gesperrt** (Tagesspiegel 09.07.2026, Ursache Bauarbeiten VIP-Bereich); das Modell zeigt den Vorzustand. Nur zur Kenntnis.

## E · Hinweise ohne Handlungsbedarf
- Crowd-/Sitzflächen (`C_*`, Textur `audi_seat_mat` mit „WERDER"/„BREMEN"-Schriftzug und Raute im Sitzmuster) werden wie bei allen Modellen pro Tribüne mit der Gestaltungsfarbe getönt; im aktuellen Design (einheitlich `#f4f6f8`) bleibt der Quellzustand sichtbar.
- AD-Wurzel (14 Meshes: Banden `adboardweser`, Choreo-Banner `ad_st009_normal_12` über der Ostkurve) und SCARECROW (428 Figuren) sind nicht Teil des Exports (Standardwurzeln MAIN/AUDIAREA/PITCH2021/MESH_CROWD + EXTRA).
- Replits `editor.js` (v65) ist über die Dateischnittstelle nicht lesbar (> 100 KB); die 2D-Ansicht nutzt das produktive `editor.js` von playwebsoccer.de (14.10.).
- Produktionsserver (playwebsoccer.de) hatte am 13.10. noch keinen Unity-Renderer deployt; Abnahme dort erst nach Push des Replit-Stands.
