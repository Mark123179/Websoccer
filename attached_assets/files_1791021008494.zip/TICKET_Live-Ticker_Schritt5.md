# TICKET · Live-Ticker Schritt 5 — Persistenz, Segment-Log, Sperre, Ticker-Tab

Stand: 08.09.2026 · Projekt: Blueprint (playwebsoccer.de) · Repo `Mark123179/Websoccer`, Django 6 / PostgreSQL
Status: **freigegeben für Replit** · Erzähler-Paket `match_story` v4 ist eingefrorene Baseline (Änderungen an der Erzähllogik nur durch Claude, nicht durch dieses Ticket)

---

## 0. Ziel in drei Sätzen

Die Match-Engine liefert Ergebnis und Statistik. Direkt nach der Simulation erzählt der Erzähler (`game/match_story/`) daraus **einmal** die Geschichte des Spiels und speichert sie: Textzeilen mit Spielminute, Akteuren, Sichtbarkeit, Abspiel-Offset und Dauer, dazu ein Segment-Log der Erzählung und der Spielzustand. Ticker-Tab, Spieltagsseite, Momentum-Kurve und später der 2D-Modus lesen ausschließlich diese gespeicherte Geschichte. Ergebnisse einer Runde bleiben gesperrt, bis das letzte Spiel der Runde seinen Abpfiff-Offset erreicht hat.

## 1. Was Mark vorab tut (kein Replit-Teil)

1. `match_story_v4_baseline.zip` entpacken und als `game/match_story/` ins Repo legen (Django-frei, keine Abhängigkeiten außer Stdlib). Enthalten: `narrator.py, context.py, budget.py, actors.py, compose.py, phases.py, planner.py, state.py, render.py, cli.py, model.py, pools/de.py`.
2. Danach dieses Ticket als Replit-Prompt abschicken (Abschnitt 9).

## 2. Engine: Segment-Log als Ausgabefeld (E-T11)

**Datei:** `game/match_engine.py`, Segmentschleife um Zeile 1636 (`_add_segment_stats(...)`).

Die Engine berechnet je 5-Minuten-Block bereits `h_seg_stats` / `a_seg_stats` (`shots`, `shots_on_target`, `corners`, `fouls`, `yellow`, `pressing_ball_wins`, `pressing_bypassed`, Zonen …) und addiert sie nur zu Summen. Änderung: **dieselben, bereits berechneten Werte zusätzlich je Block in eine Liste schreiben** und in `report_data` ausgeben.

```python
segment_log.append({
    'minute_from': seg_start, 'minute_to': seg_end,
    'home': {k: h_seg_stats.get(k, 0) for k in SEGMENT_LOG_KEYS},
    'away': {k: a_seg_stats.get(k, 0) for k in SEGMENT_LOG_KEYS},
    'active_plan_home': <aktiver Plan home in diesem Block oder None>,
    'active_plan_away': <…>,
    'possession_home': home_poss,
})
# result['segment_log'] = segment_log   (neben 'plan_seg_stats', Zeile ~1762)
```
`SEGMENT_LOG_KEYS = ('shots', 'shots_on_target', 'corners', 'fouls', 'yellow', 'red', 'pressing_ball_wins', 'pressing_bypassed', 'attacks_left', 'attacks_center', 'attacks_right')` — nur Schlüssel übernehmen, die `_segment_team_stats` tatsächlich liefert.

**Harte Bedingung (Freeze-Regel):** kein zusätzlicher Zufallszug, keine Formel, kein Multiplikator wird berührt. Beleg: Regressionsbefehl (`masstest_engine` / `validate_default_tactic_v1`) vor und nach der Änderung mit festem Seed — **Summen, Tore, Noten bitgleich**. Ergebnis des Vergleichs im Ticket-Abschluss ausgeben. Auch Verlängerungssegmente (91–120) loggen.

`match_story/budget.py::from_segment_log()` liest das Feld automatisch, sobald es existiert; die Ersatzverteilung bleibt als Fallback für Altspiele.

## 3. Datenmodell (E-T09)

Neue Modelle in `game/models.py` (oder `game/models_story.py` + Import), Migration erzeugen.

```python
class MatchStory(models.Model):
    match = models.OneToOneField(SimulatedMatch, on_delete=models.CASCADE, related_name='story')
    version = models.CharField(max_length=16)                 # Erzähler-Version, z. B. 'v4'
    kickoff_at = models.DateTimeField(null=True, blank=True)   # Anstoß in Echtzeit (Sperre)
    duration_s = models.FloatField()                           # 900 / 1200 / + Elfer
    final_score = models.CharField(max_length=8)
    tactic_snapshot = models.JSONField()                       # home/away TacticSetup zum Simulationszeitpunkt
    segments = models.JSONField()                              # Segment-Log der Erzählung (state.py::build_segments)
    state = models.JSONField()                                 # Narrative Memory am Ende (MatchState.as_dict)
    issues = models.JSONField(default=list)                    # Erzähler-Prüfhinweise (Engine-Datenfehler)
    created_at = models.DateTimeField(auto_now_add=True)

class MatchEvent(models.Model):
    story = models.ForeignKey(MatchStory, on_delete=models.CASCADE, related_name='events')
    order = models.PositiveIntegerField()                      # Reihenfolge im Ticker
    seq = models.FloatField()                                  # Sequenz-Nr. (Phasenzeilen haben x.5)
    beat = models.PositiveSmallIntegerField()
    minute = models.PositiveSmallIntegerField()
    added = models.PositiveSmallIntegerField(default=0)        # Nachspielzeit
    team = models.CharField(max_length=4, null=True)           # 'home' | 'away' | None
    kind = models.CharField(max_length=40)                     # Pool-Schlüssel (tor, schuss_gehalten, aufbau, phase …)
    cls = models.CharField(max_length=24)                      # Planer-Klasse (goal, shot, corner, buildup, phase, analysis …)
    level = models.PositiveSmallIntegerField(default=2)        # Ebene 1–5
    visible = models.BooleanField(default=True)                # hat eine 2D-Szene
    text = models.TextField()
    actors = models.JSONField(default=dict)                    # rolle -> player_id
    offset_s = models.FloatField()                             # Abspielzeit ab Anstoß
    duration_s = models.FloatField()
    payload = models.JSONField(default=dict)                   # beats[], score, goal_ctx, zone, phase, card …
    class Meta:
        ordering = ['story', 'order']
        indexes = [models.Index(fields=['story', 'offset_s']), models.Index(fields=['story', 'cls'])]
```
`payload.beats` enthält je Zeile die vollständige Beat-Liste (Typ, Akteure, Rohdaten) — das ist die 2D-Schnittstelle. `report_data` bleibt unverändert; nichts wird daraus entfernt.

Optional, aber empfohlen: `Club.nickname` (CharField, z. B. „Bayern", „Gladbach") — der Erzähler nutzt heute eine Heuristik (`phases._short`), ein Feld ist sauberer. Wenn vorhanden, in `context.py::_team_from` als `Team.nick` durchreichen (eine Zeile).

## 4. Post-Sim-Hook (E-T01, E-T12)

**Ort:** `game/management/commands/play_matchday.py`, direkt nach dem Erstellen/Ersetzen des `SimulatedMatch` (Schleife „1. SimulatedMatch erstellen"), und in allen anderen Pfaden, die `SimulatedMatch` mit `report_data` erzeugen (Pokal, Freundschaft, Admin-Simulation) — eine gemeinsame Funktion:

```python
# game/match_story/django_bridge.py  (neu, einziger Django-abhängiger Teil des Pakets)
def build_story_for(sm: SimulatedMatch, kickoff_at=None) -> MatchStory:
    export = {
        'match': {...id, match_type, home_club{id,name}, away_club{id,name}, home_goals, away_goals, referee},
        'report_data': sm.report_data,
        'home_tactic': tactic_dump(sm.home_club),   # wie export_story_input.py::_tactic_dump
        'away_tactic': tactic_dump(sm.away_club),
    }
    result = match_story.narrate(export)
    with transaction.atomic():
        MatchStory.objects.filter(match=sm).delete()          # Neuaufbau nur explizit (Backfill/Admin), s. u.
        story = MatchStory.objects.create(match=sm, version='v4', kickoff_at=kickoff_at,
            duration_s=<letzter offset+duration>, final_score=..., tactic_snapshot={'home': ..., 'away': ...},
            segments=result['segments'], state=result['state'], issues=result['issues'])
        MatchEvent.objects.bulk_create([MatchEvent(story=story, order=i, ...) for i, l in enumerate(result['lines'])])
    return story
```
Regeln:
- Läuft **einmal** je Simulation, bevor der Spieltag freigegeben wird. Fehler im Erzähler dürfen den Spieltag **nicht** abbrechen: `try/except`, Fehler loggen, `MatchStory` mit `issues=['narrator_failed: …']` anlegen, Ticker-Tab zeigt dann den Fallback (Abschnitt 6).
- **Nie neu erzählen** bei Seitenaufruf. Neuaufbau nur über den Backfill-Command oder einen Admin-Button „Geschichte neu erzählen" (bewusst, protokolliert).
- `tactic_snapshot` wird **zum Simulationszeitpunkt** gezogen (TacticSetup ist mutabel; `report_data` enthält nur die kompilierte Taktik des letzten Segments).
- Determinismus: gleicher `report_data` + gleicher Snapshot → identische Geschichte (Seed = match id). Test dafür aufnehmen.

**Backfill-Command** `python manage.py build_match_stories [--since ID] [--force] [--dry-run]`: für alle `SimulatedMatch` ohne `MatchStory` (oder alle mit `--force`) den Hook ausführen; Ausgabe je Spiel: Zeilen, Sichtbar, Dauer, Issues; Zusammenfassung der Issues am Ende (das sind Engine-Datenfehler, siehe Abschnitt 8).

## 5. Sperre je Wettbewerb und Runde (E-T10)

- `MatchStory.kickoff_at` = Anstoßzeitpunkt der Runde (aus `Fixture.scheduled_date`, sonst Zeitpunkt des Spieltag-Laufs). Alle Spiele einer Liga-Runde bzw. Pokalrunde bekommen **denselben** `kickoff_at`.
- Freigabezeitpunkt der Runde = `max(kickoff_at + duration_s)` über alle Spiele der Runde (Verlängerung/Elfmeterschießen verlängern einzelne Spiele; die Runde öffnet mit dem letzten).
- **Bis dahin gesperrt:** Ergebnis, Tabelle, Spielbericht (alle Tabs außer Ticker), Statistik, Spielernoten, Elf des Spieltags, Nachrichten/Benachrichtigungen mit Ergebnisbezug, Admin-Übersicht (Admin sieht Sperrstatus, nicht das Ergebnis — außer Schalter aus).
- **Nicht gesperrt:** der Ticker-Tab jedes Spiels, aber nur Zeilen mit `offset_s <= now - kickoff_at`; der Spielstand in der Kopfzeile folgt den freigegebenen Zeilen (aus `payload.score` der letzten sichtbaren Torzeile), nicht aus `SimulatedMatch`.
- Zentrale Hilfsfunktion `story_release.is_released(sm)` / `round_release_time(sm)`; **alle** betroffenen Views laufen über sie. Liste der Views vor Umsetzung im Ticket-Zwischenstand nennen (mindestens: Übersicht, Verein/letztes Spiel, Spielbericht `match_report_by_id`, Tabelle, Spielplan, Datencenter, Nachrichten).
- **Admin-Schalter** `Settings.story_release_enabled` (global) + Override je Runde: aus → sofortige Freigabe (Testbetrieb).
- Cache/ETag der Ticker-Antwort nur bis zum nächsten Zeilen-Offset gültig.

## 6. Ticker-Tab und Spieltagsseite

- `views.py`: `_generate_narrative_events` (Zeile ~4056) und der Ticker-Zusammenbau in `match_report_by_id` (Zeile ~4270 ff.) werden **ersetzt** durch das Lesen von `MatchEvent` (Reihenfolge `order`). Kein zweiter Erfinder mehr.
- Darstellung je Zeile: Uhr (`90+2'`), Team-Kürzel, Ebene (1 Hintergrund … 5 Tor) als Gewicht: Ebene 1–2 kleiner/grau, 3 normal, 4 hervorgehoben, 5 Tor-Kachel wie heute. Phasen- und Analysezeilen (`cls in ('phase','analysis')`) ohne Team-Marker, kursiv, als Zwischentitel.
- Filter: „Alle / Tore & Chancen (Ebene ≥ 3) / Nur Tore".
- Fallback, wenn keine `MatchStory` existiert oder `issues` `narrator_failed` enthält: die heutige Ereignisliste aus `report_data` (Tore, Karten, Wechsel) ohne erfundene Zeilen, mit Hinweis im Admin.
- **Momentum-Kurve** (`_build_match_momentum`, Zeile ~4653): Eingang wird `report_data['segment_log']` (Schüsse, Ecken, Zonen, Pressing je Block, plus Tore) statt Torimpulse allein; Regel „Kurve liegt an der Torminute auf der Schützenseite" bleibt. Altspiele ohne Segment-Log: heutiger Pfad.
- Spieltagsseite / Konferenz: Liste aller Spiele der Runde mit Live-Spielstand und letzter freigegebener Zeile je Spiel, Aktualisierung per Polling (≤ 10 s) bis zur Freigabe der Runde; danach statisch.
- 2D-Modus: **nicht Teil dieses Tickets**, wird im 2D-Chat auf `MatchEvent.payload.beats` + `offset_s` gesetzt.

## 7. Akzeptanzkriterien

1. Regressionsbeleg Engine: Summen/Tore/Noten vor und nach Segment-Log bitgleich (Ausgabe im Ticket-Abschluss).
2. Kernzahlen je Spiel exakt: Anzahl Tore, Schüsse, aufs Tor, Ecken, Karten in `MatchEvent` = `report_data['match_stats']` (Erzähler prüft das selbst; `issues` muss dazu leer sein).
3. Abspieldauer: 15,0 min für 90 Minuten, +5,0 min bei Verlängerung, +8 s je Elfmeter; letzter Offset+Dauer = `MatchStory.duration_s`.
4. Determinismus: zweimal `build_story_for` auf dasselbe Spiel → identische Zeilen (Text und Offsets).
5. Keine narrativen Tor-Präfixe kombiniert mit separatem „TOR!" (Regel liegt im Paket; Test über die drei Referenzspiele 114, 179, 6).
6. „Späte Führung" (ab 80') und „Schlussakkord" (85'+) sind Zustandsklassen (`payload.goal_ctx`, `payload.phase == 'schlussdrang'`), keine Zufallssätze.
7. Elfmeterschießen: jede Zeile trägt `payload.tally`; Anschlussformulierungen bei Fehlschuss-Serien vorhanden.
8. Sperre: vor Freigabe der Runde liefert keine der in Abschnitt 5 genannten Views ein Ergebnis; Ticker zeigt nur Zeilen ≤ verstrichene Zeit; Admin-Schalter hebt alles auf.
9. Backfill über alle vorhandenen Spiele läuft durch; Spiele mit Erzähler-Fehler bekommen `issues`, der Spieltag bleibt nutzbar.
10. `report_data` unverändert (Diff = Segment-Log-Feld, sonst nichts).

## 8. Engine-Datenfehler (separate Tickets, nicht hier fixen)

Vom Erzähler an den drei Referenzspielen gemeldet, jeweils im Text ersetzt:
- Ausgewechselter Spieler als Torschütze (114, 66' Gregoritsch, seit 62' draußen) — bekanntes Ticket.
- Torwart als Kopfballspieler nach Ecke in `sp_near_miss_events` (6, 18' Ramaj).
- Karte für ausgewechselten Spieler (6, 65' Honsak, seit 63' draußen).
- Elfmeterschießen: ausgewechselter Schütze (6, Pieringer), beide Torhüter in Runde 1/2, `home_players` und `home_bench` enthalten denselben Torwart (Kobel).
- Torwart-Vorlagen (`assister_id` = Torwart) bei Toren aus dem Spiel — vermutlich langer Ball; im Text zulässig, aber prüfen.
Der Backfill listet weitere Fälle. Bis zur Behebung ersetzt der Erzähler und meldet.

## 9. Replit-Prompt (Kurzfassung zum Abschicken)

> Implementiere Ticket „Live-Ticker Schritt 5" (Datei `TICKET_Live-Ticker_Schritt5.md` im Repo-Root). Reihenfolge: (1) Engine-Segment-Log mit Regressionsbeleg bitgleich, (2) Modelle `MatchStory`/`MatchEvent` + Migration, (3) `game/match_story/django_bridge.py` mit `build_story_for` und Hook in allen Simulationspfaden, (4) Backfill-Command, (5) Sperre je Runde mit Admin-Schalter und zentraler `is_released`, (6) Ticker-Tab + Spieltagsseite auf `MatchEvent`, Momentum aus Segment-Log. Das Paket `game/match_story/` ist Baseline v4 und wird nicht inhaltlich verändert (Ausnahme: `django_bridge.py` neu, `context.py` optional `Club.nickname`). Vor Beginn: Liste der Views nennen, die die Sperre betrifft, und Blocker melden. Am Ende: Regressionsausgabe, Backfill-Zusammenfassung, Screenshots Ticker-Tab und Konferenzseite.

**Replit-Empfehlung:** Power-Modus, Opus, Effort hoch; ein Ticket, weil Engine-Feld, Modelle, Hook, Sperre und Views zusammenhängen. Bei Kontextgrenze in dieser Reihenfolge splitten: (1–2) · (3–4) · (5–6).

## 10. Offene Punkte nach diesem Ticket

- 2D-Modus auf `MatchEvent.payload.beats` (2D-Chat).
- Pools ausbauen (Claude, kein Ticket).
- `Club.nickname` pflegen, sobald das Feld existiert.
- Momentum-Kalibrierung mit echten Segment-Logs.
- Mindestdauern des Planers an abgenommenen 2D-Szenen kalibrieren (`planner.MIN_S`).

---

## Anhang · Entscheidungslog Live-Ticker

| # | Entscheidung |
|---|---|
| E-T01 | Eine Ereignisliste, einmal erzählt direkt nach der Simulation, gespeichert, nie neu erzählt; Text, Bericht, Momentum, 2D lesen dieselbe Liste |
| E-T02 | Erzähleinheit ist die Sequenz (Angriff mit Beats); eine Sequenz = eine 2D-Szene |
| E-T03 | Taktik ist Gewichtung, kein Verbot; Verteilung nach Engine-Zahlen; Generator + Analysezeilen (Anpfiff, Plan, Halbzeit, Abpfiff), Analyse zitiert Zahlen |
| E-T04 | Kernzahlen exakt (Tore, Schüsse, aufs Tor, Ecken, Karten, Wechsel, Verletzungen, Elfmeter); Fouls nur mit Folge; Bindegewebe frei |
| E-T05 | 15 Minuten fest; Prioritätsplaner mit Mindestdauern, Aufbau elastisch; VL/Elfer proportional |
| E-T06 | Katalog A/B/C/D; Verkettung mit Deckel 3 Standards |
| E-T07 | Akteure nach Position + Note; Engine-Ereignisse nie gedeckelt; Schützen/Vorlagen nur aus der Engine |
| E-T08 | Sätze aus Pools (von Claude geschrieben); Radio-Stil, Präsens, keine Emojis |
| E-T09 | Tabelle `MatchEvent` mit Offset und Dauer je Zeile; `report_data` unangetastet |
| E-T10 | Echtzeit mit Sperre je Wettbewerb und Runde; Admin-Schalter |
| E-T11 | Segment-Log als Engine-Ausgabefeld, Regressionsbeleg bitgleich; Momentum daraus |
| E-T12 | Reihenfolge Export → Erzähler → Pools → Ping-Pong → ein Replit-Ticket → 2D |
| E-T13 | Narrative Schicht (Fassung 2–4): Phasen aus dem sichtbar Erzählten, Komposition Beats → 1–3 Zeilen, Ebenen 1–5, Zustand → Konsequenz, Tor-Klassifikation (10 Klassen), Streak als eigene Zeile, Schlussakkord, Phasenstufen mit Beweisstandard |
| E-T14 | Fassung 4 ist Baseline; keine weitere Textrunde vor Schritt 5; Narrative Memory und Segment-Log der Erzählung werden persistiert (`MatchStory.state`, `MatchStory.segments`) |
