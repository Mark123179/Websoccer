"""
batch_tactic_tests.py — Websoccer Taktik-Batch-Analyse
======================================================

Standalone, Django-frei.

Standardmodus:
    python batch_tactic_tests.py bayern_fixture.json 10000

Minutenmodus mit Bedingungen:
    python batch_tactic_tests.py bayern_fixture.json 10000 --minutes
"""
from __future__ import annotations

import argparse
import json
import time
from copy import deepcopy
from pathlib import Path
from typing import Callable

from run_match import simulate_match, simulate_match_minutes
from tactic_compiler import compile_tactic, select_active_condition_plan


def _avg(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _safe_stat(result: dict, key: str, default: float = 0.0) -> float:
    return result.get('match_stats', {}).get(key, default)


def _conditions(*items: tuple[int | str, str, str]) -> list[dict]:
    return [
        {'active': True, 'minute': str(minute).zfill(2), 'condition': condition, 'plan': plan}
        for minute, condition, plan in items
    ]


def _without_conditions(base: dict) -> dict:
    t = deepcopy(base)
    t['conditions'] = [{**c, 'active': False} for c in t.get('conditions', [])]
    t.pop('_active_plan', None)
    return t


def _with_conditions(base: dict, conditions: list[dict]) -> dict:
    t = deepcopy(base)
    t['conditions'] = conditions
    t.pop('_active_plan', None)
    return t


def build_tactic_variants(base: dict) -> list[tuple[str, dict]]:
    """Classic one-shot tactic variants for simulate_match()."""
    base_no_conditions = _without_conditions(base)
    return [
        ('baseline_default', base_no_conditions),
        ('home_ueber_links_vs_baseline', {**deepcopy(base_no_conditions), 'attack_focus': 'ueber_links'}),
        ('home_durch_mitte_vs_baseline', {**deepcopy(base_no_conditions), 'attack_focus': 'durch_mitte'}),
        ('home_fluegelspiel_vs_baseline', {**deepcopy(base_no_conditions), 'attack_focus': 'fluegelspiel'}),
        ('home_high_press_vs_baseline', {
            **deepcopy(base_no_conditions),
            'pressing': {'defense': 'hoch', 'midfield': 'hoch', 'attack': 'hoch'},
        }),
        ('home_low_press_vs_baseline', {
            **deepcopy(base_no_conditions),
            'pressing': {'defense': 'passiv', 'midfield': 'passiv', 'attack': 'passiv'},
        }),
        ('home_high_tempo_vs_baseline', {
            **deepcopy(base_no_conditions),
            'buildup': {**base_no_conditions.get('buildup', {}), 'tempo': 90},
        }),
        ('home_slow_tempo_vs_baseline', {
            **deepcopy(base_no_conditions),
            'buildup': {**base_no_conditions.get('buildup', {}), 'tempo': 10},
        }),
        ('home_schlussangriff_like_vs_baseline', {**deepcopy(base_no_conditions), '_active_plan': 'schlussangriff'}),
        ('home_zeitspiel_like_vs_baseline', {**deepcopy(base_no_conditions), '_active_plan': 'zeitspiel'}),
    ]


def build_condition_variants(base: dict) -> list[tuple[str, dict]]:
    """Minute-mode condition variants. Home tactic is tested vs away baseline."""
    base_no_conditions = _without_conditions(base)
    return [
        ('baseline_no_conditions', base_no_conditions),
        ('conditions_time_wasting_only', _with_conditions(
            base_no_conditions,
            _conditions((80, 'fuehrung', 'zeitspiel')),
        )),
        ('conditions_aggressive_when_behind', _with_conditions(
            base_no_conditions,
            _conditions((60, 'rueckstand', 'aggressiv_risiko')),
        )),
        ('conditions_late_final_push', _with_conditions(
            base_no_conditions,
            _conditions((85, 'rueckstand', 'schlussangriff')),
        )),
        ('conditions_full_matchplan', _with_conditions(
            base_no_conditions,
            # Reihenfolge ist Priorität: Später Schlussangriff muss vor normalem Rückstandsplan stehen.
            _conditions(
                (85, 'rueckstand', 'schlussangriff'),
                (60, 'rueckstand', 'aggressiv_risiko'),
                (80, 'fuehrung', 'zeitspiel'),
            ),
        )),
    ]


def run_batch(
    home_team: dict,
    away_team: dict,
    home_tactic: dict,
    away_tactic: dict,
    n: int,
    label: str,
    simulator: Callable[..., dict],
) -> dict:
    outcomes = {'home': 0, 'draw': 0, 'away': 0}
    totals = {
        'home_goals': [], 'away_goals': [], 'total_goals': [],
        'home_xg': [], 'away_xg': [],
        'home_shots': [], 'away_shots': [],
        'home_possession': [], 'away_possession': [],
        'home_fouls': [], 'away_fouls': [],
        'home_yellow': [], 'away_yellow': [],
        'home_red': [], 'away_red': [],
        'home_attacks_left': [], 'home_attacks_center': [], 'home_attacks_right': [],
        'home_pressing_ball_wins': [], 'home_pressing_bypassed': [],
        'home_fatigue_cost': [], 'home_tactic_coherence': [], 'home_tactic_complexity': [],
        'plan_activations': [], 'goals_after_plan_activation': [], 'conceded_after_plan_activation': [],
    }
    plan_counts: dict[str, int] = {}
    active_segment_counts: dict[str, int] = {}
    lead_after_80_count = 0
    leads_protected_after_80 = 0
    leads_lost_after_80 = 0
    trailed_at_60_count = 0
    comeback_wins = 0
    comeback_draws = 0

    for _ in range(n):
        r = simulator(home_team, away_team, home_tactic, away_tactic)
        hg, ag = r['home_goals'], r['away_goals']
        if hg > ag:
            outcomes['home'] += 1
        elif hg == ag:
            outcomes['draw'] += 1
        else:
            outcomes['away'] += 1

        totals['home_goals'].append(hg)
        totals['away_goals'].append(ag)
        totals['total_goals'].append(hg + ag)
        totals['home_xg'].append(r.get('home_xg', 0.0))
        totals['away_xg'].append(r.get('away_xg', 0.0))
        for key in (
            'home_shots', 'away_shots', 'home_possession', 'away_possession',
            'home_fouls', 'away_fouls', 'home_yellow', 'away_yellow', 'home_red', 'away_red',
            'home_attacks_left', 'home_attacks_center', 'home_attacks_right',
            'home_pressing_ball_wins', 'home_pressing_bypassed',
            'home_fatigue_cost', 'home_tactic_coherence', 'home_tactic_complexity',
        ):
            totals[key].append(_safe_stat(r, key, 0.0))

        debug = r.get('condition_debug', {}) or {}
        activations = debug.get('plan_activations', []) or r.get('plan_activations', []) or []
        totals['plan_activations'].append(len([a for a in activations if a.get('side') == 'home']))
        for a in activations:
            if a.get('side') == 'home':
                plan = a.get('plan', 'unknown')
                plan_counts[plan] = plan_counts.get(plan, 0) + 1
        for plan, count in (debug.get('plan_active_segments', {}) or {}).get('home', {}).items():
            active_segment_counts[plan] = active_segment_counts.get(plan, 0) + count

        totals['goals_after_plan_activation'].append(debug.get('goals_after_plan_activation', 0))
        totals['conceded_after_plan_activation'].append(debug.get('conceded_after_plan_activation', 0))
        if debug.get('lead_after_80'):
            lead_after_80_count += 1
        if debug.get('lead_protected_after_80'):
            leads_protected_after_80 += 1
        if debug.get('lead_lost_after_80'):
            leads_lost_after_80 += 1
        if debug.get('trailed_at_60'):
            trailed_at_60_count += 1
        if debug.get('comeback_win'):
            comeback_wins += 1
        if debug.get('comeback_draw'):
            comeback_draws += 1

    result = {
        'name': label,
        'n': n,
        'home_wins': outcomes['home'],
        'draws': outcomes['draw'],
        'away_wins': outcomes['away'],
        'home_win_pct': outcomes['home'] / n * 100,
        'draw_pct': outcomes['draw'] / n * 100,
        'away_win_pct': outcomes['away'] / n * 100,
        'avg_home_goals': _avg(totals['home_goals']),
        'avg_away_goals': _avg(totals['away_goals']),
        'avg_total_goals': _avg(totals['total_goals']),
        'avg_home_xg': _avg(totals['home_xg']),
        'avg_away_xg': _avg(totals['away_xg']),
        'avg_home_shots': _avg(totals['home_shots']),
        'avg_away_shots': _avg(totals['away_shots']),
        'avg_home_possession': _avg(totals['home_possession']),
        'avg_away_possession': _avg(totals['away_possession']),
        'avg_home_fouls': _avg(totals['home_fouls']),
        'avg_away_fouls': _avg(totals['away_fouls']),
        'avg_home_yellow': _avg(totals['home_yellow']),
        'avg_away_yellow': _avg(totals['away_yellow']),
        'avg_home_red': _avg(totals['home_red']),
        'avg_away_red': _avg(totals['away_red']),
        'avg_home_attacks_left': _avg(totals['home_attacks_left']),
        'avg_home_attacks_center': _avg(totals['home_attacks_center']),
        'avg_home_attacks_right': _avg(totals['home_attacks_right']),
        'avg_home_pressing_ball_wins': _avg(totals['home_pressing_ball_wins']),
        'avg_home_pressing_bypassed': _avg(totals['home_pressing_bypassed']),
        'avg_home_fatigue_cost': _avg(totals['home_fatigue_cost']),
        'avg_home_coherence': _avg(totals['home_tactic_coherence']),
        'avg_home_complexity': _avg(totals['home_tactic_complexity']),
        'avg_plan_activations': _avg(totals['plan_activations']),
        'plan_activation_counts': plan_counts,
        'plan_active_segment_counts': active_segment_counts,
        'avg_goals_after_plan_activation': _avg(totals['goals_after_plan_activation']),
        'avg_conceded_after_plan_activation': _avg(totals['conceded_after_plan_activation']),
        'lead_after_80_count': lead_after_80_count,
        'leads_protected_after_80': leads_protected_after_80,
        'leads_lost_after_80': leads_lost_after_80,
        'trailed_at_60_count': trailed_at_60_count,
        'comeback_wins': comeback_wins,
        'comeback_draws': comeback_draws,
    }
    return result


def print_result(r: dict) -> None:
    print(f'\n── {r["name"]} ({r["n"]:,} Sims) ─────────────────')
    print(f'  Heimsieg/Remis/Auswärts: {r["home_win_pct"]:5.1f}% / {r["draw_pct"]:5.1f}% / {r["away_win_pct"]:5.1f}%')
    print(f'  Ø Tore: {r["avg_total_goals"]:.2f}  (H {r["avg_home_goals"]:.2f} | A {r["avg_away_goals"]:.2f})')
    print(f'  Ø xG:   H {r["avg_home_xg"]:.3f} | A {r["avg_away_xg"]:.3f}')
    print(f'  Ø Besitz H/A: {r["avg_home_possession"]:.1f}% / {r["avg_away_possession"]:.1f}%')
    print(f'  Ø Schüsse H/A: {r["avg_home_shots"]:.1f} / {r["avg_away_shots"]:.1f}')
    print(f'  Ø Fouls/Gelb H: {r["avg_home_fouls"]:.1f} / {r["avg_home_yellow"]:.2f}')
    print(f'  Ø Plan-Aktivierungen H: {r["avg_plan_activations"]:.2f}  {r["plan_activation_counts"]}')
    if r['lead_after_80_count']:
        protected_pct = r['leads_protected_after_80'] / r['lead_after_80_count'] * 100
        lost_pct = r['leads_lost_after_80'] / r['lead_after_80_count'] * 100
        print(f'  Führung nach 80: {r["lead_after_80_count"]} | gehalten {protected_pct:.1f}% | verloren {lost_pct:.1f}%')
    if r['trailed_at_60_count']:
        win_pct = r['comeback_wins'] / r['trailed_at_60_count'] * 100
        draw_pct = r['comeback_draws'] / r['trailed_at_60_count'] * 100
        print(f'  Rückstand nach 60: {r["trailed_at_60_count"]} | Sieg {win_pct:.1f}% | Remis {draw_pct:.1f}%')


def test_conditions(tactic: dict) -> None:
    print('\n── Bedingungen / Matchpläne Quickcheck ─────────────────────────')
    scenarios = [
        (60, 0, 1, True, 0, 0, 'Min 60, Heim 0:1'),
        (80, 2, 1, True, 0, 0, 'Min 80, Heim 2:1'),
        (85, 0, 1, True, 0, 0, 'Min 85, Heim 0:1'),
    ]
    for minute, hg, ag, is_home, own_red, opp_red, desc in scenarios:
        plan = select_active_condition_plan(tactic, minute, hg, ag, is_home, own_red, opp_red)
        print(f'  {desc:<22} → {plan or "(kein Plan)"}')


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('fixture', nargs='?', default='bayern_fixture.json')
    parser.add_argument('n_sims', nargs='?', type=int, default=5000)
    parser.add_argument('--minutes', action='store_true', help='simulate_match_minutes() statt simulate_match() verwenden')
    parser.add_argument('--out', default=None, help='JSON-Ausgabedatei')
    args = parser.parse_args()

    fixture_path = Path(args.fixture)
    with fixture_path.open(encoding='utf-8') as f:
        team = json.load(f)
    base_tactic = team.get('tactic', {})
    baseline_away = _without_conditions(base_tactic)

    if args.minutes:
        simulator = simulate_match_minutes
        variants = build_condition_variants(base_tactic)
        out_path = Path(args.out or 'tactic_test_results_minutes.json')
        print(f'Minutenmodus aktiv: {args.n_sims:,} Sims pro Variante')
    else:
        simulator = simulate_match
        variants = build_tactic_variants(base_tactic)
        out_path = Path(args.out or 'tactic_test_results.json')
        print(f'Standardmodus aktiv: {args.n_sims:,} Sims pro Variante')

    print(f'Team: {team["team"]["name"]}')
    preview = compile_tactic(team, baseline_away)
    print(f'Compiler Preview: pressing={preview["pressing_index"]:.3f}, tempo={preview["tempo"]:.0f}, coherence={preview["coherence"]:.3f}')
    if args.minutes:
        test_conditions(variants[-1][1])

    results = []
    t0 = time.perf_counter()
    for label, tactic in variants:
        r = run_batch(team, team, tactic, baseline_away, args.n_sims, label, simulator)
        results.append(r)
        print_result(r)

    elapsed = time.perf_counter() - t0
    payload = {
        'mode': 'minutes' if args.minutes else 'standard',
        'fixture': str(fixture_path),
        'n_per_variant': args.n_sims,
        'variant_count': len(variants),
        'elapsed_seconds': round(elapsed, 3),
        'results': results,
    }
    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'\nFertig: {args.n_sims * len(variants):,} Simulationen in {elapsed:.2f}s')
    print(f'JSON gespeichert: {out_path}')


if __name__ == '__main__':
    main()
