# REPLIT-HANDOFF · Stadion-Editor V1

**Grundregel für den Agent:** Der Editor ist fertig entwickelt und getestet (Prototyp liegt als Datei bei). Deine Aufgabe ist **Verdrahtung in das bestehende Django-Projekt** — kein Neubau von Editor-Logik, kein Redesign, keine Änderungen an Shell/Navigation/Kalender außer den hier explizit genannten Stellen. Alle gelieferten Dateien werden unverändert übernommen, sofern nicht ausdrücklich „anpassen" vermerkt ist.

**Kontext:** Django 6.0.7, App `game`, Modelle `Stadium` (12 Kapazitätszähler je Tribüne×Platzart) und `StadiumExpansion` existieren und bleiben **unangetastet**. Der Editor ist eine neue, separate Seite; Ausbau läuft weiter über die bestehende Ausbau-Seite.

---

## TICKET 1 — Fundament: Modelle, Editor-Seite, Lese-API

**Voraussetzung:** ZIP `stadioneditor_integration.zip` von Claude (liegt dem Ticket bei) mit:
`static/stadium_editor/editor.js`, `editor.css`, `templates/stadium_editor/editor.html` (API-Fassung: lädt Geometrie/Design per fetch, kein Inline-Datenblock, kein Stadion-Dropdown — Manager sieht nur das eigene Stadion), `stadium_editor/geometry.py` (Pipeline-Modul).

**Aufgaben:**
1. Neue Django-App `stadium_editor` anlegen, in `INSTALLED_APPS` registrieren.
2. Zwei Modelle exakt nach beiliegender `models.py` übernehmen:
   - `StadiumGeometry` — OneToOne zu `game.Stadium`; Felder: `blocks` (JSONField), `bg` (JSONField), `meta` (JSONField), `created_at`, `updated_at`.
   - `StadiumDesign` — OneToOne zu `game.Stadium`; Felder: `base_data` (JSONField, RLE je Block), `pressings` (JSONField; Bildquellen als verkleinerte quantisierte dataURLs ≤ 480 px), `palette` (JSONField), `cache_image` (ImageField, upload_to='stadium_designs/'), `updated_at`.
   Migration erzeugen und ausführen.
3. Views + URLs:
   - `GET /stadion/editor/` — Editor-Seite; nur eingeloggter Manager des Vereins (bestehende Manager-Club-Beziehung nutzen); rendert Template mit `stadium_id` des eigenen Vereins.
   - `GET /api/stadion/<id>/geometrie/` — liefert `{meta, blocks, bg}` aus `StadiumGeometry`; 404 mit klarer Meldung, wenn keine Geometrie existiert.
   - `GET /api/stadion/<id>/design/` — liefert `{base_data, pressings, palette}` oder leeres Default-Design.
4. Navigation: **genau einen** Link „Stadion-Editor" auf der bestehenden Stadion-/Ausbau-Seite ergänzen (nicht in der Haupt-Shell).
5. Statische Dateien einbinden; `collectstatic` muss sauber durchlaufen.

**Nicht tun:** Keine Änderungen an `Stadium`/`StadiumExpansion`, keine Fixtures, keine Beispieldaten.

**Agent-Empfehlung:** Economy · Claude Sonnet · Effort mittel. Ein Run. Kein Grund für Power: reine Verdrahtung nach Vorlage.

---

## TICKET 2 — Speichern, Cache-Bild, Vereinsprofil, Gates

**Voraussetzung:** Ticket 1 deployed; Endpoint-Verträge aus beiliegender `api_contract.md`.

**Aufgaben:**
1. `POST /api/stadion/<id>/design/` — nimmt `{base_data, pressings, palette, cache_png}` (cache_png = dataURL des vom Client gerenderten 3D-PNG). Validierung: Manager des Vereins, Payload-Limit 4 MB, pressings-Bildquellen ≤ 480 px Kantenlänge (serverseitig prüfen, sonst 400). Speichert `StadiumDesign` + `cache_image` (dataURL dekodieren, als PNG unter `stadium_designs/<club_id>.png`).
2. Vereinsprofil: `cache_image` als Stadion-Bild im bestehenden Stadion-Block anzeigen (nur wenn vorhanden; sonst nichts ändern). Keine weiteren Layout-Eingriffe.
3. Gates: Editor-Seite nur für den Vereinsmanager (Ticket 1) **plus** Sperrflag: neues BooleanField `stadium_editor_banned` (default False) am Manager-Profil-Modell (kleinstmögliche Migration); gesperrte Manager erhalten 403 mit Hinweistext. Ausbau-Simulator-Panel im Template nur rendern, wenn `user.is_staff`.
4. CSRF für den POST korrekt verdrahten (Token ins Template, Header im mitgelieferten editor.js bereits vorgesehen — nur Template-Variable setzen).

**Agent-Empfehlung:** Economy · Claude Sonnet · Effort mittel. Ein Run.

---

## TICKET 3 — Import-Pipeline: alle Vereine

**Voraussetzung:** Beiliegend `management/commands/import_stadium_geometry.py` + `stadium_config.json` (Konfig-Overrides) von Claude — unverändert übernehmen.

**Aufgaben:**
1. Command einhängen: `python manage.py import_stadium_geometry --all` bzw. `--club <id>` / `--way-id <osm_id>`.
   Ablauf pro Verein (im Command fertig implementiert): `map_lat/map_lng` → OSM-Bbox-Abfrage → `leisure=stadium`-Umriss wählen → Blöcke + Blaupause generieren → Platzarten aus den 12 `Stadium`-Zählern verteilen → `StadiumGeometry` speichern. Ränge: Heuristik nach Kapazität (< 30.000 → 2 Ränge, sonst 3), überschreibbar in `stadium_config.json`.
2. Warnungs-Report: Vereine ohne brauchbaren OSM-Umriss werden mit Club-ID und Grund gelistet (kein Fallback-Stadion erzeugen — Abbruch für diesen Verein).
3. Hook in den Club-Import: in `game/club_import/club_reconcile.py` nach der Stadium-Erzeugung den Geometrie-Import für den neuen Verein aufrufen; Fehlschlag als Warnung in den bestehenden Review-Report, Import nicht abbrechen.
4. Command für alle Bestandsvereine ausführen; Report ausgeben.

**Nicht tun:** Keine Laufzeit-Fallbacks im Editor („kein Stadion ohne Geometrie live schalten" ist Redaktionsprozess, nicht Code).

**Agent-Empfehlung:** Economy · Claude Sonnet · Effort mittel-hoch. Zwei Stages: (a) Command + Hook verdrahten und mit 1 Verein testen, (b) `--all`-Lauf + Report. Nicht in einem Rutsch mit Ticket 4 mischen.

---

## TICKET 4 — Ausbau-Hook & Moderation

**Voraussetzung:** Beiliegend `stadium_editor/expand.py` (Python-Port der Wachstumsmechanik: Reihen an den äußersten sortengleichen Rang der Tribüne bis max. 40 Reihen, danach neuer Rang; neue Sitze = Farbindex 0/Beton; Kapazitätsdeckel 120.000) — unverändert übernehmen, Tests liegen bei.

**Aufgaben:**
1. Hook: Beim Anwenden einer `StadiumExpansion` (bestehender Codepfad, der die 12 Zähler erhöht) zusätzlich `expand.apply(stadium, stand, seat_type, amount)` auf `StadiumGeometry` ausführen. Bestehende Ausbau-Logik/Preise unangetastet.
2. Moderation:
   - Report-Button an der Stadionansicht im Vereinsprofil → `POST /api/stadion/<id>/melden/` → einfacher `DesignReport`-Eintrag (Model beiliegend).
   - Django-Admin: `StadiumDesign` registrieren mit Admin-Action „Design zurücksetzen" (base_data leeren, pressings leeren, cache_image löschen) und Link zum Setzen von `stadium_editor_banned` am Manager.
3. Regressionscheck: Ausbau → Editor öffnen → neue graue Reihen/Ränge sichtbar, bestehendes Design unverändert.

**Agent-Empfehlung:** Economy · Claude Sonnet · Effort mittel. Ein Run, nach Ticket 3.

---

## Reihenfolge & Dispatch

1 → 2 → 3 → 4, jeweils als **eigener Run** (kein Kombinieren — Ticket 3 und 4 tragen die meiste eigene Logik in Claude-gelieferten Dateien, der Agent soll nur einhängen). Vor jedem Dispatch liefert Claude das jeweilige Datei-ZIP; ohne ZIP nicht starten.
