# Ticket: Kalibrierung v1.1 — roofMeshPrefixes, _Base_Texture (klein)

Ziel: Der Dachschalter darf nur Dachmeshes betreffen. Bei Stadien, deren Oberrang höher liegt als die Dachkante (Allianz Arena: Oberrang bis 39,8 m, Dach ab 36,1 m), trennt eine Höhenschwelle allein nicht. Gladbach bleibt pixelgleich.

1. Vertrag (`docs/stadium/model-manifest.md`): neues Pflichtfeld `calibration.roofMeshPrefixes`
   – Liste von Namenspräfixen; leer = bisherige Höhenregel für alle Nicht-Crowd-Meshes.
   – Dach = Mesh-Name beginnt mit einem Präfix (falls Liste nicht leer) UND alle drei Vertices ≥ roofMinHeight; Crowd nie.
2. `unity_stadium_scene.js`: Klassifikation wie in `werkzeuge/render/static/stadium_editor/unity_stadium_scene.roofMeshPrefixes.js` (eine Bedingung `roofCandidate` vor `isRoof`).
3. `unity_calibration.js` + `model_registry.validate_model_manifest`: Feld prüfen (Liste nichtleerer Strings, darf leer sein).
4. `models/908.json`: `"roofMeshPrefixes": []` ergänzen; assetVersion unverändert lassen (Assets bleiben gültig). Regression: fünf Gladbach-Ansichten Pixel-Diff 0.
5. `scripts/export_stadium_model.py`: Texturschlüssel `"_Base_Texture"` ergänzen:
   `if key in ("baseColorTexture", "_BaseMap", "_MainTex", "_Base_Texture") and value.m_Texture:`
   Nachweis: Gladbach-Export bleibt byte-identisch (dort `_BaseMap`); Bayern-Export ergibt geometrySha256 07869ec9ddd1c5fe270d350a30bf5803eb98ac3a634b43819d501c5f97447eda.
6. Tests: JS (Präfixregel: Tribünenmesh über Schwelle bleibt Körper; leere Liste = altes Verhalten), Python-Validator (fehlendes/ungültiges Feld → ValueError mit Feldname).
7. Optional, nur wenn Mark zustimmt (reine Daten): `models/908.json` standAxes auf +x OST, −x WEST, +z NORD, −z SUED.

Nicht im Umfang: neue Vereine, DB, Kamera, Kapazität, Designs.
Abgabe: geänderte Dateien, Testausgabe, Gladbach-Fünfer-Serie nach dem Umbau.
