# Stadionpaket · Allianz Arena · FC Bayern München (FMI 915) — Fassung 2 (nach Replit-Prüfung)

Stand 11.10.2026 · Quelle: BassyBoy FM26 3D Stadium Megapack v3.0 (`allianzarena.bundle`, SHA-256 `52c0d091…c0b3`), Freigabe durch Mark für den gesamten Megapack.
Erzeugt mit der lokalen Fassung von `scripts/export_stadium_model.py` (Stand Registry-Ticket 11.10.2026).

## Was sich gegenüber Fassung 1 geändert hat (Antwort auf die Prüfung)
1. **Dach-aus trifft keine Tribünenteile mehr.** Kalibrierung v1.1 mit neuem Feld `roofMeshPrefixes: ["center3_", "cover_"]` und `roofMinHeight: 35`. Nachweis (Dreieckszählung über das Binary): Höhenregel ≥36 allein = **3.698 Tribünen-Dreiecke** aus front3/back3/left3/right3 als Dach; mit Präfixregel = **0**, center3 vollständig Dach (71.220 Dreiecke, 0 Restkörper). Das Feld braucht die kleine Vertragsänderung aus `TICKET-kalibrierung-v1.1.md` (Renderer-Zeile, Validator, Doku, Gladbach-Manifest `"roofMeshPrefixes": []`). Rückfall ohne Ticket: `roofMinHeight` im Manifest auf 36 setzen → exakt der geprüfte Stand; assetVersion und Assets bleiben gültig.
2. **Harness = Editorpfad.** `werkzeuge/render/presentation_915.json` trägt jetzt `designColors` wie `unity_presentation()` sie liefert (Standard-Design → je Tribüne `#f4f6f8`); der frühere `scene`-Update-Schritt ist entfernt. Bilder neu gerendert.
3. **Reproduktion.** Die Originalquellen (Bundle 271 MB, Sitz-JSON 30 MB, Lightmaps, Lightprobes) liegen bei Mark unter `C:\Users\markp\Downloads\stadion_pilot\` (Kopie aus dem Megapack) und gehören laut Vertrag in einen eigenen, ignorierten Paketordner in Replit, z. B. `attached_assets/stadion_915/` — bitte dorthin hochladen. SHA-256: Bundle `52c0d0916cc4e780bd9d3d4cc60363b134195125ce95cd7a34a87b2c4a48c0b3`, `allianzarena.json` `dc3f90dd…cbcb8b`, `_lightmaps` `d9f7bd74…e8d49`, `_lightprobes` `4a2e5ab0…ddeb9` (vollständig in `models/915.json` → sourceEvidence). Der Export ist damit unabhängig wiederholbar; erwartete geometrySha256 `07869ec9…7eda`, assetVersion `7bc8ec0fcf20c166`.
4. **2D-Editor-Bild.** Entsteht nur aus Geometrie + Login (das Paket ändert daran nichts); es wird bei der Registrierung in Replit bzw. beim Live-Check mit aufgenommen. Die fünf Ansichten sind damit: 2D (Replit/live), 3D, Ticker Tag mit Dach, Ticker Tag ohne Dach, Nacht mit Flutlicht (hier).

## Inhalt
- `models/915.json` – Manifest (Registry-Datei), assetVersion **7bc8ec0fcf20c166**, geometrySha256 `07869ec9…7eda`, Validator grün
- `stadium-models/915/7bc8ec0fcf20c166/` – `geometry.bin` (34,1 MB) + 109 Texturen (WebP ≤ 1024 px), 110 Hashes geprüft
- `kalibrierung.json` – calibration v1.1 (Begründung unten)
- `bilder/` – Vorab-Ansichten (lokal, Replits `unity_stadium_scene.js` mit der roofMeshPrefixes-Zeile, Software-WebGL)
- `werkzeuge/` – Exportskript (lokale Fassung), Validator-Kopie, Render-Harness, `presentation_915.json`, Experimentalkopie `unity_stadium_scene.roofMeshPrefixes.js`
- `TICKET-kalibrierung-v1.1.md` – Replit-Auftrag (klein)
- `PRUEFSUMMEN.sha256`

Kennzahlen: 418 Meshes, 109 Texturen, 65 quellgeprüfte Flutlichter → 12 Laufzeitleuchten, 72.410 Sitze, 137 Lightmaps, 140 Lightprobes.

## Einspielen (Reihenfolge)
0. Replit: `TICKET-kalibrierung-v1.1.md` umsetzen (oder Rückfall roofMinHeight 36, s. o.).
1. Assets auf Hetzner: `scp -r stadium-models/915 root@49.13.5.151:/var/www/assets/stadium-models/` (Zielordner = der, der im Container `/app/assets` ist).
2. `models/915.json` per Datei-Upload nach `stadium_editor/blueprints/v2/models/915.json` in Replit, Quellen nach `attached_assets/stadion_915/`, committen, pushen.
3. `/push` (Worker-Neustart inklusive), dann
   `docker exec websoccer-web-1 python manage.py check_stadium_model --fmi 915 --assets` → erwartet `Manifest OK: 915 · Allianz Arena · 7bc8ec0fcf20c166`, `Assets OK: 110 Dateien`.
4. Abnahme der fünf Ansichten live (`/stadion/2/live/`, Editor als Bayern-Manager/Admin).

Kein DB-Import, keine Änderung an Kapazität, Manager, Finanzen, Geometrie oder Design.

## Kalibrierung v1.1 (gegen das Modell geprüft)
| Feld | Wert | Begründung |
|---|---|---|
| roofMinHeight | 35 | Alle Dachteile (center3_*, cover_1) liegen ≥ 35,1 m; mit der Präfixregel trennt die Höhe nur noch innerhalb von center3/cover. |
| roofMeshPrefixes | center3_, cover_ | Dach = Schale, Membran, Träger, Leuchtenbänder, Decke; Tribünenstufen (back3/front3/left3/right3 bis 39,5 m) sind nie Dach. |
| skipMeshPrefixes | Couvercle_, notdemo_, center3_probe_21. | Tifo-Banner (131.880 Dreiecke, Event-Inhalt); Vinyl- und Stahlrahmen-Schale liegen deckungsgleich auf `cover_1` (Abstand 0,000 m) → Z-Fighting; behalten wird `cover_1`. |
| crowdPrefix / pitchPrefix | C_ / st081_pitch_ | im Bundle verifiziert (27 Crowd-Meshes, st081_pitch_0/1). |
| tickerRotationY | −90 | Kamera auf der Bankseite: BENCH_BAYERN_HOME/AWAY bei x ≈ −42 (front1); Längsachse z. Gleiche Konvention wie Gladbach (Bänke ebenfalls bei x ≈ −40). |
| tickerFrontCut | (1,0,0) / 32 | Rasen x ±34,1 (identisches Rasenmesh wie Gladbach); Schnitt blendet nur die Nahtribüne aus, Rasen per pitchPrefix ausgenommen. |
| standAxes | +x OST, −x WEST, +z NORD, −z SUED | Ortsadapter `editorPointToDortmund` (Szene +x → Unity +z, Szene +y → Unity −x) + Prod-Szene (homeStand SUED bei Szene −x, WEST bei +y): −z = SUED (Modell `C_right1_C2-UltraHome`), +z = NORD (`left3_*Away`), −x = WEST (Bänke), +x = OST. |
| orbitDefault | 0,95 / 0,65 / 360 | wie Gladbach, Distanz wegen Modellgröße (x ±114, z ±130 m) von 310 auf 360. |

## Weitere Befunde
- Exportskript: Texturschlüssel `_Base_Texture` nötig (Shader-Graph-Rasen `0002-Botafogo`), sonst weißer Rasen — Teil des Tickets.
- 34 MB Geometrie (Sitze einzeln modelliert, Crowd 15,5 MB); Tifo 3,8 MB liegt vertragsgemäß im Binary, wird zur Laufzeit übersprungen.
- Ticker: Dach liegt oberhalb des Bildrands, „ohne Dach" sichtbar nur im 3D-Editor.
- Nacht dunkler als Gladbach (Quellintensität 25–40 statt 70); Kandidat `floodlightGain` für eine spätere Kalibrierung.
- Gladbach-Hinweis (nicht Teil dieses Pakets, Marks Entscheidung): standAxes in `models/908.json` nach demselben Adapter um 90° verdreht; korrekt +x OST, −x WEST, +z NORD, −z SUED.
- Material-/Texturnamen folgen Konami-PES-Konventionen; Nutzung laut Marks Freigabe.

## Reproduktion
```sh
python3 -I werkzeuge/export_stadium_model.py --bundle attached_assets/stadion_915/allianzarena.bundle \
  --seats attached_assets/stadion_915/allianzarena.json --fmi 915 --name "Allianz Arena" \
  --out export --calibration kalibrierung.json
```
Bilder: `werkzeuge/render/harness.html` + `shoot.py` neben Replits `static/stadium_editor/` (unity_stadium_scene.js, unity_calibration.js, study_camera.js, dortmund_surroundings.js, stage/) und `presentation_915.json`; Chromium mit `--use-gl=angle --use-angle=swiftshader`. Maße wie Replit: 3D 1000×560, Ticker 1000×500.
