# Prompt für Replit — KPI-Leiste korrigieren (wörtlich einfügen)

Die KPI-Leiste im Managerprofil weicht von der abgenommenen Vorlage ab. **Du triffst keine Designentscheidungen** — du übernimmst Werte.

Vorgehen, in dieser Reihenfolge:

1. Öffne `replit_ready/kpi_leiste.html`. Das ist der **Soll-Zustand**, selbständig lauffähig. Vergleiche sie Seite an Seite mit dem aktuellen Build bei gleicher Breite.
2. Lies `replit_ready/KPI_LEISTE_SPEC.md`. Dort stehen alle Maße verbindlich (Grid-Spalten, `gap: 7px`, `padding: 14px 12px`, Label `900 9px` + 0.5 px Tracking mit 11 px Icon, Großwert `900 21px`, Balkenhöhe 5 px, Farben je Zelle).
3. **Ersetze deine KPI-Leiste komplett** durch Markup + CSS aus `kpi_leiste.html` — nicht nachjustieren, nicht mischen. Nur zwei Anpassungen sind erlaubt:
   - Base64-Bilder → `{% static %}`-Pfade,
   - statische Zahlen → Werte aus dem Django-Context.
   Struktur, Klassen, Reihenfolge, Abstände, Farben, Schriftgrößen und Copy bleiben **unverändert**.
4. Führe `replit_ready/kpi_selfcheck.js` in der Browser-Konsole der fertigen Seite aus. Das Skript vermisst die gerenderte Leiste und gibt pro Eigenschaft PASS/FAIL aus.
5. Beheben, bis **kein FAIL** mehr erscheint. Erst dann melden — mit der PASS-Tabelle als Nachweis.

Konkret falsch im letzten Build (Abschnitt 4 der Spec):
- Zeile zu hoch, Werte nicht auf gleicher Höhe → `gap`/`padding` weichen ab, Label-Icons fehlen.
- XP- und Siegquoten-Balken fehlen bei Nullwerten (müssen immer rendern).
- Subzeilen fehlen („seit …", „Platz x von y", „Konto in gutem Stand").
- Trophäen: Wert muss zentriert sein, „Alle ansehen" per `margin-top: auto` am unteren Rand.
- Schriftgrößen/Tracking gerundet (10 px statt 9 px, 1 px statt 0.5 px).

Wenn ein Wert im Context fehlt: **Platzhalter mit korrekter Struktur rendern** (z. B. `0` + Subzeile), nicht das Element weglassen.
