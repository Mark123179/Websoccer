# ZUSTÄNDE — verbindliche Zustandsliste

Jeder Zustand muss im Build erzeugbar und geprüft sein. Darstellung wie im jeweiligen `replit_ready`-Baustein bzw. im klickbaren `standalone/Managerprofil_standalone.html`.

## 1. Trainer-Titel (4 Zustände) — `replit_ready/trainer_titel.html`

| Zustand | Darstellung |
|---|---|
| **aktiv** | Rahmen `rgba(44,231,255,.55)`, Füllung `rgba(34,230,255,.16)`, Glow `0 0 14px rgba(34,230,255,.18)`, Text `#22e6ff`, Subzeile „x % der Manager · aktiv" |
| **freigeschaltet** (durch Auszeichnung) | Rahmen `rgba(255,209,102,.55)`, Füllung `rgba(255,209,102,.1)`, Text `#ffd166`, Subzeile nennt die Auszeichnung: „durch Badge „Pokalheld"" |
| **wählbar** | Rahmen `var(--line)`, Füllung `rgba(255,255,255,.03)`, Text `var(--muted)`, Hover hebt Rahmen auf `--line-strong` |
| **gesperrt** | Rahmen **1 px gestrichelt** `rgba(244,251,255,.18)`, `opacity: .65`, `cursor: not-allowed`, 9-px-Schloss-Icon vor dem Namen |

Regel: genau **ein** Titel ist aktiv. Jede Kachel zeigt die Verbreitungsquote „x % der Manager".

## 2. Nicht aufgestellt — 3 Stufen (KPI-Zelle 6)

| Stufe | Auslöser | Anzeige | Wirkung |
|---|---|---|---|
| **1** | jedes verpasste Spiel | Saison-Zähler weiß, Folge-Zähler gold, z. B. `2/5 SAISON · 1/3 FOLGE` | Stärkemalus + Nachricht an den Manager |
| **2** | 2 in Folge **oder** 3 in der Saison | Folge-/Saison-Zähler am Limit, Label-Icon gold | **Transfersperre** bis zur nächsten eigenen Aufstellung + Nachricht („letzte Warnung") |
| **3** | 3 in Folge **oder** 5 in der Saison | Zähler voll, Werte rot | **Verein verloren** + automatischer Timeline-Eintrag „Entlassung" + Nachricht |

Zusatzregeln: Urlaubsmodus pausiert **beide** Zähler · Saisonwechsel setzt beide auf 0 · Stufentexte im `title`-Tooltip des i-Icons.

## 3. Transfersperre (KPI-Zelle 7)

| Zustand | Darstellung |
|---|---|
| **keine** | Häkchen-Icon + „Keine" in `#30f29c`, Subzeile „Konto in gutem Stand" |
| **aktiv** | Schloss-Icon + „Gesperrt" in `#ff5570`, Subzeile mit Grund und Ende („bis eigene Aufstellung") |

## 4. Karte — 1 / 5 / 12 Stationen

- **1 Station:** Ausschnitt auf Land/Mitteleuropa, Marker zentriert, kein Rand-Anschnitt.
- **5 Stationen:** enger Ausschnitt über die Bounding-Box aller Marker (Referenzfall im PNG).
- **12 Stationen:** Ausschnitt zoomt heraus; Marker behalten 34 px, Beschriftungen dürfen sich **nicht** überlappen — bei Kollision wird die Beschriftung des inaktiven Markers ausgeblendet, der Marker bleibt.
- Immer: aktuelle Station grün mit Puls-Ring, alle übrigen weiß umrandet.

## 5. Timeline — leer / 3 Events / 40 Events

- **leer:** Achse, HEUTE-Marker, Legende und Filter-Chips bleiben sichtbar; zentrierter Hinweistext, keine leere Fläche.
- **3 Events:** Track-Breite minimal, aber Karten überlappen nicht; Abstände bleiben zeitproportional.
- **40 Events:** Track wächst, horizontal scrollbar; Karten weiterhin abwechselnd über/unter der Achse. Bei Kollision auf derselben Seite wird der zweite Eintrag auf die andere Seite gesetzt; ist auch dort belegt, rückt er um Kartenhöhe + 8 px nach außen.

## 6. Mannschaftsfoto — 18 / 40 / 60 Spieler

- **18:** 2 Reihen (sitzend + stehend), maximale Figurengröße.
- **40:** 3–4 Reihen, Figuren kleiner, Reihen nach hinten gestaffelt.
- **60 (Maximum):** 5 Reihen; ab Reihe 4 zusätzliche Höhenstaffelung, damit nichts gequetscht wirkt. Kein Spieler wird links/rechts angeschnitten.
- Immer: Torhüter (HP = TW) generisch im TW-Look, außen platziert; Bande trägt Wappen + Vereinsname; Gras-Streifen vor der Bande.

## 7. Urlaubsmodus (Tab Sicherheit & Einstellungen)

| Zustand | Darstellung |
|---|---|
| **aus** | Schalter aus, Hinweis auf Kontingent („14 Tage am Stück, 1× pro Saison — oder 2 Blöcke à 5 Tage") |
| **aktiv** | Schalter an, gewählter Zeitraum als Chip, Kalender markiert die Tage, Hinweis „Zähler pausiert" |
| **verbraucht** | Schalter deaktiviert, Hinweis „Kontingent für Saison #n aufgebraucht"; Vergangenheitsdaten nicht wählbar (nicht rückwirkend) |

## 8. Lange Texte & Überlauf

- Vereinsnamen, Titel und Beschreibungen dürfen die Kachel **nicht** sprengen: Micro-Labels und Werte `white-space: nowrap` + `text-overflow: ellipsis`, Beschreibungstexte umbrechen mit `text-wrap: pretty` auf max. 2 Zeilen.
- Testfälle: „Borussia Mönchengladbach", „1. FSV Mainz 05", „Underdog-Flüsterer", „DFL-Supercup-Finale 2026 gegen …".

## 9. Neuer Manager — alles leer / 0-Werte

- Alle Kacheln bleiben in **voller Struktur** stehen: Label → Wert `0` → Subzeile.
- Balken (XP, Siegquote) rendern mit 0 % Füllung, Spurfarbe sichtbar.
- Trophäen: Wert `0`, keine Logos, „Alle ansehen" bleibt (Vitrine zeigt leeren Schrank mit Hinweis).
- Timeline: nur „Amtsantritt" bzw. Hinweistext; Karte: eine Station.
- Rekordbuch: alle Zeilen mit „—" statt Zahl, keine Zeile entfernen.
