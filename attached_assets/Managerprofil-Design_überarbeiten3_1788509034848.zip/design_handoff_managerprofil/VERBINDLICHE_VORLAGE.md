# VERBINDLICHE VORLAGE — Managerprofil

**Dieser Screen ist die verbindliche Vorlage. Abweichungen bei Abständen, Größen, Farben, Reihenfolge und Zuständen sind Fehler.**
Nicht frei interpretieren, nichts „unverändert lassen, weil es schon da ist".

## Dateien und ihre Rolle

| Datei | Rolle |
|---|---|
| `design_reference/screen_2a_profil.png` | **Verbindliches Gesamtlayout** Profil-Tab (1440 × 1468) |
| `design_reference/screen_2b_mannschaftsfotos.png` | Verbindliches Layout Tab „Mannschaftsfotos" (1440 × 914) |
| `design_reference/screen_1d_einstellungen.png` | Verbindliches Layout Tab „Sicherheit & Einstellungen" (1440 × 953) |
| `standalone/Managerprofil_standalone.html` | **Klickbarer Soll-Zustand**, alle Assets eingebettet — Maßstab für Interaktion und Zustände |
| `replit_ready/*.html` | **Exakte Maße, Farben und CSS** je Baustein — wörtlich kopieren (siehe `replit_ready/README.md`) |
| `replit_ready/KPI_LEISTE_SPEC.md` + `kpi_selfcheck.js` | Maßvorgabe + messende Selbstprüfung für die KPI-Leiste |
| `GESPRAECHSVERLAUF.md` | Warum etwas so ist (Entscheidungsprotokoll) |
| `PROMPT_REPLIT.md` | Aufgabenliste + Abnahme-Checkliste |

Bei Widerspruch gilt: **`replit_ready/*.html` (Werte) > PNG (Layout) > Prosa.**

## Zielgröße und Skalierung

- Referenz: **1440 × 900 bei 100 % Browser-Zoom**, aufgenommen **vor** der Game-Shell-Skalierung.
- Der Content-Artboard des Managerprofils ist **1440 px breit** (Innenmaß 1352 px bei 44 px seitlichem Padding). Alle `replit_ready`-Bausteine sind auf dieses Innenmaß gerechnet.
- **Verhalten auf breiteren/schmaleren Ansichten: die Seite skaliert als Ganzes (Zoom-Verhalten).** Höhen, Schriftgrößen, Paddings und Spaltenverhältnisse bleiben unverändert; es wird **nicht** umgebrochen und **nicht** einzeln gestreckt.
- **Die Game-Shell ist zu berücksichtigen, aber nicht Teil dieser Vorlage**: links **232 px Sidebar**, oben **56 px Kalender-Header** sind Bestand. Der Content-Artboard beginnt rechts der Sidebar und unter dem Header. Sidebar und Header **nicht anfassen**.
  → Rechnung: benötigte Shell-Breite = `232 + 1440 = 1672 px`. Ist die verfügbare Content-Breite kleiner, wird **skaliert**, nicht umgebaut.

## Geltungsbereich

Die komplette Seite `/manager/profil` mit ihren drei Tabs: **Profil**, **Mannschaftsfotos**, **Sicherheit & Einstellungen**.

## Muss exakt übereinstimmen

- Spaltenbreiten, Kachelhöhen und Reihenfolge der Kacheln
- Innen- und Außenabstände (Kartenpadding 18 px bzw. wie im Baustein angegeben, Kachelabstand 16 px, Seitenpadding 44 px)
- Schriftgrößen und -gewichte (keine Rundung: 9 px bleibt 9 px, 0,5 px Tracking bleibt 0,5 px)
- Farben und Zustandsdarstellungen, inklusive Glow, Border-Opazität und Balkenhöhen
- Anzahl und Reihenfolge der Elemente; kein Element weglassen, wenn ein Wert fehlt (dann 0-Wert mit vollständiger Struktur rendern)
- Copy exakt wie in der Vorlage, deutsch, Micro-Labels in Großbuchstaben

## Farbcode (systemweit, nicht pro Kachel neu entscheiden)

| Farbe | Bedeutung |
|---|---|
| Gold `#ffd166` | Titel · Historie · Saison-Score · Warnstufe |
| Cyan `#22e6ff` | Verein · Liga · Level · neutrale Kennzahl · Links |
| Grün `#30f29c` | Jugend · aktuelles Amt · positive Werte · „keine Sperre" |
| Rot `#ff5570` | Finale verloren · Entlassung · Sperre · Niederlagen |

## Dynamisches Verhalten

- **Karte** zeigt alle bisherigen Stationen mit möglichst engem Ausschnitt; keine Station darf angeschnitten sein. Bei nur einer deutschen Station wird Deutschland/Mitteleuropa fokussiert. Aktuelle Station grün mit Puls-Ring, Marker-Klick wechselt die Statistik mit.
- **Statistik und Karte enden immer auf derselben Höhe.** **Rekordbuch und Trainer-Titel enden ebenfalls auf derselben Höhe.**
- **Karriere-Timeline**: Abstände sind **zeitproportional** (`left = (datum − start) / (ende − start) × trackWidth`), Karten abwechselnd über/unter der Achse, HEUTE-Marker immer sichtbar, Saison-Label-Klick zoomt auf die Saison. Bei 0 Events bleiben Achse, HEUTE-Marker und Legende stehen.
- **Vereins-Umschalter**: Wahl in der Leiste, im Dropdown oder auf der Karte aktualisiert KPI-Leiste **und** Statistik-Karte; „ALLE" aggregiert die Gesamtkarriere.
- **Nicht aufgestellt**: Zähler laufen nur außerhalb des Urlaubsmodus; Saisonwechsel setzt beide auf 0; Stufe 3 erzeugt automatisch den Timeline-Eintrag „Entlassung".
- **Mannschaftsfoto**: 18–60 Spieler, Reihenanzahl und Skalierung passen sich der Kadergröße an; Torhüter (HP = TW) generisch, außen platziert. Renders werden **einmal pro Saison** erzeugt und gecacht.
- **Trophäen-Vitrine**: genau 3 Trophäen pro Regalreihe, danach seitenweises Blättern; Hover-Tooltip mit Wettbewerbslogo, Verein(en) + Saison und Anzahl.

## Daten

- **Alle Zahlen, Namen, Vereine und Datumsangaben in der Vorlage sind Beispielwerte.** Darstellung, Farben und Struktur müssen übereinstimmen; die Werte kommen aus der Datenbank.
- **Ausnahme — verbindliche Listen:** die Trainer-Titel und die Auszeichnungen in `replit_ready/trainer_titel.html` und `auszeichnungen.html` sind die vollständige aktuelle Liste inklusive Freischaltlogik (Auszeichnung → Titel).
- **Saison-Notation überall `#1`, `#2`, `#3` …** — niemals „2023/24".
- Zahlenformat deutsch: Tausenderpunkt, Dezimalkomma, `€` nachgestellt.

## Nicht ändern

- Sidebar (232 px) und Kalender-Header (56 px) der Game-Shell
- Login-Flow, KI-Kloppo-Verhalten
- Bestehende Daten- und Interaktionslogik außerhalb des Managerprofils
- Design-Tokens (`--panel`, `--line`, `--faint`, `--muted`, Cyan/Grün/Gold/Rot, Inter, Radius 8 px)

## Zuordnung HTML-Baustein → Django

| Baustein (`replit_ready/`) | Bereich der Seite | Ziel |
|---|---|---|
| `kpi_leiste.html` | Kennzahlenleiste rechts im Kopf | `manager_profile.html` Block Kopf · CSS → `manager-profile.css` |
| `karriere_timeline.html` | Timeline über Stadionfoto | Template + `extra_js` (Positionsberechnung) |
| `karte_trainerstationen.html` | Europa-Karte links | Template · Marker aus `CITY_MAP_PCT` in `views.py` |
| `statistik.html` | Statistik-Karte rechts neben der Karte | Template · Aggregate aus `views.py` |
| `trainer_titel.html` | Reihe unten links (breit) | Template · Titel/Freischaltungen aus DB |
| `auszeichnungen.html` | Kachel oben links | Template · Fortschritt aus DB |
| `rekordbuch.html` | Reihe unten rechts (schmal) | Template · Aggregate aus `views.py` |
| `timeline_trophies.html` | Timeline + Trophäen-Vitrine (Popup) | Template + `extra_js` |

## Ablauf für die Umsetzung (verbindlich)

1. Vorlage in einzelne prüfbare Anforderungen zerlegen.
2. Bestehende Daten- und Interaktionslogik erfassen.
3. **Den vollständigen Bereich** umsetzen — nicht nur den zuletzt gemeldeten Fehler.
4. Ergebnis und Vorlage in **derselben Größe** gegenüberstellen.
5. Geometrie **messen**: Kachelgrenzen, Spaltenbreiten, Höhen, Abstände, Schriftgrößen (`kpi_selfcheck.js` als Muster).
6. Alle sichtbaren Zustände prüfen (siehe `ZUSTAENDE.md`).
7. Erst dann als fertig melden — **verbleibende Abweichungen offen benennen**, nicht übersehen.
