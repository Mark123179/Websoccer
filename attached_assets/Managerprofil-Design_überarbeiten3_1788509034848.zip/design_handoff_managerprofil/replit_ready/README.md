# replit_ready — fertiger Vanilla-Code je Baustein

Jede Datei ist **selbständig lauffähig** (im Browser öffnen, keine Abhängigkeiten, Assets als Base64 eingebettet) und enthält **exakt** die abgenommenen Werte. Regel für die Umsetzung: **wörtlich kopieren** — Markup und CSS unverändert übernehmen, keine eigenen Styles, keine Umbenennungen.

| Datei | Baustein | Designbreite |
|---|---|---|
| `kpi_leiste.html` | KPI-Leiste (9 Zellen) | 973 px |
| `karriere_timeline.html` | Karriere-Timeline (FM-Stil) | 1350 px |
| `karte_trainerstationen.html` | Interaktive Europa-Karte | 684 px |
| `statistik.html` | Statistik-Karte (folgt der Vereinswahl) | 298 px |
| `trainer_titel.html` | Trainer-Titel | 1034 px |
| `auszeichnungen.html` | Auszeichnungen (schalten Titel frei) | 336 px |
| `rekordbuch.html` | Rekordbuch | 300 px |
| `timeline_trophies.html` | Timeline + Trophäen-Vitrine (ältere Sammel-Datei) | — |

## Was beim Einbau ins Django-Projekt zu tun ist

1. **CSS** aus dem `<style>`-Block in `game/static/game/css/manager-profile.css` übernehmen. Die `:root`-Tokens stehen dort schon — den Token-Block aus der Datei **nicht** doppelt einfügen.
2. **Markup** aus `<div id="wrap">…</div>` (ohne den Wrapper selbst) ins Template `game/templates/game/manager_profile.html` übernehmen.
3. **Assets**: Base64-Datenblöcke durch `{% static %}`-Pfade ersetzen —
   `assets/backgrounds/fc-bayern-stadium.jpg`, `assets/backgrounds/europe-night.png`,
   `assets/crests/<fm_inside_id>.png`, `assets/competitions/<slug>.png`.
4. **Dynamische Werte** aus der View einsetzen; die statischen Zahlen sind Demo-Daten:
   - Timeline: `left`-Werte der Karten/Punkte werden **serverseitig oder per JS aus den Datumswerten berechnet** (zeitproportional). Die Werte in der Datei sind das Ergebnis für die Demo-Karriere — Formel: `left = (datum − start) / (ende − start) × trackWidth`.
   - Karte: Marker-`left/top` kommen aus `CITY_MAP_PCT` (Prozent → px des gezoomten Bildes), Auto-Zoom aus der Bounding-Box aller Stationen.
   - Statistik/KPI/Rekordbuch: Aggregate der gewählten Station bzw. der Gesamtkarriere.
5. **Interaktion** (Filter-Chips, Saison-Zoom, Vereins-Dropdown, ALLE-Toggle, Vitrine, Anträge) nach `PROMPT_REPLIT.md` — die Standalones zeigen den jeweils **abgenommenen Ruhezustand**.

## Abnahme
Jeder gebaute Screen wird gegen die zugehörige Datei gelegt (gleicher Zoom, gleiche Breite). Abweichung in Farbe, Abstand, Schriftgröße oder Copy = Fehler.
