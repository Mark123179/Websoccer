# KPI-Leiste — verbindliche Maßvorgabe (Abnahme-Spec)

Referenz: `replit_ready/kpi_leiste.html` (im Browser öffnen). **Diese Datei ist der Soll-Zustand.** Jede Abweichung in Maß, Farbe, Schriftgröße oder Copy ist ein Fehler — auch wenn es „besser" aussieht.

## 1. Container

```css
display: grid;
grid-template-columns:
  minmax(0,1.2fr)  /* 1 Managerlevel      */
  minmax(0,1fr)    /* 2 Saison-Score      */
  minmax(0,1fr)    /* 3 Trophäen          */
  minmax(0,0.9fr)  /* 4 Spiele gesamt     */
  minmax(0,1.15fr) /* 5 Siegquote         */
  minmax(0,1fr)    /* 6 Nicht aufgestellt */
  minmax(0,0.95fr) /* 7 Transfersperre    */
  minmax(0,1.05fr) /* 8 Letzte Anmeldung  */
  minmax(0,0.95fr);/* 9 Registriert am    */
background: var(--panel-strong);   /* rgba(12,31,45,.94) */
border: 1px solid var(--line);     /* rgba(44,231,255,.18) */
border-radius: 8px;
overflow: hidden;
```

- **Keine `height`, kein `min-height`, kein `align-items: stretch`-Ersatz durch feste Höhen.** Die Zeilenhöhe ergibt sich aus der höchsten Zelle (≈ 139 px bei 973 px Breite).
- **Keine `gap`** im Grid. Die Trennlinien sind `border-left` der Zellen 2–9.
- Die Zeile darf **nicht schrumpfen**: im Flex-Kontext `flex: 0 0 <breite>` bzw. `min-width` setzen und den Container horizontal scrollen lassen. Gequetschte Zellen → Labels brechen um → Fehler.

## 2. Zelle (gilt für alle, Ausnahmen unter 3.)

```css
display: flex; flex-direction: column;
gap: 7px;                 /* NICHT 8, 10 oder 12 */
padding: 14px 12px;
border-left: 1px solid var(--line);   /* Zelle 1: kein border-left */
```

Hover: `background: rgba(34,230,255,.04)` — sonst nichts.

## 3. Textrollen — exakte Werte

| Rolle | CSS | Farbe |
|---|---|---|
| Micro-Label (MANAGERLEVEL …) | `font: 900 9px Inter; letter-spacing:.5px; text-transform:uppercase` | `var(--faint)` = `rgba(244,251,255,.38)` |
| Label-Icon | 11 × 11 px SVG, `stroke-width: 1.6`, `gap: 5px` zum Text | Cyan `rgba(34,230,255,.75)`, bei Warnung `rgba(255,209,102,.8)` |
| Großwert | `font: 900 21px Inter` | siehe Farbregel unten |
| Datumswert (Zellen 8/9) | `font: 800 13px/1.4 Inter` | `#f4fbff`, 2. Zeile `var(--muted)` `font-weight:700` |
| Subzeile | `font: 700 9px Inter` | `var(--faint)` |
| Trendzeile | `font: 800 9px Inter`, 8×8-Icon, `gap: 4px` | `#30f29c` |

**Farbregel Großwerte:** Managerlevel-Chip `#22e6ff` · Saison-Score `#ffd166` · Trophäen `#22e6ff` · Spiele gesamt `#f4fbff` · Siegquote `#30f29c` · Transfersperre „Keine" `#30f29c` (bei Sperre `#ff5570`) · Datumsangaben `#f4fbff`.

Abweichende Zellen:
- **Zelle 1 (Managerlevel):** Level-Chip 32 × 32 px, `border-radius: 6px`, `background rgba(34,230,255,.14)`, `border 1px solid rgba(44,231,255,.5)`, `font: 900 17px`, `box-shadow: 0 0 14px rgba(34,230,255,.2)`; daneben `font: 800 9px/1.35`, zweizeilig. XP-Balken: Höhe **5 px**, `border-radius: 999px`, Spur `rgba(255,255,255,.08)`, Füllung `linear-gradient(90deg,#19c8e0,#22e6ff)` + `box-shadow: 0 0 8px rgba(34,230,255,.6)`.
- **Zelle 3 (Trophäen):** Wert **zentriert** (`text-align:center`); darunter Logo-Reihe `display:flex; justify-content:center; gap:3px`, Logos **18 × 18 px**, `object-fit: contain`, **max. 6**; „Alle ansehen" mit `margin-top: auto` (klebt am unteren Rand), `font: 700 9px`, zentriert, Linkfarbe `#22e6ff`.
- **Zelle 5 (Siegquote):** Segmentbalken Höhe **5 px**, drei Segmente Grün `#30f29c` / Weiß `rgba(244,251,255,.3)` / Rot `#ff5570`, Breiten = S/U/N-Anteil; Subzeile `white-space: nowrap`, Trennzeichen **` · `** (Mittelpunkt, keine Slashes).
- **Zelle 6 (Nicht aufgestellt):** `gap: 4px`, `padding: 12px`. Zwei Zähler nebeneinander `display:flex; align-items:baseline; gap:9px`; Zahl `font: 900 17px`, Nenner `font-size: 11px` in `var(--faint)` bzw. `rgba(255,209,102,.55)`, Mikro-Label `font: 800 7.5px` (`SAISON` / `FOLGE`). Saison-Zähler weiß, Folge-Zähler `#ffd166`. Fußzeile „Stufen-Regeln" mit 11 px i-Icon `#22e6ff` und `title`-Tooltip (Volltext der drei Stufen), `cursor: help`.
- **Zelle 7:** Wert mit 13 px Häkchen-SVG, `gap: 6px`, `font: 900 18px`.

## 4. Häufige Fehler (aus dem letzten Replit-Build)

1. ❌ Zeile deutlich höher als 139 px → Ursache: `gap` > 7 px, `padding` > 14 px oder eine Zelle mit fester Höhe. **Fix:** exakt die Werte aus 2./3. übernehmen.
2. ❌ Werte nicht auf gleicher Höhe → Ursache: unterschiedliche Label-Höhen, weil Icons fehlen oder eine andere Größe haben. **Fix:** jedes Micro-Label bekommt sein 11 px SVG, auch wenn es „nicht nötig" aussieht.
3. ❌ Segmentbalken (Siegquote) und XP-Balken fehlen bei Nullwerten. **Fix:** Balken immer rendern, Segmentbreiten 0 % zulassen, Spurfarbe bleibt sichtbar.
4. ❌ Subzeilen fehlen (z. B. „seit Aug. 2023", „Platz 214 von 18.402"). **Fix:** jede Zelle hat Label → Wert → Subzeile; fehlt der Wert, bleibt die Subzeile trotzdem stehen.
5. ❌ Trophäen-Wert linksbündig, „Alle ansehen" direkt unter den Logos. **Fix:** Wert zentriert, Link mit `margin-top: auto`.
6. ❌ Letterspacing/Schriftgrößen „gerundet" (10 px statt 9 px, 1 px statt 0.5 px Tracking). **Fix:** Werte 1:1.
7. ❌ Saison als „2023/24" ausgegeben. **Fix:** überall `#1`, `#2`, `#3` …

## 5. Selbstprüfung vor der Abgabe

`kpi_selfcheck.js` in die Browser-Konsole der fertigen Seite einfügen. Das Skript vermisst die gerenderte Leiste und gibt pro Eigenschaft **PASS/FAIL** aus. Abgabe erst, wenn alles PASS ist.
