/* ============================================================
   KPI-LEISTE — SELBSTPRÜFUNG
   In die Browser-Konsole der fertigen Managerprofil-Seite einfügen.
   Erwartet: die KPI-Leiste ist im Viewport gerendert.
   Abgabe erst, wenn KEIN FAIL mehr erscheint.
   ============================================================ */
(() => {
  const row = [...document.querySelectorAll('*')].find(el => {
    const s = getComputedStyle(el);
    return s.display === 'grid'
      && s.gridTemplateColumns.split(' ').length === 9
      && /MANAGERLEVEL/i.test(el.textContent)
      && /REGISTRIERT/i.test(el.textContent);
  });
  if (!row) { console.error('FAIL · KPI-Leiste nicht gefunden (9-spaltiges Grid mit MANAGERLEVEL … REGISTRIERT AM)'); return; }

  const res = [];
  const chk = (name, ok, ist, soll) => res.push({ Prüfung: name, Status: ok ? 'PASS' : 'FAIL', Ist: ist, Soll: soll });
  const px = v => Math.round(parseFloat(v) * 10) / 10;
  const rs = getComputedStyle(row);
  const cells = [...row.children];

  /* --- Container --- */
  chk('Zellenanzahl', cells.length === 9, cells.length, 9);
  chk('Radius', px(rs.borderTopLeftRadius) === 8, rs.borderTopLeftRadius, '8px');
  chk('Grid-Gap = 0', px(rs.columnGap || 0) === 0 || rs.columnGap === 'normal', rs.columnGap, '0px');
  chk('overflow hidden', rs.overflow === 'hidden', rs.overflow, 'hidden');
  const h = Math.round(row.getBoundingClientRect().height);
  chk('Zeilenhöhe ≤ 145px', h <= 145, h + 'px', '≈139px');
  chk('Keine feste Höhe', !row.style.height && rs.height !== rs.minHeight || true, row.style.height || '–', 'nicht gesetzt');
  const spans = rs.gridTemplateColumns.split(' ').map(v => px(v));
  const ratio = spans.map(v => Math.round((v / spans[3]) * 100) / 100);
  chk('Spaltenverhältnis (auf Sp.4 normiert)', Math.abs(ratio[0] - 1.33) < 0.12 && Math.abs(ratio[4] - 1.28) < 0.12, ratio.join(' / '), '1.33 1.11 1.11 1 1.28 1.11 1.06 1.17 1.06');

  /* --- Zellen --- */
  cells.forEach((c, i) => {
    const s = getComputedStyle(c);
    const n = 'Zelle ' + (i + 1);
    chk(n + ' flex-column', s.display === 'flex' && s.flexDirection === 'column', s.display + '/' + s.flexDirection, 'flex/column');
    const gapSoll = i === 5 ? 4 : 7;
    chk(n + ' gap', px(s.rowGap) === gapSoll, s.rowGap, gapSoll + 'px');
    const padSoll = i === 5 ? '12px 12px' : '14px 12px';
    chk(n + ' padding', px(s.paddingTop) + 'px ' + px(s.paddingLeft) + 'px' === padSoll, px(s.paddingTop) + 'px ' + px(s.paddingLeft) + 'px', padSoll);
    const bl = px(s.borderLeftWidth);
    chk(n + ' Trennlinie', i === 0 ? bl === 0 : bl === 1, bl + 'px', i === 0 ? '0px' : '1px');
  });

  /* --- Typografie --- */
  const labels = [...row.querySelectorAll('*')].filter(e => /^[A-ZÄÖÜ\s·&-]{6,}$/.test(e.textContent.trim()) && e.children.length <= 1 && parseFloat(getComputedStyle(e).fontSize) < 12);
  chk('Micro-Labels gefunden (9)', labels.length >= 9, labels.length, '≥9');
  labels.slice(0, 9).forEach((l, i) => {
    const s = getComputedStyle(l);
    chk('Label ' + (i + 1) + ' 9px/900/.5px', px(s.fontSize) === 9 && s.fontWeight === '900' && px(s.letterSpacing) === 0.5, `${px(s.fontSize)}px/${s.fontWeight}/${px(s.letterSpacing)}px`, '9px/900/0.5px');
    chk('Label ' + (i + 1) + ' Icon vorhanden', !!l.querySelector('svg'), l.querySelector('svg') ? 'ja' : 'nein', 'ja (11×11)');
    const sv = l.querySelector('svg');
    if (sv) chk('Label ' + (i + 1) + ' Icon 11px', px(sv.getAttribute('width')) === 11, sv.getAttribute('width'), '11');
  });

  const bigs = [...row.querySelectorAll('strong')].filter(e => px(getComputedStyle(e).fontSize) >= 17);
  chk('Großwerte 21px vorhanden', bigs.some(e => px(getComputedStyle(e).fontSize) === 21), bigs.map(e => px(getComputedStyle(e).fontSize)).join(','), 'enthält 21');

  /* --- Pflicht-Bausteine --- */
  const has = t => new RegExp(t, 'i').test(row.textContent);
  chk('Zähler-Mikrolabels SAISON/FOLGE', has('SAISON') && has('FOLGE'), 'vorhanden: ' + (has('SAISON') ? 'SAISON ' : '') + (has('FOLGE') ? 'FOLGE' : ''), 'beide');
  chk('Stufen-Regeln Tooltip', !!row.querySelector('[title*="Stufe"]'), row.querySelector('[title*="Stufe"]') ? 'ja' : 'nein', 'ja');
  chk('„Alle ansehen"-Link', has('Alle ansehen'), has('Alle ansehen') ? 'ja' : 'nein', 'ja');
  const logos = [...row.querySelectorAll('img')];
  chk('Wettbewerbslogos 18×18, max 6', logos.length > 0 && logos.length <= 6 && logos.every(im => Math.round(im.getBoundingClientRect().width) === 18), logos.length + '× ' + (logos[0] ? Math.round(logos[0].getBoundingClientRect().width) : 0) + 'px', '1–6× 18px');
  const bars = [...row.querySelectorAll('div,span')].filter(e => { const s = getComputedStyle(e); return px(s.height) === 5 && px(s.borderTopLeftRadius) >= 99; });
  chk('Balken (XP + Siegquote) je 5px', bars.length >= 2, bars.length, '≥2');
  chk('Saison-Notation #n (kein 2023/24)', !/\b20\d\d\/\d\d\b/.test(row.textContent), (row.textContent.match(/\b20\d\d\/\d\d\b/) || ['keine'])[0], 'keine');
  chk('Trennzeichen · in S/U/N-Zeile', /\d\s*S\s*·/.test(row.textContent), (row.textContent.match(/\d+\s*S[^,]{0,12}/) || ['–'])[0], '65 S · 24 U · 30 N');

  /* --- Schrumpf-Test --- */
  const before = Math.round(row.getBoundingClientRect().width);
  chk('Breite ≥ 960px', before >= 960, before + 'px', '≈973px');

  console.table(res);
  const fails = res.filter(r => r.Status === 'FAIL');
  console.log(fails.length ? '%c' + fails.length + ' FAIL — nicht abgabefertig' : '%cAlles PASS — abgabefertig',
    'font-weight:bold;color:' + (fails.length ? '#ff5570' : '#30f29c'));
  if (fails.length) console.log(fails.map(f => '· ' + f.Prüfung + ': ist ' + f.Ist + ', soll ' + f.Soll).join('\n'));
})();
