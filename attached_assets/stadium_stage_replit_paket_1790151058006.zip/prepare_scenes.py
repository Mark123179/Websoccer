"""Szenen-Vorbereitung für das Standbild-Duo — Python-Referenz für die spätere Serverlogik.

Regeln (Entscheidungen 7, 8, 9, 11 aus claude_2d-stadion.md):
- mainStand: Langseite mit VIP-Blöcken (Rückfall: Langseite mit den meisten Rasterplätzen)
- Elversberg: Oberrang nach Editor-Gesetz "z0 = z1_unter + 2 m" (12,0 → 7,3), Dach folgt
- Standard-Design ohne gespeichertes Design: Farbe 1 Schalen, Farbe 2 als Band
- Testmuster "R" in einem Block der Gegentribüne (Prüfpunkt 5)
"""
import json, math, sys
from copy import deepcopy
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

SRC = Path('/home/claude/2d/uploads')
OUT = Path('/home/claude/stage/scenes'); OUT.mkdir(exist_ok=True)

CLUB_COLORS = {                      # Entscheidung 7 — später color_primary/color_secondary am Verein
    'Borussia Dortmund': ('#ffd400', '#101216'),
    'SV Elversberg':     ('#17191c', '#f4f7fb'),
}
TIER_GAP = 2.0                       # Editor-Gesetz: Oberrang beginnt 2 m über dem Unterrang


def decode(rle):
    out = []
    for n, c in rle:
        out.extend([c] * n)
    return out


def encode(seq):
    rle = []
    for c in seq:
        if rle and rle[-1][1] == c:
            rle[-1][0] += 1
        else:
            rle.append([1, c])
    return rle


def color_index(scene, hexcol):
    pal = scene['palette']
    if hexcol not in pal:
        pal.append(hexcol)
    return pal.index(hexcol)


def centroid(q):
    return sum(p[0] for p in q) / 4, sum(p[1] for p in q) / 4


def is_long_side(scene, stand):
    pts = [centroid(b['quad']) for b in scene['blocks'] if b['stand'] == stand]
    cx = sum(p[0] for p in pts) / len(pts); cy = sum(p[1] for p in pts) / len(pts)
    return abs(cy) > abs(cx)


def main_stand(scene):
    stands = sorted(set(b['stand'] for b in scene['blocks']))
    long_sides = [s for s in stands if is_long_side(scene, s)]
    vip = [s for s in long_sides if any(b.get('type') == 'vip' and b['stand'] == s for b in scene['blocks'])]
    if vip:
        return vip[0]
    return max(long_sides, key=lambda s: sum(b['rows'] * b['seats'] for b in scene['blocks'] if b['stand'] == s))


def opposite_long_side(scene, stand):
    return [s for s in sorted(set(b['stand'] for b in scene['blocks'])) if is_long_side(scene, s) and s != stand][0]


def fix_tier_gap(scene):
    """Oberrang-Unterkante auf z1(Unterrang) + 2 m setzen, Höhe des Rangs beibehalten, Dach mitziehen."""
    by_stand = {}
    for b in scene['blocks']:
        if b['tier'] == 'UNTER':
            by_stand[b['stand']] = max(by_stand.get(b['stand'], 0), b['z1'])
    deltas = []
    for b in scene['blocks']:
        if b['tier'] == 'OBER' and b['stand'] in by_stand:
            new_z0 = by_stand[b['stand']] + TIER_GAP
            d = new_z0 - b['z0']
            if abs(d) > 0.05:
                b['z1'] = b['z1'] + d
                b['z0'] = new_z0
                deltas.append(d)
    if deltas:
        d = sum(deltas) / len(deltas)
        for seg in scene['roof']['segments']:
            seg['heights'] = [h + d for h in seg['heights']]
        return d
    return 0.0


def normalize_roof(scene, inner_clearance=3.0, outer_clearance=4.5):
    """Dach-Höhen nach Server-Regel: Traufkante (feldnahe Kante) auf zTop + 3 m, Außenkante auf zTop + 4,5 m —
    zTop = höchste Hinterkante der Tribüne, über der das Segment liegt. Die Quads bleiben, nur die Höhen ändern sich."""
    def pd(p):
        return pitch_distance(p)
    for seg in scene['roof']['segments']:
        q = seg['quad']
        cx = sum(p[0] for p in q) / 4; cy = sum(p[1] for p in q) / 4
        near = sorted(scene['blocks'], key=lambda b: (centroid(b['quad'])[0] - cx) ** 2 + (centroid(b['quad'])[1] - cy) ** 2)[:4]
        z_top = max(b['z1'] for b in near)
        d = [pd(p) for p in q]
        order = sorted(range(4), key=lambda i: d[i])
        inner = set(order[:2])
        seg['heights'] = [z_top + (inner_clearance if i in inner else outer_clearance) for i in range(4)]


def pitch_distance(p, length=105.0, width=68.0):
    dx = max(abs(p[0]) - length / 2, 0); dy = max(abs(p[1]) - width / 2, 0)
    return math.hypot(dx, dy)


def standard_design(scene, col1, col2):
    """Blöcke ohne Design (nur Index 0) bekommen Farbe 1 mit einem Band in Farbe 2."""
    i1, i2 = color_index(scene, col1), color_index(scene, col2)
    n = 0
    for b in scene['blocks']:
        if set(c for _, c in b['rle']) != {0}:
            continue
        rows, seats = b['rows'], b['seats']
        seq = []
        for r in range(rows):
            v = (r + 0.5) / rows
            band = 0.45 <= v < 0.60
            seq.extend([i2 if band else i1] * seats)
        b['rle'] = encode(seq)
        n += 1
    return n


def press_letter(scene, block, letter, col_bg, col_fg):
    """Buchstabe als Bitmap rows×seats in den Block pressen — Reihe 0 vorne, links→rechts aus Feldsicht."""
    rows, seats = block['rows'], block['seats']
    img = Image.new('L', (seats, rows), 0)
    d = ImageDraw.Draw(img)
    font = None
    for path in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
                 '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'):
        try:
            font = ImageFont.truetype(path, int(rows * 0.9)); break
        except OSError:
            continue
    bbox = d.textbbox((0, 0), letter, font=font)
    w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
    d.text(((seats - w) / 2 - bbox[0], (rows - h) / 2 - bbox[1]), letter, fill=255, font=font)
    # Bildzeile 0 = oben = hinterste Reihe; Reihe 0 der RLE ist die vorderste → vertikal spiegeln
    px = img.load()
    i_bg, i_fg = color_index(scene, col_bg), color_index(scene, col_fg)
    seq = []
    for r in range(rows):
        y = rows - 1 - r
        seq.extend([i_fg if px[c, y] > 127 else i_bg for c in range(seats)])
    block['rle'] = encode(seq)


def prepare(path, club, strip_design_stands=(), letter_block=None):
    scene = json.load(open(path))
    scene['blocks'] = [deepcopy(b) for b in scene['blocks']]
    col1, col2 = CLUB_COLORS[club]
    report = {'club': club}
    for b in scene['blocks']:                     # ggf. Demo-Design entfernen, um den Standard zu prüfen
        if b['stand'] in strip_design_stands:
            b['rle'] = [[b['rows'] * b['seats'], 0]]
    report['tier_fix_m'] = round(fix_tier_gap(scene), 2)
    normalize_roof(scene)
    scene['mainStand'] = main_stand(scene)
    scene['clubColors'] = {'primary': col1, 'secondary': col2}
    report['standard_design_blocks'] = standard_design(scene, col1, col2)
    far = opposite_long_side(scene, scene['mainStand'])
    if letter_block is None:
        cands = sorted([b for b in scene['blocks'] if b['stand'] == far and b['tier'] == 'UNTER'], key=lambda b: b['order'])
        letter_block = cands[len(cands) // 2]['id']
    blk = next(b for b in scene['blocks'] if b['id'] == letter_block)
    press_letter(scene, blk, 'R', col1, col2)
    report.update(mainStand=scene['mainStand'], farStand=far, letter_block=letter_block,
                  palette=len(scene['palette']), blocks=len(scene['blocks']))
    for b in scene['blocks']:
        assert sum(n for n, _ in b['rle']) == b['rows'] * b['seats'], b['id']
    return scene, report


if __name__ == '__main__':
    bvb, r1 = prepare(SRC / 'claude-design-stadion-prototyp-handoff/data/stadion-live-scene.json', 'Borussia Dortmund')
    elv, r2 = prepare(SRC / 'claude-design-elversberg-prototyp-handoff/data/elversberg-live-scene-demo.json', 'SV Elversberg',
                      strip_design_stands=('NORD', 'SUED', 'WEST'))
    json.dump(bvb, open(OUT / 'bvb.json', 'w'), separators=(',', ':'))
    json.dump(elv, open(OUT / 'elversberg.json', 'w'), separators=(',', ':'))
    print(json.dumps([r1, r2], indent=1, ensure_ascii=False))
