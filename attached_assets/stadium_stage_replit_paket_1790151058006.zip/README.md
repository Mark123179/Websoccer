# Stadion-Bühne · Replit-Paket (15.09.2026)

Lies zuerst `REPLIT_AUFTRAG_stadion_stage.md` (der Auftrag), dann `claude_2d-stadion.md` (Konzept, 14 Entscheidungen, Regeln) und `GESPRAECHSVERLAUF.md` (wie es dazu kam).

- `stadium_stage.js` + `vendor/` — das Renderer-Modul (Blackbox) mit three.js 0.170
- `index.html` — Testseite (`python3 -m http.server`, dann `index.html?scene=scenes/bvb_v2.json&view=orbit&light=night`)
- `stadion_duo.html` — Referenz als Einzeldatei (vier Stadien, alle Ansichten)
- `blueprint_v2.py` — Python-Referenz der Blaupause V2 (OSM → Szene), `steckbrief.json` — Ebene 2
- `osm/` — Overpass-Cache, `scenes/` — Soll-Ausgabe des Endpunkts, `out/` — Abnahmebilder
- `render_duo.py` — Headless-Render für Screenshots (Playwright + SwiftShader)
- `referenz/` — Objektnamen und abgelesene Maße aus der Dortmund-Referenz (BassyBoy); nur Namen und Zahlen, keine Geometrie
