# Stadion im 2D-Modus — Konzeptstand

Stand: 15.09.2026 · **14 Entscheidungen; Modul mit drei Kameras (Spiel, Außen, Sitz), Blaupause V2 aus OSM, Steckbrief-Ebene begonnen. Prüfpaar liegt zur Abnahme vor.** Siehe auch `stadion-editor.md`, `2d-modus.md`.

---

## Kernidee in drei Sätzen

Das Heimstadion aus dem Stadion-Editor steht im 2D-Modus als Kessel um das Spielfeld — nicht von Hand gebaut, sondern aus Geometrie erzeugt, damit Elversberg als Elversberg und Dortmund als Dortmund erkennbar ist. **Ein** Renderer (`stadium_stage.js`) liest **ein** Scene-Schema, das aus zwei Quellen gefüllt wird: OSM-Blaupause, wo es sie gibt, parametrischer Generator für alle anderen. Vorbild für die Darstellung ist der Camp-Nou-Explorer von @thebuggeddev (three.js, Instanz-Sitze) — nur dass bei uns der Automat dahinter steht, nicht ein einzelnes handgebautes Stadion.

---

## Befunde, die den Rahmen setzen (10.–15.09.)

1. **Geometrie stimmt, Reihen nicht.** `quad`, `z0`, `z1` sind plausibel (Unterrang 15–20°, Oberrang 36–45°). `rows`/`seats` sind Kapazitätsbuchhaltung (Dortmund Süd-Unterrang: 11 Reihen auf 44 m; Nord-Oberrang: 16 Reihen auf 20 m Höhe). Jeder Renderer, der daraus Stufen baut, baut Platten.
2. **Zwei Renderer.** Bühne und Debug-Werkzeug in Claude Design hatten getrennten Blockcode; Fixes landeten immer nur in einem. Zwei von drei Bühnen-Fixes waren messbar wirkungslos (0 von 52 Blöcken betroffen).
3. **Kamera über dem Dach.** 42 m Kamera gegen 27–36 m Dach — man sah Dachoberseiten statt Ränge.
4. **Abdeckung.** Server-Bundle: 22 Blaupausen (18 Bundesligisten, Basel, 3 PoC), Elversberg separat. Produktiv (Test 15.09., IDs 1–30): Clubs 2–15 und 18 haben Geometrie, aber kein Design → `404`; 19–21 keine Geometrie; kein Verein liefert heute eine Szene.
5. **Camp Nou technisch:** three.js/WebGL, 86.964 Sitze als `InstancedMesh`, `MeshStandardMaterial`, `PerspectiveCamera`, `OrbitControls`; Kessel parametrisch aus Rängen und Sektionen.

---

## Entscheidungen

| # | Thema | Entscheidung |
|---|---|---|
| 1 | Zeicheneinheit | **Block als eine schräge Fläche.** `rows`/`seats` teilen nur die Farben (RLE-Adressierung), nie die Form. Sitze auf festem Raster 0,5 × 0,8 m im Block, Farbe je Sitz aus dem RLE abgetastet |
| 2 | Ein Renderer | **`stadium_stage.js`**, von Claude außerhalb von Design gebaut. Nicht verhandelbar: `project(xm, ym, zm)` — eine Projektion für Kessel, Figuren, Ball, Banden, Torrahmen. Design baut es als Blackbox ein, behält Rasen, Banden, Figuren, Ball, HUD, Demo-Loop, Tweaks; der Block-Zweig der Bühne entfällt, Debug und Größenvergleich ziehen aus demselben Modul |
| 3 | Kamera | **Marks Feld-Preset** (42 m Höhe, 28 m Abstand, 43°, Zoom 700) für alle Stadien, am Spielfeld verankert, **kein Auto-Fit**. Dach nur als Traufkante und Unterseite, nie von oben. Kameraseite wird nie gezeichnet, Kurven reihenweise an der Nahebene geschnitten |
| 4 | Technik | **three.js/WebGL**, ES-Modul aus `static/` per Importmap, kein Bundler. Sitze als `InstancedMesh`; unter der Leistungsgrenze Rückfall auf Blocktextur aus dem RLE |
| 5 | Herkunft | **Ein Scene-Schema, zwei Zulieferer:** OSM-Blaupause (Bundle) und parametrischer Generator aus dem `Stadium`-Modell (12 Kapazitäten + Grundform, Laufbahn, Ecken, Dachtyp). Blaupause/JSON werden nachgeschärft, bis das Ergebnis passabel ist |
| 6 | Weg | **Ein Endpunkt** `GET /stadion/<club_id>/live-scene/` (existiert): Geometrie + Design serverseitig gemischt, beim Speichern und nach Ausbau einmal neu abgelegt. Editor, 2D-Modus, Debug, Größenvergleich lesen alle diesen |
| 7 | Ohne Design | **Standard-Design aus Vereinsfarben** (Sitzschalen Farbe 1, Muster Farbe 2). Braucht `color_primary`/`color_secondary` am Verein — einmalig aus dem Wappen abgeleitet, im Admin korrigierbar |
| 8 | Ausbau | **Wächst die Geometrie:** je Reihe Hinterkante +0,8 m, `z1` + Rangsteigung; ab 42 Reihen additiv ein neuer Rang außen (`z0` = alte Oberkante + 2 m). Bestehende Blöcke, IDs, Designs bleiben. `Stadium` bleibt einzige Kapazitätsquelle |
| 9 | Kameraseite | **`mainStand`** je Stadion in der Szene (Standard: Langseite mit den meisten VIP-Plätzen, Dortmund West), Kamera dort, Gegentribüne gegenüber, Kurven im Anschnitt. Physikalisch treu, keine Drehung fürs Design |
| 10 | V1-Umfang | **Kessel komplett, statisch:** Blöcke mit Sitzen, Körper (Außenwand, Blende, Fugenpaneele, Umlauf), Dach aus `roof.meta` (Server erzeugt Segmente; explizite haben Vorrang), Preset, `project()`, Cull. **Nicht V1:** Zuschauer/Auslastung, Rasen, Choreo-Karten, Flutlicht, Umgebung, Tag/Nacht |
| 11 | Abnahme | **Standbild-Duo** Dortmund/Elversberg aus derselben Kamera, fünf Prüfpunkte (unten) plus Sichtprobe; verschmolzen mit Designs Liste aus `SCHNITTSTELLE-STADIUM-STAGE.md` |
| 13 | Blaupause | **V2 aus OSM-Polygonen** (Tribünenpolygone → Stadionring mit Innenring → Außenkontur); Blöcke parallel zur feldnahen Kante, Eckfächer, Raster physisch |
| 14 | Wissensebenen | **Vermessung (OSM) → Steckbrief je Verein → Korrektur im Editor.** Ohne Fremdcode; Prinzipien aus StadiView (Canvas-Texturen, FPS-Pixelrate, Sitzblick) nachgebaut |
| 12 | Reihenfolge | **Alles hier**, Replit bleibt draußen: Modul, Python-Referenz für die Server-Regeln, fertige Szenen. Design danach als Blackbox-Einbau. Replit am Ende als reine Implementierung. Rollout Verein für Verein, Prüfpaar zuerst |

---

## Schnittstelle des Moduls

- **Eingabe:** Live-Scene-JSON (`websoccer.stadium-live-scene`, Version 1), Feldmeter, Ursprung Spielfeldmitte, `+X` Tor-zu-Tor, `+Y` Seitenlinie-zu-Seitenlinie, `+Z` hoch. Neu in der Szene: `mainStand` (NORD/OST/SUED/WEST).
- **Ausgabe:** ein WebGL-Canvas mit dem Kessel von der Bande nach außen, transparent darüber liegt Designs Ebene.
- **`project(xm, ym, zm) → {x, y, d}`** in Canvas-Pixeln; alles, was Design zeichnet, läuft durch diese Funktion.
- **Kamera** liegt im Modul (Preset), nicht in der Szene.

### Bauteil-Regeln (Konstanten des Moduls)

| Bauteil | Regel |
|---|---|
| Sitzraster | 0,5 m je Sitz, 0,8 m je Reihe, im Viereck bilinear verteilt; Farbe = RLE-Zelle `(floor(u·seats), floor(v·rows))` |
| Stufenkanten | alle 0,8 m Tiefe, unabhängig von `rows` |
| Umlauf | waagerecht auf Höhe der letzten Unterrangreihe plus senkrechte Brüstung (Editor-Gesetz: Oberrang beginnt 2 m über dem Unterrang) |
| Außenwand | von `z1` senkrecht auf 0, nur im äußeren Ring |
| Blende | von `z0` abwärts, wenn `z0` > 3 m |
| Fugenpaneel | zwischen Nachbarblöcken bei Lücke > 0,3 m |
| Dach | Traufkante über der Außenkante des obersten Rangs, Unterseite nach innen; Oberseite wird nie gezeichnet |

---

## Fünf Prüfpunkte für das Standbild-Duo

1. **Maßstab** — Feld auf denselben Pixeln; Dortmund breiter und höher, ohne Einpassung.
2. **Form** — Grundriss der Blaupause erkennbar (Dortmund Kessel mit Umlauf, Elversberg vier Tribünen, offene Ecken).
3. **Ränge** — Rangzahl und Umlauf stimmen mit `z0`/`z1`; nichts schwebt, nichts klebt.
4. **Dach** — Traufkante über dem obersten Rang der Gegentribüne, keine Dachoberseite.
5. **Pressen** — Testmuster („R" in einem Block) liegt exakt, Reihe 0 am Feld, lesbar, nicht gespiegelt; ohne Design das Standard-Design.

Sichtprobe: ein Unbeteiligter nennt in zwei Sekunden das größere Stadion.

---

## Spuren

1. **Modul + Duo (hier):** `stadium_stage.js`, Testseite, Python-Vorbereitung der Szenen (Elversberg-Oberrang `z0` 12,0 → 7,3 m; `mainStand`; Standard-Design; Testmuster), zwei Standbilder.
2. **Python-Referenz (hier):** Standard-Design, `mainStand`/Dach-Segmente aus `roof.meta`, Ausbau-Gesetz, Generator — passend zu `stadium_editor/`, läuft auf Bundle und Elversberg-Datei, erzeugt Szenen für alle Vereine.
3. **Design:** Einbau nach abgenommenem Duo; bis dahin keine Änderung am Bühnen-Renderer.
4. **Replit:** ein Paket am Ende (Modelle, Serializer, Endpunkt-Erweiterung, Generator-Command).

---

## Stand Spur 1 (15.09.)

`stadium_stage.js` V1 rendert beide Szenen; Feld-Ecken projizieren in beiden Bildern auf identische Pixel (Prüfpunkt 1 erfüllt), das „R" sitzt lesbar und ungespiegelt (Prüfpunkt 5), Dortmund 71.500 Sitze / 40 Blöcke in ~300 ms, Elversberg 20.873 / 44 in ~150 ms. Paket: `stadium_stage_v1.zip`, Live-Seite `stadion_duo.html`.

Zwei Befunde aus dem Bau, die eine Entscheidung brauchen:

- **RLE-Raster folgt der Kapazität, nicht der Fläche.** Weil `rows × seats` = Kapazität sein muss, hat Elversbergs Gegentribüne 9 Farbreihen auf 13 physische, Dortmunds Süd-Unterrang 11 auf 55. Gepresste Designs werden dadurch grob. Vorschlag: Design-Raster = physisches Raster (`depth/0,8 × width/0,5`), Kapazität bleibt Zahl am Block — das ändert die Invariante `sum(rle) == rows × seats` in `sum(rle) == physRows × physSeats`.
- **Die bisherige Bühne war gespiegelt** (linkshändige Projektion). Das Modul nutzt eine echte Kamera: von der Westtribüne aus liegt Dortmunds Süd rechts hinter dem Tor — wie im Fernsehbild. Prüfen, ob Designs Figuren-Ebene mit der neuen `project()` seitenrichtig läuft.

## Blaupause V2 (15.09., Vorschau zu Frage 13)

Befund: Das Bundle nutzt nur die OSM-Außenkontur, die Blöcke darin erzeugt ein radialer Kessel-Generator — geschlossene Ecken, 25 m Abstand hinter den Toren, Eckblöcke auch bei Elversberg. OSM selbst liefert mehr: Dortmund als `building=stadium`-Multipolygon mit **Innenring** (echter Kesselrand, 5–7 m vom Feld, eckig), Elversberg als vier einzelne `building=grandstand`-Polygone (offene Ecken; Nord fehlt noch → parametrisch ergänzt). Beide mit `leisure=pitch`, also echter Himmelsrichtung.

`blueprint_v2.py` baut daraus Szenen: Tribünenpolygone → sonst Ring an den Innenecken mit 9-m-Fase in vier Seiten und Ecken (Eckfächer, 5 Keile) → sonst Außenkontur. Blöcke ~22 m parallel zur feldnahen Kante, Tiefe per Strahl bis zur Rückkante; Ränge aus der Tiefe (≤ 22 m ein Rang, sonst zwei bei 46 %), Steigung 16°/30°, Umlauf 2 m; Raster physisch (0,8 × 0,5 m). Ergebnis: Dortmund 72 Blöcke / ~91.000 Rasterplätze (DB 81.365), Elversberg 17 / ~19.400 (DB 14.643) — Kapazität bleibt DB-Sache, die Fläche liefert nur das Bild. Standbild-Duo neu gerendert, Modul unverändert.

## Drei Wissensebenen je Stadion (Vorschlag 15.09., Frage 14)

| Ebene | Quelle | Liefert | Pflege |
|---|---|---|---|
| 1 · Vermessung | OSM (Overpass) | Grundriss, Tribünenpolygone, Ecken offen/zu, Feldlage und Himmelsrichtung, teils Dachpolygone | automatisch, ein Lauf für alle |
| 2 · Steckbrief | `STECKBRIEF` je Verein (~10 Felder) | je Tribüne: Ränge, Steigung, Steh/Sitz, Dach; global: Ecktyp, Dachtyp, Pylone, Haupttribüne | einmal je Verein aus Fotos/stadiumdb, Tabelle zum Gegenlesen |
| 3 · Korrektur | Stadion-Editor / Admin | Blockecken schieben, Rangzahl ändern, Tribüne ergänzen — gespeichert in `StadiumGeometry` | bei Bedarf, Community („Mitsprache") |

Erste Steckbrief-Einträge: Dortmund Süd = ein durchgehender Stehrang (30°); Elversberg C1 = Stehplätze, Nord = Neubau ein Rang 24° mit Dach, Westtribüne ohne Dach.

## Stand 15.09. (abends)

- Modul: Spielkamera (fest), Außenansicht (Orbit) und Sitzblick (`seatAt` → `view: 'seat'`), Fassade mit Etagen/Fenstern aus Canvas, Betontextur, Pylone und Flutlicht aus dem Steckbrief, Umfeld aus dem Bundle (Gebäude, Straßen, Grün), `adaptQuality` (FPS-gesteuerte Pixelrate).
- Steckbrief-Felder bisher: je Tribüne `tiers`, `rake`, `standing`, `roof`; global `corners`, `roofType`, `pylons`, `floodlights`. Dortmund: Süd Stehrang 30°, 8 Pylone 62 m gelb. Elversberg: Nord Neubau 24°, Flutlicht 4 × 30 m.
- StadiView (github.com/thebuggeddev/football-stadium): PolyForm Noncommercial — kein Code übernommen; Ellipsen-Generator ohnehin ungeeignet.
- Regeln aus dem Prüfpaar: Tribünenpolygon → eine Tiefe (Median über die Front); Mindestabstand Front–Feld 5 m Langseite / 7 m Torseite; Stadionfläche (`leisure=stadium`) ist nur Kulisse, Bauteile beziehen sich auf die Tribünen-Bbox; Kulisse zeichnet nichts innerhalb der Tribünen.
- **Tag/Flutlicht** (`lighting: 'day' | 'night'`): nachts Spots von den Dachkanten (drei je Seite) bzw. Mastköpfen aufs Feld, Leuchten alle 9 m auf der Traufkante, Umfeld dunkel, Rasen leicht selbstleuchtend. Sitzschalen (Sitzfläche + Lehne) statt Klötze. `design`-Override für den Editor (RLE je Block, ungespeichert).
- Feld-Ecken projizieren in allen Stadien auf identische Pixel (nachgemessen) — der 2D-Modus ist stadionunabhängig.
- **Weg 3 der Blaupause — Oval aus OSM-Ringen** (Camp Nou als Test): konzentrische `building:part`-Multipolygone mit Höhen → Ränge; Front = Innenkante (Auslaufzone mit runden Ecken), eine Tiefe je Rang (Median), Rückkante = Front + Normale × Tiefe, Kragarm der oberen Ränge (Steckbrief), 0,6 m Treppe zwischen den Blöcken. Flutlicht-Typen im Steckbrief: Dachkante / Masten / `rim` (Kranz auf dem Oberrang). Spots enden 1,35 × hinter dem Ziel — keine Lichtsterne auf den Gegenrängen.
- Dacharten im Steckbrief: `ring` (je Block, Dortmund), `separate` (je Tribüne, Elversberg), `plate` (Tribuna-Dach, folgt der Krümmung: deckt alle Blöcke, deren Frontkante weniger als `span`° von der Tribünenachse abweicht — Camp Nou 30° → Blöcke 15–20, ≈137 m; je Block ein Segment vom Mittelrang bis zur Hinterkante, eine Höhe). Flutlicht nachts: Feldspot mit Reichweite + breiter Füllspot ohne Reichweite (Streulicht auf die Ränge), Grundlicht 0,7.
- **Olympiastadion Berlin** (viertes Beispiel): OSM liefert das Gebäude als ein Polygon mit Lücke (Marathontor), die Laufbahn als Relation (außen/innen) und die Gebäudehöhe. Regeln dazu: Ränge beginnen hinter der Laufbahn (Innenkante = Laufbahn ∪ Auslaufzone); ein Ring in zwei Ränge nach Tiefenanteil (45 % / 55 %, 16°/28°); Sektoren ohne Treffer auf dem Gebäude entfallen (Marathontor) — dadurch hat auch das Ringdach die Lücke; Laufbahn als Tartanring mit Rasen-Innenraum in der Szene (`track`); Steckbrief `sunken: 12` legt Gelände, Umfeld und Fassadenfuß 12 m über das Rasenniveau (versenktes Stadion), Boden mit konvexem Loch.
- Vergleich mit dem Camp-Nou-Explorer: Form, Ränge, Farben, Größe stimmen; sein Vorsprung ist Tageslicht und Feinarbeit (Fassadenraster, Bäume, Schriftzug über Blockgrenzen — das kann bei uns der Editor).
- Nächster Schritt: OSM-Lauf über alle Vereine mit Blaupause, Steckbrief-Tabelle je Verein, ein Bild je Stadion zum Gegenlesen; Editor-Integration als Orbit-Tab mit `design`-Override.

## Referenzmessung Dortmund (23.09.) — Bassy-Sitzwolke

`dortmundv3.json` aus dem FM26-Megapack (Nutzungserlaubnis von BassyBoy) enthält 71.659 Sitzpositionen mit Höhe. **Nicht ins Spiel** (Objektnamen `st051_sc2018`, `SCARECROW`, `AUDIAREA` = EA-FIFA-Konvention; die Erlaubnis deckt EA-Rechte nicht) — nur als Maßquelle für den Steckbrief, wie ein Foto. Abgelesen: Unterrang Front 6,7 m hinter der Seitenlinie, Tiefe 33,4 m, 1,0→17,9 m (26,8°); Oberrang ab 17,4 m Kragarm, Tiefe 34,5 m, 13,0→36,6 m (34,3°); Süd zwei Ränge (Stehrang 26,6°, Sitzrang 33,8°), Front 9,2 m hinter dem Tor; Nord unten 17,9 m tief (25,4°), Front 11,1 m; Ecken nur im Oberrang. Neue Steckbrief-Felder je Tribüne: `front`, `lower_depth`, `rake_lower`, `upper_front`, `upper_depth`, `rake_upper`, `z_upper`, `corners_lower`. Ergebnis: Dortmund 52 Blöcke, Ränge wie im Original.

## Offen

- Designs fünf Abnahmepunkte (`SCHNITTSTELLE-STADIUM-STAGE.md`) — zum Verschmelzen mit den fünf oben.
- Welche Vereine ohne Blaupause genau (produktiv 19–21; Gesamtliste aus der DB).
- Elversberg in der Datenbank: 10.000 bleibt oder 14.643 — Ökonomie-Entscheidung, nicht Teil dieses Vorhabens.
- Vereinsfarben-Quelle: Wappenanalyse einmalig, danach Admin.
