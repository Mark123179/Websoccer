# Gesprächsverlauf · Stadion im 2D-Modus

Mark ↔ Claude, 10.–15.09.2026. Vorgeschichte: Claude-Design-Bühne (Paket `Fussball_Manager_2D_Modus.zip`, eigener `Gesprächsverlauf.md` dort). Entscheidungen im Detail: `claude_2d-stadion.md`.

---

## 10.09. — Diagnose und die ersten zwei Entscheidungen

**Ausgangslage:** Die Perspektiv-Bühne aus Claude Design zeigte die Ränge als verdrehte Platten. Mehrere „Fixes" (Quad-Wicklung, Kantenerkennung) waren wirkungslos (0 von 52 Blöcken betroffen).

**Befunde:**
1. Geometrie (`quad`, `z0`, `z1`) stimmt; `rows`/`seats` sind Kapazitätsbuchhaltung (Süd-Unterrang 11 Reihen auf 44 m, Nord-Oberrang 16 Reihen auf 20 m Höhe). Jeder Renderer, der daraus Stufen baut, baut Platten.
2. Bühne und Debug-Werkzeug hatten **zwei getrennte Blockrenderer**; Fixes landeten nur in einem.
3. Kamera 42 m über dem Dach (27–36 m).
4. Bundle: 22 Blaupausen; produktiv liefert kein Verein eine Szene (Design fehlt → 404).

**Entscheidungen 1–2:** Block als eine schräge Fläche, `rows`/`seats` nur Farbadressierung. Ein Renderer `stadium_stage.js`, von Claude gebaut, mit `project(xm, ym, zm)` als gemeinsamer Projektion (Bedingung aus Claude Design, Datei `SCHNITTSTELLE-STADIUM-STAGE.md`).

## 15.09. — Referenz Camp Nou, Entscheidungen 3–12, Modul V1

- Marks Referenz: Camp-Nou-Explorer von @thebuggeddev (three.js, Instanz-Sitze). Untersucht: `InstancedMesh`, `MeshStandardMaterial`, `OrbitControls`; Kessel parametrisch.
- **Entscheidungen 3–12:** feste Feldkamera (Marks Preset, kein Auto-Fit, Dach nie von oben); three.js; ein Scene-Schema mit zwei Zulieferern (OSM-Blaupause, parametrischer Generator); ein Endpunkt (existiert, produktiv getestet: IDs 2–15/18 ohne Design, 19–21 ohne Geometrie); Standard-Design aus Vereinsfarben; Ausbau wächst Geometrie; `mainStand` je Stadion (VIP-Langseite); V1 = Kessel statisch, keine Zuschauer; Standbild-Duo Dortmund/Elversberg mit fünf Prüfpunkten; alles hier, Replit zum Schluss.
- Gemeinsames Verständnis bestätigt („passt"). Ablage `claude_2d-stadion.md`.
- **Modul V1** gebaut, Duo gerendert: Feldecken beider Stadien auf identischen Pixeln; „R" lesbar, nicht gespiegelt; 71.500 Instanz-Sitze in ~300 ms. Befunde: RLE-Raster folgt der Kapazität (Elversberg 9 Farbreihen auf 13 physische); die alte Bühne war seitenverkehrt (linkshändige Projektion).

## 15.09. — Form: Blaupause V2 aus OSM (Entscheidung 13)

- Mark: „hat mit dem Original nichts zu tun". Draufsicht-Vergleich: das Bundle nutzt nur die OSM-Außenkontur, die Blöcke sind ein radialer Kessel-Generator (Dortmund rund mit 25 m Abstand hinter den Toren, Elversberg mit Eckblöcken).
- Overpass: Dortmund als `building=stadium`-Multipolygon mit **Innenring**; Elversberg als vier `building=grandstand`-Polygone (Nord fehlt → parametrisch).
- **Entscheidung 13:** Blaupause V2 aus OSM-Polygonen (Tribünenpolygone → Stadionring → Außenkontur).
- Iterationen: Eckfächer (5 Keile); Namenskollisionen (Kompass nur für Seiten, Ecken zur Torseite); Tiefe bis zum Außenring statt bis zum Schnitt; Westtribüne Elversberg mit Zickzack-Rückseite → **eine Tiefe je Tribünenpolygon (Median)**; Flutlicht auf der Stadionfläche (Parkplatz) → **Bauteile beziehen sich auf die Tribünen-Bbox**; OSM-Haupttribüne 2 m im Rasen → **Mindestabstand 5 m Langseite / 7 m Torseite**; OSM-Grünfläche unter den Rängen → **Kulisse zeichnet nichts innerhalb der Tribünen**.
- Marks Frage „Feld muss überall gleich groß sein": per Bauart erfüllt — Feld ist Ursprung, Kamera fest, `project()` aus dem Modul, nachgemessen (191,9·805,6 … 940·530,6 in beiden Stadien).

## 15.09. — Drei Wissensebenen (Entscheidung 14) und Camp-Nou-Prinzipien

- **Entscheidung 14:** Vermessung (OSM) → Steckbrief je Verein (~10 Felder) → Korrektur im Editor. Erste Steckbriefe: Dortmund Süd = ein Stehrang 30°, acht gelbe Pylone 62 m; Elversberg C1 Stehplätze, Nord Neubau 24°, Flutlicht 4 × 30 m.
- StadiView-Repo (github.com/thebuggeddev/football-stadium) geprüft: **PolyForm Noncommercial** → kein Code übernommen. Nachgebaute Prinzipien: Canvas-Texturen (Beton, Fassade mit Etagen/Fenstern), FPS-gesteuerte Pixelrate, Sitzblick (`seatAt`, 1,18 m Augenhöhe), Sitzschalen mit Lehne.
- Außenansicht (Orbit), Draufsicht, Fassade aus der Außenkontur, Umfeld aus dem Bundle (Gebäude, Straßen, Grün). **Tag/Flutlicht**: Spots von Dachkante, Masten oder Kranz (`rim`) aufs Feld, Leuchten alle 9 m auf der Traufkante; Streulicht (breite, schwache Füllspots) für die Ränge nach Marks Einwand „beleuchtet nur das Feld". `design`-Override fürs Editor-Live-Umfärben.

## 15.09. — Camp Nou mit unseren Daten (Vergleichstest)

- OSM: vier konzentrische `building:part`-Ringe mit Höhen → **Weg 3: Terrassenringe → Ränge** (drei Ränge, Kragarm 10/12 m für die oberen Ränge, Front = Auslaufzone mit runden Ecken).
- Iterationen: Strahl vom Feldmittelpunkt → schräge Blöcke und Keile in der Kurve → **lokale Normale der Innenkante, geteilte Rückpunkte**; **eine Tiefe je Rang**, Reihen laufen durch; **0,6 m Treppe** zwischen Ovalblöcken; Dach der Tribuna erst als Blockplatten bis in die Ecken, dann als Rechteck („plump, zu kurz"), dann **aus der Krümmung abgeleitet** (`span` 30° → Blöcke 15–20, ≈137 m — deckt sich mit dem Luftbild); Flutlicht `rim`; Spots mit Reichweite gegen Lichtsterne, dann Füllspots gegen „nur Feld beleuchtet".
- Ergebnis: Form, Ränge, Farben, Größe stimmen mit dem Explorer überein; Unterschied ist Feinarbeit und Tageslicht.

## 15.09. — Olympiastadion Berlin

- OSM: Gebäude als ein Polygon mit Lücke (Marathontor), Laufbahn als Relation, Höhe 21 m. **Weg 3b:** Ränge beginnen hinter der Laufbahn; ein Ring in zwei Ränge nach Tiefenanteil (45/55 %, 16°/28°); Sektoren ohne Gebäudetreffer entfallen → Dachring hat die Lücke; Laufbahn als Tartanring; Steckbrief `sunken: 12` (Gelände, Umfeld, Fassadenfuß 12 m über Rasen; Boden mit konvexem Loch, weil Earcut das Gebäudepolygon nicht trianguliert).
- Iterationen: Boden verdeckte den Innenraum (Loch nur konvex zuverlässig); **„Wand in der Luft"** = Fassade an der Innenkante des C-förmigen Polygons → Fassadenkanten nur außerhalb 1,3 × Laufbahnradius; **zwei verschobene Dachplatten** am Marathontor = Kompassname des Unterrangs ≠ Oberrang → Ränge eines Sektors über Blocknummer + Nähe (< 70 m) finden.

## Stand am Ende

Vier Stadien aus vier Grundtypen, ein Modul, vier Kameras (Spiel, Außen, Draufsicht, Sitzblick), Tag/Flutlicht, Steckbrief-Ebene mit je einem Wort für Ecken, Dach, Flutlicht, Pylone, Versenkung. Offen: Lauf über alle Vereine, Steckbrief-Tabelle je Verein, Editor-Integration (Orbit-Tab mit `design`), Feinarbeit (Fassadenraster, Dachträger, Bäume, Schriftzug über Blockgrenzen im Editor), Zuschauer.
