"""Rendert das Standbild-Duo headless (Chromium + SwiftShader) und baut das Vergleichsbild."""
import http.server, json, sys, threading, time, os
from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw, ImageFont

ROOT = Path('/home/claude/stage'); OUT = ROOT / 'out'; OUT.mkdir(exist_ok=True)
PORT = 8765
import os; SUFFIX = os.environ.get('SUFFIX', '')
SCENES = [('bvb', 'Signal Iduna Park · Borussia Dortmund'), ('elversberg', 'URSAPHARM-Arena · SV Elversberg')]
if os.environ.get('ONLY'): SCENES = [(os.environ['ONLY'], os.environ['ONLY'])]


class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass


def serve():
    srv = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), lambda *a, **k: Quiet(*a, directory=str(ROOT), **k))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def render(extra_query=''):
    srv = serve()
    results = {}
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        for key, _ in SCENES:
            pg = b.new_page(viewport={'width': 1880, 'height': 940})
            logs = []
            pg.on('console', lambda m: logs.append(m.text))
            pg.on('pageerror', lambda e: logs.append('PAGEERROR ' + str(e)))
            pg.goto(f'http://127.0.0.1:{PORT}/index.html?scene=scenes/{key}{SUFFIX}.json{extra_query}')
            pg.wait_for_function('window.__stage !== undefined', timeout=120000)
            st = pg.evaluate('window.__stage')
            corners = pg.evaluate('[[-52.5,-34],[52.5,-34],[52.5,34],[-52.5,34],[0,0]].map(p=>{const r=window.__stage.project(p[0],p[1],0);return [Math.round(r.x*10)/10, Math.round(r.y*10)/10]})')
            st = {**st, 'pitchPx': corners}
            pg.wait_for_timeout(300)
            pg.locator('#stage').screenshot(path=str(OUT / f'{key}.png'))
            results[key] = {'stage': {k: v for k, v in st.items() if k != 'project'}, 'logs': logs[:8]}
            pg.close()
        b.close()
    srv.shutdown()
    return results


def compose():
    imgs = [Image.open(OUT / f'{k}.png').convert('RGB') for k, _ in SCENES]
    w, h = imgs[0].size
    pad, head = 24, 60
    canvas = Image.new('RGB', (w * 2 + pad * 3, h + head + pad * 2), (6, 9, 13))
    d = ImageDraw.Draw(canvas)
    try:
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 30)
        small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 22)
    except OSError:
        font = small = ImageFont.load_default()
    d.text((pad, 16), 'Standbild-Duo — dieselbe Kamera, kein Auto-Fit, das Feld ist der Maßstab', fill=(223, 230, 238), font=font)
    for i, (key, title) in enumerate(SCENES):
        x = pad + i * (w + pad)
        canvas.paste(imgs[i], (x, head + pad))
        d.text((x + 6, head + pad + h - 34), title, fill=(200, 210, 220), font=small)
    canvas.save(OUT / 'duo.png')
    small_img = canvas.resize((canvas.width // 2, canvas.height // 2), Image.LANCZOS)
    small_img.save(OUT / 'duo_half.png')


if __name__ == '__main__':
    res = render(sys.argv[1] if len(sys.argv) > 1 else '')
    print(json.dumps(res, indent=1, ensure_ascii=False))
    compose()
    print('ok', OUT)
