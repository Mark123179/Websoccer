from lib import *
import unicodedata, difflib
FMI=json.load(open('fmi.json')); RAW=json.load(open('fmi_match_raw.json'))
MON={m:i+1 for i,m in enumerate(['January','February','March','April','May','June','July','August','September','October','November','December'])}
def fmi_info(page):
    d={}
    for line in page.get('info',[]):
        if ':' in line:
            k,v=line.split(':',1); d[k.strip()]=v.strip()
    return d
def fmi_dob(page):
    m=re.match(r'(\d{1,2}) (\w+) (\d{4})',fmi_info(page).get('Date of birth',''))
    return dt.date(int(m.group(3)),MON[m.group(2)],int(m.group(1))) if m else None
def norm(s):
    s=s.replace('ß','ss').replace('ø','o').replace('ı','i').replace('ð','d').replace('æ','ae')
    s=unicodedata.normalize('NFKD',s); s=''.join(c for c in s if not unicodedata.combining(c)).lower()
    return ' '.join(re.sub(r'[^a-z ]+',' ',s).split())
def tmfull(pid):
    p=TM['players'][pid]['profile']['info']
    return (p.get('Name im Heimatland:',{}).get('text') or p.get('Vollständiger Name:',{}).get('text') or '')
def fmi_age(page):
    try: return int(fmi_info(page).get('Age'))
    except Exception: return None
def fmi_for(pid):
    """Zuordnung TM -> FMInside. Geburtsdatum, wenn FMInside eines zeigt; sonst Name + Alter (+ Nation).
    Liefert (key, basis, hinweis)"""
    b=base(pid); a=age(b['dob']); names=[norm(b['name'])]; f=norm(tmfull(pid))
    if f: names.append(f)
    toks=set(' '.join(names).split())
    scored=[]
    for key,pg in FMI['pages'].items():
        if not pg or pg.get('status')!=200: continue
        inf=fmi_info(pg); fn=[norm(inf.get('Name',''))]
        if inf.get('Full name'): fn.append(norm(inf['Full name']))
        r=max(difflib.SequenceMatcher(None,x,y).ratio() for x in names for y in fn)
        ftoks=set(' '.join(fn).split())
        subset=bool(ftoks) and (set(fn[0].split())<=toks)
        if r<0.85 and not subset: continue
        d=fmi_dob(pg); fa=fmi_age(pg)
        if d is not None:
            if d!=b['dob']: continue
            basis='dob'
        else:
            if fa not in (a,a-1): continue
            basis='name_age'
        nat_ok=any(n.lower() in pg.get('hero','').lower() for n in NATEN.get(b['nat'][0],[b['nat'][0]])) if b['nat'] else None
        scored.append((r,key,basis,nat_ok,inf.get('Name')))
    scored.sort(reverse=True)
    if not scored: return None,None,None
    if len(scored)>1 and scored[0][2]!='dob':
        strict=[s for s in scored if s[3]]
        if len(strict)==1: return strict[0][1],strict[0][2],'mehrere Namensgleiche, über Nation entschieden'
        return scored[0][1],scored[0][2],'MEHRDEUTIG: %s'%[(s[1],s[3]) for s in scored]
    return scored[0][1],scored[0][2],(None if scored[0][2]=='dob' else 'ohne Geburtsdatum bei FMInside, Abgleich über Name und Alter (Nation %s)'%('passt' if scored[0][3] else 'nicht geprüft'))
NATEN={'Deutschland':['Germany'],'Schweiz':['Switzerland'],'Österreich':['Austria'],'Frankreich':['France'],'Italien':['Italy'],'Luxemburg':['Luxembourg'],'Griechenland':['Greece'],'Algerien':['Algeria'],'Belgien':['Belgium'],'Brasilien':['Brazil'],'Ecuador':['Ecuador'],'England':['England'],'Vereinigte Staaten':['United States'],'Polen':['Poland'],'Japan':['Japan'],'Angola':['Angola'],'Niederlande':['Netherlands'],'Guinea':['Guinea'],'Türkei':['Turkey','Türkiye'],'Norwegen':['Norway'],'Schweden':['Sweden'],'Portugal':['Portugal'],'Kroatien':['Croatia'],'Island':['Iceland'],'Marokko':['Morocco']}
if __name__=='__main__':
    miss=[]
    for pid in TM['players']:
        b=base(pid); k,st,h=fmi_for(pid)
        if k: print('OK ',b['name'],'->',k,st,h or '')
        if not k: miss.append((b['name'],str(b['dob']),'+'.join(MEMB[pid]) or 'loan', [ (x[3],str(fmi_dob(FMI['pages'][x[3]])) if FMI['pages'].get(x[3]) else None) for x in RAW.get(pid,[])[:2]]))
        
    print('ohne FMI:',len(miss))
    for m in miss: print('  ',m)

MAXMV=3_000_000
def profile_nat(pid):
    """(Teamname, Länderspiele) laut TM-Profilkopf"""
    p=TM['players'].get(pid,{}).get('profile')
    if not p: return None,None
    team=None; caps=None
    for it in p['headerItems']:
        t=it['text']
        if 'Nationalspieler:' in t: team=t.split(':',1)[1].strip()
        if t.startswith('Länderspiele/Tore:'):
            m=re.search(r'(\d+)\s*/',t); caps=int(m.group(1)) if m else None
    return team,caps
def is_youth_international(pid):
    team,caps=profile_nat(pid)
    ev=[]
    if team and re.search(r'U\d\d',team) and (caps or 0)>=1: ev.append('TM-Profil: %s, %s Länderspiele'%(team,caps))
    yn=Counter(g['comp'] for g in perf(pid) if g['state']=='played' and g['nat'] and g['ctype'] in YOUTH_NAT_CT)
    if yn: ev.append('Einsätze in U-Wettbewerben: '+', '.join('%s×%s'%(n,COMPS[c]['name']) for c,n in yn.items()))
    return ev
def first_team_apps(pid):
    out=Counter()
    for g in perf(pid):
        if g['state']=='played' and not g['nat'] and g['ctype'] in PRO_CT:
            nm=CLUBNAME.get(str(g['club']))
            if nm and NONFIRST.search(nm): continue
            out[(str(g['club']),nm,COMPS[g['comp']]['name'])]+=1
    return out
def u21_pool():
    pool={}
    for k in ['u23','u19','u17']:
        for r in TM['squads'][k]['rows']:
            pid=r['id']
            if pid in pool: continue
            b=base(pid); a=age(b['dob'])
            if a<16 or a>21: continue
            if (b['mv'] or 0)>MAXMV: continue
            if 'first' in MEMB[pid] and not (set(MEMB[pid])&{'u23','u19'}): continue
            team=[x for x in MEMB[pid] if x!='first'][0]
            pool[pid]=dict(b,age=a,team=team,double='first' in MEMB[pid],loan_in=pid in LOAN_IN)
    return pool
def gem_check(pid,b):
    crit=[]; ev={}
    if b['age']<=18 and (b['mv'] or 0)>=1_000_000:
        crit.append('early_value'); ev['early_value']='%d Jahre, Marktwert %s €'%(b['age'],b['mv'])
    yi=is_youth_international(pid); fa=first_team_apps(pid)
    if yi and fa:
        crit.append('youth_international'); ev['youth_international']={'junioren':yi,'profieinsaetze':['%s× %s (%s)'%(n,nm or 'Verein %s'%cid,comp) for (cid,nm,comp),n in fa.items()]}
    return crit,ev
def select():
    pool=u21_pool(); quota={'TOR':2,'ABW':6,'MIT':7,'ANG':5}
    for pid,b in pool.items():
        po=positions(pid,b['pos']); b['positions']=po; b['group']=GROUP.get(po['main'][0]) if po['main'] else None
        b['min26']=minutes(pid); k,basis,h=fmi_for(pid) if pid in TM['players'] else (None,None,None); b['fmi']=k
        b['gem'],b['gem_ev']=gem_check(pid,b)
    chosen=[]; log=[]
    for grp,q in quota.items():
        gems=[p for p,b in pool.items() if b['group']==grp and b['gem']]
        gems.sort(key=lambda p:(-(pool[p]['mv'] or 0),-pool[p]['min26']))
        take=gems[:q]
        for p in take: chosen.append((p,'gem'))
        rest=q-len(take)
        for team in ['u23','u19','u17']:   # E71: U17 nach der U19
            c=[p for p,b in pool.items() if b['group']==grp and b['team']==team and not b['gem']]
            c.sort(key=lambda p:(-(pool[p]['mv'] or 0),-pool[p]['min26']))
            for p in c:
                if rest<=0: log.append((grp,pool[p]['name'],team,'Reserve')); continue
                if not pool[p]['fmi']: log.append((grp,pool[p]['name'],team,'übersprungen: kein FMInside (E59)')); continue
                chosen.append((p,'filler:'+team)); rest-=1
        if rest>0: log.append((grp,'—','—','%d Platz/Plätze bleiben leer'%rest))
    return pool,chosen,log
if __name__=='__main__':
    pool,chosen,log=select()
    print('\n=== U21-Auswahl ===')
    for p,why in chosen:
        b=pool[p]; print('%-4s %-24s %s %2d J. MW %-8s %-4s HP %-10s min26 %-4s FMI %-5s %s %s %s'%(b['group'],b['name'],b['dob'],b['age'],b['mv'],b['team'],'/'.join(b['positions']['main']),b['min26'],'ja' if b['fmi'] else 'NEIN',why,'DOPPELT' if b['double'] else '','LEIHE' if b['loan_in'] else ''), b['gem'] or '')
    print(len(chosen))
    for l in log: print('  ',l)
    print('Gems im Pool:',[(pool[p]['name'],pool[p]['gem'],pool[p]['gem_ev']) for p in pool if pool[p]['gem']])
    print('ohne Gruppe:',[(b['name'],b['pos']) for b in pool.values() if not b['group']])
