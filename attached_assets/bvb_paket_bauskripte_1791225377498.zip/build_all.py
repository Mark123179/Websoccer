import os, hashlib, zipfile, io
from build_players import *
X=json.load(open('tmx.json')); R=json.load(open('recherche.json')); P=TM['club']['pages']
TMU='https://www.transfermarkt.de'
def src(name,url): return {'name':name,'url':url,'checked_at':CHK}
gaps=[]
def gap(entity,ref,field,severity,note): gaps.append(dict(entity=entity,ref=ref,field=field,severity=severity,note=note))

# ---------------- CMTracker Nachwuchs (Server-Abruf) ----------------
CMTU=json.load(open('cmt_u21.json')) if os.path.exists('cmt_u21.json') else None
cmt_extra=[]
if CMTU:
    for d,l in CMTU['hits_by_dob'].items():
        for p in l:
            p=dict(p); p['_db']=CMTU['db_used']; cmt_extra.append(p)

# ---------------- Verein ----------------
club={'name':'Borussia Dortmund','official_name':R['club']['official_name'],'short_name':'BVB','founded_year':1909,'city':'Dortmund','country':'Deutschland',
 'lat':R['stadium']['lat'],'lng':R['stadium']['lng'],
 'colors':{'primary':'#FFD900','secondary':'#000000','tertiary':None},
 'nickname':'Die Schwarzgelben','motto':'Echte Liebe',
 'ids':{'fmi':{'value':907,'status':'gefunden','checked_at':CHK},'tm':{'value':16,'status':'gefunden','checked_at':CHK},
        'cmtracker':{'value':int(CMT['team_id']),'status':'gefunden','checked_at':CHK},'api_football':{'value':165,'status':'gefunden','checked_at':CHK}},
 'sources':[dict(field='official_name / founded_year',**src('bvb.de','https://www.bvb.de/de/de/der-bvb/der-verein.html')),
            dict(field='founded_year',**src('wikipedia','https://de.wikipedia.org/wiki/Borussia_Dortmund')),
            dict(field='lat/lng (Stadionkoordinaten)',**src('wikipedia','https://de.wikipedia.org/wiki/Signal_Iduna_Park')),
            dict(field='colors.primary',**src('bvb.de (Stylesheet, --color-primary-1)','https://www.bvb.de/')),
            dict(field='nickname',**src('wikipedia','https://en.wikipedia.org/wiki/Borussia_Dortmund')),
            dict(field='motto',**src('welt.de','https://www.welt.de/sport/fussball/article139395929/Wie-der-BVB-aus-echter-Liebe-echtes-Geld-macht.html')),
            dict(field='ids.cmtracker',**src('cmtracker (DB %s)'%CMT['db_used'],None)),
            dict(field='ids.api_football',**src('api-football (/players/squads?team=165)',None))]}
gap('club','tm:16','lat/lng','info','Koordinaten sind die des Stadions. Für die Geschäftsstelle (Rheinlanddamm 207-209) ist keine Quelle belegt.')
gap('club','tm:16','colors.primary','info','Kein offizielles Markenhandbuch gefunden. #FFD900 stammt aus dem bvb.de-Stylesheet; teamcolorcodes.com nennt #FDE100, Wikipedia #FFDD00. Keine dritte Vereinsfarbe belegt.')
gap('club','tm:16','motto','info','„Echte Liebe“ ist als Claim belegt (2015, Rebranding-Bericht), steht am 05.10.2026 aber auf keiner geprüften bvb.de-Seite. Kein neuerer offizieller Claim gefunden.')

# ---------------- Stadion (Stufe 2, belegte Einzelwerte haben Vorrang) ----------------
CAP=81365; STEH=28337; SITZ=53028; VIP=3668+168; SUED=24454
nord_steh=STEH-SUED; sitz_rest=SITZ-VIP
w={'N':21.25,'W':20.5,'E':25.0}; tot=sum(w.values())
n_sitz=int(sitz_rest*w['N']/tot); w_sitz=int(sitz_rest*w['W']/tot); e_sitz=sitz_rest-n_sitz-w_sitz
V=lambda v,b:{'value':v,'basis':b}
stadium={'name':'SIGNAL IDUNA PARK','city':'Dortmund','capacity_national':CAP,'home_end':'S','main_stand':'W',
 'stands':{'N':{'standing':V(nord_steh,'berechnet'),'seating':V(n_sitz,'berechnet'),'vip':V(0,'berechnet')},
           'E':{'standing':V(0,'belegt'),'seating':V(e_sitz,'berechnet'),'vip':V(0,'berechnet')},
           'S':{'standing':V(SUED,'belegt'),'seating':V(0,'belegt'),'vip':V(0,'belegt')},
           'W':{'standing':V(0,'belegt'),'seating':V(w_sitz,'berechnet'),'vip':V(VIP,'berechnet')}},
 'tier':2,
 'totals':{'standing':V(STEH,'belegt'),'seating_incl_vip':V(SITZ,'belegt'),'vip':V(VIP,'belegt')},
 'lat':R['stadium']['lat'],'lng':R['stadium']['lng'],
 'sources':[dict(field='capacity_national',**src('bvb.de','https://www.bvb.de/de/de/signal-iduna-park.html')),
            dict(field='capacity_national (Saison 2026/27)',**src('bundesliga.com','https://www.bundesliga.com/en/bundesliga/news/stadiums-germany-2026-27-munich-dortmund-37962')),
            dict(field='stands.S.standing',**src('bvb.de','https://www.bvb.de/de/de/der-bvb/die-bvb-historie/signal-iduna-park.html')),
            dict(field='totals.standing / totals.seating_incl_vip',**src('fansicht.com','https://www.fansicht.com/stadionbilder/westfalenstadion-dortmund/')),
            dict(field='totals.standing / totals.seating_incl_vip',**src('worldstadia.com','https://worldstadia.com/de/signal-iduna-park-4.html')),
            dict(field='totals.vip (3.668 Business Seats + 168 Logenplätze)',**src('bulitickets.net','https://bulitickets.net/klubs/borussia-dortmund/')),
            dict(field='home_end / Blockplan',**src('bvb.de','https://www.bvb.de/de/de/signal-iduna-park/stadionbesuch/stadionplan.html')),
            dict(field='main_stand',**src('wikipedia','https://de.wikipedia.org/wiki/Signal_Iduna_Park')),
            dict(field='stands.E.standing / stands.W.standing (keine Stehblöcke)',**src('fansicht.com','https://www.fansicht.com/stadionbilder/westfalenstadion-dortmund/'))]}
assert sum(s[k]['value'] for s in stadium['stands'].values() for k in s)==CAP
gap('club','stadium','stands','info','Stufe 2 mit belegten Einzelwerten: Süd 24.454 Stehplätze, Ost und West ohne Stehplätze sind belegt. Nord-Stehplätze = 28.337 − 24.454 = 3.883 (berechnet). Sitzplätze ohne VIP (49.192) nach Profil auf Nord, West, Ost verteilt (21,25 : 20,5 : 25), Rundungsrest auf Ost. VIP komplett auf der Haupttribüne West.')
gap('club','stadium','totals','info','Summen Steh (28.337) und Sitz (53.028) nur über Drittseiten belegt, VIP (3.836) nur über bulitickets.net. Keine offizielle BVB- oder DFL-Zahl abrufbar. Sitz- und VIP-Plätze je Tribüne sind nirgends veröffentlicht.')
gap('club','stadium','stands.S.standing','info','Südtribüne: bvb.de und Wikipedia nennen 24.454, signal-iduna-park.de und WELT (11.12.2025) 24.457. Übernommen: 24.454.')

# ---------------- Spieler ----------------
pool,chosen,log=select()
players=[]; first_ids=[]
def add(pid,team,status,gem=None):
    o,g=build_player(pid,team,status,gem,cmt_extra)
    players.append(o); gaps.extend(g); return o
u21_ids=[p for p,_ in chosen]
for r in TM['squads']['first']['rows']:
    pid=r['id']
    if pid in u21_ids: continue          # E67: doppelt gelistet und innerhalb der U21-Grenzen
    add(pid,'first','loaned_in' if pid in LOAN_IN else 'own'); first_ids.append(pid)
for pid,(k,r) in LOAN_OUT.items():
    if k=='first': add(pid,'first','loaned_out'); first_ids.append(pid)
for pid,why in chosen:
    b=pool[pid]
    gem={'criteria':b['gem'],'evidence':b['gem_ev'],'sources':[src('transfermarkt',TMU+TM['players'][pid]['href'])]} if b['gem'] else None
    o=add(pid,'u21','loaned_in' if pid in LOAN_IN else 'own',gem)
    o['squad']['u21_source']={'u23':'Borussia Dortmund II','u19':'Borussia Dortmund U19'}[b['team']]
    o['squad']['u21_reason']='gem' if b['gem'] else 'filler'
    o['squad']['position_group']=b['group']
    o['squad']['double_listed']=b['double']
    if not b['double']:
        nr=squadrow(b['team'],pid)['cells'][0]
        o['squad']['shirt_number']=int(nr) if nr.isdigit() else None
for pid,(k,r) in LOAN_OUT.items():
    if k!='first':
        b=base(pid)
        if 16<=age(b['dob'])<=21 and (b['mv'] or 0)<=MAXMV:
            o=add(pid,'u21','loaned_out'); o['squad']['u21_source']='Borussia Dortmund II'; o['squad']['u21_reason']='loaned_out'; o['squad']['position_group']=GROUP.get(o['positions']['main'][0]); o['squad']['double_listed']=False
for o in players:
    if o['squad']['status']=='loaned_out': o['squad']['shirt_number']=None
    for t in o['transfers']:
        if t['fee_text']: t['fee_text']=re.sub(r'\s+',' ',re.sub(r'<[^>]+>',' ',t['fee_text'])).strip()
# Lücken je Spieler nach E40 / E58 / E59
cmt_scan = bool(CMTU and CMTU.get('complete'))
cmt_n = sum((CMTU.get('counts_by_rating') or CMTU.get('counts_by_dob') or {}).values()) if CMTU else 0
for o in players:
    ref='tm:%s'%o['ids']['tm']['value']; first=o['squad']['team']=='first'; nm=o['display_name']
    if o['ids']['fmi']['status']!='gefunden':
        if first: gap('player',ref,'ids.fmi','blocking','%s: kein FMInside-Eintrag gefunden.'%nm)
        elif o.get('gem'): gap('player',ref,'ids.fmi','player_lock','%s: Gem ohne FMInside-Eintrag. Erstellt, aber einzeln gesperrt, bis Werte vorliegen (E59). Gesucht über Vereinsseite, Namenssuche und Suche beim abgebenden Verein.'%nm)
        else: gap('player',ref,'ids.fmi','player_lock','%s: ohne FMInside-Eintrag, einzeln gesperrt (E59).'%nm)
    if o['ids']['cmtracker']['status']!='gefunden':
        if first: gap('player',ref,'ids.cmtracker','blocking','%s: in CMTracker (DB %s) nicht gefunden.'%(nm,CMT['db_used']))
        elif cmt_scan:
            o['ids']['cmtracker']['status']='nicht_vorhanden'
            o['ids']['cmtracker']['proof']='DB %s am %s über alle Stärkestufen abgefragt (%s Spieler, Modus: %s). Kein Eintrag mit diesem Geburtsdatum und Namen.'%(CMTU['db_used'],CMTU['fetched_at'][:10],cmt_n,CMTU['mode'])
        else: gap('player',ref,'ids.cmtracker','info','%s: CMTracker-Nachweis über Name + Geburtsdatum steht noch aus (Server-Abruf).'%nm)
    gap('player',ref,'ids.api_football','info','%s: API-Football-Zuordnung folgt mit dem bezahlten Plan (E50).'%nm)
# doppelte Rückennummern in der U21
_nr=Counter(o['squad']['shirt_number'] for o in players if o['squad']['team']=='u21' and o['squad']['shirt_number'] is not None)
for n_,k_ in _nr.items():
    if k_>1: gap('club','u21','squad.shirt_number','info','Rückennummer %d ist in der U21 doppelt vergeben (%s). Die Nummern stammen aus verschiedenen Nachwuchsteams.'%(n_,', '.join(o['display_name'] for o in players if o['squad']['team']=='u21' and o['squad']['shirt_number']==n_)))
# U21-Protokoll
for grp,name,team,what in log:
    if name=='—': gap('club','u21','squad','info','U21 %s: %s. Kein weiterer Kandidat aus U23, U19 oder U17 mit FMInside-Eintrag innerhalb der Grenzen (E57, E59, E71).'%({'TOR':'Tor','ABW':'Abwehr','MIT':'Mittelfeld','ANG':'Angriff'}[grp],what))
    elif what.startswith('übersprungen'): gap('club','u21','squad','info','U21-Auffüller %s (%s) übersprungen: kein FMInside-Eintrag (E59).'%(name,team.upper()))
gap('club','u21','gems','info','Talentlisten geprüft: Golden Boy 2026 Top 100 (Karetsas, Reggiani, Gadou, Inácio) und FM26-Wonderkids (Bellingham, Albert) liegen alle über 3 Mio. € und stehen in der 1. Mannschaft. Guardian Next Generation 2025 war nicht abrufbar (Seite gesperrt), die Ausgabe 2026 war am Erhebungstag nicht veröffentlicht.')
json.dump({'players':players},open('_players_tmp.json','w'),ensure_ascii=False)

# ---------------- Personen, Rekorde, Titel ----------------
persons=[]; _pref={}
def person(name,nat,tm_id,tm_type='spieler',fmi_id=None):
    key=(tm_type,tm_id)
    if key not in _pref:
        _pref[key]='p%d'%(len(persons)+1)
        persons.append({'ref':_pref[key],'name':name,'nationality':nat,'tm_id':tm_id,'tm_type':tm_type,'fmi_id':fmi_id})
    return {'person_ref':_pref[key]}
def coach_nat(cid_):
    m=X['misc'].get(cid_)
    if m:
        for h in m['header']:
            if h['text'].startswith('Staatsbürgerschaft'): return h['text'].split(':',1)[1].strip().split('  ')[0]
    return None
records=[]
def rec(key,basis,value_numeric,value_display,holder=None,opponent=None,date=None,period_from=None,period_to=None,season=None,competition=None,context=None,sources=None,status='belegt',searched=None):
    records.append({'key':key,'origin':'real','basis':basis,'status':status,'value_numeric':value_numeric,'value_display':value_display,'holder':holder,'opponent':opponent,'date':date,'period_from':period_from,'period_to':period_to,'season':season,'competition':competition,'context':context,'sources':sources or [],'searched':searched or []})
RS=P['rekordspieler']['tables'][0]['rows']; TS=P['toptorschuetzen']['tables'][0]['rows']
def prow(row): 
    l=[x for x in row['links'] if '/profil/spieler/' in x][0]; return int(l.split('|')[0].split('/')[-1]), l.split('|')[1]
# Spieler
pid_,nm=prow(TS[0]); c=TS[0]['cells']
rec('top_scorer','all_competitive',int(c[7]),'%s Tore in %s Spielen'%(c[7],c[4]),person(nm,'Deutschland',pid_),context='Alle Wettbewerbe laut Transfermarkt. Wikipedia nennt 177 (en) bzw. 168 (de).',sources=[src('transfermarkt',TMU+'/borussia-dortmund/toptorschuetzen/verein/16')])
a=X['misc']['assists_sorted']['rows'][0]; aid=int(a['links'][0].split('/')[-1])
rec('top_assists','all_competitive',int(a['cells'][6]),'%s Vorlagen in %s Spielen'%(a['cells'][6],a['cells'][4]),person('Marco Reus','Deutschland',aid,fmi_id=91013383),period_from='2012-07-01',period_to='2024-06-30',context='Vorlagen sind bei Transfermarkt für frühere Jahrzehnte nicht vollständig erfasst. fussballdaten.de nennt 107.',sources=[src('transfermarkt',TMU+X['misc']['assists_sorted']['url'])])
pid_,nm=prow(RS[0]); c=RS[0]['cells']
rec('most_apps_field','all_competitive',int(c[4]),'%s Pflichtspiele'%c[4],person(nm,'Deutschland',pid_),period_from='1981-07-01',period_to='1998-06-30',context='fussballdaten.de nennt 569.',sources=[src('transfermarkt',TMU+'/borussia-dortmund/rekordspieler/verein/16')])
gkrow=[r for r in RS if 'Weidenfeller' in r['cells'][1]][0]; pid_,nm=prow(gkrow)
rec('most_apps_gk','all_competitive',int(gkrow['cells'][4]),'%s Pflichtspiele'%gkrow['cells'][4],person(nm,'Deutschland',pid_),period_from='2002-07-01',period_to='2018-06-30',context='Bestplatzierter Torwart in der Rekordspieler-Liste (Rang %s).'%gkrow['cells'][0],sources=[src('transfermarkt',TMU+'/borussia-dortmund/rekordspieler/verein/16')])
rec('most_titles_player','all_competitive',8,'8 Titel',person('Michael Zorc','Deutschland',38033),context='Gezählt: Meisterschaft, DFB-Pokal, Supercup, Champions League, Weltpokal mit dem BVB. Gleichauf mit je 8 Titeln: Andreas Möller, Marcel Schmelzer, Łukasz Piszczek. Zorc: 2× Meister, 1× Pokal, 3× Supercup, Champions League, Weltpokal.',sources=[src('transfermarkt',TMU+'/michael-zorc/erfolge/spieler/38033'),src('transfermarkt',TMU+'/andreas-moller/erfolge/spieler/124'),src('transfermarkt',TMU+'/marcel-schmelzer/erfolge/spieler/35208'),src('transfermarkt',TMU+'/lukasz-piszczek/erfolge/spieler/25727')])
gap('record','most_titles_player','holder','info','Vier Spieler liegen mit 8 Titeln gleichauf (Zorc, Möller, Schmelzer, Piszczek). Als Halter eingetragen ist Zorc, die anderen stehen im Kontext. Geprüft wurden die 30 Spieler mit den meisten Einsätzen.')
hl=[e for e in X['mv']['haaland']['data']['list'] if e['verein']=='Borussia Dortmund']; he=max(hl,key=lambda e:e['y'])
rec('highest_market_value','all_competitive',int(he['y']),'150,00 Mio. €',person('Erling Haaland','Norwegen',418560,fmi_id=29179241),date=str(pdate(he['datum_mw'])),context='Höchster Transfermarkt-Marktwert eines Spielers während seiner Zeit beim BVB. Dahinter Jadon Sancho (130 Mio. €, 2020) und Jude Bellingham (120 Mio. €, 2023).',sources=[src('transfermarkt',TMU+'/erling-haaland/marktwertverlauf/spieler/418560')])
rec('youngest_player','all_competitive',(dt.date(2020,11,21)-dt.date(2004,11,20)).days,'16 Jahre, 1 Tag',person('Youssoufa Moukoko','Deutschland',467720,fmi_id=2000074825),opponent={'tm_id':44,'name':'Hertha BSC'},date='2020-11-21',season='2020/21',competition='Bundesliga',context='Wert in Tagen. Erster Pflichtspieleinsatz für die 1. Mannschaft, zugleich Bundesliga-Rekord.',sources=[src('transfermarkt',TMU+'/youssoufa-moukoko/leistungsdatendetails/spieler/467720'),src('bundesliga.com / wikipedia','https://en.wikipedia.org/wiki/Borussia_Dortmund')])
# Trainer
MH=P['mitarbeiterhistorie']['tables'][0]['rows']
def mrow(name): return [r for r in MH if r['cells'][0].startswith(name)][0]['cells']
k=mrow('Jürgen Klopp'); klopp=person('Jürgen Klopp','Deutschland',118,'trainer')
MHU=TMU+'/borussia-dortmund/mitarbeiterhistorie/verein/16/personalie_id/1/plus/1'
rec('longest_tenure','all_competitive',(pdate(k[3])-pdate(k[2])).days,'7 Jahre',klopp,period_from=str(pdate(k[2])),period_to=str(pdate(k[3])),context='Wert in Tagen.',sources=[src('transfermarkt',MHU)])
rec('most_matches_coach','all_competitive',int(k[5]),'%s Pflichtspiele'%k[5],klopp,period_from=str(pdate(k[2])),period_to=str(pdate(k[3])),context='Wikipedia (en) nennt 318.',sources=[src('transfermarkt',MHU)])
rec('most_wins_coach','all_competitive',int(k[6]),'%s Siege in %s Spielen'%(k[6],k[5]),klopp,period_from=str(pdate(k[2])),period_to=str(pdate(k[3])),context='Wikipedia (en) nennt 180.',sources=[src('transfermarkt',MHU)])
rec('most_titles_coach','all_competitive',5,'5 Titel',person('Ottmar Hitzfeld','Deutschland',92,'trainer'),period_from='1991-07-01',period_to='1997-06-30',context='Hitzfeld: 2× Meister, 2× Supercup, Champions League. Gleichauf: Jürgen Klopp mit 2× Meister, 1× DFB-Pokal, 2× Supercup.',sources=[src('transfermarkt',TMU+'/borussia-dortmund/erfolge/verein/16'),src('transfermarkt',MHU),src('wikipedia','https://en.wikipedia.org/wiki/List_of_Borussia_Dortmund_records_and_statistics')])
gap('record','most_titles_coach','holder','info','Hitzfeld und Klopp liegen mit je 5 Titeln gleichauf. Als Halter eingetragen ist Hitzfeld (zuerst erreicht).')
def cgames(cid_):
    c=X['coach'][str(cid_)]; t=[t for t in c['tables'] if t['head'] and t['head'][0]=='Datum'][0]; out=[]
    for r in t['rows']:
        cc=r['cells']; m=re.match(r'(\d+):(\d+)(.*)',cc[6])
        if not m: continue
        home='Dortmund' in cc[4]; h,a=int(m.group(1)),int(m.group(2))
        out.append(dict(date=pdate(cc[0]),comp=r['titles'][1] if len(r['titles'])>1 else None,gf=h if home else a,ga=a if home else h,suffix=m.group(3)))
    return out
kv=[g for g in cgames(10463) if g['comp']=='Bundesliga']; w=sum(g['gf']>g['ga'] for g in kv); d=sum(g['gf']==g['ga'] for g in kv)
tu=[g for g in cgames(7471) if g['comp']=='Bundesliga']; tw=sum(g['gf']>g['ga'] for g in tu); td=sum(g['gf']==g['ga'] for g in tu)
ppg=round((3*w+d)/len(kv),2)
rec('best_ppg_coach','league',ppg,('%.2f'%ppg).replace('.',',')+' Punkte je Spiel (%d Bundesliga-Spiele: %d S, %d U, %d N)'%(len(kv),w,d,len(kv)-w-d),person('Niko Kovač','Kroatien',10463,'trainer'),period_from='2025-02-02',period_to=None,competition='Bundesliga',context='Nur Bundesliga, mindestens 30 Ligaspiele. Kovač ist im Amt, der Wert ändert sich mit jedem Spiel (Stand 05.10.2026). Bester abgeschlossener Wert: Thomas Tuchel %s (%d Spiele).'%(('%.2f'%((3*tw+td)/len(tu))).replace('.',','),len(tu)),sources=[src('transfermarkt',TMU+'/trainer/leistungsdatenDetail?id=10463&verein_id=16'),src('bundesliga.com','https://www.bundesliga.com/de/bundesliga/news/besserer-punkteschnitt-als-klopp-hitzfeld-und-co-kovac-lasst-alle-hinter-sich-39065')])
gap('record','best_ppg_coach','value_numeric','info','Halter Niko Kovač ist amtierender Trainer, der Punkteschnitt ändert sich laufend. Ligaspiele = nur Bundesliga (Oberliga West vor 1963 nicht mitgezählt).')
BVBN='https://www.bvb.de/de/de/aktuelles/news/news.html/News/Uebersicht/8-und-11-die-Rekordserien-der-Schwarzgelben.html'
rec('longest_win_streak_coach','all_competitive',11,'11 Pflichtspielsiege in Folge',person('Thomas Tuchel','Deutschland',7471,'trainer'),period_from='2015-07-30',period_to='2015-09-20',season='2015/16',context='4× Europa-League-Qualifikation, 1× Europa League, 1× DFB-Pokal, 5× Bundesliga. Aus der TM-Spielliste nachgerechnet.',sources=[src('transfermarkt',TMU+'/trainer/leistungsdatenDetail?id=7471&verein_id=16'),src('bvb.de',BVBN)])
# Verein
RSP=P['rekordspiele']['tables']; RSU=TMU+'/borussia-dortmund/rekordspiele/verein/16'
def game(row):
    c=row['cells']; l=[x for x in row['links'] if '/verein/' in x][0]
    return dict(date=str(pdate(c[1])),comp=c[4],round=c[3],opp={'tm_id':int(re.search(r'/verein/(\d+)',l).group(1)),'name':c[7]},res=c[9],venue=c[5])
g=game(RSP[0]['rows'][0]); a_,b_=map(int,g['res'].split(':')[:2])
rec('biggest_win','all_competitive',a_-b_,g['res'],opponent=g['opp'],date=g['date'],season='1978/79',competition=g['comp'],context='%s, Heimspiel. Höchster Bundesliga-Sieg: 11:1 gegen Arminia Bielefeld (06.11.1982).'%g['round'],sources=[src('transfermarkt',RSU)])
g=game(RSP[1]['rows'][0]); a_,b_=map(int,g['res'].split(':')[:2])
rec('biggest_defeat','all_competitive',abs(a_-b_),'0:12',opponent=g['opp'],date=g['date'],season='1977/78',competition=g['comp'],context='34. Spieltag, auswärts (Rheinstadion Düsseldorf).',sources=[src('transfermarkt',RSU),src('bundesliga.com','https://www.bundesliga.com/de/bundesliga/news/rekorde-tore-meisterschaft-historie-bestmarken-spieler-meiste-3235')])
rec('longest_win_streak','all_competitive',11,'11 Pflichtspielsiege in Folge',period_from='2015-07-30',period_to='2015-09-20',season='2015/16',context='Vereinsrekord laut bvb.de (Stand 07.03.2023). In den TM-Spiellisten der Trainer bis 05.10.2026 nicht übertroffen. Längste Bundesliga-Serie: 8 Siege (2011/12, 2021, 2022/23).',sources=[src('bvb.de',BVBN),src('transfermarkt',TMU+'/trainer/leistungsdatenDetail?id=7471&verein_id=16')])
rec('longest_unbeaten','league',31,'31 Bundesliga-Spiele ohne Niederlage',season='2011/12 bis 2012/13',competition='Bundesliga',context='Ab dem 7. Spieltag 2011/12. Nur als Liga-Serie belegt.',sources=[src('bulibox.de','http://www.bulibox.de/bundesligarekorde/rekord_R241-108.html')],searched=['bvb.de','de.wikipedia.org','en.wikipedia.org','transfermarkt.de (keine Serien-Tabelle je Verein)'])
rec('longest_winless','league',14,'14 Bundesliga-Spiele ohne Sieg',season='1990/91',competition='Bundesliga',context='Spieltage 18 bis 31 der Saison 1990/91, später noch einmal 14 Spiele ab dem 18. Spieltag 1999/2000. Nur als Liga-Serie belegt.',sources=[src('bulibox.de','http://www.bulibox.de/bundesligarekorde/rekord_R242-108.html')],searched=['bvb.de','de.wikipedia.org','en.wikipedia.org','transfermarkt.de (keine Serien-Tabelle je Verein)'])
gap('record','longest_unbeaten','basis','info','Nur als Bundesliga-Serie belegt (31 Spiele). Ein Wert über alle Pflichtspiele (E15) ist nicht auffindbar.')
gap('record','longest_winless','basis','info','Nur als Bundesliga-Serie belegt (14 Spiele). Ein Wert über alle Pflichtspiele (E15) ist nicht auffindbar.')
seas=[]
for r in P['platzierungen']['tables'][0]['rows']:
    c=r['cells']
    if c[2]!='Bundesliga' or c[0]=='26/27': continue
    g_,u_,v_=int(c[4]),int(c[5]),int(c[6]); tf,ta=map(int,c[7].split(':'))
    seas.append(dict(season=season_long(c[0]),g=g_,u=u_,v=v_,tf=tf,ta=ta,pts=3*g_+u_,platz=c[10],n=g_+u_+v_))
PLU=TMU+'/borussia-dortmund/platzierungen/verein/16'
b=max(seas,key=lambda s:s['pts']); rec('best_season','league',b['pts'],'%d Punkte (%d S, %d U, %d N, %d:%d Tore)'%(b['pts'],b['g'],b['u'],b['v'],b['tf'],b['ta']),season=b['season'],competition='Bundesliga',context='Platz %s, %d Spiele.'%(b['platz'],b['n']),sources=[src('transfermarkt',PLU)])
b=min(seas,key=lambda s:s['pts']); rec('worst_season','league',b['pts'],'%d Punkte (%d S, %d U, %d N, %d:%d Tore)'%(b['pts'],b['g'],b['u'],b['v'],b['tf'],b['ta']),season=b['season'],competition='Bundesliga',context='Platz %s, Abstieg. Auf die 3-Punkte-Regel umgerechnet, real 20:48 Punkte.'%b['platz'],sources=[src('transfermarkt',PLU)])
b=max(seas,key=lambda s:s['tf']); rec('most_goals_season','league',b['tf'],'%d Tore'%b['tf'],season=b['season'],competition='Bundesliga',context='%d Spiele, Platz %s.'%(b['n'],b['platz']),sources=[src('transfermarkt',PLU)])
b=min(seas,key=lambda s:s['ta']); rec('fewest_conceded_season','league',b['ta'],'%d Gegentore'%b['ta'],season=b['season'],competition='Bundesliga',context='%d Spiele, Platz %s.'%(b['n'],b['platz']),sources=[src('transfermarkt',PLU)])
gap('record','best_season','basis','info','Die fünf Liga-Rekorde (E17) sind nur über Bundesliga-Saisons 1963/64 bis 2025/26 gerechnet. Oberliga West und 2. Bundesliga Nord zählen nicht mit.')
for key,page_,url in [('record_signing','transferrekorde','/borussia-dortmund/transferrekorde/verein/16'),('record_sale','rekordabgaenge','/borussia-dortmund/rekordabgaenge/verein/16')]:
    r=P[page_]['tables'][0]['rows'][0]; c=r['cells']
    pl=[x for x in r['links'] if '/profil/spieler/' in x][0]; cl=[x for x in r['links'] if '/startseite/verein/' in x][0]
    v=money(c[6])
    rec(key,'all_competitive',v,c[6],person(pl.split('|')[1],'Frankreich',int(pl.split('|')[0].split('/')[-1]),fmi_id=85140178),opponent={'tm_id':int(re.search(r'/verein/(\d+)',cl).group(1)),'name':cl.split('|')[1]},season=season_long(c[4]),context=('Zugang von' if key=='record_signing' else 'Abgang zu')+' '+cl.split('|')[1]+('.' if key=='record_signing' else '. Summe einschließlich Boni; de.wikipedia nennt 105 Mio. € garantiert.'),sources=[src('transfermarkt',TMU+url)])
gap('record','most_motm','value','info','„Meiste Spieler des Spiels“ hat laut E18 keinen Echtwert und steht nicht im Paket.')
# Titel
titles=[]
EU=TMU+'/borussia-dortmund/erfolge/verein/16'
TMT=json.load(open('tm_titel_alle.json'))
MAP={'Deutscher Meister':('Deutsche Meisterschaft','championship'),'Deutscher Pokalsieger':('DFB-Pokal','national_cup'),'Deutscher Superpokalsieger':('DFB-/DFL-Supercup','national_cup'),'UEFA Champions League-Sieger':('UEFA Champions League','international_cup'),'Europapokal-der-Pokalsieger-Sieger':('Europapokal der Pokalsieger','international_cup'),'Weltpokalsieger':('Weltpokal','international_cup'),'Aufstieg in die 1. Liga':('Aufstieg in die Bundesliga','lower_tier')}
for row in TMT:
    s_,t_=row[0],row[-1]
    if t_ in MAP and s_!='26/27':
        titles.append({'competition':{'name':MAP[t_][0],'fm_id':None,'category':MAP[t_][1]},'season':season_long(s_),'origin':'real','source_url':EU})
WU='https://de.wikipedia.org/wiki/Borussia_Dortmund/Zahlen_und_Fakten'
for t in R['titles']:
    if t['category']=='lower_tier' and not t.get('optional') and not t['competition'].startswith('Aufstieg'):
        titles.append({'competition':{'name':t['competition'],'fm_id':None,'category':'lower_tier'},'season':t['season'],'origin':'real','source_url':WU})
titles.sort(key=lambda t:(t['season'][:4],t['competition']['name']))
gap('club','titles','competition.fm_id','info','Die FM-Wettbewerbs-ID (Trophäenbild) ist für keinen Titel recherchiert und bleibt leer.')
gap('club','titles','lower_tier','info','Unterklassig aufgenommen: Westfalenmeister 1946/47, sechs Oberliga-West-Titel (Wikipedia) und der Aufstieg 1975/76 (TM). Nicht aufgenommen: sieben regionale Titel 1912 bis 1936 (nur Jahresangabe), DFB-Hallenpokal, Westdeutscher Pokal, Fuji-Cup, Liga total! Cup.')
gap('club','titles','national_cup','info','Supercup mit der TM-Saison geführt (z. B. Supercup 2019 = 2019/20). Der inoffizielle Supercup 2008 zählt nicht.')

# ---------------- Zusammenbau, Prüfung, ZIP ----------------
order={'first':0,'u21':1}; st={'own':0,'loaned_in':1,'loaned_out':2}
POSORD=['TW','IV','LV','RV','LOV','ROV','DM','ZM','LM','RM','OM','LOM','ROM','LF','RF','ST']
players.sort(key=lambda p:(order[p['squad']['team']],st[p['squad']['status']],POSORD.index(p['positions']['main'][0]) if p['positions']['main'] else 99,-(p['market_value_eur'] or 0)))
data={'club':club,'stadium':stadium,'players':players,'persons':persons,'records':records,'titles':titles,'gaps':gaps}
def check(data):
    errs=[]
    s=data['stadium']; tot=sum(s['stands'][k][t]['value'] for k in 'NESW' for t in ('standing','seating','vip'))
    if tot!=s['capacity_national']: errs.append('Stadionsumme %s != %s'%(tot,s['capacity_national']))
    ZW={'ROV','ROM','LOV','LOM'}; seen=set()
    for p in data['players']:
        n=p['display_name']; tm=p['ids']['tm']['value']
        if tm in seen: errs.append('doppelt: %s'%n)
        seen.add(tm)
        m,sx=p['positions']['main'],p['positions']['secondary']
        if not m: errs.append('%s ohne HP'%n)
        if len(m)>3 or len(sx)>3: errs.append('%s zu viele Positionen'%n)
        if len(m)==3 and m[2] not in ZW: errs.append('%s dritte HP %s'%(n,m[2]))
        if len(sx)==3 and sx[2] not in ZW: errs.append('%s dritte NP %s'%(n,sx[2]))
        if len([x for x in m if x not in ZW])>2 or len([x for x in sx if x not in ZW])>2: errs.append('%s mehr als 2 reguläre'%n)
        if set(m)&set(sx): errs.append('%s Position doppelt'%n)
        a=age(dt.date.fromisoformat(p['date_of_birth']))
        if a<16: errs.append('%s unter 16'%n)
        if p['squad']['team']=='u21':
            if a>21: errs.append('%s U21 über 21'%n)
            if (p['market_value_eur'] or 0)>3_000_000: errs.append('%s U21 über 3 Mio'%n)
        if p['squad']['status']=='loaned_in' and p['squad']['owner_club']['tm_id'] in (16,None): errs.append('%s Leihe ohne Stammverein'%n)
        if p['squad']['status']=='loaned_out' and not p['squad']['loan_club']: errs.append('%s verliehen ohne Leihverein'%n)
        for mv in p['market_values']:
            if mv['value_eur']==0: errs.append('%s Marktwert 0'%n)
        if p['squad']['team']=='first':
            for k in ('fmi','tm','cmtracker'):
                if p['ids'][k]['status']!='gefunden' and not any(g_['ref']=='tm:%s'%tm and g_['severity']=='blocking' and g_['field']=='ids.'+k for g_ in data['gaps']): errs.append('%s %s fehlt ohne sperrende Lücke'%(n,k))
    def walk(o,path=''):
        if isinstance(o,dict):
            for k,v in o.items(): walk(v,path+'/'+k)
        elif isinstance(o,list):
            for i,v in enumerate(o): walk(v,path+'/%d'%i)
        elif o=='' : errs.append('leerer Text: '+path)
    walk({k:v for k,v in data.items()})
    refs={x['ref'] for x in data['persons']}
    for r in data['records']:
        if r['holder'] and r['holder']['person_ref'] not in refs: errs.append('Rekord %s ohne Person'%r['key'])
        if r['status']=='belegt' and not r['sources']: errs.append('Rekord %s ohne Quelle'%r['key'])
    u=[p for p in data['players'] if p['squad']['team']=='u21' and p['squad']['status']!='loaned_out']
    grp=Counter(p['squad']['position_group'] for p in u)
    for g_,q in {'TOR':2,'ABW':6,'MIT':7,'ANG':5}.items():
        if grp[g_]>q: errs.append('U21 %s überbesetzt'%g_)
    return errs,grp
errs,grp=check(data)
blob=json.dumps(data,ensure_ascii=False,indent=1,sort_keys=False).encode('utf-8')
sha=hashlib.sha256(blob).hexdigest()
u21=[p for p in players if p['squad']['team']=='u21']
fv=sorted({p['ratings']['fminside']['version'] for p in players if p['ratings']['fminside']})
manifest={'format':'WS_CLUB_PACKAGE','format_version':1,'package_type':'club','club':{'fmi_id':907,'tm_id':16,'name':'Borussia Dortmund'},
 'collected_at':CHK,'titles_through_season':'2025/26',
 'source_versions':{'fminside':'FM26 '+', '.join(fv),'cmtracker_db':CMT['db_used'],'cmtracker_db_name':next(d['name'] for d in CMT['dbs'] if d['slug']==CMT['db_used']),'api_football_season':None},
 'position_window':['2024/25','2025/26','2026/27'],
 'counts':{'players':len(players),'first_team':sum(p['squad']['team']=='first' for p in players),'loaned_in':sum(p['squad']['status']=='loaned_in' for p in players),'loaned_out':sum(p['squad']['status']=='loaned_out' for p in players),
           'u21':sum(1 for p in u21 if p['squad']['status']!='loaned_out'),'u21_loaned_out':sum(1 for p in u21 if p['squad']['status']=='loaned_out'),'gems':sum(1 for p in u21 if p.get('gem')),
           'persons':len(persons),'records':len(records),'titles':len(titles),
           'gaps_blocking':sum(g_['severity']=='blocking' for g_ in gaps),'gaps_player_lock':sum(g_['severity']=='player_lock' for g_ in gaps),'gaps_info':sum(g_['severity']=='info' for g_ in gaps)},
 'data_sha256':sha}
os.makedirs('out',exist_ok=True)
open('out/data.json','wb').write(blob)
open('out/manifest.json','w',encoding='utf-8').write(json.dumps(manifest,ensure_ascii=False,indent=1))
with zipfile.ZipFile('out/bvb_vereinspaket_2026-10-05.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.write('out/manifest.json','manifest.json'); z.write('out/data.json','data.json')
if __name__=='__main__' or True:
    print('FEHLER:',errs); print('U21-Gruppen:',dict(grp)); print(json.dumps(manifest['counts'])); print('bytes',len(blob),'zip',os.path.getsize('out/bvb_vereinspaket_2026-10-05.zip'),'sha',sha[:16])
