BVB-Vereinspaket neu bauen
1. In einen Ordner legen: diese Skripte, dazu tm.json (= bvb_tm_roh.json), tmx.json (= bvb_tm_rekorde_roh.json), fmi.json (= bvb_fminside_roh.json), cmt.json (= bvb_cmtracker.json), optional cmt_u21.json (= bvb_cmtracker_u21.json, vollstaendiger Lauf).
2. python3 build_all.py  -> out/data.json, out/manifest.json, out/bvb_vereinspaket_2026-10-05.zip
Ist cmt_u21.json vorhanden und "complete": true, bekommen Nachwuchsspieler ohne Treffer den Status nicht_vorhanden (E58).
