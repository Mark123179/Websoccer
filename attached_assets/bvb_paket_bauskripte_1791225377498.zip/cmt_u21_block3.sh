cd /opt/websoccer && docker exec websoccer-web-1 python manage.py shell -c "$(cat <<'PY'
def main():
    import json, time, datetime
    from game.cmtracker_api import CmtrackerClient, CmtrackerError, _extract_list
    T = """1023091|Aaron Held|2007-09-27
1179181|Nanitonda Quiala|2005-09-25
1352800|Beni Ngyombo|2007-01-13
1024973|Finn Fuchs|2006-02-17
724062|Mario Pejazic|2005-01-21
1080603|Tim Degener|2007-01-11
1211573|Luke Fahrenhorst|2008-09-27
1385085|Takato Yamamoto|2007-08-24
1253433|Fadi Zarqelain|2009-01-03
912966|Arne Wessels|2005-11-04
1162537|Daniel Sumbu|2007-05-04
1130174|Bennedikt Wüstenhagen|2005-12-29
1064706|Kevin Mutove|2004-10-14
1081530|Pharell Kegni|2007-05-21
1080602|Diego Ngambia|2007-11-19
1202473|Julien Froese|2008-09-15
1447811|Paul Hannig|2009-01-31
1113015|Jan-Mattis Wehrbein|2008-03-07
1141182|Jan-Luca Riedl|2009-05-29
1259873|Lenni Strößner|2009-01-15
1211572|Roméo Ritter|2008-03-30
1333849|Liam Claude Kanté|2010-06-22
1447815|Semih Kaymak|2009-05-30
1276304|Miguel Adje|2008-02-03
1276298|Niklas König|2008-02-28
1328461|Levin Vogt|2009-02-24
1447813|Luis Alaze|2009-05-05
1367718|Till Burkhardt|2010-01-18
1276302|Tom Faust|2008-05-21
1141180|Justin Hoy|2008-07-14
1455576|Mats Brauckmann|2009-01-09
1583561|Amine Lettifi|2009-01-01
1276306|Marwan-Omir Mirza|2009-09-01
1172134|Peniel Poba|2009-02-04
1447814|Johann Jaensch|2009-02-04
1388076|Keron Hagemann|2010-02-19
1276307|Ahmad Najdi|2009-02-04
1259874|Lyon Tepic|2009-03-04
1334363|Bjarki Gardarsson|2010-02-11
1604215|Finn van der Hoeck|2010-02-09
1473178|Bennet Birtner|2010-01-04
1420335|Georgios Zisopoulos|2010-01-17
1451872|Davis Okojie|2010-05-05
1451870|Emre Kırar|2010-01-03
1577905|Septimus Bah|2010-01-05
1577906|Maximilian Klingenheben|2010-01-08
1346330|Ilyas Arzini|2010-06-18
1596199|Chinedu Jibunor|2010-03-28
1420336|Niclas Goldberg|2010-01-09
1577901|Tim-Bakary Bojang|2010-05-19
1517315|Nikola Jekic|2010-06-25
1401136|Janis Tunkel|2010-02-03
1541071|Jonas Schwarzer|2010-08-02
1406405|Athanasios Grammozis|2010-04-07
1577902|Adriano Bejta|2010-01-21"""
    targets = []
    for l in T.strip().splitlines():
        a = l.split("|"); targets.append({"tm_id": a[0], "name": a[1], "dob": a[2]})
    dobs = set([t["dob"] for t in targets])
    c = CmtrackerClient(); db = "26091500"; log = []; hits = {}; counts = {}; failed = []
    st = {"req": 0, "retry": 0}
    out = {"db_used": db, "targets": targets, "hits_by_dob": hits, "counts_by_rating": counts, "failed_ratings": failed, "log": log, "mode": None, "complete": False, "stats": st}
    def save():
        out["fetched_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        json.dump(out, open("/tmp/bvb_cmtracker_u21.json", "w"), ensure_ascii=False)
    def dob(x):
        return str((x.get("info") or {}).get("birthdate") or "")[:10]
    def page(p, flt):
        waits = [8, 15, 25, 40, 60, 60]
        for attempt in range(len(waits) + 1):
            try:
                st["req"] += 1
                r = _extract_list(c.list_players(db=db, page=p, limit=100, filters=flt))
                time.sleep(1.5)
                return r
            except CmtrackerError as e:
                if ("404" in str(e) or "429" in str(e)) and attempt < len(waits):
                    st["retry"] += 1; time.sleep(waits[attempt]); continue
                if "404" in str(e):
                    return None
                raise
    def allpages(flt):
        res = []; p = 0
        while p < 40:
            b = page(p, flt)
            if b is None:
                return res, (p > 0)
            res.extend(b); p += 1
            if len(b) < 100: break
        return res, True
    try:
        base = {}
        probe = page(0, {"age__lte": 21, "overallrating__gte": 60, "overallrating__lte": 60})
        ok = bool(probe)
        for x in (probe or []):
            i = x.get("info") or {}
            if i.get("overallrating") != 60 or (i.get("age") or 99) > 21: ok = False
        log.append("Filter age__lte: %s (%d Treffer)" % (ok, len(probe or [])))
        if ok: base = {"age__lte": 21}
        out["mode"] = "je Gesamtstaerke" + (" + age__lte 21" if base else "")
        for ovr in range(40, 95):
            flt = dict(base); flt["overallrating__gte"] = ovr; flt["overallrating__lte"] = ovr
            r, good = allpages(flt)
            counts[str(ovr)] = len(r)
            if not good: failed.append(ovr)
            for x in r:
                if dob(x) in dobs: hits.setdefault(dob(x), []).append(x)
            save()
            if ovr % 5 == 0: print("Staerke", ovr, "| Abfragen", st["req"], "| Wiederholungen", st["retry"], flush=True)
        out["complete"] = not failed
    except Exception as e:
        log.append("ABBRUCH: " + str(e)[:300])
    n = 0
    for v in hits.values(): n += len(v)
    save()
    for l in log: print(l)
    tot = 0
    for v in counts.values(): tot += v
    print("FERTIG:", out["mode"], "| vollstaendig:", out["complete"], "| Spieler geprueft:", tot, "| Abfragen:", st["req"], "| Wiederholungen:", st["retry"], "| fehlgeschlagen:", failed, "| Geburtstags-Treffer:", n)
main()
PY
)"
docker cp websoccer-web-1:/tmp/bvb_cmtracker_u21.json /opt/websoccer/bvb_cmtracker_u21.json && ls -la /opt/websoccer/bvb_cmtracker_u21.json
