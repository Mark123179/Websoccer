from sel import *
CHK='2026-10-05'
FOOT={'rechts':'R','links':'L','beidfüßig':'B'}
BVB={'tm_id':16,'name':'Borussia Dortmund'}
def cid(href):
    m=re.search(r'/verein/(\d+)',href or ''); return int(m.group(1)) if m else None
def season_long(s):
    m=re.match(r'^(\d\d)/(\d\d)$',s or '')
    if not m: return s or None
    a=int(m.group(1)); c=1900 if a>=40 else 2000
    return '%d/%s'%(c+a,m.group(2))
def fee(text):
    t=(text or '').strip()
    if not t or t in ('-','?'): return None
    if t.lower().startswith('ablösefrei'): return 0
    if t.lower().startswith('leih'):  # "Leihe", "Leih-Ende", "Leihgebühr: 1,00 Mio. €"
        return money(t)
    return money(t)
def is_loan(text):
    return (text or '').strip().lower().startswith('leih')
def cmt_for(pid, extra=None):
    """CMTracker über Name + Geburtsdatum in der Vereinsdatei"""
    b=base(pid); hits=[]
    for p in CMT['players']+(extra or []):
        i=p['info']
        if i['birthdate'][:10]!=str(b['dob']): continue
        nm=' '.join(filter(None,[i['name'].get('knownas'),i['name'].get('firstname'),i['name'].get('lastname')]))
        r=difflib.SequenceMatcher(None,norm(i['name'].get('knownas') or ''),norm(b['name'])).ratio()
        last=norm(b['name']).split()[-1]
        if r>=0.75 or last in norm(nm).split(): hits.append((r,p))
    hits.sort(key=lambda x:-x[0])
    seen=set(); uniq=[]
    for r,p in hits:
        if str(p['playerid']) in seen: continue
        seen.add(str(p['playerid'])); uniq.append((r,p))
    return uniq
def build_player(pid, team, status, gem=None, cmt_extra=None, cmt_checked=None):
    rec=TM['players'][pid]; pr=rec['profile']; b=base(pid); info=pr['info']; gaps=[]
    name=(pr['h1'] or '').replace(pr['shirt'] or '\0','',1).strip() if pr['shirt'] else (pr['h1'] or '').strip()
    last=(pr['h1strong'] or '').strip() or None
    first=name[:-len(last)].strip() if last and name.endswith(last) else None
    if first=='': first=None
    hm=re.search(r'(\d),(\d\d)',info.get('Größe:',{}).get('text','')); height=int(hm.group(1))*100+int(hm.group(2)) if hm else None
    foot=FOOT.get(info.get('Fuß:',{}).get('text','').strip())
    nats=info.get('Staatsbürgerschaft:',{}).get('imgs') or b['nat'] or []
    ppos=info.get('Position:',{}).get('text','').split(' - ')[-1].strip() or b['pos']
    po=positions(pid,ppos)
    napps=sum(a['count'] for a in po['appearances'])
    ref='tm:%s'%pid
    for w in po['warnings']: gaps.append(dict(entity='player',ref=ref,field='positions',severity='info',note=w))
    if po['method']=='appearances' and napps<10:
        gaps.append(dict(entity='player',ref=ref,field='positions',severity='info',note='Hauptposition aus nur %d Einsätzen im Fenster 2024/25 bis 2026/27 (TM-Profilposition: %s).'%(napps,ppos)))
    if po['method']=='profile':
        gaps.append(dict(entity='player',ref=ref,field='positions',severity='info',note='Keine Einsätze mit Position im Fenster, Hauptposition aus dem TM-Profil (%s).'%ppos))
    # Marktwert
    mvl=(rec['mv'] or {}).get('list') or []
    name2id={}
    for e in mvl:
        m=re.search(r'/wappen/[^/]+/(\d+)\.',e.get('wappen') or '')
        if m: name2id[e['verein']]=int(m.group(1))
    rev={v:int(k) for k,v in CLUBNAME.items()}
    mvs=[]
    for e in mvl:
        d=pdate(e['datum_mw']); 
        mvs.append({'date':str(d) if d else None,'value_eur':int(e['y']) if e.get('y') is not None else None,'club':{'tm_id':name2id.get(e['verein'],rev.get(e['verein'])),'name':e['verein'] or None}})
    mv_now=mvs[-1]['value_eur'] if mvs else None
    if mv_now is None:
        gaps.append(dict(entity='player',ref=ref,field='market_value_eur',severity='info',note='Transfermarkt führt keinen Marktwert. Gehalt bleibt leer.'))
    elif b['mv'] is not None and b['mv']!=mv_now:
        gaps.append(dict(entity='player',ref=ref,field='market_value_eur',severity='info',note='Kaderliste (%s) und Marktwertverlauf (%s) weichen ab, Verlauf übernommen.'%(b['mv'],mv_now)))
    # Transfers
    trs=[]; loan_until=None
    for t in rec['transfers'] or []:
        d=t.get('dateUnformatted') or (str(pdate(t['date'])) if pdate(t['date']) else None)
        if d and d>CHK:
            if is_loan(t['fee']) and 'ende' in (t['fee'] or '').lower(): loan_until=d
            continue
        trs.append({'date':d,'season':season_long(t['season']),'from':{'tm_id':cid(t['from']['href']),'name':t['from']['name']},'to':{'tm_id':cid(t['to']['href']),'name':t['to']['name']},'fee_eur':fee(t['fee']),'fee_text':t['fee'] or None,'is_loan':is_loan(t['fee'])})
    # Kader
    nr=(pr['shirt'] or '').lstrip('#').strip() or (b['nr'] if b['nr'] not in ('-','',None) else '')
    shirt=int(nr) if str(nr).isdigit() else None
    owner=dict(BVB); loan_club=None
    if status=='loaned_in':
        k,r=LOAN_IN[pid]; l=[x for x in r['clubLinks'] if cid(x.split('|')[0])]
        oid=cid(l[0].split('|')[0]); owner={'tm_id':oid,'name':l[0].split('|')[1] or CLUBNAME.get(str(oid))}
        loan_club=dict(BVB)
        if not loan_until:
            ends=[c for c in r['cells'] if pdate(c)]; loan_until=str(pdate(ends[-2])) if len(ends)>=2 else None
    if status=='loaned_out':
        k,r=LOAN_OUT[pid]; l=[x for x in r['clubLinks'] if cid(x.split('|')[0])]
        lid=cid(l[0].split('|')[0]); loan_club={'tm_id':lid,'name':l[0].split('|')[1] or CLUBNAME.get(str(lid))}
        if not loan_until:
            ends=[c for c in r['cells'] if pdate(c)]; loan_until=str(pdate(ends[-1])) if ends else None
    # FMInside
    fk,fbasis,fhint=fmi_for(pid)
    ids={'tm':{'value':int(pid),'status':'gefunden','checked_at':CHK}}
    ratings={'fminside':None,'cmtracker':None}
    if fk:
        pg=FMI['pages'][fk]; inf=fmi_info(pg); attrs={}
        for t in pg['tables']:
            if t['cls']=='player-update-table': continue
            for row in t['rows']:
                if len(row)==2 and row[1].strip().isdigit(): attrs[row[0]]=int(row[1])
        mt=' '.join(pg['metrics'])
        ca=re.search(r'Current ability\s*(\d+)\s*/\s*100',mt); pa=re.search(r'Potential\s*(\d+)\s*/\s*100',mt)
        ptxt=re.search(r'Potential\s*([A-Za-z]+)',mt)
        ids['fmi']={'value':int(fk.split('-')[0]),'status':'gefunden','checked_at':CHK,'match':fbasis}
        ratings['fminside']={'version':inf.get('Database version'),'url':pg['final'],'rating':int(ca.group(1)) if ca else None,'potential':int(pa.group(1)) if pa else None,
            'raw':{'attributes':attrs,'positions':inf.get('Positions'),'footedness':inf.get('Footedness'),'height':inf.get('Height'),'age':inf.get('Age'),'date_of_birth':inf.get('Date of birth'),'name':inf.get('Name'),'full_name':inf.get('Full name'),'club':next((c.split(':',1)[1].strip() for c in pg['contract'] if c.startswith('Club:')),None),'potential_text':(ptxt.group(1) if (ptxt and not pa) else None)}}
        if fbasis!='dob': gaps.append(dict(entity='player',ref=ref,field='ids.fmi',severity='info',note='FMInside zeigt kein Geburtsdatum. Zuordnung über Name, Alter und Nation (%s).'%fk))
        if not pa: gaps.append(dict(entity='player',ref=ref,field='ratings.fminside.potential',severity='info',note='FMInside nennt kein Potenzial (Anzeige „%s“).'%(ptxt.group(1) if ptxt else '—')))
        if not attrs: gaps.append(dict(entity='player',ref=ref,field='ratings.fminside.raw',severity='blocking' if team=='first' else 'info',note='FMInside-Seite ohne lesbare Attribute.'))
    else:
        ids['fmi']={'value':None,'status':'nicht_gefunden','checked_at':CHK}
    # CMTracker
    hits=cmt_for(pid,cmt_extra)
    if hits:
        p=hits[0][1]; i=p['info']
        ids['cmtracker']={'value':int(p['playerid']),'status':'gefunden','checked_at':CHK}
        ratings['cmtracker']={'db':p.get('_db') or CMT['db_used'],'rating':i.get('overallrating'),'potential':i.get('potential'),'raw':{'info':{k:i.get(k) for k in ['playerid','birthdate','name','nation','secondNation','overallrating','potential','growth','age','teams','league','preferredfoot','skillmoves','weafoot','internationalrep','height','weight','positions','accType','valueEUR','wageEUR','release_clause','traits','traits_plus']},'attributes':p.get('attributes'),'stats':p.get('stats'),'card_attrs':p.get('card_attrs'),'real_ovrs':p.get('real_ovrs'),'roles':p.get('roles')}}
        if len(hits)>1: gaps.append(dict(entity='player',ref=ref,field='ids.cmtracker',severity='info',note='Mehrere CMTracker-Einträge mit gleichem Geburtsdatum, bester Namenstreffer gewählt.'))
    else:
        ids['cmtracker']={'value':None,'status':'nicht_gefunden','checked_at':CHK}
    ids['api_football']={'value':None,'status':'nicht_gefunden','checked_at':CHK}
    out={'ids':{k:ids[k] for k in ['fmi','tm','cmtracker','api_football']},'last_name':last,'first_name':first,'display_name':name,'date_of_birth':str(b['dob']),
         'nationalities':nats,'height_cm':height,'foot':foot,
         'squad':{'team':team,'status':status,'owner_club':owner,'loan_club':loan_club,'loan_until':loan_until,'shirt_number':shirt},
         'positions':{'main':po['main'],'secondary':po['secondary'],'method':po['method'],'seasons':['2024/25','2025/26','2026/27'],'appearances':po['appearances'],'tm_profile_position':ppos or None},
         'market_value_eur':mv_now,'market_values':mvs,'transfers':trs,'ratings':ratings,'api_football':None,
         'sources':{'tm_profile':'https://www.transfermarkt.de'+rec['href']}}
    if team=='u21': out['gem']=gem
    return out,gaps
if __name__=='__main__':
    for pid in ['388198','257814','890719','627228','1311594','1385085','931668']:
        o,g=build_player(pid,'first','own')
        s=json.dumps(o,ensure_ascii=False)
        print(o['display_name'],'|',o['first_name'],'|',o['last_name'],o['date_of_birth'],o['nationalities'],o['height_cm'],o['foot'],o['squad'],o['positions']['main'],o['positions']['secondary'],o['market_value_eur'],len(o['market_values']),len(o['transfers']),o['ids'],(o['ratings']['fminside'] or {}).get('rating'),(o['ratings']['fminside'] or {}).get('potential'),len(((o['ratings']['fminside'] or {}).get('raw') or {}).get('attributes',{})),(o['ratings']['cmtracker'] or {}).get('rating'),len(s))
        print('   gaps',g)
        print('   mv0',o['market_values'][:2],'tr0',o['transfers'][:2])
