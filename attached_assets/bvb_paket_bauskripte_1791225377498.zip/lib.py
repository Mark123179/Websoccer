import json, re, datetime as dt
from collections import Counter, defaultdict
TM=json.load(open('tm.json')); CMT=json.load(open('cmt.json'))
ERH=dt.date(2026,10,5)
COMPS={c['id']:c for c in TM['comps']}
POSID={1:'Torwart',2:'Libero',3:'Innenverteidiger',4:'Linker Verteidiger',5:'Rechter Verteidiger',6:'Defensives Mittelfeld',7:'Zentrales Mittelfeld',8:'Rechtes Mittelfeld',9:'Linkes Mittelfeld',10:'Offensives Mittelfeld',11:'Linksaußen',12:'Rechtsaußen',13:'Hängende Spitze',14:'Mittelstürmer'}
TMMAP={'torwart':'TW','innenverteidiger':'IV','libero':'IV','linker verteidiger':'LV','rechter verteidiger':'RV','defensives mittelfeld':'DM','zentrales mittelfeld':'ZM','linkes mittelfeld':'LM','rechtes mittelfeld':'RM','offensives mittelfeld':'OM','linksaußen':'LF','rechtsaußen':'RF','hängende spitze':'ST','mittelstürmer':'ST','sturm':'ST'}
def pdate(s):
    m=re.search(r'(\d{2})\.(\d{2})\.(\d{4})',s or '')
    return dt.date(int(m.group(3)),int(m.group(2)),int(m.group(1))) if m else None
def age(d,on=ERH):
    return on.year-d.year-((on.month,on.day)<(d.month,d.day))
def money(s):
    if not s: return None
    s=s.replace('\xa0',' ')
    m=re.search(r'([\d.,]+)\s*(Mio\.|Tsd\.|Mrd\.)?\s*€',s)
    if not m: return None
    v=float(m.group(1).replace('.','').replace(',','.')) if m.group(2) else float(m.group(1).replace('.','').replace(',','.'))
    mult={'Mio.':1e6,'Tsd.':1e3,'Mrd.':1e9,None:1}[m.group(2)]
    return int(round(v*mult))
def squadrow(key,pid):
    for r in TM['squads'][key]['rows']:
        if r['id']==pid: return r
MEMB=defaultdict(list)
for k in ['first','u23','u19','u17']:
    for r in TM['squads'][k]['rows']: MEMB[r['id']].append(k)
LOAN_OUT={}; LOAN_IN={}
for k,boxes in TM['loans'].items():
    for b in boxes:
        for r in b['rows']:
            (LOAN_IN if b['h2'].startswith('Ausgeliehene') else LOAN_OUT)[r['id']]=(k,r)
def base(pid):
    """Stammdaten aus Kaderzeile (auch für U17 ohne Profil)"""
    for k in ['first','u23','u19','u17']:
        r=squadrow(k,pid)
        if r:
            c=r['cells']; nm=r['name']
            return dict(id=pid,name=nm,dob=pdate(c[2]),pos=c[1].replace(nm,'').strip(),mv=money(c[-1]),nr=c[0],nat=r['nat'])
    if pid in LOAN_OUT:
        k,r=LOAN_OUT[pid]; p=TM['players'][pid]['profile']
        return dict(id=pid,name=r['name'],dob=pdate(p['info']['Geb./Alter:']['text']),pos=p['info']['Position:']['text'].split(' - ')[-1],mv=money(r['cells'][-1]),nr=(p['shirt'] or '').lstrip('#'),nat=p['info']['Staatsbürgerschaft:']['imgs'])
PERF_F=['season','comp','ctype','club','nat','date','state','pos','min','start','game','shirt','goals']
def perf(pid): return [dict(zip(PERF_F,g)) for g in (TM['perf'].get(pid) or [])]

WINDOW={2024,2025,2026}
CLUBNAME={}
for pid,p in TM['players'].items():
    for t in p['transfers'] or []:
        for side in ('from','to'):
            m=re.search(r'/verein/(\d+)',t[side]['href'] or '')
            if m: CLUBNAME.setdefault(m.group(1),t[side]['name'])
    for it in p['profile']['headerItems']:
        for l in it['links']:
            m=re.search(r'/verein/(\d+)',l)
            if m and '|' in l and not l.split('|')[1].isdigit(): CLUBNAME.setdefault(m.group(1),l.split('|')[1])
CLUBNAME.update({'16':'Borussia Dortmund','17':'Borussia Dortmund II','1464':'Borussia Dortmund U19','21055':'Borussia Dortmund U17'})
NONFIRST=re.compile(r'(\bII\b|\bU\d\d\b|\bB\b$|Jgd\.|Jugend|Yth\.|Youth|\bU-\d\d|Res\.|Reserve| C$|Primavera|Sub-\d\d|Jong )')
PRO_CT={1,2,3,8,9,10,13,14}
YOUTH_NAT_CT={17,20}
def pos_counts(pid, seasons=WINDOW):
    c=Counter()
    for g in perf(pid):
        if g['state']=='played' and g['pos'] and g['season'] in seasons: c[POSID.get(g['pos'],'#%s'%g['pos'])]+=1
    return c
PAIRS=[(('RV','RM'),'ROV'),(('RM','RF'),'ROM'),(('LV','LM'),'LOV'),(('LM','LF'),'LOM')]
def positions(pid, profile_pos):
    """E11/E12/E65. Liefert main, secondary, method, appearances, warnings"""
    raw=pos_counts(pid); warn=[]
    apps=Counter(); order=[]
    for label,n in raw.most_common():
        code=TMMAP.get(label.lower())
        if code is None: warn.append('Unbekannte TM-Position: %s'%label); continue
        if code not in apps: order.append(code)
        apps[code]+=n
    ranked=sorted(order,key=lambda c:-apps[c])
    appearances=[{'tm_position':l,'code':TMMAP.get(l.lower()),'count':n} for l,n in raw.most_common()]
    if not ranked:
        code=TMMAP.get((profile_pos or '').lower())
        if code is None: warn.append('Keine Einsätze im Fenster und Profilposition nicht zuordenbar: %r'%profile_pos); return dict(main=[],secondary=[],method='profile',appearances=appearances,warnings=warn)
        return dict(main=[code],secondary=[],method='profile',appearances=appearances,warnings=warn)
    main=[c for c in ranked if apps[c]>=25][:2]
    if not main: main=[ranked[0]]
    sec=[c for c in ranked if c not in main and apps[c]>=10][:2]
    for (a,b),z in PAIRS:
        if a in main and b in main: main.append(z)
        elif (a in main and b in sec) or (b in main and a in sec) or (a in sec and b in sec): sec.append(z)
    return dict(main=main,secondary=sec,method='appearances',appearances=appearances,warnings=warn)
GROUP={'TW':'TOR','IV':'ABW','LV':'ABW','RV':'ABW','LOV':'ABW','ROV':'ABW','DM':'MIT','ZM':'MIT','LM':'MIT','RM':'MIT','OM':'MIT','LOM':'MIT','ROM':'MIT','LF':'ANG','RF':'ANG','ST':'ANG'}
def minutes(pid, season=2026):
    return sum((g['min'] or 0) for g in perf(pid) if g['state']=='played' and g['season']==season)
def pro_apps(pid):
    out=[]
    for g in perf(pid):
        if g['state']=='played' and not g['nat'] and g['ctype'] in PRO_CT:
            nm=CLUBNAME.get(str(g['club']))
            out.append((g['date'],g['comp'],str(g['club']),nm))
    return out
def youth_nat(pid):
    return [(g['date'],g['comp'],str(g['club'])) for g in perf(pid) if g['state']=='played' and g['nat'] and g['ctype'] in YOUTH_NAT_CT]
def nat_all(pid):
    return Counter((g['comp'],str(g['club'])) for g in perf(pid) if g['state']=='played' and g['nat'])
