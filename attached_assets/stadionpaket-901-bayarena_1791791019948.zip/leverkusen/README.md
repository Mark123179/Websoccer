# Stadionpaket · BayArena · Bayer 04 Leverkusen (FMI 901, Verein 4) — Fassung 1

Stand 12.10.2026 · Quelle: BassyBoy FM26 3D Stadium Megapack v3.0 (`bayarena.bundle`, SHA-256 `9bd73626…4e226`), Freigabe durch Mark für den gesamten Megapack. Export mit Werkzeug Fassung 4 (Bodenregeln der Bayern-Referenz) + zwei Ergänzungen (unten).

## Inhalt
- `models/901.json` – Manifest, assetVersion **ed7527940bb8ec5b**, geometrySha256 `f0691288…45ac`, Validator grün
- `stadium-models/901/ed7527940bb8ec5b/` – `geometry.bin` (13,7 MB) + 80 Texturen, alle Hashes in `PRUEFSUMMEN.sha256`
- `kalibrierung.json` (mit Kommentaren), `boden_901.json` (festgeschriebene Bodenlisten), `bodenregeln_bericht.json`
- `umfeld_korrektur_901.json` – **Datenkorrektur am Bestand nötig, siehe unten**
- `bilder/` – fünf Ansichten (zentraler Renderer 12.10.), Kontaktbogen, `nachweis-umfeld-korrektur.png`
- `transparenz_scan_901.txt`, `werkzeuge/` (Export, Scans, Harness, `presentation_901.json`)

Kennzahlen: 265 Meshes, 80 Texturen, 203 quellgeprüfte Flutlichter → 12 Laufzeitleuchten, 33.759 Sitze, 137 Lightmaps (Datei), 140 Lightprobes.

## Befund, der vor der Registrierung gelöst sein muss: Umfeld im Bestand
Die Leverkusener Stadiongeometrie (Seed aus `stadium_data_all.js.gz`, `bg.buildings`) enthält **8 OSM-Gebäudeteile des Stadions selbst** (Indizes 212, 866, 869, 906, 907, 908, 909, 910 — Tribünenkörper als `building:part`). Der Umfeld-Adapter zeichnet sie als 9-m-Klötze; sie verdecken Spielfeldrand und Unterrang (Nachweis: `bilder/nachweis-umfeld-korrektur.png`, Verursacher durch Ein-/Ausblenden bestimmt — `field_*`-Bodenteile und `center1_*` waren es nicht). Außerdem zwei degenerierte Wasserflächen (Indizes 1, 3, je 2 Punkte), an denen der Adapter mit „Eine Umfeldfläche benötigt mindestens drei Punkte" abbricht — **ohne Korrektur lädt der Unity-Renderer für Leverkusen gar nicht**.
Korrektur = Datenänderung an `StadiumGeometry.geometry.bg` (Verein 4): die 8 Gebäude und die 2 Wasserflächen entfernen. Keine Codeänderung. Für die Vorab-Bilder wurde dieselbe Korrektur auf die Vorschau-Präsentation angewandt. Bayern/Gladbach/Dortmund sind nicht betroffen (geprüft: dort liegt kein Gebäude im Stadionumriss); Union Berlin und Olympiastadion Berlin haben je ein Gebäude im Umriss — wird bei deren Paket geprüft.

## Kalibrierung
| Feld | Wert | Begründung |
|---|---|---|
| roofMinHeight | 3 | mit `roofMeshPrefixes` zählt alles in `front3_` zum Dach, auch die Pylone (front3_11, 3,4–40 m); Crowd (bis 24,8 m) und Tribünen (center1_*) nie Dach. |
| roofMeshPrefixes | front3_ | Dachring, Membran/Seilnetz (front3_8/15/16/17), Träger, Lautsprecher, Leuchten (front3_13/19), Pylone. |
| skipMeshPrefixes | center2_, center1_97, center1_99, front1_probe_2, front1_probe_3 | entfernte Kulisse (Bäume/Gebäude ±400 m, der Ortsplan ersetzt sie); zwei Choreo-Objekte (Material tifo_player_common_blue, Südende); Glas am Spielertunnel mit 100 % transparenter Textur. **Keine Fangnetze im Bundle**, keine weiteren Choreos in MAIN (CHEER1/2, FLAGAREA liegen außerhalb und werden nicht exportiert). |
| crowdPrefix / pitchPrefix | C_ / st081_pitch_ | 10 Crowd-Meshes; st081_pitch_0 (±43,6 × ±60,6 m, Material 0002-Bayer, Textur identisch mit Bayern) + st081_pitch_1 (Linien). |
| tickerRotationY | −90 | Bänke BENCH_BAYER_HOME/AWAY bei x ≈ −43 (Hauptseite −x), Längsachse z. |
| tickerFrontCut | (1,0,0) / 32 | Linienrasen ±34,1; Nahtribüne ab x −37 und Bänke werden weggeschnitten. |
| standAxes | +x OST, −x WEST, +z NORD, −z SUED | Prod-Szene: homeStand NORD bei Szene +x (→ Unity +z, Modell `left*_UltraHome` = Nordkurve ✔), WEST mit 3 VIP-Blöcken bei Szene +y (→ Unity −x = Bankseite ✔), Gästeblock `front1_UltraAway` in der Südwest-Ecke. |
| orbitDefault | 0,95 / 0,65 / 300 | Modell x ±83, z ±100 m. |

## Bodenregeln (Werkzeug Fassung 4, Heuristik, nach Sichtprüfung festgeschrieben)
- transparent + alphaTest 1/255: 3 Boden-Decals (Leverkusen-Logo am Tunnel, Coach-Zone-Linien).
- Rasenangleichung: keine Teile nötig — der Spielfeldrand ist hier Beton/Gitter (field_3/field_4), kein Rasen; uvProjection trotzdem abgeleitet (`[0,0,−0.006742537,0.49987793,0.011012515,0,0,0.5]`, Rasen ±43,6 × ±60,6 m).
- **Ergänzung A — Alpha-Schnitt** (neu im Werkzeug): 23 Nicht-Bodenteile mit ≥ 50 % transparenter Textur (Geländer, Glasfronten, Logos, Dachgitter, Leuchtröhren) erhalten `alphaTest` = Material-Cutoff (sonst 0,5), bleiben opak (depthWrite). Ohne das wären Geländer als massive Wände über den Rängen sichtbar. Liste in `boden_901.json → alphaCutParts`. Für Bayern **nicht** angewandt (Referenz bleibt).
- Teile mit ≥ 99 % transparenter Textur werden gemeldet und in die Skip-Liste übernommen (hier die zwei Glasflächen).
- **Ergänzung B — Leuchtenmaterialien**: dieses Bundle benennt Leuchten `light_01_color`/`light_fixture_a_color`; Replits Standard-Schlüsselliste (`lght, lamp, light_bulb, light_floodlight`) findet sie nicht → Export bricht ab. Option `--lamp-materials light_fixture,light_01` ergänzt die Liste; 203 Leuchten quellgeprüft.

## Sichtprüfung (fünf Ansichten, zentraler Renderer 12.10.)
Keine dunklen Rasenrechtecke, keine deckenden Markierungsträger, Linien vollständig, Tribünen beim Dachschalter vollständig (Dach aus = Dach, Seilnetz und Pylone weg, Tribünen und Oberrang bleiben), keine Tore im Bundle (wie bei allen Megapack-Stadien). Nacht: 12 Leuchten im Dachring, Rasen ausgeleuchtet.
Offen: 2D-Editor-Bild (nur in der App), Quellen nach Replit `attached_assets/stadion_901/` (liegen unter `Downloads\stadion_pilot\bayarena*`), Umfeld-Korrektur am Bestand (oben), Replit-Export braucht `--lamp-materials` + Bodenregeln (Werkzeug Fassung 4) für eine byte-gleiche Reproduktion.

## Einspielen
0. Umfeld-Korrektur in `StadiumGeometry` (Verein 4) nach `umfeld_korrektur_901.json`.
1. `scp -r stadium-models/901 root@49.13.5.151:/var/www/assets/stadium-models/`
2. `models/901.json` nach `stadium_editor/blueprints/v2/models/`, Quellen nach `attached_assets/stadion_901/`, committen, pushen.
3. `/push`, dann `docker exec websoccer-web-1 python manage.py check_stadium_model --fmi 901 --assets` → `Assets OK: 81 Dateien`.
4. Fünf Ansichten live abnehmen (`/stadion/4/live/`).
