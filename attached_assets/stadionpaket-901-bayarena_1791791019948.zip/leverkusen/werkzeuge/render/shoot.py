import asyncio, sys, json, subprocess, time, os
from playwright.async_api import async_playwright
PORT=8765
async def main(shots, outdir):
    os.makedirs(outdir, exist_ok=True)
    srv=subprocess.Popen([sys.executable,"-m","http.server",str(PORT),"--bind","127.0.0.1"],cwd="render",stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    time.sleep(1.0)
    try:
        async with async_playwright() as p:
            b=await p.chromium.launch(args=["--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader","--ignore-gpu-blocklist","--enable-webgl","--disable-gpu-sandbox"])
            for name,params,w,h in shots:
                pg=await b.new_page(viewport={"width":w,"height":h},device_scale_factor=1)
                logs=[]; pg.on("console",lambda m:logs.append(m.text)); pg.on("pageerror",lambda e:logs.append("PAGEERROR "+str(e)))
                url=f"http://127.0.0.1:{PORT}/harness.html?{params}&w={w}&h={h}"
                t0=time.time(); await pg.goto(url, wait_until="load", timeout=120000)
                await pg.wait_for_function("window.__ready===true || window.__error!==null", timeout=300000)
                err=await pg.evaluate("window.__error")
                if err: print(name,"ERROR",err[:800]); print("\n".join(logs[-10:]))
                else:
                    await pg.wait_for_timeout(800)
                    await pg.locator("#stage").screenshot(path=f"{outdir}/{name}.png")
                    print(name,"ok %.1fs"%(time.time()-t0))
                await pg.close()
            await b.close()
    finally: srv.terminate()
shots=json.loads(sys.argv[1]); asyncio.run(main(shots, sys.argv[2]))
