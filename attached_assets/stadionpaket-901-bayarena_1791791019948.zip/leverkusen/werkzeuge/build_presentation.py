"""presentation_<fmi>.json für den Render-Harness: wie unity_presentation()/runtime_presentation() im Projekt.
Aufruf: build_presentation.py <club_id> <fmi> "<Stadionname im Blueprint-Bundle>" <manifest.json> <assetVersion> <out>"""
import sys, json, gzip, re, collections, pathlib
club_id, fmi, name, manifest_path, version, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]
raw=gzip.open("repo/stadium_editor/blueprints/stadium_data_all.js.gz","rt",encoding="utf-8").read()
data=json.loads(raw[raw.index("["):raw.rindex("]")+1])
geo=next(s for s in data if s["meta"]["name"]==name)
scene=json.load(open(f"livescene/{club_id}.json")); man=json.load(open(manifest_path))
legacy=geo.get("bg") or {}; live=geo.get("surroundings") or {}
buildings=legacy.get("buildings") or live.get("buildings") or []
surr={"source": live.get("source") or legacy.get("source") or "OpenStreetMap/BLUEPRINT-Bundle (ODbL)","treeSource":"",
 "green":legacy.get("green") or [],"water":legacy.get("water") or [],"roads":legacy.get("roads") or [],
 "buildings":[b if isinstance(b,list) else b["poly"] for b in buildings],
 "buildingHeights":[None if isinstance(b,list) else b.get("h") for b in buildings],
 "buildingIds":[None if isinstance(b,list) else b.get("id") for b in buildings],"trees":legacy.get("trees") or [],"heightQuality":"schematic"}
# Umfeld-Korrektur: OSM-Gebäudeteile, die innerhalb des Stadion-Umrisses liegen (= das Stadion selbst),
# würden als 9-m-Klötze über dem Spielfeldrand gezeichnet. Sie werden für die Vorschau entfernt und gemeldet.
def inside(poly,x,y):
    n=len(poly); c=False
    for i in range(n):
        x1,y1=poly[i][:2]; x2,y2=poly[(i+1)%n][:2]
        if (y1>y)!=(y2>y) and x < (x2-x1)*(y-y1)/(y2-y1+1e-12)+x1: c=not c
    return c
outline=geo.get("outline") or []
drop=[]
for i,poly in enumerate(surr["buildings"]):
    cx=sum(p[0] for p in poly)/len(poly); cy=sum(p[1] for p in poly)/len(poly)
    if outline and (inside(outline,cx,cy) or any(inside(outline,p[0],p[1]) for p in poly)): drop.append(i)
degenerate={k:[i for i,poly in enumerate(surr[k]) if len({tuple(p[:2]) for p in poly})<3] for k in ("green","water","buildings")}
korrektur={"club_id":club_id,"fmi":fmi,"stadium":scene["stadium"],"buildingsInsideOutline":drop,
           "buildingIds":[surr["buildingIds"][i] for i in drop],"degenerate":degenerate,
           "hinweis":"Indizes beziehen sich auf geometry.bg.buildings des Blueprint-Bundles (= Seed der StadiumGeometry). Für die Vorschau entfernt; im Bestand muss die Geometrie korrigiert werden."}
json.dump(korrektur,open(out.replace(".json","_umfeld_korrektur.json"),"w"),indent=1)
if "--ohne-korrektur" in sys.argv: drop=[]   # nur für Vorher-Bilder
keep=[i for i in range(len(surr["buildings"])) if i not in drop and i not in degenerate["buildings"]]
surr["buildings"]=[surr["buildings"][i] for i in keep]; surr["buildingHeights"]=[surr["buildingHeights"][i] for i in keep]; surr["buildingIds"]=[surr["buildingIds"][i] for i in keep]
for k in ("green","water"):
    surr[k]=[poly for i,poly in enumerate(surr[k]) if i not in degenerate[k]]
print("Umfeld-Korrektur:",len(drop),"Gebäude im Stadionumriss entfernt",drop[:12],"| degeneriert:",{k:v for k,v in degenerate.items() if v})
tot=collections.defaultdict(collections.Counter)
for bl in scene["blocks"]:
    for cnt,idx in bl.get("rle") or []:
        if idx>0: tot[bl["stand"]][idx]+=cnt
pal=scene["palette"]; dc={st:pal[max(c,key=c.get)] for st,c in tot.items() if c}
pres={"renderer":"unity-spatial","modelUrl":f"/models/{fmi}/{version}/manifest.json","stadium":scene["stadium"],"clubId":club_id,"clubFmiId":fmi,
      "sourceSha256":man["sourceSha256"],"frame":geo.get("meta") or {},"surroundings":surr,"calibration":man["calibration"],"capacity":scene["capacity"],"designColors":dc}
json.dump({"presentation":pres,"scene":{"blocks":scene["blocks"],"palette":scene["palette"]}},open(out,"w"))
print("presentation:",scene["stadium"],"designColors",dc,"buildings",len(surr["buildings"]),"roads",len(surr["roads"]),"green",len(surr["green"]),"frame",geo.get("meta",{}).get("axisTheta"))
