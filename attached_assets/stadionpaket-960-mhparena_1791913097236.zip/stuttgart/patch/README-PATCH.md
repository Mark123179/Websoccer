# Patch „Ortsplan folgt den Modellachsen“ (calibration.surroundingsAxes) — zentraler Renderer

Stand 13.10.2026, gegen den Replit-Stand vom 13.10. (`unity_stadium_scene.js` 243 Zeilen, `dortmund_surroundings.js?v=51`, `unity_calibration.js`, `model_registry.py`). Eng begrenzt: **4 Dateien, 45 geänderte/neue Zeilen, kein vereinsbezogener Sonderfall, keine Geometrieänderung.** Das Paket 912 Fassung 2 gilt erst als korrigiert, wenn dieser Patch integriert ist; bis dahin registriert das Manifest zwar (das Feld ist für den alten Renderer unbekannt und wird ignoriert), zeigt aber weiter das vertauschte Umfeld.

## Was sich ändert
- `static/stadium_editor/dortmund_surroundings.js`: `editorPointToDortmund(point, frame, axes = SURROUNDINGS_AXES_DEFAULT)` und `buildDortmundSurroundings(THREE, data, frame, axes = …)`. Editor +X (Spielfeldachse zum NORD-Ende, Konvention aller 22 Blaupausen) landet auf der Modellachse `axes.NORD`, Editor +Y (zur WEST-Seite) auf `axes.WEST`. Standard `{NORD: '+z', WEST: '-x'}` ergibt wörtlich `[-v, u]` wie bisher — inklusive Vorzeichen der Null (`[-0, 52.5]`), damit der bestehende Test weiter bit für bit gilt. Ungültige Achsen werden vor dem Lesen der Kartendaten abgewiesen.
- `static/stadium_editor/unity_calibration.js`: optionales `calibration.surroundingsAxes` wird validiert: Objekt mit genau `NORD`/`WEST`, Werte aus `+x/-x/+z/-z`, zwei verschiedene Achsen, **und muss standAxes entsprechen** (`standAxes[axes.NORD] === 'NORD'`, `standAxes[axes.WEST] === 'WEST'`). Fehlt das Feld: Altverhalten.
- `static/stadium_editor/unity_stadium_scene.js`: eine Zeile — `buildDortmundSurroundings(THREE, presentation.surroundings, presentation.frame, calibration.surroundingsAxes)`.
- `model_registry.py`: `validate_surroundings_axes(calibration)` mit denselben Regeln als Registrierungs-Gate (Aufruf in `validate_model_manifest` nach `standAxes`).
- Nicht angefasst: `dortmund_editor_scene.js` (ruft weiter mit drei Argumenten), Ticker-Kamera, `standForCenter`, Dachlogik, Bayern/Leverkusen/Gladbach-Manifeste.

## Warum so
Das Frankfurter Quellmodell ist gegenüber der Realität gespiegelt gebaut (FM-Konvention: Heimkurve rechts der Hauptkamera). Haupttribüne/Bänke liegen bei −x = WEST wie im Ortsplan, die Heimkurve aber bei −z, während der feste Adapter das NORD-Ende des Ortsplans immer auf +z legt. Keine Drehung bringt beide Enden **und** beide Längsseiten zusammen; das Modell zu spiegeln würde Schriftzüge und Windungen kippen. Also folgt der Ortsplan dem Modell: je Modell deklariert, aus den tatsächlichen Modellachsen (standAxes) abgeleitet und dagegen validiert.

## Dateien
- `umfeld-achsen.diff` — unified diff der drei JS-Dateien; `model_registry.diff` — Python.
- `nachher/` — die vier vollständigen Dateien nach dem Patch.
- `tests/test_surroundings_axes.mjs` → nach `stadium_editor/tests_js/`; `tests/test_surroundings_axes.py` → nach `stadium_editor/`.

## Tests
```sh
node --test stadium_editor/tests_js/test_surroundings_axes.mjs      # 6 Tests
node --test stadium_editor/tests_js/test_dortmund_surroundings.mjs stadium_editor/static/stadium_editor/unity_calibration.test.mjs   # bestehende, unverändert grün
python manage.py test stadium_editor.test_surroundings_axes stadium_editor.test_model_registry
```
Die neuen Tests prüfen: (1) ohne Feld identische Koordinaten zum bisherigen Adapter für mehrere Rahmen und Punkte, (2) **alle registrierten Manifeste** in `blueprints/v2/models/` — ohne Feld unverändert, mit Feld Ortsplan-Tribüne = Modell-Tribüne über `standForCenter`, (3) Frankfurt: Enden gespiegelt, Längsseiten gleich, alle vier Seiten per `standForCenter` passend, Altadapter hätte SUED geliefert, (4) Umfeldgeometrie (Gebäude, Straßen, Bäume) folgt den Achsen, Kartendaten bleiben unverändert, (5) ungültige/widersprüchliche Achsen werden im Adapter und in der Kalibrierung abgewiesen, (6) die Unity-Szene reicht `calibration.surroundingsAxes` durch, die Dortmund-Editorszene nicht. Lokal gegen die Replit-Dateien vom 13.10. ausgeführt: 6/6 bzw. 3/3 grün; `unity_calibration.test.mjs` und das Gladbach-Manifest bleiben unberührt (kein `surroundingsAxes` in 901/908/915).
