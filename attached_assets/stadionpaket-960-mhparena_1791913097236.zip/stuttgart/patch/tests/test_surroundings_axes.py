"""Optionales Kalibrierfeld surroundingsAxes: Ortsplan folgt den Modellachsen; Altbestand unverändert."""
from copy import deepcopy

from django.test import SimpleTestCase

from . import model_registry as registry

FRANKFURT = {
    "roofMinHeight": 3, "roofMeshPrefixes": ["front3_"], "skipMeshPrefixes": ["MESH_ROOT"],
    "crowdPrefix": "C_", "pitchPrefix": "st081_pitch_", "tickerRotationY": -90,
    "tickerFrontCut": {"normal": [1, 0, 0], "constant": 32},
    "standAxes": {"+x": "OST", "-x": "WEST", "+z": "SUED", "-z": "NORD"},
    "surroundingsAxes": {"NORD": "-z", "WEST": "-x"},
    "orbitDefault": {"azimuth": 0.95, "elevation": 0.65, "distance": 340},
}


class SurroundingsAxesTests(SimpleTestCase):
    def setUp(self):
        self.manifest = deepcopy(registry.model_manifest(908))

    def test_registered_models_without_the_field_keep_registering(self):
        for fmi in registry.registered_fmi_ids():
            manifest = registry.model_manifest(fmi)
            with self.subTest(fmi=fmi):
                registry.validate_model_manifest(manifest)
                axes = manifest["calibration"].get("surroundingsAxes")
                if axes is None:
                    self.assertIsNone(registry.validate_surroundings_axes(manifest["calibration"]))
                else:
                    stands = manifest["calibration"]["standAxes"]
                    self.assertEqual(stands[axes["NORD"]], "NORD")
                    self.assertEqual(stands[axes["WEST"]], "WEST")

    def test_frankfurt_axes_are_accepted_and_bound_to_stand_axes(self):
        m = deepcopy(self.manifest)
        m["calibration"] = deepcopy(FRANKFURT)
        registry.validate_model_manifest(m)
        self.assertEqual(registry.validate_surroundings_axes(m["calibration"]), {"NORD": "-z", "WEST": "-x"})
        contradictions = [({"NORD": "+z", "WEST": "-x"}, "surroundingsAxes.NORD widerspricht"),
                          ({"NORD": "-z", "WEST": "+x"}, "surroundingsAxes.WEST widerspricht")]
        for axes, message in contradictions:
            with self.subTest(axes=axes):
                m["calibration"]["surroundingsAxes"] = axes
                with self.assertRaisesRegex(ValueError, message):
                    registry.validate_model_manifest(m)

    def test_malformed_axes_are_rejected_and_absence_is_legacy(self):
        m = deepcopy(self.manifest)
        m["calibration"] = deepcopy(FRANKFURT)
        for bad in ({"NORD": "-z"}, {"NORD": "-z", "WEST": "-x", "OST": "+x"}, {"NORD": "-y", "WEST": "-x"},
                    {"NORD": "-z", "WEST": "-z"}, "x", 5, [], {}):
            with self.subTest(value=bad):
                m["calibration"]["surroundingsAxes"] = bad
                with self.assertRaisesRegex(ValueError, "surroundingsAxes"):
                    registry.validate_model_manifest(m)
        del m["calibration"]["surroundingsAxes"]
        registry.validate_model_manifest(m)
        self.assertIsNone(registry.validate_surroundings_axes(m["calibration"]))
        self.assertNotIn("surroundingsAxes", self.manifest["calibration"])
