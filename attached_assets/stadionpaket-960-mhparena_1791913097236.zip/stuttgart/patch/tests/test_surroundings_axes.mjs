// Ortsplan-Zuordnung je Stadionmodell (calibration.surroundingsAxes).
// Bestehende Modelle ohne das Feld behalten den bisherigen Adapter bit für bit;
// ein gespiegelt gebautes Modell (Frankfurt) bekommt den Ortsplan an beiden
// Enden UND beiden Längsseiten passend, ohne Geometrie oder standAxes zu ändern.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readdirSync, readFileSync} from 'node:fs';
import * as THREE from '../static/stadium_editor/stage/vendor/three.module.js';
import {editorPointToDortmund, buildDortmundSurroundings, resolveSurroundingsAxes,
  SURROUNDINGS_AXES_DEFAULT} from '../static/stadium_editor/dortmund_surroundings.js';
import {validateCalibration, standForCenter} from '../static/stadium_editor/unity_calibration.js';

const MODELS = new URL('../blueprints/v2/models/', import.meta.url);
const registered = readdirSync(MODELS).filter(name => /^\d+\.json$/.test(name))
  .map(name => ({name, calibration: JSON.parse(readFileSync(new URL(name, MODELS), 'utf8')).calibration}));

// Deutsche Bank Park (FMI 912), Fassung 2: Bänke/WEST bei −x, Heimkurve/NORD bei −z.
const FRANKFURT = {
  roofMinHeight: 3, roofMeshPrefixes: ['front3_'], skipMeshPrefixes: ['MESH_ROOT'],
  crowdPrefix: 'C_', pitchPrefix: 'st081_pitch_', tickerRotationY: -90,
  tickerFrontCut: {normal: [1, 0, 0], constant: 32},
  standAxes: {'+x': 'OST', '-x': 'WEST', '+z': 'SUED', '-z': 'NORD'},
  surroundingsAxes: {NORD: '-z', WEST: '-x'},
  orbitDefault: {azimuth: .95, elevation: .65, distance: 340},
};
// Blaupausen-Rahmen des Deutsche Bank Parks (stadium_data_all: fieldC, axisTheta).
const FRAME = {fieldC: [.1, 4.3], axisTheta: 2.4871};
// Editor-Punkte (OSM-Lage, +x Ost, +y Nord): Stadionbad NO, Trainingsplatz NW, Gebäude SO, Landessportbund W.
const SAMPLES = [[0, 0], [100, 0], [0, 100], [-50, 80], [310.3, 181.8], [-162.7, 140.9], [183.6, -196], [-347.9, -21.2], [.1, 4.3]];
// Der bisherige Adapter, wörtlich (Stand 12.10.2026).
const legacy = (point, frame = {}) => {
  const center = frame.fieldC || [0, 0], theta = frame.axisTheta ?? 0;
  const dx = point[0] - center[0], dy = point[1] - center[1];
  const u = dx * Math.cos(theta) + dy * Math.sin(theta);
  const v = -dx * Math.sin(theta) + dy * Math.cos(theta);
  return [-v, u];
};
const close = (a, b) => assert.ok(Math.abs(a - b) < 1e-9, `${a} != ${b}`);
const sameAs = (actual, expected) => actual.forEach((value, i) => close(value, expected[i]));
// Editor-Richtung → Tribünenname (Rahmenkonvention aller Blaupausen: +X NORD, +Y WEST).
const editorStand = ([u, v]) => Math.abs(u) > Math.abs(v) ? (u > 0 ? 'NORD' : 'SUED') : (v > 0 ? 'WEST' : 'OST');

test('without surroundingsAxes the mapping is the previous adapter, bit for bit', () => {
  for (const frame of [{}, FRAME, {fieldC: [100, 200], axisTheta: Math.PI / 2}]) {
    for (const point of SAMPLES) {
      assert.deepEqual(editorPointToDortmund(point, frame), legacy(point, frame));
      assert.deepEqual(editorPointToDortmund(point, frame, undefined), legacy(point, frame));
      assert.deepEqual(editorPointToDortmund(point, frame, SURROUNDINGS_AXES_DEFAULT), legacy(point, frame));
      assert.deepEqual(editorPointToDortmund(point, frame, {NORD: '+z', WEST: '-x'}), legacy(point, frame));
    }
  }
  assert.deepEqual(editorPointToDortmund([52.5, 0]), [-0, 52.5]);
  assert.deepEqual(editorPointToDortmund([0, 34]), [-34, 0]);
});

test('every registered model is accepted; models without the field stay unchanged', () => {
  assert.ok(registered.length > 0, 'keine registrierten Modelle gefunden');
  for (const {name, calibration} of registered) {
    assert.equal(validateCalibration(calibration), calibration, name);
    if (calibration.surroundingsAxes === undefined) {
      for (const point of SAMPLES)
        assert.deepEqual(editorPointToDortmund(point, FRAME, calibration.surroundingsAxes), legacy(point, FRAME), name);
    } else {
      // Ein Modell mit dem Feld: der Ortsplan landet auf den Achsen, die standAxes NORD und WEST nennen.
      for (const point of SAMPLES) {
        const [u, v] = [point[0], point[1]];
        if (!u && !v) continue;
        const [x, z] = editorPointToDortmund(point, {}, calibration.surroundingsAxes);
        assert.equal(standForCenter({x, z}, calibration.standAxes), editorStand([u, v]), `${name} ${point}`);
      }
    }
  }
});

test('Frankfurt: both ends and both long sides follow the model axes, geometry untouched', () => {
  assert.equal(validateCalibration(FRANKFURT), FRANKFURT);
  for (const point of SAMPLES) {
    const before = legacy(point, FRAME);
    const after = editorPointToDortmund(point, FRAME, FRANKFURT.surroundingsAxes);
    close(after[0], before[0]);      // Längsseiten: unverändert (WEST bleibt −x)
    close(after[1], -before[1]);     // Enden: gespiegelt (NORD jetzt −z)
  }
  // Richtung zum NORD-Ende des Ortsplans (Editor +X nach Drehung) → Modell −z, WEST-Seite → Modell −x.
  const northEnd = [FRAME.fieldC[0] + 100 * Math.cos(FRAME.axisTheta), FRAME.fieldC[1] + 100 * Math.sin(FRAME.axisTheta)];
  const westSide = [FRAME.fieldC[0] - 80 * Math.sin(FRAME.axisTheta), FRAME.fieldC[1] + 80 * Math.cos(FRAME.axisTheta)];
  sameAs(editorPointToDortmund(northEnd, FRAME, FRANKFURT.surroundingsAxes), [0, -100]);
  sameAs(editorPointToDortmund(westSide, FRAME, FRANKFURT.surroundingsAxes), [-80, 0]);
  // Tribünenname des Modells (standAxes) = Tribünenname im Ortsplan, für alle vier Seiten.
  for (const [u, v] of [[100, 0], [-100, 0], [0, 80], [0, -80], [60, 50], [-60, -50]]) {
    const [x, z] = editorPointToDortmund([u, v], {}, FRANKFURT.surroundingsAxes);
    assert.equal(standForCenter({x, z}, FRANKFURT.standAxes), editorStand([u, v]));
  }
  // Der bisherige Adapter hätte die Enden vertauscht:
  const [, zLegacy] = legacy(northEnd, FRAME);
  assert.equal(standForCenter({x: 0, z: zLegacy}, FRANKFURT.standAxes), 'SUED');
});

test('environment geometry follows the axes; map data is never mutated', () => {
  const square = [[0, 0], [10, 0], [10, 20], [0, 20], [0, 0]];
  const data = {buildings: [square], buildingHeights: [12], roads: [{p: [[0, 0], [10, 0]], w: 2}], trees: [[10, 20]]};
  const before = JSON.stringify(data);
  const box = (env, name) => { const g = env.group.getObjectByName(name).geometry; g.computeBoundingBox(); return g.boundingBox; };
  const legacyEnv = buildDortmundSurroundings(THREE, data);
  const explicitEnv = buildDortmundSurroundings(THREE, data, {}, SURROUNDINGS_AXES_DEFAULT);
  const frankfurtEnv = buildDortmundSurroundings(THREE, data, {}, FRANKFURT.surroundingsAxes);
  try {
    for (const name of ['ENV_BUILDINGS', 'ENV_ROADS']) {
      const a = box(legacyEnv, name), b = box(explicitEnv, name), c = box(frankfurtEnv, name);
      assert.deepEqual(b.min.toArray(), a.min.toArray()); assert.deepEqual(b.max.toArray(), a.max.toArray());
      close(c.min.x, a.min.x); close(c.max.x, a.max.x);       // Längsseiten gleich
      close(c.min.z, -a.max.z); close(c.max.z, -a.min.z);     // Enden gespiegelt
    }
    const walls = box(legacyEnv, 'ENV_BUILDINGS');
    close(walls.min.x, -20); close(walls.max.x, 0); close(walls.min.z, 0); close(walls.max.z, 10);
    const crowns = frankfurtEnv.group.getObjectByName('ENV_TREE_CROWNS');
    const matrix = new THREE.Matrix4(); crowns.getMatrixAt(0, matrix);
    const position = new THREE.Vector3().setFromMatrixPosition(matrix);
    close(position.x, -20); close(position.z, -10);
    assert.equal(JSON.stringify(data), before);
    assert.deepEqual(frankfurtEnv.group.userData.counts, {green: 0, water: 0, roads: 1, buildings: 1, trees: 1});
  } finally { legacyEnv.dispose(); explicitEnv.dispose(); frankfurtEnv.dispose(); }
});

test('invalid or contradictory axes fail closed, in the adapter and in the calibration', () => {
  for (const axes of [null, [], 'NORD', {NORD: '+z'}, {NORD: '+z', WEST: '-z'}, {NORD: '+y', WEST: '-x'},
    {NORD: '+z', WEST: '-x', OST: '+x'}, {NORD: 'z', WEST: 'x'}])
    assert.throws(() => resolveSurroundingsAxes(axes), /Ortsplan-Achsen/);
  assert.throws(() => editorPointToDortmund([0, 0], {}, {NORD: '+z', WEST: '+z'}), /Ortsplan-Achsen/);
  assert.throws(() => buildDortmundSurroundings(THREE, {}, {}, {NORD: '+x', WEST: '+x'}), /Ortsplan-Achsen/);
  const c = structuredClone(FRANKFURT);
  c.surroundingsAxes = {NORD: '+z', WEST: '-x'};          // widerspricht standAxes (NORD liegt bei −z)
  assert.throws(() => validateCalibration(c), /widerspricht standAxes: surroundingsAxes\.NORD/);
  c.surroundingsAxes = {NORD: '-z', WEST: '+x'};          // WEST liegt bei −x
  assert.throws(() => validateCalibration(c), /widerspricht standAxes: surroundingsAxes\.WEST/);
  for (const bad of [{NORD: '-z'}, {NORD: '-z', WEST: '-x', OST: '+x'}, {NORD: '-z', WEST: '-y'}, 'x', 5])
    { c.surroundingsAxes = bad; assert.throws(() => validateCalibration(c), /Kalibrierung fehlt: surroundingsAxes/); }
  delete c.surroundingsAxes;
  assert.equal(validateCalibration(c), c);
});

test('the Unity scene hands the model axes to the map; the Dortmund editor scene is untouched', () => {
  const scene = readFileSync(new URL('../static/stadium_editor/unity_stadium_scene.js', import.meta.url), 'utf8');
  assert.match(scene, /buildDortmundSurroundings\(THREE, presentation\.surroundings, presentation\.frame,\s*calibration\.surroundingsAxes\)/);
  const editor = readFileSync(new URL('../static/stadium_editor/dortmund_editor_scene.js', import.meta.url), 'utf8');
  assert.doesNotMatch(editor, /surroundingsAxes/);
});
