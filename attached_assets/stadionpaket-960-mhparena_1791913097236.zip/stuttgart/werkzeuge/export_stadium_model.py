"""Offline source-model export – lokale Fassung von scripts/export_stadium_model.py (Replit, 11.10.2026)
plus Bodenregeln der abgenommenen Allianz-Arena-Referenz (12.10.2026):
  * Texturschlüssel "_Base_Texture" (Shader-Graph-Rasen), sonst weißer Rasen.
  * Bodenmarkierungen: Boden-Detailteile mit Alpha-Textur -> transparent:true, alphaTest:1/255
    (Renderer: depthWrite false). Geometrie bleibt.
  * Rasenangleichung: Rasenunterlage/Bodenabdeckung/dunkle Boden-Decals -> Spielfeldtextur +
    uvProjection [uX,uY,uZ,u0,vX,vY,vZ,v0], aus den Original-UVs des Spielfeldmeshes (<pitchPrefix>0)
    per Kleinste-Quadrate-Fit abgeleitet (Bayern: Abweichung 2e-9 zur Referenz).
  * --ground <json>: explizite Teilelisten {"transparentParts":[...], "grassParts":[...]} ("mesh|material"),
    sonst Heuristik mit Vorschlagsausgabe. Bayern-Referenz liegt als boden_915.json bei.
  * --asset-version: Version festnageln, wenn Assets unverändert bleiben (Referenzabgleich).
  * --exclude-meshes a,b,c: gezielte Exportauswahl mit EXAKTEN Meshnamen (kein Präfix) – Kulisse, die nicht
    in die Assets soll; Nachweis in ausschluss_bericht.json (13.10.2026, Frankfurt center2_0–13)."""
import argparse, hashlib, json, sys
from pathlib import Path
import numpy as np, UnityPy
from UnityPy.helpers.MeshHelper import MeshHandler
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
sys.path.insert(0, str(Path(__file__).resolve().parent))
from stadium_editor.model_registry import validate_model_manifest

TEXTURE_KEYS = ("baseColorTexture", "_BaseMap", "_MainTex", "_Base_Texture")  ### ABWEICHUNG: "_Base_Texture" ergänzt

def matrix(transform):
    p, q, s = transform.m_LocalPosition, transform.m_LocalRotation, transform.m_LocalScale
    result = np.eye(4)
    result[:3, :3] = Rotation.from_quat([q.x, q.y, q.z, q.w]).as_matrix() @ np.diag([s.x, s.y, s.z])
    result[:3, 3] = [p.x, p.y, p.z]
    return result

def world(transform, cache):
    key = transform.m_GameObject.path_id
    if key not in cache:
        parent = world(transform.m_Father.read(), cache) if transform.m_Father else np.eye(4)
        cache[key] = parent @ matrix(transform)
    return cache[key]


GROUND_Y_MAX, GROUND_Y_MIN = 0.35, -3.1
GRASS_FAMILIES = ("pich", "line007", "line008", "tire_decal")      # nachgewiesene Verursacher dunkler Rechtecke (Bayern-Referenz)
GRASS_CANDIDATES = ("turf", "dtch")                                  # nur Vorschlag; Sichtprüfung entscheidet (Bayern: 2 von 5 übernommen)

def texture_alpha_fraction(pointer, cache):
    """Anteil (0..1) transparenter Pixel (alpha<128) der Basistextur."""
    return texture_alpha_stats(pointer, cache)[0]

def texture_alpha_stats(pointer, cache):
    """(Anteil alpha<128, mittlere Deckung 0..1, min. Deckung 0..1) der Basistextur."""
    if pointer is None:
        return (0.0, 1.0, 1.0)
    key = pointer.path_id
    if key not in cache:
        try:
            image = pointer.read().image
            if image.mode in ("RGBA", "LA", "PA"):
                alpha = np.asarray(image.convert("RGBA"))[:, :, 3].astype(np.float64) / 255.0
                cache[key] = (float((alpha < 0.5).mean()), float(alpha.mean()), float(alpha.min()))
            else:
                cache[key] = (0.0, 1.0, 1.0)
        except Exception:
            cache[key] = (0.0, 1.0, 1.0)
    return cache[key]

def pitch_uv_projection(meshes, binary, pitch_prefix):
    """Affine Projektion (x,y,z)->(u,v) aus den Original-UVs des Spielfeldmeshes <pitchPrefix>0."""
    entry = next((m for m in meshes if m["name"] == pitch_prefix + "0"), None)
    if entry is None:
        raise ValueError(f"Spielfeldmesh {pitch_prefix}0 fehlt – keine Rasenprojektion ableitbar")
    pos = np.frombuffer(binary, "<f4", count=entry["vertexCount"] * 3, offset=entry["positionOffset"]).reshape(-1, 3)
    uv = np.frombuffer(binary, "<f4", count=entry["vertexCount"] * 2, offset=entry["uvOffset"]).reshape(-1, 2)
    # Bodenebene: nur x und z tragen die Projektion; y ist auf dem Rasen ~0 und würde den Fit verfälschen.
    A = np.c_[pos[:, 0].astype(np.float64), pos[:, 2].astype(np.float64), np.ones(len(pos))]
    au = np.linalg.lstsq(A, uv[:, 0].astype(np.float64), rcond=None)[0]
    av = np.linalg.lstsq(A, uv[:, 1].astype(np.float64), rcond=None)[0]
    coeffs = [float(c) if abs(c) > 1e-7 else 0.0 for c in (au[0], 0.0, au[1], au[2], av[0], 0.0, av[1], av[2])]
    residual = float(np.abs(A @ au - uv[:, 0]).max() + np.abs(A @ av - uv[:, 1]).max())
    if residual > 1e-3:
        raise ValueError(f"Spielfeld-UVs sind nicht affin in x/z (Residuum {residual:.4f})")
    texture = next((p["texture"] for p in entry["parts"] if p["texture"]), None)
    if texture is None:
        raise ValueError("Spielfeldmesh ohne Textur – keine Rasenangleichung möglich")
    return coeffs, texture

def family(material):
    name = material.split(".")[0]
    for prefix in ("st011_", "st0", "cm000_", "cm0"):
        if name.startswith(prefix) and "_" in name:
            name = name.split("_", 1)[1]
            break
    return name

ALPHA_CUT_MIN, ALPHA_INVISIBLE = 0.5, 0.99

TRANSLUCENT_MAX_MEAN, TRANSLUCENT_MIN_MIN = 0.97, 0.02

def apply_translucency_rules(meshes, opacity_of_material, calibration, override=None):
    """Teildurchsichtige Materialien (Textur-Alpha gleichmäßig zwischen 2 % und 97 %, z. B. Makrolon, Glas)
    -> transparent:true ohne Alpha-Schnitt; der Renderer blendet sie mit depthWrite=false."""
    crowd, pitch = calibration["crowdPrefix"], calibration["pitchPrefix"]
    skip = calibration.get("skipMeshPrefixes", [])
    report = {"translucentParts": []}
    for entry in meshes:
        if entry["name"].startswith((crowd, pitch)) or any(entry["name"].startswith(p) for p in skip):
            continue
        for part in entry["parts"]:
            key = f'{entry["name"]}|{part["material"]}'
            mean, minimum = opacity_of_material.get(part["material"], (1.0, 1.0))
            translucent = (key in override.get("translucentParts", [])) if override else (
                mean <= TRANSLUCENT_MAX_MEAN and minimum >= TRANSLUCENT_MIN_MIN)
            if translucent and "transparent" not in part:
                part["transparent"] = True
                part["alphaTest"] = 0
                report["translucentParts"].append(f"{key} (Deckung {mean:.0%})")
    return report

def apply_alpha_rules(meshes, binary, alpha_of_material, mask_of_material, calibration, override=None):
    """Alpha-Schnitt (alphaTest, opak) für Nicht-Bodenteile mit >=50 % transparenter Textur; Teile mit >=99 %
    transparenter Textur sind im Original unsichtbar und werden als Ausblendkandidaten gemeldet."""
    crowd, pitch = calibration["crowdPrefix"], calibration["pitchPrefix"]
    skip = calibration.get("skipMeshPrefixes", [])
    report = {"alphaCutParts": [], "invisibleParts": [], "mode": "override" if override else "heuristik"}
    for entry in meshes:
        if entry["name"].startswith((crowd, pitch)) or any(entry["name"].startswith(p) for p in skip):
            continue
        pos = np.frombuffer(binary, "<f4", count=entry["vertexCount"] * 3, offset=entry["positionOffset"]).reshape(-1, 3)
        ground = pos[:, 1].max() <= GROUND_Y_MAX and pos[:, 1].min() >= GROUND_Y_MIN
        for part in entry["parts"]:
            key = f'{entry["name"]}|{part["material"]}'
            alpha = alpha_of_material.get(part["material"], 0.0)
            if part.get("transparent") is True:
                continue  # bereits als transluzent/transparent behandelt
            if override:
                cut = key in override.get("alphaCutParts", [])
            else:
                if alpha >= ALPHA_INVISIBLE:
                    report["invisibleParts"].append(key)
                    continue
                cut = (not ground) and alpha >= ALPHA_CUT_MIN
            if cut and "transparent" not in part:
                mask, cutoff = mask_of_material.get(part["material"], (False, 0.5))
                part["alphaTest"] = cutoff if mask else 0.5
                report["alphaCutParts"].append(key)
    return report

def apply_ground_rules(meshes, binary, alpha_of_material, pitch_prefix, override=None):
    """Bodenmarkierungen transparent, Rasenflächen an das Spielfeld angleichen. Gibt Bericht zurück."""
    projection, grass_texture = pitch_uv_projection(meshes, binary, pitch_prefix)
    report = {"uvProjection": projection, "grassTexture": grass_texture, "transparentParts": [], "grassParts": [],
              "grassCandidates": [], "mode": "override" if override else "heuristik"}
    for entry in meshes:
        if entry["name"].startswith(pitch_prefix):
            continue
        pos = np.frombuffer(binary, "<f4", count=entry["vertexCount"] * 3, offset=entry["positionOffset"]).reshape(-1, 3)
        ground = pos[:, 1].max() <= GROUND_Y_MAX and pos[:, 1].min() >= GROUND_Y_MIN
        for part in entry["parts"]:
            key = f'{entry["name"]}|{part["material"]}'
            if override:
                transparent = key in override.get("transparentParts", [])
                grass = key in override.get("grassParts", [])
            else:
                if not ground:
                    continue
                fam = family(part["material"])
                grass = any(fam.startswith(g) for g in GRASS_FAMILIES)
                if any(fam.startswith(g) for g in GRASS_CANDIDATES):
                    report["grassCandidates"].append(key)
                transparent = alpha_of_material.get(part["material"], 0.0) >= 0.02 and not fam.startswith(("turf", "dtch", "pich"))
            if transparent:
                part["transparent"] = True
                part["alphaTest"] = 1 / 255
                report["transparentParts"].append(key)
            if grass:
                part["texture"] = grass_texture
                part["uvProjection"] = projection
                report["grassParts"].append(key)
    return report

LAMP_KEYWORDS = ("lght", "lamp", "light_bulb", "light_floodlight")   # Replit-Standard; je Bundle erweiterbar (--lamp-materials)

DEFAULT_ROOTS = ("MAIN", "AUDIAREA", "PITCH2021", "MESH_CROWD")

def export_model(SOURCE, seats_path, fmi, name, DEST, calibration, ground_override=None, asset_version=None, lamp_keywords=LAMP_KEYWORDS, roots=DEFAULT_ROOTS, exclude_meshes=()):
    DEST.mkdir(parents=True, exist_ok=True)
    exclude_meshes, excluded = set(exclude_meshes), []
    calibration = {k: v for k, v in calibration.items() if not k.startswith("_")}  # Kommentarfelder bleiben in kalibrierung.json
    env = UnityPy.load(str(SOURCE))
    cache, binary, meshes, tex_refs, lamps = {}, bytearray(), [], {}, []
    alpha_cache, alpha_of_material, mask_of_material, opacity_of_material = {}, {}, {}, {}
    for obj in env.objects:
        if obj.type.name != "MeshFilter":
            continue
        filt = obj.read()
        go = filt.m_GameObject.read()
        renderer = next((c.read() for c in go.m_Components if c.type.name == "MeshRenderer"), None)
        if renderer is None or not renderer.m_Enabled:
            continue
        transform = next(c.read() for c in go.m_Components if c.type.name == "Transform")
        chain, t = [], transform
        while t:
            chain.append(t.m_GameObject.read().m_Name)
            t = t.m_Father.read() if t.m_Father else None
        if not any(n in roots for n in chain):
            continue
        mesh = filt.m_Mesh.read()
        h = MeshHandler(mesh); h.process()
        if not h.m_Vertices:
            continue
        m = world(transform, cache)
        if mesh.m_Name in exclude_meshes:   # exakter Name, bewusst kein Präfix
            v = np.array(h.m_Vertices) @ m[:3, :3].T + m[:3, 3]
            excluded.append({"name": mesh.m_Name, "pathId": str(filt.m_Mesh.path_id), "hierarchy": chain,
                             "vertexCount": len(v), "bounds": [v.min(axis=0).tolist(), v.max(axis=0).tolist()],
                             "materials": [mm.read().m_Name for mm in renderer.m_Materials]})
            continue
        vertices = np.array(h.m_Vertices) @ m[:3, :3].T + m[:3, 3]
        positions = np.asarray(vertices, dtype="<f4")
        po = len(binary); binary.extend(positions.tobytes())
        uv = np.asarray(h.m_UV0, dtype="<f4")
        if len(uv) != len(vertices):
            uv = np.zeros((len(vertices), 2), dtype="<f4")
        uo = len(binary); binary.extend(uv.tobytes())
        parts = []
        for i, tris in enumerate(h.get_triangles()):
            if not tris:
                continue
            mat = renderer.m_Materials[min(i, len(renderer.m_Materials) - 1)].read()
            colors = dict(mat.m_SavedProperties.m_Colors)
            floats = dict(mat.m_SavedProperties.m_Floats)
            color = colors.get("baseColorFactor") or colors.get("_BaseColor") or colors.get("_Color")
            rgb = [max(0, min(1, getattr(color, k))) for k in "rgb"] if color else [0.55]*3
            texture = None
            for key, value in mat.m_SavedProperties.m_TexEnvs:
                if key in TEXTURE_KEYS and value.m_Texture:
                    pointer = value.m_Texture
                    texture = f"texture-{pointer.path_id}.webp"
                    tex_refs[texture] = pointer
                    alpha_of_material[mat.m_Name] = texture_alpha_fraction(pointer, alpha_cache)
                    opacity_of_material[mat.m_Name] = texture_alpha_stats(pointer, alpha_cache)[1:]
                    kw = set(getattr(mat, "m_ValidKeywords", None) or [])
                    cutoff = floats.get("_Cutoff")
                    mask_of_material[mat.m_Name] = (("_ALPHATEST_ON" in kw or floats.get("_AlphaClip") == 1),
                                                    float(cutoff) if cutoff is not None and 0 < cutoff < 1 else 0.5)
                    break
            ix = np.asarray(tris, dtype="<u4").reshape(-1)
            if len(ix) % 3 or int(ix.max()) >= len(vertices):
                raise ValueError("Invalid source triangle indices")
            offset = len(binary); binary.extend(ix.tobytes())
            parts.append({"material": mat.m_Name, "color": rgb, "texture": texture,
                          "indexOffset": offset, "indexCount": len(ix)})
            if any(s in mat.m_Name.lower() for s in lamp_keywords):
                lamps.extend(vertices[np.unique(ix)])
        if not parts:
            continue
        meshes.append({"name": mesh.m_Name, "pathId": str(filt.m_Mesh.path_id),
                       "hierarchy": chain, "positionOffset": po, "uvOffset": uo,
                       "vertexCount": len(vertices), "parts": parts,
                       "bounds": [vertices.min(axis=0).tolist(), vertices.max(axis=0).tolist()]})
    for tname, pointer in tex_refs.items():
        image = pointer.read().image
        image.thumbnail((1024, 1024))
        image.save(DEST / tname, "WEBP", quality=86)
    if not lamps:
        raise ValueError("No actual lamp-material geometry found")
    tree = cKDTree(np.asarray(lamps))
    lights = []
    for obj in env.objects:
        if obj.type.name != "Light":
            continue
        light = obj.read()
        if light.m_Type != 0 or not light.m_Enabled:
            continue
        go = light.m_GameObject.read()
        transform = next(c.read() for c in go.m_Components if c.type.name == "Transform")
        m = world(transform, cache)
        point = m[:3, 3]
        direction = m[:3, :3] @ np.array([0., 0., 1.]); direction /= np.linalg.norm(direction)
        distance = float(tree.query(point)[0])
        if point[1] < 18 or direction[1] >= -.05 or distance > 2:
            continue
        hit = point - direction * point[1] / direction[1]
        if abs(hit[0]) > 40 or abs(hit[2]) > 60:
            continue
        lights.append({"id": str(obj.path_id), "name": go.m_Name,
                       "position": point.tolist(), "direction": direction.tolist(),
                       "color": [light.m_Color.r, light.m_Color.g, light.m_Color.b],
                       "range": light.m_Range, "angle": light.m_SpotAngle,
                       "intensity": light.m_Intensity, "meshDistance": distance})
    if not lights:
        raise ValueError("No source-verified pitch-directed roof lights")
    selected = [min(lights, key=lambda f: f["id"])]
    while len(selected) < min(12, len(lights)):
        candidates = [f for f in lights if f not in selected]
        selected.append(max(candidates, key=lambda f: min(np.linalg.norm(
            np.array(f["position"]) - np.array(s["position"])) for s in selected)))
    for fixture in selected:
        fixture["representedIds"] = [f["id"] for f in lights if min(selected, key=lambda s:
            np.linalg.norm(np.array(f["position"]) - np.array(s["position"]))) is fixture]
    (DEST / "geometry.bin").write_bytes(binary)
    ground_report = apply_ground_rules(meshes, binary, alpha_of_material, calibration["pitchPrefix"], ground_override)
    translucency_report = apply_translucency_rules(meshes, opacity_of_material, calibration, ground_override)
    ground_report.update(translucency_report)
    alpha_report = apply_alpha_rules(meshes, binary, alpha_of_material, mask_of_material, calibration, ground_override)
    ground_report.update(alpha_report)
    (DEST / "bodenregeln_bericht.json").write_text(json.dumps(ground_report, indent=1, ensure_ascii=False))
    missing = sorted(exclude_meshes - {e["name"] for e in excluded})
    if missing:
        raise ValueError(f"--exclude-meshes nennt unbekannte Meshes: {missing}")
    (DEST / "ausschluss_bericht.json").write_text(json.dumps({"excludedMeshes": excluded}, indent=1, ensure_ascii=False))
    manifest = {"format": "unity-mesh-binary-v1", "clubFmiId": fmi, "stadiumName": name,
                "calibration": calibration,
                "source": SOURCE.name, "sourceSha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                "geometrySha256": hashlib.sha256(binary).hexdigest(),
                "meshes": meshes, "textures": list(tex_refs), "fixtures": selected,
                "verifiedFixtureCount": len(lights),
                "limits": ["Source meshes and UVs; simplified browser materials, not original Unity shaders.",
                           "Provided lightmap indices and probes retained as evidence; no full baked-lighting reconstruction."]}
    manifest["assetSha256"] = {n: hashlib.sha256((DEST / n).read_bytes()).hexdigest()
                               for n in ["geometry.bin", *manifest["textures"]]}
    manifest["sourceEvidence"] = {}
    for path in sorted(SOURCE.parent.glob("*.json")):
        document = json.loads(path.read_text())
        manifest["sourceEvidence"][path.name] = {
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "count": document.get("total_seats", document.get("probeCount", document.get("lightmapCount")))
            if isinstance(document, dict) else len(document) if isinstance(document, list) else None}
    seats = json.loads(seats_path.read_text())["seats"]
    index, seat = min(enumerate(seats), key=lambda item:
                      abs(item[1]["pos"][2]+75) + 3*abs(item[1]["pos"][0]) + abs(item[1]["pos"][1]-12))
    x, y, z = seat["pos"]
    manifest["seatView"] = {"position": [z, y, -x], "sourceIndex": index, "sourceFrameRotationY": 90}
    manifest["assetVersion"] = asset_version or hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()[:16]
    validate_model_manifest(manifest)
    (DEST / "manifest.json").write_text(json.dumps(manifest, separators=(",", ":")))
    print(json.dumps({"meshes": len(meshes), "textures": len(tex_refs), "verifiedLights": len(lights),
                      "runtimeLights": len(selected), "binaryMB": round(len(binary)/1024**2, 2),
                      "assetVersion": manifest["assetVersion"], "geometrySha256": manifest["geometrySha256"],
                      "boden": {"modus": ground_report["mode"], "transparent": len(ground_report["transparentParts"]),
                                "rasen": len(ground_report["grassParts"]), "alphaSchnitt": len(ground_report["alphaCutParts"]), "transluzent": len(ground_report["translucentParts"]),
                                "unsichtbar": len(ground_report["invisibleParts"]), "uvProjection": ground_report["uvProjection"]},
                      "ausgeschlossen": [e["name"] for e in excluded]}))
    return manifest

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--bundle", type=Path, required=True); p.add_argument("--seats", type=Path, required=True)
    p.add_argument("--fmi", type=int, required=True); p.add_argument("--name", required=True)
    p.add_argument("--out", type=Path, required=True); p.add_argument("--calibration", type=Path, required=True)
    p.add_argument("--ground", type=Path, help="explizite Bodenlisten (transparentParts/grassParts), sonst Heuristik")
    p.add_argument("--exclude-meshes", default="", help="exakte Meshnamen (Komma), die nicht exportiert werden")
    p.add_argument("--asset-version", help="assetVersion festnageln (nur wenn Assets unverändert bleiben)")
    p.add_argument("--roots", help="zusätzliche Wurzel-Hierarchien, die exportiert werden (Standard: MAIN,AUDIAREA,PITCH2021,MESH_CROWD), kommagetrennt, z. B. EXTRA")
    p.add_argument("--lamp-materials", help="zusätzliche Material-Teilstrings für Leuchtenmeshes, kommagetrennt (z. B. light_fixture,light_01)")
    a = p.parse_args()
    calibration = json.loads(a.calibration.read_text())
    required = {"roofMinHeight", "skipMeshPrefixes", "crowdPrefix", "pitchPrefix", "tickerRotationY", "tickerFrontCut", "standAxes", "orbitDefault"}
    if not isinstance(calibration, dict) or not required <= calibration.keys():
        p.error("--calibration muss den vollständigen calibration-Block enthalten")
    ground = json.loads(a.ground.read_text()) if a.ground else None
    lamps = LAMP_KEYWORDS + tuple(k.strip().lower() for k in a.lamp_materials.split(",") if k.strip()) if a.lamp_materials else LAMP_KEYWORDS
    roots = DEFAULT_ROOTS + tuple(r.strip() for r in a.roots.split(",") if r.strip()) if a.roots else DEFAULT_ROOTS
    exclude = tuple(n for n in a.exclude_meshes.split(",") if n)
    export_model(a.bundle, a.seats, a.fmi, a.name, a.out, calibration, ground, a.asset_version, lamps, roots, exclude)

if __name__ == "__main__":
    main()
