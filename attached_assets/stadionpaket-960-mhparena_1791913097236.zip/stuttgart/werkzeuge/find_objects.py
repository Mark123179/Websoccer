import sys, numpy as np, UnityPy, re
from scipy.spatial.transform import Rotation
def matrix(t):
    p,q,s=t.m_LocalPosition,t.m_LocalRotation,t.m_LocalScale
    r=np.eye(4); r[:3,:3]=Rotation.from_quat([q.x,q.y,q.z,q.w]).as_matrix()@np.diag([s.x,s.y,s.z]); r[:3,3]=[p.x,p.y,p.z]; return r
def world(t,cache):
    k=t.m_GameObject.path_id
    if k not in cache:
        par=world(t.m_Father.read(),cache) if t.m_Father else np.eye(4)
        cache[k]=par@matrix(t)
    return cache[k]
env=UnityPy.load(sys.argv[1]); pat=re.compile(sys.argv[2],re.I); cache={}
rows=[]
for obj in env.objects:
    if obj.type.name!="GameObject": continue
    go=obj.read()
    if not pat.search(go.m_Name): continue
    tr=next((c.read() for c in go.m_Components if c.type.name=="Transform"),None)
    if tr is None: continue
    m=world(tr,cache); p=m[:3,3]
    chain,t=[],tr
    while t: chain.append(t.m_GameObject.read().m_Name); t=t.m_Father.read() if t.m_Father else None
    rows.append((go.m_Name,"/".join(reversed(chain[1:3])),p.round(1).tolist()))
for r in sorted(rows)[:60]: print(r)
print(len(rows),"objects")
