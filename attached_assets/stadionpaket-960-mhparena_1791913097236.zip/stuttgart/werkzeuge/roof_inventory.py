"""Vollständige Dach-Inventur: ALLE MeshFilter/MeshRenderer im Bundle (auch deaktivierte, alle Wurzeln, LODs),
Bounds, Dreiecke, Materialien, Texturen, Alpha-Anteil, Blend/Mask, Renderer-Status, LODGroup-Zugehörigkeit."""
import sys, json, numpy as np, UnityPy, collections
from UnityPy.helpers.MeshHelper import MeshHandler
from scipy.spatial.transform import Rotation
def matrix(t):
    p,q,s=t.m_LocalPosition,t.m_LocalRotation,t.m_LocalScale
    r=np.eye(4); r[:3,:3]=Rotation.from_quat([q.x,q.y,q.z,q.w]).as_matrix()@np.diag([s.x,s.y,s.z]); r[:3,3]=[p.x,p.y,p.z]; return r
def world(t,cache):
    k=t.m_GameObject.path_id
    if k not in cache:
        par=world(t.m_Father.read(),cache) if t.m_Father else np.eye(4)
        cache[k]=par@matrix(t)
    return cache[k]
env=UnityPy.load(sys.argv[1]); ymin=float(sys.argv[2]) if len(sys.argv)>2 else 25.0
cache={}; texcache={}
def alpha_frac(ptr):
    if ptr is None: return None
    k=ptr.path_id
    if k not in texcache:
        try:
            im=ptr.read().image
            texcache[k]=float((np.asarray(im.convert("RGBA"))[:,:,3]<128).mean()) if im.mode in ("RGBA","LA","PA") else 0.0
        except Exception: texcache[k]=-1
    return texcache[k]
# LODGroups: welche Renderer gehören zu welcher LOD-Stufe
lod_of={}
for obj in env.objects:
    if obj.type.name!="LODGroup": continue
    g=obj.read()
    for li,lod in enumerate(g.m_LODs):
        for r in lod.renderers:
            if r.renderer: lod_of[r.renderer.path_id]=(obj.path_id,li,round(float(lod.screenRelativeHeight),3))
go_active={}
rows=[]; counts=collections.Counter()
for obj in env.objects:
    if obj.type.name!="MeshFilter": continue
    filt=obj.read(); go=filt.m_GameObject.read()
    rend=None; rend_id=None
    for c in go.m_Components:
        if c.type.name=="MeshRenderer": rend=c.read(); rend_id=c.path_id
    tr=next(c.read() for c in go.m_Components if c.type.name=="Transform")
    chain,t=[],tr
    active=bool(go.m_IsActive)
    while t:
        g=t.m_GameObject.read(); chain.append(g.m_Name); active=active and bool(g.m_IsActive)
        t=t.m_Father.read() if t.m_Father else None
    mesh=filt.m_Mesh.read() if filt.m_Mesh else None
    if mesh is None: counts["ohne Mesh"]+=1; continue
    h=MeshHandler(mesh); h.process()
    if not h.m_Vertices: counts["leer"]+=1; continue
    m=world(tr,cache); v=np.array(h.m_Vertices)@m[:3,:3].T+m[:3,3]
    counts["gesamt"]+=1
    if v[:,1].max()<ymin: continue
    mats=[]
    for mm in (rend.m_Materials if rend else []):
        if not mm: mats.append(("<null>",None,None,None)); continue
        mat=mm.read(); base=None
        for k,val in mat.m_SavedProperties.m_TexEnvs:
            if k in ("baseColorTexture","_BaseMap","_MainTex","_Base_Texture") and val.m_Texture: base=val.m_Texture; break
        kw=set(getattr(mat,"m_ValidKeywords",None) or []); fl=dict(mat.m_SavedProperties.m_Floats)
        mode=("blend" if ("_BUILTIN_SURFACE_TYPE_TRANSPARENT" in kw or "_SURFACE_TYPE_TRANSPARENT" in kw) else "opaque")+("+mask" if ("_ALPHATEST_ON" in kw or fl.get("_AlphaClip")==1) else "")
        cols=dict(mat.m_SavedProperties.m_Colors); bc=cols.get("baseColorFactor") or cols.get("_BaseColor") or cols.get("_Color")
        mats.append((mat.m_Name, base.read().m_Name if base else None, alpha_frac(base), mode, [round(getattr(bc,c),2) for c in "rgba"] if bc else None))
    tris=sum(len(x) for x in h.get_triangles())
    rows.append({"mesh":mesh.m_Name,"path":"/".join(reversed(chain)),"active":active,"rendererEnabled":bool(rend and rend.m_Enabled),"hasRenderer":rend is not None,
                 "lod":lod_of.get(rend_id),"tris":tris,"min":v.min(0).round(1).tolist(),"max":v.max(0).round(1).tolist(),"mats":mats,"pathId":str(filt.m_Mesh.path_id)})
print("Meshes gesamt:",dict(counts),"| LODGroups:",len({v[0] for v in lod_of.values()}),"| Meshes mit y_max >=",ymin,":",len(rows))
rows.sort(key=lambda r:(r["path"].split("/")[1] if "/" in r["path"] else "", -r["tris"]))
for r in rows:
    flags=("" if r["active"] else " INAKTIV")+("" if r["rendererEnabled"] else " RENDERER-AUS")+(f" LOD{r['lod'][1]}" if r["lod"] else "")
    print(f"{r['mesh']:28s} {r['path'].split('/')[1] if '/' in r['path'] else '':9s} tris={r['tris']:6d} y[{r['min'][1]:5.1f},{r['max'][1]:5.1f}] x±{max(abs(r['min'][0]),abs(r['max'][0])):6.1f} z±{max(abs(r['min'][2]),abs(r['max'][2])):6.1f}{flags}")
    for m in r["mats"]: print(f"      mat={m[0]} tex={m[1]} alpha={m[2] if m[2] is None else round(m[2],2)} {m[3]} base={m[4]}")
json.dump(rows,open(sys.argv[3] if len(sys.argv)>3 else "/dev/null","w"),indent=1)
