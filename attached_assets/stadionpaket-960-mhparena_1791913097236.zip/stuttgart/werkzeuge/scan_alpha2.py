"""Echte Transparenz: Anteil transparenter Pixel je Basistextur; Meshes, die solche Texturen nutzen."""
import sys, json, numpy as np, UnityPy, collections
env=UnityPy.load(sys.argv[1]); man=json.load(open(sys.argv[2]))
texcache={}
def alpha_fraction(texobj):
    pid=texobj.path_id
    if pid in texcache: return texcache[pid]
    try:
        im=texobj.read().image
        if im.mode in ("RGBA","LA"):
            a=np.asarray(im.convert("RGBA"))[:,:,3]; fr=float((a<128).mean())
        else: fr=0.0
    except Exception as e: fr=-1
    texcache[pid]=fr; return fr
mats={}
for obj in env.objects:
    if obj.type.name!="Material": continue
    m=obj.read(); base=None; name=None
    for k,v in m.m_SavedProperties.m_TexEnvs:
        if k in ("baseColorTexture","_BaseMap","_MainTex","_Base_Texture") and v.m_Texture:
            base=v.m_Texture; name=base.read().m_Name; break
    fl=dict(m.m_SavedProperties.m_Floats)
    kw=set(getattr(m,'m_ValidKeywords',None) or [])
    mats[m.m_Name]={"tex":name,"alpha":alpha_fraction(base) if base else 0.0,"mask":("_ALPHATEST_ON" in kw or fl.get("_AlphaClip")==1),"cutoff":fl.get("_Cutoff")}
rows=[]
for e in man["meshes"]:
    for p in e["parts"]:
        mi=mats.get(p["material"],{})
        if (mi.get("alpha") or 0)>=0.02:
            lo,hi=e["bounds"]; rows.append((mi["alpha"],e["name"],p["material"],mi["tex"],"mask" if mi["mask"] else "blend",p["indexCount"]//3,[round(v,1) for v in lo],[round(v,1) for v in hi]))
rows.sort(key=lambda r:(-r[0],r[1]))
print(len(rows),"Teile mit ≥2 % transparenten Texturpixeln")
for r in rows: print(f"alpha={r[0]:.2f} {r[1]:30s} {r[2]:30s} tex={r[3]:28s} {r[4]:5s} tris={r[5]:6d} x[{r[6][0]:7.1f},{r[7][0]:7.1f}] y[{r[6][1]:5.1f},{r[7][1]:5.1f}] z[{r[6][2]:7.1f},{r[7][2]:7.1f}]")
