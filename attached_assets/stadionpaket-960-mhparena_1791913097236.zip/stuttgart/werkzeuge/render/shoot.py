import asyncio, sys, json, subprocess, time, os
from playwright.async_api import async_playwright
from PIL import Image
import numpy as np
PORT=8765
def blank(path):
    a=np.asarray(Image.open(path).convert('L'),dtype=float); return a.mean()<4 or a.std()<2
async def shoot(b,name,params,w,h,outdir):
    for attempt in range(3):
        pg=await b.new_page(viewport={"width":w,"height":h},device_scale_factor=1)
        logs=[]; pg.on("console",lambda m:logs.append(m.text)); pg.on("pageerror",lambda e:logs.append("PAGEERROR "+str(e)))
        url=f"http://127.0.0.1:{PORT}/harness.html?{params}&w={w}&h={h}&nocache={time.time()}"
        t0=time.time(); await pg.goto(url, wait_until="load", timeout=120000)
        await pg.wait_for_function("window.__ready===true || (window.__error!==undefined && window.__error!==null)", timeout=300000)
        err=await pg.evaluate("window.__error")
        if err: print(name,"ERROR",err[:600]); await pg.close(); return False
        # zwei Frames + expliziter Neu-Render, dann Aufnahme
        await pg.evaluate("new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))")
        await pg.evaluate("window.__mounted.update({})")
        await pg.wait_for_timeout(1200)
        path=f"{outdir}/{name}.png"; await pg.locator("#stage").screenshot(path=path)
        await pg.close()
        if not blank(path): print(name,"ok %.1fs"%(time.time()-t0), "(Versuch %d)"%(attempt+1) if attempt else ""); return True
        print(name,"leer, wiederhole")
    print(name,"FEHLER: Bild bleibt leer"); return False
async def main(shots, outdir):
    os.makedirs(outdir, exist_ok=True)
    srv=subprocess.Popen([sys.executable,"-m","http.server",str(PORT),"--bind","127.0.0.1"],cwd="render",stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    time.sleep(1.0)
    try:
        async with async_playwright() as p:
            b=await p.chromium.launch(args=["--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader","--ignore-gpu-blocklist","--enable-webgl","--disable-gpu-sandbox"])
            for name,params,w,h in shots: await shoot(b,name,params,w,h,outdir)
            await b.close()
    finally: srv.terminate()
shots=json.loads(sys.argv[1]); asyncio.run(main(shots, sys.argv[2]))
