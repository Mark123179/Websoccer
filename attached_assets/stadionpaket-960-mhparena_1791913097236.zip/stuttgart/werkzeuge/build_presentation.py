"""presentation_<fmi>.json für den Render-Harness – wie unity_presentation()/runtime_presentation() im Projekt.
Aufruf: build_presentation.py <fmi> "<Stadionname im Blueprint-Bundle>" <manifest.json> <assetVersion> <livescene.json> <bundle.js.gz> <out> [--ohne-korrektur]
Keine lokalen IDs: der Verein wird nur über clubFmiId identifiziert; clubId/capacity werden nicht geschrieben (Vorschau-Harness).
Umfeld-Prüfung: Gebäude, die im Stadion-Umriss liegen, und degenerierte Flächen werden für die VORSCHAU entfernt
und gemeldet (geometrisches Kriterium, keine festen Listenindizes). Der Produktivbestand wird nicht berührt."""
import sys, json, gzip, collections
fmi, name, manifest_path, version, livescene, bundle, out = int(sys.argv[1]), sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7]
raw=gzip.open(bundle,"rt",encoding="utf-8").read(); data=json.loads(raw[raw.index("["):raw.rindex("]")+1])
geo=next(s for s in data if s["meta"]["name"]==name)
scene=json.load(open(livescene)); man=json.load(open(manifest_path))
legacy=geo.get("bg") or {}; live=geo.get("surroundings") or {}
buildings=legacy.get("buildings") or live.get("buildings") or []
surr={"source": live.get("source") or legacy.get("source") or "OpenStreetMap/BLUEPRINT-Bundle (ODbL)","treeSource":"",
 "green":legacy.get("green") or [],"water":legacy.get("water") or [],"roads":legacy.get("roads") or [],
 "buildings":[b if isinstance(b,list) else b["poly"] for b in buildings],
 "buildingHeights":[None if isinstance(b,list) else b.get("h") for b in buildings],
 "buildingIds":[None if isinstance(b,list) else b.get("id") for b in buildings],"trees":legacy.get("trees") or [],"heightQuality":"schematic"}
def inside(poly,x,y):
    n=len(poly); c=False
    for i in range(n):
        x1,y1=poly[i][:2]; x2,y2=poly[(i+1)%n][:2]
        if (y1>y)!=(y2>y) and x < (x2-x1)*(y-y1)/(y2-y1+1e-12)+x1: c=not c
    return c
outline=geo.get("outline") or []
drop=[i for i,poly in enumerate(surr["buildings"]) if outline and (inside(outline,sum(p[0] for p in poly)/len(poly),sum(p[1] for p in poly)/len(poly)) or any(inside(outline,p[0],p[1]) for p in poly))]
degenerate={k:[i for i,poly in enumerate(surr[k]) if len({tuple(p[:2]) for p in poly})<3] for k in ("green","water","buildings")}
if "--ohne-korrektur" in sys.argv: drop=[]
keep=[i for i in range(len(surr["buildings"])) if i not in drop and i not in degenerate["buildings"]]
surr["buildings"]=[surr["buildings"][i] for i in keep]; surr["buildingHeights"]=[surr["buildingHeights"][i] for i in keep]; surr["buildingIds"]=[surr["buildingIds"][i] for i in keep]
for k in ("green","water"): surr[k]=[poly for i,poly in enumerate(surr[k]) if i not in degenerate[k]]
tot=collections.defaultdict(collections.Counter)
for bl in scene["blocks"]:
    for cnt,idx in bl.get("rle") or []:
        if idx>0: tot[bl["stand"]][idx]+=cnt
pal=scene["palette"]; dc={st:pal[max(c,key=c.get)] for st,c in tot.items() if c}
assert scene["club"]["fmInsideId"]==fmi==man["clubFmiId"], "live-scene, Manifest und Aufruf nennen verschiedene FMI-IDs"
pres={"renderer":"unity-spatial","modelUrl":f"/models/{fmi}/{version}/manifest.json","stadium":scene["stadium"],"clubFmiId":fmi,
      "sourceSha256":man["sourceSha256"],"frame":geo.get("meta") or {},"surroundings":surr,"calibration":man["calibration"],"designColors":dc,
      "_hinweis":"Vorschau für den Render-Harness; Umfeld/Design aus dem öffentlichen live-scene bzw. Blaupausen-Bundle, keine lokalen IDs, nichts davon übernehmen"}
json.dump({"presentation":pres},open(out,"w"))  # keine Szene/Blockdaten im Paket, nur abgeleitete Tribünenfarben
print(f"presentation {scene['stadium']}: designColors {dc} | Umfeld-Vorschau: {len(drop)} Gebäude im Stadionumriss entfernt, degeneriert {({k:v for k,v in degenerate.items() if v})} (nur Vorschaudaten)")
