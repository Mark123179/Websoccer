import sys, json, collections
import numpy as np, UnityPy
from UnityPy.helpers.MeshHelper import MeshHandler
from scipy.spatial.transform import Rotation
def matrix(t):
    p,q,s=t.m_LocalPosition,t.m_LocalRotation,t.m_LocalScale
    r=np.eye(4); r[:3,:3]=Rotation.from_quat([q.x,q.y,q.z,q.w]).as_matrix()@np.diag([s.x,s.y,s.z]); r[:3,3]=[p.x,p.y,p.z]; return r
def world(t,cache):
    k=t.m_GameObject.path_id
    if k not in cache:
        par=world(t.m_Father.read(),cache) if t.m_Father else np.eye(4)
        cache[k]=par@matrix(t)
    return cache[k]
env=UnityPy.load(sys.argv[1]); cache={}
roots=collections.Counter(); sel=[]; skipped=collections.Counter()
for obj in env.objects:
    if obj.type.name!="MeshFilter": continue
    filt=obj.read(); go=filt.m_GameObject.read()
    r=next((c.read() for c in go.m_Components if c.type.name=="MeshRenderer"),None)
    if r is None or not r.m_Enabled: continue
    tr=next(c.read() for c in go.m_Components if c.type.name=="Transform")
    chain,t=[],tr
    while t: chain.append(t.m_GameObject.read().m_Name); t=t.m_Father.read() if t.m_Father else None
    roots["/".join(reversed(chain[-3:]))]+=1
    if not any(n in ("MAIN","AUDIAREA","PITCH2021","MESH_CROWD") for n in chain): skipped["/".join(reversed(chain[-2:]))]+=1; continue
    mesh=filt.m_Mesh.read(); h=MeshHandler(mesh); h.process()
    if not h.m_Vertices: continue
    m=world(tr,cache); v=np.array(h.m_Vertices)@m[:3,:3].T+m[:3,3]
    mats=[mm.read().m_Name for mm in r.m_Materials if mm]
    sel.append((mesh.m_Name,chain,v,mats))
print("ROOT chains (top3):"); [print("  ",k,n) for k,n in roots.most_common(25)]
print("SKIPPED (not MAIN/AUDIAREA/PITCH2021/MESH_CROWD):"); [print("  ",k,n) for k,n in skipped.most_common(15)]
print("selected meshes:",len(sel))
pref=collections.Counter(n.split("_")[0] for n,_,_,_ in sel); print("name prefixes:",pref.most_common(20))
allv=np.concatenate([v for _,_,v,_ in sel]); print("all bounds",allv.min(0).round(1),allv.max(0).round(1))
print("\nCROWD / PITCH / big meshes:")
for n,ch,v,mats in sorted(sel,key=lambda s:s[0]):
    lo,hi=v.min(0).round(1),v.max(0).round(1)
    if n.startswith("C_") or "pitch" in n.lower() or n.startswith("field") or (hi[0]-lo[0])>150 or (hi[2]-lo[2])>150 or hi[1]>40:
        print(f"  {n:38s} {ch[1] if len(ch)>1 else '':12s} x[{lo[0]:7.1f},{hi[0]:7.1f}] y[{lo[1]:5.1f},{hi[1]:5.1f}] z[{lo[2]:7.1f},{hi[2]:7.1f}] {mats[:3]}")
ys=np.concatenate([v[:,1] for n,_,v,_ in sel if not n.startswith("C_")])
print("\nheight histogram non-crowd (bins):",[(a,int(c)) for a,c in zip([-5,0,5,10,15,20,25,30,35,40,45,50,60,80],np.histogram(ys,bins=[-5,0,5,10,15,20,25,30,35,40,45,50,60,80,200])[0])])
cy=np.concatenate([v[:,1] for n,_,v,_ in sel if n.startswith("C_")]); print("crowd y range",cy.min().round(1),cy.max().round(1))
lampmats=collections.Counter(mm for _,_,_,mats in sel for mm in mats if any(s in mm.lower() for s in ("lght","lamp","light_bulb","light_floodlight")))
print("lamp materials:",lampmats.most_common(10))
lights=collections.Counter()
for obj in env.objects:
    if obj.type.name=="Light":
        L=obj.read(); lights[(L.m_Type,bool(L.m_Enabled))]+=1
print("lights (type,enabled):",dict(lights))
