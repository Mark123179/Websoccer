"""Erzeugt Manifest-Varianten mit gefilterter Meshliste (für isolierte Ein-/Ausblend-Renders).
Aufruf: isolate.py <manifest> <out> only|without <regex> [--keep-calibration]
Standard: skipMeshPrefixes leer, roofMinHeight -100, roofMeshPrefixes leer (alles sichtbar, Dach-an-Zustand);
Texturliste wird auf die verbleibenden Meshes beschnitten (schnellere Ladezeit, keine Darstellungsänderung)."""
import json, sys, re
src, out, mode, pattern = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
m=json.load(open(src)); rx=re.compile(pattern)
if mode=="only": m["meshes"]=[e for e in m["meshes"] if rx.search(e["name"])]
elif mode=="without": m["meshes"]=[e for e in m["meshes"] if not rx.search(e["name"])]
if "--keep-calibration" not in sys.argv:
    m["calibration"]["skipMeshPrefixes"]=[]; m["calibration"]["roofMinHeight"]=-100; m["calibration"]["roofMeshPrefixes"]=[]
used={p["texture"] for e in m["meshes"] for p in e["parts"] if p.get("texture")}
m["textures"]=[t for t in m["textures"] if t in used]
json.dump(m,open(out,"w"),separators=(",",":")); print(out, len(m["meshes"]), "Meshes,", len(m["textures"]), "Texturen")
