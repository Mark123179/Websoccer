"""Lichtkalibrierung genau einmal anwenden: fixtures[].intensity = Quellintensität (Unity Light) × Faktor.
Erkennt einen bereits kalibrierten Stand (Manifest == Quelle × Faktor → keine Änderung) und bricht bei unpassenden
Werten ab (weder Quelle noch Quelle × Faktor). Assets bleiben unverändert → assetVersion bleibt; die Manifestrevision
(sha256 des Manifests, wie unity_presentation()) unterscheidet den neuen Inhalt. Schreibt einen Prüfbeleg.
Aufruf: licht_kalibrieren.py <exportordner> <bundle> <faktor> <beleg.json> [--renderer <unity_stadium_scene.js>]"""
import sys, json, hashlib
from pathlib import Path
import UnityPy
sys.path.insert(0, str(Path(__file__).resolve().parent))
from stadium_editor.model_registry import validate_model_manifest

src, bundle, factor, out = Path(sys.argv[1]), sys.argv[2], float(sys.argv[3]), sys.argv[4]
renderer = Path(sys.argv[sys.argv.index("--renderer") + 1]) if "--renderer" in sys.argv else None
path = src / "manifest.json"; m = json.loads(path.read_text())
before_revision = hashlib.sha256(json.dumps(m, sort_keys=True).encode()).hexdigest()[:16]
env = UnityPy.load(bundle)
source = {}
for obj in env.objects:
    if obj.type.name == "Light":
        light = obj.read()
        source[str(obj.path_id)] = {"name": light.m_GameObject.read().m_Name, "intensity": float(light.m_Intensity),
                                    "range": float(light.m_Range), "spotAngle": float(light.m_SpotAngle),
                                    "color": [light.m_Color.r, light.m_Color.g, light.m_Color.b]}
rows = []; state = set()
for f in m["fixtures"]:
    s = source.get(f["id"])
    if s is None: sys.exit(f"ABBRUCH: Leuchte {f['id']} nicht in der Quelle")
    cur = float(f["intensity"]); orig = s["intensity"]
    if abs(cur - orig) < 1e-6: state.add("quelle")
    elif abs(cur - orig * factor) < 1e-6: state.add("kalibriert")
    else: sys.exit(f"ABBRUCH: Leuchte {f['id']} ({s['name']}) hat Intensität {cur}, weder Quelle {orig} noch Quelle×{factor} = {orig*factor}")
    if s["range"] != f["range"] or s["spotAngle"] != f["angle"]:
        sys.exit(f"ABBRUCH: Reichweite/Winkel von {f['id']} weichen von der Quelle ab")
    rows.append({"id": f["id"], "name": s["name"], "quellIntensitaet": orig, "browserIntensitaet": round(orig * factor, 6),
                 "range": f["range"], "angle": f["angle"], "color": f["color"], "position": f["position"], "direction": f["direction"],
                 "representedIds": len(f["representedIds"]), "meshDistance": f["meshDistance"]})
if len(state) != 1: sys.exit(f"ABBRUCH: gemischter Zustand {state}")
already = state == {"kalibriert"}
if not already:
    for f, r in zip(m["fixtures"], rows): f["intensity"] = r["browserIntensitaet"]
    validate_model_manifest(m)
    path.write_text(json.dumps(m, separators=(",", ":")))
after_revision = hashlib.sha256(json.dumps(m, sort_keys=True).encode()).hexdigest()[:16]
beleg = {"stadion": m["stadiumName"], "clubFmiId": m["clubFmiId"], "assetVersion": m["assetVersion"], "geometrySha256": m["geometrySha256"],
         "faktor": factor, "zustandVorher": "bereits kalibriert (keine Änderung)" if already else "Quellwerte",
         "manifestRevisionVorher": before_revision, "manifestRevisionNachher": after_revision,
         "rendererDatei": str(renderer) if renderer else None,
         "rendererSha256": hashlib.sha256(renderer.read_bytes()).hexdigest() if renderer else None,
         "rendererFormel": "onIntensity = fixture.intensity * 8 * min(4, sqrt(representedIds.length)) (unity_stadium_scene.js, unverändert)",
         "regel": "Faktor nur in fixtures[].intensity, genau einmal; nicht zusätzlich im Renderer oder beim Einspielen anwenden. Faktor gilt nur für dieses Stadion.",
         "quellgeprueft": m["verifiedFixtureCount"], "laufzeitleuchten": len(rows), "leuchten": rows}
json.dump(beleg, open(out, "w"), indent=1, ensure_ascii=False)
print(json.dumps({k: v for k, v in beleg.items() if k != "leuchten"}, indent=1, ensure_ascii=False))
