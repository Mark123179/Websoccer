# Volkswagen Arena (FMI 961) — offene Punkte und notwendige Metadatenkorrekturen

Getrennte Liste. Nichts davon ist im Paket umgesetzt; Entscheidung und Freigabe liegen beim Betreiber.

## A · Entscheidungen zum Modell (Empfehlung jeweils zuerst)
1. **Lichtfaktor 1,5** (Quelle 60 → Browser 90, genau einmal in `fixtures[].intensity`). Gemessen im Ticker bei identischer Kamera/Exposure: ×1 Rasen 66 / Gegentribüne 60, ×1,5 ≈ 87 / 73 (Ziel = von Replit abgenommene Freiburg-Helligkeit 86 / 71), ×2 107 / 87, ×4 155 / 118 (Rasen überstrahlt). Alternative: Faktor 1 oder 2 — `licht_kalibrieren.py` auf dem unkalibrierten Export erneut ausführen, Assets/assetVersion bleiben, neue Manifestrevision.
2. **Dachstützen `front3_16/17` gehen mit dem Dach** (`roofMinHeight −1`). Alternative: aus der Dachliste nehmen → Stützenring bleibt ohne Dach stehen (Probeexport v0, Bilder 02/07/08 zeigen die Stummel bei roofMinHeight 24).
3. **Logo-Schriftzüge `front3_29`** (Fassade und Dachblende, eine Quellmesh) gehen mit dem Dach. Alternative: Mesh aus der Dachliste nehmen (prefix-Liste statt `front3_`) → Fassadenlogos bleiben, 36 Dreiecke der Dachblende schweben ohne Dach.
4. **Fangnetz-Abspannung ausgeschlossen** (Masten bis 38,6 m, FM-Ergänzung, real nicht vorhanden). Alternative: nur Netze ausschließen, Masten behalten (Re-Export, neue assetVersion).
5. Kleine Anzeigetafeln `center1_67/68/80/81` auf der Dachliste (Regel); kein Handlungsbedarf.

## B · Metadatenkorrekturen in der Anwendung (nicht Teil des Manifests, gesondert freizugeben)
Der öffentliche live-scene liefert abgeleitet `homeStand: NORD`, `mainStand: NORD`, `farStand: SUED`. Belegt (offizieller Stadionplan, Modell, Blaupause, Plätze):

```json
{
  "meta": {"homeStand": "NORD"},
  "scene_meta": {"mainStand": "WEST", "farStand": "OST"}
}
```

- `homeStand NORD` ist bereits richtig (Nordtribüne, Blöcke 1–16/F, Singing Area).
- `mainStand` muss **WEST** sein (Haupttribüne: Ehrenblock, Logen, Medien, VIP), `farStand` **OST** (Osttribüne/Skylounge).
- Teilansicht der zu ergänzenden Schlüssel; Geometrie, Blöcke, Kapazitäten, Designs, Ausbauten bleiben unberührt; Ergänzung unter Zeilensperre mit Backup und Nachher-Abgleich.

## C · Prüfpunkte an der lokalen Geometrie (lesend prüfen, nichts ändern)
1. **`bg.water[5]` der Wolfsburg-Blaupause hat nur 2 Punkte** (`[-358,3, -223,3]`, `[-375,7, -150,5]`). `buildDortmundSurroundings` wirft bei Polygonen mit < 3 Punkten; wenn dieser Eintrag so in der lokalen Geometrie liegt, lädt die Unity-Szene für Wolfsburg nicht. Im Blaupausen-Bundle betrifft das auch Dortmund `water[5]`, BayArena `water[1,3]`, SNP Arena (8 Einträge), Weserstadion `water[2]`, Alte Försterei `water[5]`, Millerntor `water[4,5]`, Holstein-Stadion `water[5,6]`, St. Jakob-Park `water[1,2,3]`. Da Dortmund und Leverkusen laufen, ist die lokale Geometrie vermutlich bereinigt — bitte bestätigen. Keine Renderer-Änderung durch mich.
2. Rohblaupause führt 6 Stehplatzblöcke im SUED-Unterrang, die wirtschaftliche Zuteilung alle Stehplätze im NORD (richtig). Kein Modellthema, nur zur Kenntnis.

## D · Hinweise ohne Handlungsbedarf
- Kapazität im öffentlichen live-scene 28.917 (= Betreiberangabe); kein Importwert.
- Crowd-/Sitzflächen (`C_*`, Textur `au_choreo1`, grün-weißes Sitzmuster) werden wie bei allen Modellen pro Tribüne mit der Gestaltungsfarbe getönt; im aktuellen Design (einheitlich `#f4f6f8`) bleibt der Quellzustand sichtbar.
- Replits `editor.js` (v65) ist über die Dateischnittstelle nicht lesbar (> 100 KB); die 2D-Ansicht nutzt das produktive `editor.js` von playwebsoccer.de (14.10.).
