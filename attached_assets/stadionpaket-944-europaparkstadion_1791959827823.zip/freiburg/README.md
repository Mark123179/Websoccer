# Europa-Park Stadion · SC Freiburg (FMI 944) — Fassung 1

Stand 13.10.2026 · Quelle `freiburg.bundle` (FM26 Stadium Megapack v3.0, 160 MB, SHA-256 `15b8cef9afe759d25d11bd6469f6bb0de095e2c04af0bf726f62506dffdeddc4`) + `freiburg.json` (34.295 Sitzplätze), `_lightmaps.json`, `_lightprobes.json` (Prüfsummen in `models/944.json` → `sourceEvidence`).
assetVersion **`9643c2ee49684a2e`**, geometrySha256 `8bdac0d593771e8b19fefe096f2ac560e3253e6a56fa75fc1ffcf9dd1333e14f`, 115 Meshes (117.827 Dreiecke), 28 Texturen, **29 Assets**, 7,12 MB, 35 quellgeprüfte Leuchten → 12 Laufzeitleuchten.
Identität nur über `clubFmiId 944` + Vereins-/Stadionname; keine lokale Vereins-/Stadion-ID, keine Kapazität, kein Block-/Design-Datum im Paket. Erstellt und geprüft gegen den **Replit-Stand vom 13.10.2026** (`unity_stadium_scene.js` mit `dortmund_surroundings.js?v=52`, `unity_calibration.js?v=2`, `model_registry.py` mit `validate_surroundings_axes`, `pitch_validation.py` boundary-cross-sections-v1) — kein gemeinsamer Patch nötig, keine Renderer-Datei im Paket, die zurückkopiert werden müsste (`werkzeuge/render/static_replit/` ist nur die Harness-Kopie dieses Stands).

## Befund in einem Satz
Kompaktes, einfach gebautes Bundle (SketchUp-Stil, 665 Meshes: 535 Figuren/Requisiten, 10 Banden, 120 Stadion-/Spielfeld-Meshes): klar getrennte Dachfamilie (Dachplatte, Lichtbänder, Innenkante, V-Stützen, zwei Videotafeln), Fangnetze mit Abspannung hinter beiden Toren und eine 630-m-Panoramakulisse — fünf Meshes per exakten Namen ausgeschlossen, Rest unverändert.

## 1 · Kurvenlage: vier unabhängige Ebenen (Anweisung §2)
| Ebene | Befund | Beleg |
|---|---|---|
| **Reales Stadion** | Offizieller Stadionplan: **Südtribüne = einrangige Fanwand** mit Stehblöcken S/C/F + Sitzblöcken E/V (Heimkurve); **Nordtribüne** N1/N2 Heim-Steh, **Gastbereich N5–N7 / N15–N17** (Ecke zur Osttribüne, Eingang E4 Gäste); **Westtribüne = Haupttribüne** (Business W4/W5, W13–W16, Presse, Logen, Geschäftsstelle, Fanshop, „Eingang Hauptgebäude"); Osttribüne O1–O7/O11–O17. Umfeld (OSM/Nominatim, ODbL): Suwonallee + Flugplatz Freiburg **östlich**, Parkplatz P2 **nördlich**, Achim-Stocker-Straße **süd-/westlich**, Im Wolfswinkel **westlich**, Boulevard/Technische Fakultät/Messe/Stadtbahn Europa-Park Stadion **südöstlich**. | `quellbelege/stadionplan_scf.jpg` (scfreiburg.com/stadion/europa-park-stadion/stadionplaene), `quellbelege/anker_freiburg.json`, `quellbelege/umfeld_pruefung.json`, `quellbelege/osm_*.json` |
| **Quellmodell (native Bounds)** | Gäste-Crowd `C_back1_C1-UltraAway` x 39…58 / z 58…76 und `C_left1_C1-UltraAway` x 34…43 / z 64…78 → **Ecke +x/+z**. Einrangige Fanwand `93_TRIBUNE-01` x ±31, y 1…23, z −98…−64 + `C_right1_C2-UltraHome` y 1,5…23,2 → **−z** (einziger einrangiger Kopf; +z hat zwei Ränge `91_TRIBUNE-01` y 1…8,6 / `.001` y 13,6…27,4). Logen-/Pressefront mit Glas `65_TRIBUNE-Tr-01`, `68_TRIBUNE-Tr-04` (Kd027), `74_TRIBUNE-Tr-08` (Kd028), Logenbau `106/107_TRIBUNE-07/08` x −82…−63 y bis 35,5, Bankbereich `94_TRIBUNE-01` x −59…−45 y 1…8 z ±39, LED-Bande `119_TRIBUNE-19` x −42,7 → **−x**. Spielfeldlängsachse = z. | `quellbelege/inventar_alle.json`, `bilder/isolation/*` |
| **Blaupause** | `axisTheta 110,0°` → +X (NORD-Ende) Peilung **340° (NNW)**, SUED 160°, WEST 250°, OST 70°; `fieldC [11, −25,7]`; Tribünenlabels: SUED 26 Blöcke, WEST mit 3 VIP-Blöcken, NORD 14, OST 12. Abgeleitet im live-scene: `homeStand SUED` (stimmt hier mit der Realität überein), `mainStand SUED`, `farStand NORD` (abgeleitet, **falsch** → Metadatenliste). | `bilder/00-2d-editor.jpg`, `werkzeuge/render/geometry_944_vorschau.json` |
| **Wirtschaftliche Daten (lesend, öffentlicher live-scene)** | Kapazität 34.700; Raster je Tribüne: SUED 12.564 Zellen **alle Steh** (26 Blöcke), WEST 6.104 Sitz + **2.016 VIP**, OST 8.060 Sitz, NORD 6.787 Sitz. Große Stehplatzseite = SUED, VIP = WEST → deckt sich mit Plan und Modell. Lokale Blockkapazitäten/Ausbauten wurden nicht gelesen und nicht berührt. | `werkzeuge/render/livescene_vorschau.json` (ohne lokale ID) |

**Ergebnis (alle vier Ebenen einig):** `standAxes {+x: OST, −x: WEST, +z: NORD, −z: SUED}`, `surroundingsAxes {NORD: +z, WEST: −x}` (= Standardabbildung, ausdrücklich deklariert; keine Spiegelung, keine Drehung, keine Kameraänderung). Geografische Gegenprobe an beiden Enden und beiden Längsseiten (`bilder/11-umfeld-verortet-weit.jpg`, `12-…-nah.jpg`): Suwonallee liegt **0,1 m** auf der bg-Straße an der OST-Seite, Achim-Stocker-Straße **0,8 m** (SUED/WEST), Boulevard 1,7 m (SUED), Parkplatz P2 innerhalb der bg-Fläche am NORD-Ende, Flugplatzfläche innerhalb der bg-Fläche OST, Im Wolfswinkel 13,8 m WEST; OSM-Spielfeldachse 160,1° vs. Blaupause 160,0°. Ticker-Kamera gemeinsam (`tickerRotationY −90`, Bänke bei −x), `tickerFrontCut (1,0,0)/32`, Orbit 0,95/0,65/330.

## 2 · Vorgehen
1. Inventur aller 665 Meshes (`quellbelege/inventar_alle.json`: Pfad, Renderer-Status, LOD (keine), Bounds, Material, Textur-Alpha, Blend/Mask); Texturübersicht `quellbelege/texturen-uebersicht.jpg`.
2. Probeexport v0 ohne Ausschlüsse → Gruppen-Isolierung im aktuellen Renderer (`bilder/isolation/`: 18 Gruppen aus 2 Winkeln, Nahansichten, Sitzkamera, Fangnetz-Geometrie opak eingefärbt).
3. Ausschluss mit **exakten Namen** (`ausschluss_bericht.json`, Hierarchie/Bounds/Material): `79_ROOF-Tr-01` Panoramakulisse (x ±313,6, y −20,9…41,8, z ±304,4; Landschaftstextur Kd021, 31 % Alpha) · **Fangnetze** `13_142` (z −61,2…−60,7) und `13_142.001` (z 60,7…61,2), je x ±28, y 1,9…28,0, Netztextur diffuseTexture_75 (83 % Alpha) — keine Tornetze (die FM-Tore sind nicht Teil des Bundles) · **Abspannung der Fangnetze** `133_59` / `133_59.001` (x ±38, y 1,8…37,9, z ±60,4…68,4, Seile/Pfosten, Textur equip 82 % Alpha). AD (10 Banden/Banner) und SCARECROW (535 Figuren) nicht übernommen.
4. Dachliste aus den Isolierungen, Bodenregeln → `boden_944.json`, OSM-Anker, Abnahmeserie.

## 3 · Dachschalter
`roofMeshPrefixes` (33 Einträge): `124…143_ROOF-04/05/06` Dachplatte mit Trägern (Kd018), `144_ROOF-07` Dachinnenkante/Lichtträger (Kd009), `145_ROOF-08` Dachbalken an den Enden, `61…64_ROOF-Tr-03/04` + `146/147_ROOF-Tr-03/04` transluzente Lichtbänder (Kd022, blend), **`80_jumbotron` + `specificstadium_346_116.001` = Videotafeln an beiden Enden** (y 30…35, Dachzustand-Regel), **`88_ROOF-03`/`89_ROOF-03` = V-förmige Dachstützen ringsum** (Kd020, y 10,3…34,4) und `60_ROOF-Tr-02` (Verbinder/Fußplatten der Stützen, y 9,8…34,9). **`roofMinHeight 9`**: jedes gelistete Mesh liegt vollständig über 9 m → Stützen gehen vollständig mit dem Dach (wie Pylone Leverkusen / Masten Stuttgart), kein Stummel. Nicht Dach trotz Namens: `86_ROOF-01`/`87_ROOF-02` (Umlaufdeck 8,6…9,8 m).
Nachrechnung über das Binary, Regel identisch zum Renderer (`quellbelege/nachweise.json`, `werkzeuge/dach_nachweis.py`): **Dachliste 51.232 / 51.232 Dreiecke Dach; Tribünen (`*TRIBUNE*`) 0 / 59.627; Umlauf/Fassade 0 / 612; Spielfeld 0 / 4.892; Crowd 0 / 298; Banden 0 / 1.142; `82_77` 0 / 24** — kein gelistetes Mesh mit Körperdreiecken, kein ungelistetes mit Dachdreiecken. Dach an/aus mit identischer Kamera: `bilder/01`/`02`, `03`/`04`, `06`/`07`, `08`/`09`; Gegenseite `08`; Isolation `bilder/isolation/dach-koerper-isolation.jpg` (Dachliste allein, Körper allein, Stützen allein, Videotafeln im Ticker mit/ohne Dach).

## 4 · Spielfeld, Boden, Licht
- Spielfeld nach Replits `pitch_validation` (Linienmittelachsen `000STADIUMLINE`, Mesh `st081_pitch_1`, Schnitte ±13/±23/±27 bzw. ±13/±27/±40 m): **105,000 × 68,000 m**, Längsachse z, Geometriehash = Manifest. Spielfeldtextur der Quelle `0002-Freiburg` (Rasen, Linien separat).
- `boden_944.json` (Re-Export deterministisch): transparent 1 (`field_0` Coach-Zonen), **Rasenangleichung 1** (`83_FIELD-02`: Bodenplatte Kd001 unter dem Spielfeld bei y 0, ±38,7 × ±57,8 m → Spielfeldtextur + `uvProjection`, sonst Z-Fighting), Alpha-Schnitt 21 (Zäune/Geländer Kd013/Kd024, Lichtbänder Kd022), transluzent 2 (Logenglas Kd027, 83 % Deckung), unsichtbar 0.
- Leuchten: 126 Spot-Lichter `H_Area.*` der Quelle sitzen an der Dachinnenkante `144_ROOF-07` (y 30…36; `quellbelege/lights_roh.json`); `--lamp-materials 1.019` (Material dieser Kante) → 35 Leuchten ≤ 2 m zum Trägermesh und aufs Spielfeld gerichtet → **12 Laufzeitleuchten** (meshDistance 0,64…1,74 m, `representedIds` decken alle 35). Die 490 Punktlichter `L_Point.*` am Dachrand/Umlauf sind keine Flutlichter und entfallen. Keine erfundenen Lichtorte.

## 5 · Umfeld (Anweisung §4)
Vollständiges Vereinsumfeld der Blaupause (136 Gebäude, 212 Straßen, 158 Grünflächen, 1 Wasser), **ungefiltert**: der Vorschaufilter des Harness („Gebäude im Stadionumriss") trifft hier 0 Gebäude, alle Ansichten entstanden mit `--ohne-korrektur`. Gebäudehöhen schematisch (`heightQuality: schematic`, wie im Projekt). Anker-Abstände siehe §1; die 0,1 m / 0,8 m belegen zugleich, dass bg-Ursprung = OSM-Spielfeldmitte minus `fieldC` (`quellbelege/umfeld_pruefung.json`).

## 6 · Abnahmeserie (`bilder/`)
`00-2d-editor.jpg` (2D-Editor `editor.js` der Produktion, Karte nord-oben, Blöcke/Blockarten/Gestaltung aus dem öffentlichen live-scene, Anker eingezeichnet) · `01/02` 3D-Editor Dach an/aus · `03/04` LiveTicker Dach an/aus · `05` LiveTicker Nacht + Flutlicht · `06/07` Draufsicht an/aus · `08/09` Gegenseite aus/an · `10` Sitzkamera (Haupttribüne) · `11/12` verortete Umfeldansicht · Übersicht `freiburg-ansichten.jpg` · `isolation/` Dach/Körper, Gruppen, Fangnetz-Geometrie, Probeexport v0 (vorher).
Hinweis zur 2D-Ansicht: Replits `editor.js` (v65) ist über die Dateischnittstelle nicht lesbar (> 100 KB); verwendet wurde das identische 2D-Zeichenmodul des produktiven `editor.js` von playwebsoccer.de (13.10.).

## 7 · Paketinhalt
`models/944.json` · `stadium-models/944/9643c2ee49684a2e/` (geometry.bin + 28 Texturen) · `PRUEFSUMMEN.sha256` (Endstand) · `kalibrierung.json`, `boden_944.json`, `ausschluss_namen.txt`, `ausschluss_bericht.json`, `bodenregeln_bericht.json` · `quellbelege/` (Inventur, Nachweise, Lichter, OSM-Anker, Stadionplan, Umfeldprüfung) · `bilder/` · `OFFENE-PUNKTE-UND-METADATEN.md` · `werkzeuge/` (Export, Nachweise, Harness 3D + 2D mit Replit-Renderer-Kopie, Vorschaudaten ohne lokale IDs).

## 8 · Einspielen (Replit, Anweisung §7 — Kontrolle ist keine Freigabe)
1. Lokale Identität (FMI 944, SC Freiburg, Europa-Park Stadion) und Schutzdaten lesend prüfen; fachliche Freigabe einholen, insbesondere für die Dachstützen-Entscheidung (§3) und die Metadatenliste.
2. Vorher-Backup Verein/Stadium/Geometrie/Design/Ausbauten.
3. `scp -r stadium-models/944 root@49.13.5.151:/var/www/assets/stadium-models/`; nach dem Upload zurückladen und gegen `PRUEFSUMMEN.sha256` prüfen.
4. `models/944.json` nach `stadium_editor/blueprints/v2/models/`, committen, `/push`; `python manage.py check_stadium_model --fmi 944 --assets` → `Assets OK: 29 Dateien`.
5. Nur freigegebene Orientierungsmetadaten ergänzen (siehe `OFFENE-PUNKTE-UND-METADATEN.md`), Nachher-Abgleich: Kapazitäten, Blöcke, Designs, Ausbauten identisch.
6. Abnahme im Livemodus mit echten Zielassets und aktuellem Renderer: fünf Ansichten + Draufsicht; Suwonallee/Flugplatz an der OST-Seite, P2 am NORD-Ende, Achim-Stocker-Straße SUED/WEST.

## Reproduktion
```sh
python3 -I werkzeuge/export_stadium_model.py --bundle freiburg.bundle --seats freiburg.json --fmi 944 --name "Europa-Park Stadion" \
  --out export --calibration kalibrierung.json --lamp-materials 1.019 --ground boden_944.json \
  --exclude-meshes "$(cat ausschluss_namen.txt)"
#  → assetVersion 9643c2ee49684a2e
python3 -I werkzeuge/dach_nachweis.py export nachweise.json 'dachliste=^(1[2-4][0-9]_ROOF|6[0-4]_ROOF|8[89]_ROOF-03|80_jumbotron|specificstadium_346_116\.001)' 'tribuenen=TRIBUNE'
python3 -I werkzeuge/roof_inventory.py freiburg.bundle -100 inventar_alle.json
cd werkzeuge/render && python3 shoot.py '[["editor","r=static_replit&p=presentation_fr_v1.json&mode=orbit",1000,560]]' ../../bilder   # Harness
python3 shoot2d.py "x=1" ../../bilder/2d.png                                                                                   # 2D-Editor
```
