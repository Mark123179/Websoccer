# Europa-Park Stadion (FMI 944) — offene Punkte und notwendige Metadatenkorrekturen

Getrennte Liste gemäß Anweisung §6. Nichts davon ist im Paket umgesetzt; Entscheidung und Freigabe liegen beim Betreiber.

## A · Entscheidungen zum Modell (Empfehlung jeweils zuerst)
1. **Dachstützen gehen mit dem Dach** (`88_ROOF-03`, `89_ROOF-03`, `60_ROOF-Tr-02`, V-förmige Außenstützen y 10,3–34,4 m). Empfehlung: so lassen — ohne Dach blieben ringsum freistehende Zacken (siehe `bilder/isolation/vorher-probeexport-v0.jpg`, Bilder 02/07/08). Alternative: Stützen aus `roofMeshPrefixes` streichen und `roofMinHeight` auf 25 heben → Stützen bleiben als Körper stehen; Assets unverändert, nur Manifest/assetVersion neu.
2. **Abspannung der Fangnetze ausgeschlossen** (`133_59`, `133_59.001`: Seile/Pfosten der Netze, ohne Netz in der Luft endend). Empfehlung: ausgeschlossen lassen. Alternative: nur die Netze `13_142`/`13_142.001` ausschließen, Abspannung behalten (Re-Export, neue assetVersion).
3. **Videotafeln auf der Dachliste** (`80_jumbotron`, `specificstadium_346_116.001`, y 30–35 m an beiden Enden) — Regel aus dem Frankfurt-Review; kein Handlungsbedarf, nur zur Kenntnis.

## B · Metadatenkorrekturen in der Anwendung (nicht Teil des Manifests, gesondert freizugeben)
Der öffentliche live-scene liefert abgeleitet `homeStand: SUED`, `mainStand: SUED`, `farStand: NORD`. Belegt (offizieller Stadionplan, Modell, Blaupause, Plätze):

```json
{
  "meta": {"homeStand": "SUED"},
  "scene_meta": {"mainStand": "WEST", "farStand": "OST"}
}
```

- `homeStand SUED` ist bereits richtig (Fanwand S/C/F/E/V).
- `mainStand` muss **WEST** sein (Haupttribüne: Business, Presse, Logen, Geschäftsstelle), nicht SUED; `farStand` entsprechend **OST**.
- Teilansicht der zu ergänzenden Schlüssel; bestehende Geometrie, Blöcke, Kapazitäten, Designs und Ausbauten bleiben unberührt. Ergänzung nur unter Zeilensperre und mit Nachher-Abgleich (Anweisung §7.5/7.6).

## C · Hinweise ohne Handlungsbedarf
- Blaupause/Wirtschaft: SUED ist im live-scene komplett Stehplatz (26 Blöcke, 12.564 Rasterzellen); real sind E/V Sitzblöcke innerhalb der Fanwand. Keine Modellfrage, keine Änderung vorgeschlagen.
- Die Crowd-/Sitzflächen (`C_*`, Textur `au_seat` mit „SC FREIBURG"-Schriftzug) werden wie bei allen Modellen pro Tribüne mit der Gestaltungsfarbe getönt; im aktuellen Design (einheitlich `#f4f6f8`) bleibt der Quellzustand sichtbar.
- Produktionsserver (playwebsoccer.de) hat Stand 13.10. 21:30 noch keinen Unity-Renderer deployt (`unity_stadium_scene.js` 404, `dortmund_surroundings.js` alt) — Abnahme dort erst nach Push des Replit-Stands möglich.
