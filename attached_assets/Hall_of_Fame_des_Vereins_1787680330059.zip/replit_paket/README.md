# Ruhmeshalle — Übergabepaket für Replit

Digitales Vereinsmuseum für den Fußballmanager **Websoccer/MatchEngine** (Django).
Dieses Paket enthält den fertigen, abgenommenen Design-Stand als statische HTML/CSS-Seiten
plus alles, was Replit braucht, um es 1:1 in Django-Templates zu übernehmen.

## Inhalt

```
replit_paket/
├── README.md                  ← diese Datei
├── PROMPT_REPLIT.md           ← der Bau-Prompt für den Replit-Agenten (zuerst lesen!)
├── SPEC_Ruhmeshalle.md        ← vollständige Spezifikation + Datenvertrag
├── GESPRAECHSVERLAUF.md       ← wie das Design entstanden ist (Kontext & Entscheidungen)
├── seiten/                    ← der fertige Design-Stand — im Browser öffnen!
│   ├── 01_eingangshalle.html
│   ├── 02_spielergalerie.html   (8 Hexagon-Vitrinen, Dreh-Tafeln)
│   ├── 03_trainergalerie.html   (gleiche Wand, Trainer-Rekorde)
│   ├── 04_vereinsrekorde.html   (16 Zellen, geschwungene Wand)
│   ├── 06_leerzustand.html      (Modus „Neue Geschichte" bei Karrierestart)
│   ├── ruhmeshalle.css          (das gesamte Styling, eine Datei)
│   ├── hintergruende/           (3 Raum-Renderings — die Architektur liegt IM Bild)
│   ├── platzhalter/             (Motive, Trophäen, Wappen-Dummies)
│   └── assets/                  (players/, crests/, competitions/ aus dem Spiel)
└── werkzeuge/
    ├── polygon_editor.html          (Vitrinen-Ecken der Spieler-/Trainerwand justieren)
    └── polygon_editor_verein.html   (Zellen der Vereinswand justieren)
```

## Wichtigste Regel

**Die HTML/CSS-Dateien sind das abgenommene Design.** Nichts „verbessern", keine
Frameworks, kein Bootstrap, keine Tabellen. Nur: statisches HTML → Django-Template,
Beispieldaten → Template-Variablen. Alle Positionen (Polygone, Kipp-Winkel,
Abstände) wurden vom Manager per Hand vermessen — Zahlenwerte exakt übernehmen.

## Schnellstart Prüfung

`seiten/04_vereinsrekorde.html` im Browser öffnen: 16 Zellen sitzen passgenau auf
der gewölbten Museumswand, Hover dreht die Tafel, unten die Bodenleiste mit dem
Modus-Umschalter „Echte Geschichte / Neue Geschichte".
