# SPEC — Ruhmeshalle (Stand: 25.08.2026, abgenommen)

## 1. Konzept

Die Ruhmeshalle ist das digitale Vereinsmuseum des Fußballmanagers. Keine
Statistikseite — eine Ausstellung: dunkler Stein, Bronze, Gold, Vitrinen,
Spotlights. Die Architektur liegt in drei gerenderten Raumbildern
(`hintergruende/`), das DOM legt nur Inhalte passgenau in die im Bild
vorhandenen Rahmen/Nischen.

Zwei fortlaufende Historien („Modi"):

| Modus | Inhalt |
|---|---|
| `echt` — „Echte Geschichte" | Beginnt mit den realen historischen Vereinsrekorden; simulierte Rekorde des Managers überschreiben sie, wenn sie besser sind. Fortlaufende Vereinsgeschichte. |
| `neu` — „Neue Geschichte" | Ignoriert die reale Historie. Nur Rekorde seit Karrierestart. Beginnt leer (siehe `06_leerzustand.html`). |

## 2. Seiten

1. **01_eingangshalle** — reines Stimmungsbild (goldener Ball in Vitrine),
   einziges DOM-Element ist die Bodenleiste. Datenfrei.
2. **02_spielergalerie** — Panoramawand mit 8 Hexagon-Vitrinen. Rekorde:
   Rekordtorschütze · Meiste Spiele Feldspieler · Meiste Spiele Torwart ·
   Meiste Titel Spieler · Meiste Vorlagen · Spieler des Spiels (meiste) ·
   Schnellstes Tor (leer im Demo) · Höchster Marktwert.
3. **03_trainergalerie** — gleiche Wand, Trainer/Manager-Rekorde:
   Längste Amtszeit · Meiste Titel · Meiste Siege · Beste Punktequote ·
   Dienstältester Manager u. a.
4. **04_vereinsrekorde** — geschwungene Museumswand, 16 Zellen in 2 Reihen:
   Höchster Sieg · Höchste Niederlage · Längste Siegesserie · Serie ohne
   Niederlage · Serie ohne Sieg · Beste Saison · Schlechteste Saison ·
   Meiste Tore Saison · Wenigste Gegentore · Meisterschaften · Pokalsiege ·
   Internationale Titel (leer) · Teuerster Einkauf · Teuerster Verkauf ·
   2 Reserve-Zellen für künftige Rekordarten.
5. **06_leerzustand** — Vereinswand ohne jeden Rekord (Modus `neu`,
   Karrierestart). Muss würdig aussehen, kein Fehlerfall.

## 3. Geometrie (unantastbar)

Jede Vitrine/Zelle ist absolut positioniert mit handvermessenen Werten im
Inline-Style:

```
left:2.32%; top:22.69%; width:9.85%; height:20.75%;
--kipp:-1.47deg;          ← Wandneigung, Inhalt wird per skewY() mitgekippt
--pado:1.8%; --padu:0.4%; ← elastischer Abstand zu schrägen Ober-/Unterkanten
--form:polygon(…)         ← clip-path, Form der Glasfläche in der Wand
```

Diese Werte wurden vom Manager mit den mitgelieferten Polygon-Editoren
(`werkzeuge/`) Ecke für Ecke justiert. **Niemals runden, neu berechnen oder
„aufräumen".** Neue Justage: Editor öffnen → Ecken ziehen → „CSS exportieren"
→ Werte einsetzen.

## 4. Interaktion

- **Hover/Fokus** dreht die Glas-Tafel (3D-Flip); der Rahmen (im Bild) dreht
  nicht mit. Vorderseite: Label (graviert), Portrait/Trophäe/Wappen, Wert,
  Kurzname. Rückseite: voller Name (verlinkt), Saison/Spieltag, Kontext,
  ggf. Spielbericht-Link.
- **Klick auf Namen** → Spielerprofil. Vereins-Links → Vereinsprofil.
- **Modus-Umschalter** (Bodenleiste): blendet über (Demo-JS in jeder Seite),
  wechselt den Datenbestand.
- **Korrektur beantragen** (nur 04, nur Modus `echt`): Overlay-Formular —
  Rekordart, neuer Wert, neuer Halter, „Saison #, Spieltag", Quelle (Pflicht),
  Notiz. POST → Moderationsqueue.

## 5. Darstellungsregeln

- **Saison-Zählung:** „Saison #4 · 28. Spieltag" — nirgends Jahreszahlen.
- **Namen vorn:** „M. Reus" (1 Buchstabe + Punkt + Nachname); hinten voll.
- **Spieler:** Freisteller-Portraits `assets/players/<fm_inside_id>.png`,
  Bronze-Look per CSS-Filter (bereits in `ruhmeshalle.css`), unten weich
  maskiert. Fallback: `platzhalter/default_player.png`.
- **Trainer:** kein Freisteller — Manager-Profilbild oder Default-Silhouette.
- **Wappen:** echtes Gegner-Wappen (`assets/crests/<id>.png`) bei Höchster
  Sieg/Niederlage, vorn und auf der Rückseite.
- **Trophäen:** `platzhalter/trophaee_meisterschale.png` (Meisterschaften),
  `platzhalter/trophaee_pokal_neu.png` (Pokalsiege) — pro Wettbewerb
  austauschbar.
- **Leere Nische:** Label bleibt graviert + Zeile „Dieser Rekord wartet noch
  auf seine Geschichte." Kein Ausblenden, kein Grau.
- Deutsch, Du-Form, deutsche Zahlenformate („28,5 Mio. €").

## 6. Datenvertrag (was Django/Replit dynamisch macht)

Pro belegter Nische/Zelle:

```json
{
  "slug": "record_scorer",
  "kategorie": "spieler | trainer | verein",
  "label": "Rekordtorschütze",
  "wert": "412",
  "einheit": "Tore",
  "halter": {
    "name": "Marco Reus",
    "kurzname": "M. Reus",
    "url": "/players/4711/",
    "bild": "assets/players/4711.png"
  },
  "saison": 4,
  "spieltag": 28,
  "kontext": "Bundesliga",
  "gegner": { "name": "FC Musterstadt", "url": "/clubs/22/", "wappen": "assets/crests/905.png" },
  "spielbericht_url": "/clubs/1/match/8891/report/",
  "quelle": "real | simuliert",
  "motiv": "platzhalter/motiv_biggest_win.jpg"
}
```

- Nische leer ⇒ Objekt fehlt ⇒ Template rendert den Leerzustand der Nische.
- Modus `echt`: `max/min` über beide Quellen je Rekordart.
- Modus `neu`: Filter `quelle == simuliert`.
- Ersetzt werden in den Templates ausschließlich: Werte (`<b>`/`<small>`),
  Namen + `href`, Bild-`src` (Portrait/Wappen/Trophäe/Motiv), Saison-Angaben,
  Kontextzeilen. Geometrie-Styles bleiben statisch.

## 7. Assets

- `hintergruende/raum_eingang.jpg` (Eingangshalle), `raum_spieler.jpg`
  (Spieler- UND Trainerwand), `raum_verein.jpg` (Vereinswand + Leerzustand)
- `platzhalter/motiv_*.jpg` — Stimmungsmotive hinter Vereinsrekorden
- `platzhalter/trophaee_*.png`, `platzhalter/wappen_*.png` — Dummies
- `assets/` — echte Spielassets (players, crests, competitions)
