# Gesprächsverlauf — wie die Ruhmeshalle entstand

Chronologie der Design-Entscheidungen (Manager „Mark" × Claude), damit Replit
den Kontext und die Verbindlichkeit jeder Regel versteht.

## Phase 1 — Konzeptfindung
- Start: „Hall of Fame für den Verein" — Gegenstück zum Managerprofil.
  Erste Entwürfe als Dashboard-/Kartenlayout wurden **verworfen**: zu sehr
  Statistikseite.
- Anforderung präzisiert: **fortlaufende Ruhmeshalle** mit zwei Historien —
  „Echte Geschichte" (beginnt mit realen Vereinsdaten, Manager schreibt
  weiter) und „Neue Geschichte" (nur Manager-Ära). Beide Interessen abdecken.
- Referenzbilder (GPT-generiert) setzten die Messlatte: Museum mit Bronze-
  Statuen, Gravuren, goldener Ball in Vitrine, AAA-Game-Optik. Beschluss:
  **Architektur in gerenderten Raumbildern**, DOM nur für Inhalte.

## Phase 2 — Die Räume
- Drei Räume gebaut: Eingangshalle (datenfrei, goldener Ball),
  Spieler-/Trainerwand (Panorama mit 8 Hexagon-Vitrinen), Vereinswand
  (geschwungene Wand, 16 Zellen in 2 Reihen).
- Bodenleiste als Navigation („Ausstellungsräume statt Menüs") mit
  Modus-Umschalter Echte/Neue Geschichte.
- Leerzustand als eigene Pflicht-Seite: Verein ohne Rekorde muss würdig
  aussehen („Dieser Rekord wartet noch auf seine Geschichte.").

## Phase 3 — Passgenauigkeit (viel Handarbeit!)
- Die Inhalte müssen **haargenau** in die im Bild liegenden Rahmen passen —
  inkl. Wölbung des Raums. Automatisches Vermessen reichte nicht.
- Lösung: **Polygon-Editoren** (mitgeliefert in `werkzeuge/`). Der Manager
  hat jede Ecke jedes Polygons selbst gezogen; die exportierten Werte sind
  verbindlich (Inline-Styles `--form`, plus abgeleitete `--kipp`, `--pado`,
  `--padu` für Neigung und schräge Kanten). **Nie neu berechnen.**

## Phase 4 — Inhalte & Regeln
- **Dreh-Tafeln:** Vorderseite Label + Wert + Kurzname; Rückseite voller Name
  (Link zum Spielerprofil), Saison, Kontext, Spielbericht-Link.
  „Vorher …"-Zeilen (alter Rekord) wurden komplett **entfernt**.
- **Kurznamen** vorn: „M. Reus"-Format.
- **Spieler = Bronze-CutOut-Freisteller** (echte Spiel-Portraits mit
  CSS-Filter). **Trainer = kein CutOut** — Manager-Profilbild oder Default.
- **Trophäen:** erst Liga-Logos, dann verworfen — jetzt gerenderte
  Meisterschale + Pokal-Kelch (austauschbar pro Wettbewerb).
- **Wappen:** echte Gegner-Wappen bei Höchster Sieg/Niederlage.
- **Saison-Zählung:** Das Spiel rechnet in „Saison #1, #2, …" —
  alle Jahreszahlen/Kalenderdaten wurden aus dem Design entfernt.
- Teuerster Einkauf/Verkauf: Portrait mittig, Betrag darunter (justiert).
- **Korrektur-Antrag** (nur Modus `echt`): Formular für falsch übertragene
  reale Rekorde, mit Quellenpflicht → Moderationsqueue.

## Phase 5 — Übergabe
- Erstes Replit-Paket geschnürt (18.08.2026), danach nur noch Kommunikation
  (Community-Texte), keine Design-Änderungen mehr.
- Dieses Paket (Stand 25.08.2026) ist der abgenommene, finale Stand. Aufgabe von Replit: Django-Templates
  + Datenanbindung laut `PROMPT_REPLIT.md` und `SPEC_Ruhmeshalle.md`,
  Design unverändert.
