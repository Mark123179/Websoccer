# Prompt für Replit

Du integrierst ein fertig gestaltetes Feature in eine bestehende Django-App (Websoccer,
deutscher Fußballmanager). Das Feature heißt **Ruhmeshalle** — ein digitales
Vereinsmuseum. Das Design ist final und abgenommen; deine Aufgabe ist ausschließlich
die technische Übernahme.

## Was du bekommst

- `seiten/*.html` + `seiten/ruhmeshalle.css` — fertige, pixelgenau abgestimmte Seiten
- `SPEC_Ruhmeshalle.md` — Datenvertrag (welche Werte dynamisch werden) und alle Regeln
- Hintergrund-Renderings und Platzhalterbilder

## Deine Aufgaben

1. **Django-Templates erstellen** aus den 5 HTML-Seiten (gemeinsames Parent-Template
   für Bodenleiste/Modus-Umschalter ist sinnvoll). Markup und CSS unverändert
   übernehmen — inklusive aller Inline-Styles mit `--form`, `--kipp`, `--pado`,
   `--padu` (vermessene Polygon-Geometrie, niemals neu berechnen).
2. **Beispieldaten durch Template-Variablen ersetzen** — exakt die Stellen aus dem
   Datenvertrag in `SPEC_Ruhmeshalle.md` §Datenvertrag (Werte, Namen, Links,
   Bild-`src`, Saison-Nummern).
3. **Zwei Modi implementieren:**
   - `echt` („Echte Geschichte"): reale historische Startrekorde ∪ simulierte
     Rekorde, der bessere Wert gewinnt.
   - `neu` („Neue Geschichte"): nur simulierte Rekorde seit Karrierestart;
     leere Nischen zeigen den Text aus `06_leerzustand.html`.
   - Rekord-Modell bekommt `quelle: real|simuliert`. Der Umschalter in der
     Bodenleiste wechselt den Modus (Reload oder Fetch — frei wählbar, Überblendung
     wie im Demo-JS beibehalten).
4. **Korrektur-Antrag** (Formular in `04_vereinsrekorde.html`): nur im Modus `echt`
   anzeigen (CSS-Regel existiert schon), POST an einen neuen Endpoint, Einträge
   landen in einer Moderationstabelle.
5. **Verlinkungen setzen:** Spielername → Spielerprofil (`/players/<id>/`),
   Verein → Vereinsprofil (`/clubs/<id>/`), Spielbericht → Match-Report.
   Trainer-Nischen: Portrait = Profilbild des Managers (Fallback
   `default_player`-Grafik), Links explizit.

## Regeln (nicht verhandelbar)

- **Saison-Zählung:** Es gibt keine Jahreszahlen. Immer „Saison #1, #2, …" und
  optional „· 28. Spieltag". Auch in Formularen und Tooltips.
- **Namenskürzung Vorderseite:** „M. Reus" (erster Buchstabe Vorname + Punkt +
  Nachname). Rückseite: voller Name.
- **Spieler-Portraits** sind Freisteller (`assets/players/<fm_inside_id>.png`),
  bekommen den Bronze-Look rein per CSS (Filter existiert). Trainer bekommen KEINE
  Freisteller — Manager-Profilbild oder Default.
- Kein Bootstrap, keine UI-Bibliothek, keine Tabellen, keine weißen Karten.
  `ruhmeshalle.css` ist die einzige Stildatei des Features.
- Das Artboard folgt dem Layout-Contract des Spiels (fester Sidebar + Artboard,
  `dashboard-scaler`); die Seiten hängen sich in das bestehende Base-Template.
- Alle UI-Texte deutsch, Du-Form.

## Abnahme-Kriterien

- Seiten sehen im Browser exakt aus wie die statischen Vorlagen (Screenshot-Vergleich)
- Hover dreht Tafeln; Rückseiten zeigen Name/Saison/Kontext; Links funktionieren
- Modus-Umschalter liefert unterschiedliche Datenbestände
- Verein ohne simulierte Rekorde zeigt im Modus `neu` den würdigen Leerzustand
