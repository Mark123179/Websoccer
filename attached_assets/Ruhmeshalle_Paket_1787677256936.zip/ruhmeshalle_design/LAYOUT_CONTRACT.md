# Layout-Contract (wörtlicher Auszug)

Quelle: `game/static/game/css/global-dashboard/layout-nav.css`, Kopfkommentar. Diese Regeln sind im Projekt verbindlich und gelten auch für die Ruhmeshalle.

```css
/* ============================================================
   WEBSOCCER LAYOUT CONTRACT  (siehe auch game-stage.css)
   ------------------------------------------------------------
   Jede Hauptseite liegt innerhalb .dashboard-scaler. Die Bühne
   ist DYNAMISCH (Wide-Shell): der Scaler-JS in base.html setzt
   --dashboard-shell-width auf :root und .dashboard-scaler. Der
   AAA-Player-Profile-Fix wurde zum globalen Standard erhoben.

   Zentrale Layout-Token:
     --sidebar                  = 232px (mobil 0)
     --dashboard-shell-width    = 1884px Fallback, JS überschreibt
     --dashboard-content-width  = shell - sidebar (zentrale Größe)
     --dashboard-artboard-width = content-width (Default für alle
                                  Hauptseiten-Wrapper)

   Pflicht für neue Seiten:
     - Liegen innerhalb .dashboard-scaler.
     - Äußerer Seitenwrapper nutzt var(--dashboard-content-width)
       (über --dashboard-artboard-width geerbt) — KEINE eigene
       Artboard-Breite definieren.
     - Internes Grid/Flex/Container-Queries: ok.
     - Vertikales Scrollen: erlaubt, wenn fachlich gewollt.
     - Horizontales Scrollen: nur mit fachlicher Begründung.

   Verboten für Haupt-Artboards:
     - width: 100vw  |  width: clamp(...vw...)
     - max-width: 1180px / 1200px / 1440px
     - margin-inline:auto auf einem kleineren Artboard
     - eigene transform: scale() / eigener Viewport-Scaler
   Kleine vw-Werte (Icons, Badges, Typografie) sind ok, solange
   sie keine Layout-Breite definieren.
   ============================================================ */

```

## Token-Fallbacks

Im Spiel setzt ein Scaler-Script in `base.html` die Werte per JS. Für die eigenständigen Demo-Dateien genügen diese Fallbacks:

```css
:root {
  --sidebar: 232px;
  --dashboard-shell-width: 1884px;
  --dashboard-content-width: calc(var(--dashboard-shell-width) - var(--sidebar));
  --dashboard-artboard-width: var(--dashboard-content-width);
}
```

## Basis-Schrift des Projekts

```css
font-family: Inter, "Segoe UI", Roboto, Arial, Helvetica, sans-serif;
```

Für die Ruhmeshalle darf und soll eine charaktervolle Display-Schrift ergänzt werden (frei lizenziert, über Google Fonts einbindbar). Die Body-Schrift bleibt Inter.

## Warum das hier so wichtig ist

Die Vorgängerseite `halloffame.css` liegt in Version 11 vor. Sie positioniert jede Kachel prozentgenau auf einem festen 995×700-Bild, kommentiert als „pixel-verified". Jede Bildänderung erzwang eine Neuvermessung aller Kacheln. Das ist der Fehler, den dieses Design nicht wiederholen darf.
