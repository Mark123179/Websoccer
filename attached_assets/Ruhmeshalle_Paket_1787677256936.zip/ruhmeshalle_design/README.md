# Ruhmeshalle — Paket

Zwei Empfänger, in dieser Reihenfolge:

1. **Claude Design** baut die Räume → Einstieg unten, „Startprompt"
2. **Replit** baut das Modul → Einstieg über `REPLIT_Ruhmeshalle.md`

Claude Design kommt zuerst. Die dort entstehenden Dateien gehen anschließend als Vorlage in Ticket 3 des Replit-Handoffs.

---

## Startprompt

Diesen Text zusammen mit dem Paket an Claude Design geben:

> Du bist Ausstellungsdesigner für ein AAA-Fußballmanagerspiel — mit dem Blick eines Art Directors, der schon Museumsräume für das FIFA Museum und Interfaces für EA Sports FC gestaltet hat. Deine Aufgabe ist eine digitale Ruhmeshalle, an die sich Spieler noch Jahre später erinnern.
>
> Lies zuerst `DESIGN_BRIEF.md` vollständig. Das ist die verbindliche Vorgabe. Danach `LAYOUT_CONTRACT.md` — dessen Regeln sind hart und nicht verhandelbar. `SPEC_Ruhmeshalle.md` liefert Datenmodell und Begründungen, `GESPRAECHSVERLAUF.md` erklärt, warum die Entscheidungen so ausfielen.
>
> Baue fünf eigenständige HTML-Dateien plus eine gemeinsame `ruhmeshalle.css`, wie in `DESIGN_BRIEF.md` §0 und §11 beschrieben. Verwende die Platzhalterdaten aus `daten/`, die Raumbilder aus `hintergruende/` und die Platzhalterbilder aus `platzhalter/`.
>
> In `vorlagen/` liegen zwei bereits funktionierende Dateien: `vereinsrekorde.html` zeigt die komplette Vereinswand auf dem echten Hintergrund, `tafel_demo.html` eine einzelne Hexagon-Tafel mit Flip. Beide sind verbindliche Vorlagen — übernimm ihre Geometrie, Typografie und Filterwerte, statt neu zu erfinden.
>
> Das Leitprinzip lautet: Das Hintergrundbild liefert ausschließlich Architektur, jeder Inhalt ist DOM. Die Bilder in `referenz/` zeigen die gewünschte Wirkung, nicht die gewünschte Bildaufteilung — lies dazu `referenz/HINWEIS.md`.
>
> Denke nicht in Dashboards. Denke wie ein Museumsarchitekt.

---

## Was drin ist

| Datei / Ordner | Inhalt | Rolle |
|---|---|---|
| `DESIGN_BRIEF.md` | Vollständiger Bauauftrag: Prinzip, Layout-Contract, Tafelaufbau, Slots, Filter, Bodenleiste, Abnahmekriterien | **verbindlich** |
| `LAYOUT_CONTRACT.md` | Wörtliche Layoutregeln des Projekts plus Token-Fallbacks | **verbindlich** |
| `SPEC_Ruhmeshalle.md` | Modulspezifikation: Datenmodell, Berechnungsregeln, Bauabfolge, Entscheidungslog E01–E35 | Referenz |
| `GESPRAECHSVERLAUF.md` | Wie die Entscheidungen zustande kamen, inklusive verworfener Alternativen | Kontext |
| `daten/*.json` | Platzhalterdaten je Raum. Feldnamen entsprechen dem späteren Django-Template-Kontext | Arbeitsmaterial |
| `platzhalter/*` | Neutrale Bilddateien (Silhouetten, Wappen, Trophäen, Motive), damit nichts auf 404 läuft | Arbeitsmaterial |
| `referenz/*.png` | KI-Referenzbilder, siehe `referenz/HINWEIS.md` | Stimmungsreferenz |
| `hintergruende/` | Raumbilder: Eingang und Verein fertig, Spieler als Entwurf, plus Bildauftrag | Arbeitsmaterial |
| `REPLIT_Ruhmeshalle.md` | Vier Tickets, verifizierte Anknüpfungspunkte im Repo, Agenten-Empfehlung | **für Replit** |
| `vorlagen/` | Zwei funktionierende Dateien — Vereinswand und Einzeltafel | **verbindlich** |

**Bei Widersprüchen gilt:** `DESIGN_BRIEF.md` → `SPEC_Ruhmeshalle.md` → `GESPRAECHSVERLAUF.md` → Referenzbilder.

---

## Zu liefern

| Datei | Inhalt |
|---|---|
| `ruhmeshalle.css` | Eine Datei, kein Framework, kein Build-Step |
| `01_eingangshalle.html` | Datenfreier HUB — nur Bodenleiste über dem Bild |
| `02_spielergalerie.html` | 8 Slots, 6 belegt, hexagonal |
| `03_trainergalerie.html` | 8 Slots, 5 belegt, hexagonal |
| `04_vereinsrekorde.html` | 16 Slots, 14 belegt, hochrechteckig — Vorlage liegt bei |
| `06_leerzustand.html` | Verein ohne jeden Rekord — 16 leere Nischen, muss trotzdem würdig aussehen |

Eine Transfergalerie gibt es nicht — die zwei Transferrekorde sitzen in den Vereinsrekorden.

---

## Die drei häufigsten Fehler bei diesem Modul

1. **Inhalte ins Hintergrundbild rechnen.** Rekordhalter wechseln, Slots können leer sein, Tafeln drehen sich. Eingebranntes ist irgendwann falsch — und eine gemalte Tafel kann sich nicht drehen.
2. **Pixelgenaue Einzelpositionen je Tafel.** Die Vorgängerseite hat das gemacht und liegt in CSS-Version 11 vor. Ein Grid in einer prozentual definierten Zone verteilt die Slots selbst.
3. **Eine eigene Artboard-Breite setzen.** `--dashboard-artboard-width` wird geerbt, nie überschrieben. Kein `100vw`, kein `max-width`, kein eigener `transform: scale()`.

---

## Danach — der Weg zu Replit

Die von Claude Design gelieferten Dateien gehen als **verbindliche Vorlage** in Ticket 3. Was dort nicht drin steht, wird nicht gebaut.

`REPLIT_Ruhmeshalle.md` enthält vier Tickets in fester Reihenfolge:

| Ticket | Inhalt | Braucht Design? |
|---|---|---|
| 1 | Datenschicht: Modelle, Registry, Engine, Tasks | nein |
| 2 | Creator-Reiter für die Seed-Pflege | nein |
| 3 | Die vier Räume | **ja** |
| 4 | Antragswesen | nein |

**Ticket 1 und 2 können parallel zum Design laufen** — sie berühren kein Frontend. Das ist der schnellste Weg: Während Claude Design die Räume baut, entsteht darunter bereits die Datenschicht.
