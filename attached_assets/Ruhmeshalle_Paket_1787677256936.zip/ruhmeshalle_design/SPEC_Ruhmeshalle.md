# SPEC_Ruhmeshalle.md

**Modul:** Ruhmeshalle (Vereinsmuseum & Rekordsystem)
**Version:** 1.0
**Status:** Implementierungsbereit
**Datum:** 2026-08-05
**Vorgänger:** `management/halloffame/` (Prototyp, wird ersetzt)

---

## 1. Zweck und Abgrenzung

Die Ruhmeshalle ist ein digitales Vereinsmuseum. Sie ersetzt die bisherige Hall-of-Fame-Seite unter `management/halloffame/`, die drei Rekorde ad-hoc im Request berechnet und zwei Kacheln mit demselben Wert doppelt anzeigt.

Das Modul besteht aus zwei getrennten Teilen:

1. **Rekord-Engine** — eine materialisierte Datenschicht, die aus vorhandenen Aggregattabellen alle Vereinsrekorde berechnet und fortschreibt.
2. **Museum-Frontend** — fünf Ausstellungsräume, in denen diese Rekorde als Denkmäler statt als Tabelle präsentiert werden.

**Ausdrücklich nicht Bestandteil dieser Version:** Räume „Historische Spiele" und „Ewige Legenden", manager-weite Hall of Fame, Touch-/Mobile-Optimierung, Auswertung von `report_data`.

---

## 2. Grundmodell: Zwei Historien

Jeder Verein besitzt zwei parallel geführte Historien, umschaltbar in jedem Raum.

| Modus | Untertitel | Inhalt |
|---|---|---|
| **Echte Geschichte** | Reale Vereinshistorie | Startet mit recherchierten Realwerten (Seed). Sim-Leistungen überschreiben diese, sobald sie besser sind. |
| **Neue Geschichte** | Seit Beginn der Liga | Ausschließlich in der Simulation entstandene Rekorde. |

Die Ruhmeshalle ist **vereinsgebunden, nicht managergebunden**. Ein Managerwechsel oder -abgang verändert keinen Rekord.

Der Modus ist reiner View-State über Query-Parameter (`?modus=echt` / `?modus=neu`), wird beim Raumwechsel mitgereicht und **nicht** pro Nutzer gespeichert. Damit ist jeder Link teilbar und zeigt bei allen dasselbe.

Vereine ohne Seed zeigen in „Echte Geschichte" dieselben Werte wie in „Neue Geschichte". Der Umschalter bleibt trotzdem sichtbar.

---

## 3. Datenmodell

### 3.1 `ClubRecord`

Materialisierter Rekordbestand. **Eine Zeile je `(club, record_key, source)`.**

| Feld | Typ | Beschreibung |
|---|---|---|
| `club` | FK → Club | |
| `record_key` | CharField | Schlüssel aus der Registry, z. B. `top_scorer` |
| `source` | CharField | `SEED` \| `SIM` |
| `value_numeric` | DecimalField | Sortierrelevanter Wert |
| `value_display` | CharField | Anzeigewert, z. B. `8:0`, `28,5 Mio.`, `2012/13` |
| `holder_name` | CharField | Freitext-Name des Rekordhalters |
| `holder_player` | FK → Player, null | optional |
| `holder_coach` | FK → HistoricCoach, null | optional |
| `holder_manager` | FK → Manager, null | optional |
| `opponent_name` | CharField, blank | Freitext |
| `opponent_club` | FK → Club, null | optional |
| `context_line` | CharField, blank | z. B. `91 Punkte`, `4 Jahre 2 Monate` |
| `record_date` | DateField, null | Datum der Aufstellung |
| `period_from` / `period_to` | DateField, null | für Zeiträume (Amtszeiten) |
| `season` | CharField, blank | |
| `competition` | CharField, blank | |
| `source_note` | TextField, blank | Quellenangabe bei SEED |
| `linked_match` | FK → SimulatedMatch, null | für Ergebnis-Rekorde |
| `is_anonymized` | BooleanField | siehe §7.4 |
| `updated_at` | DateTimeField | |

**Constraint:** `UniqueConstraint(fields=['club','record_key','source'])`

**Schreibpfad-Trennung (zentral):**
- `source='SEED'` wird **ausschließlich** über den Creator-Reiter geschrieben.
- `source='SIM'` wird **ausschließlich** von der Recompute-Engine geschrieben.
- Kein Codepfad darf beide Quellen schreiben. Der Recompute filtert grundsätzlich auf `source='SIM'`.

Damit ist strukturell ausgeschlossen, dass ein Recompute recherchierte Realwerte zerstört. Mechanik statt Disziplin.

### 3.2 `ClubRecordBreak`

Ereignislog jedes Rekordwechsels. Quelle für das „gilt seit"-Datum auf der Tafel.

| Feld | Typ |
|---|---|
| `club` | FK → Club |
| `record_key` | CharField |
| `old_value_numeric` / `old_value_display` / `old_holder_name` | |
| `new_value_numeric` / `new_value_display` / `new_holder_name` | |
| `broke_seed` | BooleanField — der überbotene Wert stammte aus dem Seed |
| `season` | CharField |
| `occurred_at` | DateTimeField |

Das Log erfasst **alle** Rekordwechsel, auch sim-interne. Es erzeugt **keine** UI-Chronik (siehe E08).

### 3.3 `ClubRecordCorrectionRequest`

Nach Vorbild `PlayerEditRequest`.

| Feld | Typ |
|---|---|
| `club` | FK → Club |
| `record_key` | CharField |
| `requester` | FK → Manager |
| `old_value` | CharField (automatisch befüllt) |
| `new_value` | CharField — **Pflicht** |
| `new_holder` | CharField |
| `new_date` | CharField |
| `source_reference` | TextField — **Pflicht** |
| `requester_note` | TextField, blank |
| `status` | `open` \| `accepted` \| `rejected` |
| `decided_by` / `decided_at` / `decision_note` | |

### 3.4 `HistoricCoach`

Nach exaktem Vorbild `Referee`. Ermöglicht reale Trainer als Entitäten mit eigenen Bildern.

| Feld | Typ |
|---|---|
| `fm_inside_id` | CharField, unique |
| `name` | CharField |
| `nationality` | CharField, blank |
| `birth_date` | DateField, null |
| `notes` | TextField, blank |

Pflege im Creator-Mode analog `creator/referee_edit.html`.

### 3.5 Asset-Erweiterungen in `asset_urls.py`

```python
def coach_face_url(fm_inside_id):   # /coaches/face_{id}.png
def manager_avatar_url(manager):    # Avatar aus Managerprofil
```

`coach_face_url()` ist eine 1:1-Kopie von `referee_face_url()` inklusive png/jpg/jpeg-Fallback und Default-Silhouette. Bilder liegen auf dem Host unter `/var/www/assets/coaches/`, ausgeliefert über Nginx wie alle anderen Assets. **Nicht** im Repo.

---

## 4. Rekord-Registry

Jeder Rekord ist ein Registry-Eintrag: Schlüssel, Bezeichnung, Raum, Slot-Nummer, Berechnungsfunktion, Seed-Fähigkeit, Bildquelle. Ein neuer Rekord ist damit ein Eintrag plus eine Funktion — kein Eingriff in Engine oder Template.

### 4.1 Spielergalerie — 6 belegt, 8 Slots

| Slot | `record_key` | Bezeichnung | Berechnung |
|---|---|---|---|
| 1 | `top_scorer` | Rekordtorschütze | Σ `PlayerSeasonStat.goals` je Spieler/Verein |
| 2 | `top_assists` | Rekordvorlagengeber | Σ `assists` |
| 3 | `most_apps_field` | Meiste Spiele Feldspieler | Σ `matches`, Position ≠ TW |
| 4 | `most_apps_gk` | Meiste Spiele Torwart | Σ `matches`, Position = TW |
| 5 | `most_titles_player` | Meiste Titel Spieler | siehe §5.5 |
| 6 | `highest_market_value` | Höchster Marktwert | siehe §5.6 |
| 7–8 | — | Reserve, leer | |

### 4.2 Trainergalerie — 5 belegt, 8 Slots

| Slot | `record_key` | Bezeichnung | Berechnung |
|---|---|---|---|
| 1 | `longest_tenure` | Längste Amtszeit | `ManagerCareerEntry`, `ended_at − started_at` |
| 2 | `most_matches_coach` | Meiste Spiele | Pflichtspiele in Amtszeit |
| 3 | `most_titles_coach` | Meiste Titel | Titel in Amtszeit |
| 4 | `best_ppg_coach` | Bester Punkteschnitt | siehe §5.4 |
| 5 | `most_wins_coach` | Meiste Siege | Pflichtspielsiege in Amtszeit |
| 6–8 | — | Reserve, leer | |

### 4.3 Vereinsrekorde — 14 belegt, 16 Slots (zwei Reihen à 8)

| Slot | `record_key` | Bezeichnung |
|---|---|---|
| 1 | `biggest_win` | Höchster Sieg |
| 2 | `biggest_defeat` | Höchste Niederlage |
| 3 | `longest_win_streak` | Längste Siegesserie |
| 4 | `longest_unbeaten` | Längste Serie ohne Niederlage |
| 5 | `longest_winless` | Längste Serie ohne Sieg |
| 6 | `best_season` | Beste Saison |
| 7 | `worst_season` | Schlechteste Saison |
| 8 | `most_goals_season` | Meiste Tore in einer Saison |
| 9 | `fewest_conceded_season` | Wenigste Gegentore in einer Saison |
| 10 | `championships` | Meisterschaften |
| 11 | `cup_wins` | Pokalsiege |
| 12 | `international_titles` | Internationale Titel |
| 13–14 | — | Reserve, leer |

Slots 10–12 zeigen das Trophäenbild aus `ClubTrophy` statt eines Rekordmotivs. `international_titles` bleibt leer, bis das Modul „Internationale Wettbewerbe" existiert.

### 4.4 Transfergalerie — 2 belegt, 4 Slots

| Slot | `record_key` | Bezeichnung | Quelle |
|---|---|---|---|
| 1 | `record_signing` | Teuerster Einkauf | `PlayerTransferHistory.fee_eur` |
| 2 | `record_sale` | Teuerster Verkauf | `PlayerTransferHistory.fee_eur` |
| 3–4 | — | Reserve, leer | |

**Gesamt: 23 Rekorde, 34 Slots.** Slot-Belegung ist über alle 26 Vereine identisch.

---

## 5. Berechnungsregeln

### 5.1 Wettbewerbs-Scope

- **Pflichtspiele zählen:** Liga (`SeasonFixture`), Pokal (`CupFixture`), später internationale Wettbewerbe.
- **Freundschaftsspiele zählen nie.** Harter Filter auf `SimulatedMatch.match_type='freundschaft'` und `PlayerSeasonStat.competition='Freundschaft'`.

Begründung: Freundschaftsspiele sind im System nicht knapp. Zählten sie, wären Einsatz- und Torrekorde durch beliebig ansetzbare Testspiele manipulierbar.

### 5.2 Saisonrekorde

`best_season`, `worst_season`, `most_goals_season`, `fewest_conceded_season` sind **ligagebunden** (`LeagueStandings`). Punkte existieren nur in der Liga; ein Pokallauf würde die Vergleichbarkeit zerstören.

Vergleich über verschiedene Ligagrößen erfolgt **rein nach Punkten**. Liga und Platzierung erscheinen als Kontext auf der Tafelrückseite. Eine Normierung auf Punkte pro Spiel wird verworfen — als große Zahl auf einer Museumstafel wäre „2,4" wertlos.

### 5.3 Serien

`longest_win_streak`, `longest_unbeaten`, `longest_winless` laufen **wettbewerbsübergreifend** über alle Pflichtspiele in chronologischer Reihenfolge. Zeitachse: `SeasonFixture.scheduled_date` bzw. Datum der Pokalrunde.

**Elfmetersiege zählen als Siege.** `CupFixture.winner_club` und `decided_by` sind eindeutig auswertbar. Ein im Elfmeterschießen gewonnenes Spiel reißt keine Siegesserie.

### 5.4 Punkteschnitt Trainer

- **Nur Ligaspiele.** Pokalspiele vergeben keine Punkte; eine Wertung wäre eine Erfindung.
- Zuordnung: `SeasonFixture.scheduled_date` innerhalb `ManagerCareerEntry.started_at … ended_at`.
- Punkte 3/1/0, geteilt durch Ligaspiele.
- **Mindestschwelle: 30 Ligaspiele.** Bewusst ligagrößenunabhängig, da die 4 Ligen unterschiedlich viele Spieltage haben.

### 5.5 Titelzuordnung

- **Spieler:** zählt für einen Titel, wenn er in der Titelsaison einen `PlayerSeasonStat`-Eintrag für diesen Verein hat (mindestens ein Pflichtspiel). Reine Kaderzugehörigkeit genügt nicht.
- **Trainer:** zählt für einen Titel, wenn das Titeldatum in seine Amtszeit fällt.

### 5.6 Höchster Marktwert

`PlayerMarketValueSnapshot` ist **nicht vereinsgebunden**. Gewertet wird der höchste Snapshot **innerhalb der Vereinszugehörigkeit**, ermittelt über Zu- und Abgangsdaten aus `PlayerTransferHistory`. Spieler ohne Transferhistorie: alle Snapshots zählen.

### 5.7 Mindestschwelle Spieler

Für alle Spielerrekorde mit Quotientencharakter: **50 Pflichtspiele für den Verein.** Feste Zahl, auf der Tafel erklärbar („mind. 50 Spiele"). In der Anfangsphase bleiben betroffene Tafeln länger leer — gewollt.

### 5.8 Gleichstände

**Der frühere Wert gewinnt, immer.** Sortierung nach Wert, dann nach Datum aufsteigend. Ein Gleichstand bricht keinen Rekord.

Nebenwirkung, die ausdrücklich erwünscht ist: Rekorde werden bei Gleichstand nicht neu geschrieben, wodurch `ClubRecordBreak` und die Vereinsnews nicht mit Nicht-Ereignissen geflutet werden.

Tiebreaker je Typ:
- `biggest_win` / `biggest_defeat`: Tordifferenz → erzielte Tore (8:0 schlägt 9:1) → Datum
- alle übrigen: Wert → Datum

### 5.9 Merge-Regel der beiden Modi

- **Neue Geschichte:** zeigt ausschließlich `source='SIM'`.
- **Echte Geschichte:** zeigt je `record_key` den besseren Wert aus `SEED` und `SIM`. Bei Gleichstand gewinnt `SEED` (früher).

---

## 6. Recompute-Engine

### 6.1 Verfahren

**Vollständiger Recompute je Verein, keine Inkrementalität.** Die Engine liest ausschließlich aus Aggregattabellen:

`PlayerSeasonStat` · `LeagueStandings` · `SeasonFixture` · `CupFixture` · `MatchResult` · `PlayerTransferHistory` · `PlayerMarketValueSnapshot` · `ManagerCareerEntry` · `ClubTrophy` · `PlayerAwardTitle`

**Kein Zugriff auf `report_data`.** Alle Rekorde, die Spieldetails erfordert hätten (Elfmetertore, Freistoßtore, Comebacks, Zu-Null-Spiele), sind aus dem Katalog gestrichen.

Der Zustand ist jederzeit aus den Rohdaten reproduzierbar; Idempotenz per Konstruktion. Es existiert **genau eine** Berechnungsfunktion, aufgerufen von Task und Command.

### 6.2 Auslöser

| Auslöser | Umfang |
|---|---|
| Ende `play_matchday` | alle Vereine |
| Saisonabschluss | alle Vereine |
| Transferabschluss | alle Vereine |
| `rebuild_club_records [--club ID]` | manuell |

**Keine `post_save`-Signale.** Signale feuern auch bei Importen und Backfills und würden während eines Massenimports hunderte Recomputes auslösen. Explizite Aufrufe an definierten Stellen.

Recompute läuft als Celery-Task, nicht im Request-Pfad.

### 6.3 Vereinsnews

Ein `ClubNewsItem` entsteht **nur**, wenn `ClubRecordBreak.broke_seed = True` — also wenn ein Rekord mit realem Ursprung überboten wird.

Sim-interne Rekordwechsel erzeugen **keine** News. Andernfalls entstünde in der Anfangsphase bei jedem Spieltag eine Meldungsflut.

### 6.4 Performance

Bei 26 Vereinen und 515 Spielern ist der Vollscan der Aggregattabellen unkritisch. Sollte es mit wachsender Historie klemmen, ist die Lösung eine Aggregationstabelle — **nicht** der Umbau auf Inkrementalität. Wird jetzt bewusst nicht vorgebaut.

---

## 7. Creator-Mode

### 7.1 Reiter „Ruhmeshalle" in der Vereinsbearbeitung

Ein neuer Reiter in `club_edit.html`, neben der bestehenden Trophäen- und Sponsorenpflege. **Einziger Schreibpfad für Seed-Daten.**

Aufbau je Rekord:

| Feld | Bemerkung |
|---|---|
| Wert | numerisch + Anzeigeform |
| Halter (Freitext) | Pflicht bei gesetztem Wert |
| Halter-Verknüpfung | optional: `Player` / `HistoricCoach` |
| Gegner (Freitext) | optional |
| Gegner-Verknüpfung | optional: `Club` |
| Datum / Zeitraum | |
| Kontextzeile | |
| Quelle | Freitext oder URL |

**Leer lassen bedeutet „kein Seed".** Die Nische bleibt im Modus „Echte Geschichte" leer; es wird kein Platzhalter erfunden.

Speichern stößt Recompute für diesen Verein an.

### 7.2 Antragsbearbeitung

Im selben Reiter, oberhalb der Seed-Felder: alle offenen `ClubRecordCorrectionRequest` **dieses Vereins** mit Alt-Wert, gewünschtem Wert, Quelle, Antragsteller sowie den Aktionen *Annehmen* / *Ablehnen*.

Annehmen schreibt den Wert direkt in die darunterliegenden Seed-Felder und stößt den Recompute an. Kein manuelles Nachpflegen.

### 7.3 Wegweiser

Auf `creator/index.html` ein Eintrag „Ruhmeshalle: N offene Anträge", der auf eine reine Übersichtsliste führt. Von dort Sprung in den jeweiligen Vereinsreiter. **Die Liste ist Anzeige, kein Schreibpfad** — entschieden wird ausschließlich im Reiter.

### 7.4 Kontolöschung

Löscht ein Manager sein Konto vollständig, wird der Eintrag **anonymisiert, nicht entfernt**:

- `holder_name` → „Ehemaliger Manager"
- `holder_manager` → `NULL`
- `is_anonymized` → `True`
- Avatar → Default-Silhouette, kein Profillink

Rekordwert und Zeitraum bleiben unangetastet. Kein Recompute, keine Kaskade, keine Rekordwechsel.

Begründung: Die Titel wurden gewonnen, die Spiele haben stattgefunden. Ein Museum, aus dem rückwirkend Kapitel verschwinden, widerspricht dem Konzept — und ein einzelner Löschvorgang würde die Historie mehrerer Vereine umschreiben. Der datenschutzrechtliche Zweck ist durch den Wegfall des Personenbezugs vollständig erfüllt.

---

## 8. Frontend: Rendering-Architektur

### 8.1 Grundprinzip

> **Das Hintergrundbild liefert ausschließlich Architektur. Jeder Inhalt ist DOM.**

Das generierte Bild zeigt Raum, Boden, Decke, Spots, Seitenwände und **leere Nischen** — dunkle Vertiefungen mit Schattenkante und Lichtkegel. Es enthält:

- keine Tafeln, keine Rahmen, keine Hexagon-Formen
- keine Texte, keine Zahlen
- keine Figuren, keinen Touchtable

Rahmen, Hexagon-Kanten, Goldränder und Glasreflexe entstehen vollständig in CSS.

Begründung: Rekorde sind dynamisch, müssen einen Leerzustand haben, drehbar und teilweise verlinkbar sein. Alles, was ins Bild eingebrannt ist, ist irgendwann falsch. Eine gemalte Tafel kann sich zudem nicht drehen.

### 8.2 Positionierung

- Der Artboard erbt `--dashboard-artboard-width` gemäß Layout-Contract in `global-dashboard/layout-nav.css`.
- **Verboten:** eigene feste Artboard-Breiten, `100vw`, eigene `transform: scale()`-Scaler.
- Hintergrundbild: `width:100%; height:auto`.
- Über dem Bild eine **Nischenzone** in Prozent (`position:absolute`), darin ein CSS-Grid, das die Slots verteilt.
- **Keine pixelverifizierten Einzelpositionen** wie in der alten `halloffame.css` (v11). Da die Slotanzahl je Raum fix ist, ist die Zone einmal zu definieren.

Perspektivische Neigung der Hexagon-Tafeln über `transform: perspective() rotateY()` pro Grid-Spalte mit festem Winkel-Set links/rechts.

### 8.3 Tafelform je Raum

| Raum | Form | clip-path |
|---|---|---|
| Spielergalerie | Hexagonal | `polygon(11% 0%, 89% 0%, 100% 47%, 89% 100%, 11% 100%, 0% 47%)` |
| Trainergalerie | identisch hexagonal | wie oben |
| Vereinsrekorde | Hochrechteckig | keiner — Rahmen liegt im Bild |

Das Hexagon hat **flache Ober- und Unterkante**, die Spitzen liegen seitlich auf
halber Höhe. Nicht oben und unten — das entspricht der Raumvorlage und löst
zugleich das Platzproblem der Rekordbezeichnung.

### 8.4 Tafel: Vorder- und Rückseite

| Seite | Inhalt |
|---|---|
| **Vorn (Denkmal)** | Rekordbezeichnung, großer Wert, Bild mit Bronzefilter |
| **Hinten (Kontext)** | Name ausgeschrieben, Datum bzw. Zeitraum, Kontext (Gegner + Wappen, Wettbewerb, Saison), Vorgänger mit Wert — sofern vorhanden |

- Drehung bei **Hover**.
- **Alle Links liegen auf der Rückseite.** Vorn wäre unklar, ob ein Klick dreht oder navigiert.
- Verlinkt wird ausschließlich, was als Entität existiert: Wappen → Vereinsprofil, Spielerbild → Spielerprofil, Ergebnis → Spielbericht. Seed-Werte ohne Verknüpfung bleiben unverlinkt.
- **Leere Slots drehen nicht.** Sie zeigen die gravierte Bezeichnung und einen dezenten Leerhinweis.

### 8.5 Typografie und Wertgrößen

| Rolle | Schrift | Begründung |
|---|---|---|
| Rekordbezeichnung | **Cinzel** (Google Fonts) | Römische Kapitalis — die Schrift echter Gravuren auf Messingschildern |
| Wert | **Bodoni Moda** (Google Fonts) | Hoher Strichkontrast, Museums- statt Sportanmutung |
| Rückseitentexte | **Inter** | Projekt-Basisschrift |

**Der Wert wird in drei Stufen gesetzt, gestaffelt nach Zeichenlänge:**

| Länge | Beispiel | Größe |
|---|---|---|
| ≤ 3 Zeichen | `8:0`, `186`, `28` | groß |
| 4 Zeichen | `28,5`, `2,21` | mittel |
| ≥ 5 Zeichen | `2032/33`, `94,0` | klein |

Ohne diese Staffelung laufen lange Werte über den Rahmen. In der Demo
(`vorlagen/vereinsrekorde.html`) ist sie als `.wert--xl/--l/--s` umgesetzt.

**Rekordbezeichnungen werden in der Registry bereits zweizeilig hinterlegt**
(`Höchster<br>Sieg`), nicht per CSS umgebrochen. Nur so stehen die Werte über
alle Tafeln eines Raums auf einer Linie, und der Umbruch ist redaktionell
kontrolliert statt zufällig.

### 8.6 Bronzefilter

Zur Laufzeit in CSS, **keine vorbereiteten Bilddateien**:

```css
filter: grayscale(1) sepia(0.45) brightness(0.85) contrast(1.15);
/* darüber: Goldton-Overlay mix-blend-mode: overlay */
/* darunter: Verlauf ins Schwarz, damit das Bild in die Tafel ausläuft */
```

- **Wappen erhalten einen deutlich schwächeren Filter** — nur leichte Abdunklung und Goldkante, keine Entsättigung. Zweck des Wappens ist Erkennbarkeit.
- **Beim Flip fährt der Filter zurück:** Rückseite zeigt das Bild klarer und heller. Physische Logik — das Denkmal ist bronzen, der Kontext dahinter das echte Bild.

Begründung gegen vorgerenderte Bilder: Spielerdaten werden monatlich aktualisiert, Rekordhalter wechseln laufend. Eine zweite eingefärbte Datei je möglichem Rekordhalter wäre eine Pflegepflicht, die reißt. Der CSS-Filter greift automatisch auf jedes Bild — auch auf Spieler, die es heute noch nicht gibt.

---

## 9. Räume und Navigation

### 9.1 Routen

| Route | Raum |
|---|---|
| `clubs/<club_id>/ruhmeshalle/` | Eingangshalle |
| `clubs/<club_id>/ruhmeshalle/spieler/` | Galerie der Spieler |
| `clubs/<club_id>/ruhmeshalle/trainer/` | Galerie der Trainer |
| `clubs/<club_id>/ruhmeshalle/verein/` | Vereinsrekorde (inkl. Titel und Transfers) |

**Öffentlich einsehbar** — jeder Verein hat eine Ruhmeshalle, jeder Manager kann sie ansehen. Ein Museum, das niemand besuchen kann, ist kein Museum; erst die Einsehbarkeit macht Rekorde zum Gesprächsstoff und liefert den Hebel für Vereinsnews und Forum.

Eigener Seitenaufruf je Raum, kein Tab-Wechsel: Jeder Raum ist ein eigenes Bild plus bis zu 12 Spielerbilder, jeder Raum ist einzeln verlinkbar, und der Seitenwechsel ist die passende Metapher.

### 9.2 Eingangshalle

**Vollständig datenfrei.** Ein Template ohne jede Abfrage, für alle 26 Vereine identisch.

Inhalt vollständig im Hintergrundbild: Glasvitrine mit goldenem Ball, acht
beleuchtete Wandnischen mit Bronzebüsten, Marmorboden, Überschrift.
**Keine Bild-Slots im DOM.** Die Büsten sind Bestandteil des Bildes und damit
nicht zur Laufzeit austauschbar; jede Änderung an ihnen bedeutet ein neues Bild.

Darüber liegt ausschließlich die Bodenleiste. Der Modus-Umschalter ist auch hier
sichtbar, verändert aber nichts Sichtbares.

Die Messingschilder unter den Büsten tragen im Bild bereits Namen. Sie sind
Dekoration ohne Datenbezug.

### 9.3 Bodenleiste

Ein einziges schwebendes UI-Element je Raum, zwei Zonen, getrennt durch eine dünne Goldlinie:

- **links:** Modus-Umschalter „Echte Geschichte" / „Neue Geschichte"
- **rechts:** Raumnavigation

**Keine Sidebar.** Der obere Bildbereich bleibt frei von Bedienelementen — er trägt Wappen, Lorbeer und Titel.

Zusätzlich Pfeile links/rechts für den Raumwechsel in fester Reihenfolge:
Eingang → Spieler → Trainer → Verein → Eingang. Kreisförmig, keine Sackgasse.

Modus-Wechsel wird visuell quittiert: kurzes Abdunkeln, dann erscheinen die Tafeln neu.

### 9.4 Antragsbutton

Ein Button pro Seite, **nur im Modus „Echte Geschichte"** sichtbar. Öffnet ein Formular mit Auswahlfeld, das **ausschließlich Rekorde dieses Vereins mit Seed-Ursprung** listet. Bei Auswahl wird der Alt-Wert automatisch gezogen. `source_reference` ist Pflichtfeld.

Sim-Rekorde erscheinen nicht in der Liste. Ein berechneter Rekord kann per Definition nicht „falsch recherchiert" sein; weicht er ab, ist die Engine defekt und ein Korrekturantrag das falsche Werkzeug.

---

## 10. Bildmaterial

| Asset | Anzahl | Beschreibung |
|---|---|---|
| Raumhintergründe | 4 | Eingang und Verein **liegen vor**, Spieler und Trainer offen |
| Rekordmotive | 12 | Ein festes Motiv **pro Rekordtyp**, vereinsunabhängig |
| Sockelfiguren | — | Entfällt: Büsten sind im Eingangsbild eingebrannt |
| Trophäenbilder | vorhanden | aus `ClubTrophy`, für Slots 10–12 |
| Spieler-CutOuts | vorhanden | `player_face_url(fm_inside_id)` |
| Trainerbilder | neu | `coach_face_url()` / `manager_avatar_url()` |
| Wappen | vorhanden | `club_logo_url(fm_inside_id)` |

**Rekordmotive:** dunkle Stadionatmosphäre, passend zur Aussage des Rekords, **ohne erkennbare Gesichter, ohne Trikots, ohne Vereinsbezug**. Ein Motiv gehört zum Rekord, nicht zum Verein — 12 Bilder gesamt statt 12 pro Verein.

Begründung gegen vereinsspezifische Stadionbilder: 12 Tafeln mit demselben Stadion wären monoton, und ein Stadionbild sagt über „Längste Serie ohne Sieg" nichts aus.

---

## 11. Bauabfolge

### Stufe 1 — Datenschicht (ohne jede UI)

Modelle `ClubRecord`, `ClubRecordBreak`, `ClubRecordCorrectionRequest`, `HistoricCoach` · Registry mit allen 23 Definitionen · Recompute-Funktion · `rebuild_club_records` · Task-Aufrufe an Spieltagsende, Saisonende, Transferabschluss · `coach_face_url()`, `manager_avatar_url()`

**Abnahme:** `rebuild_club_records` läuft durch, bei 26 Vereinen stehen plausible Werte. Prüfung allein über die Django-Shell.

### Stufe 2 — Creator-Reiter „Ruhmeshalle"

Seed-Pflege mit Freitext plus optionaler Verknüpfung, `HistoricCoach`-Editor nach Vorbild `referee_edit.html`.

**Abnahme:** Seed eintragbar, Merge zwischen beiden Modi über die Shell prüfbar — noch ohne Frontend.

### Stufe 3 — Die vier Räume

Routen, Templates, CSS, Flip, Bodenleiste, **Ruhmeshalle-Link im Vereinsprofil** (Pflicht), Redirect `management/halloffame/` → eigene Ruhmeshalle.

**Abnahme:** Alle vier Räume in beiden Modi, Layout-Contract eingehalten.

### Stufe 4 — Antragswesen

Button, Formular, Bearbeitung im Reiter, Zähler auf `creator/index.html`.

Begründung der Trennung: In der alten `halloffame.css` wurde Darstellung gebaut, bevor die Datenlage stimmte — Ergebnis waren doppelte Kacheln mit identischem Wert. Steht Stufe 1 sauber, ist Stufe 3 reine Kosmetik und beliebig oft überarbeitbar, ohne die Rekorde zu gefährden.

**Parallel zu Stufe 1–2 zu liefern:** die Bildmaterialien aus §10 (Erzeugung dauert erfahrungsgemäß länger als der Code) sowie die recherchierten Seed-Inhalte.

---

## 12. Offene Punkte / V2

| Punkt | Status |
|---|---|
| Seed-Inhalte (reale Rekordwerte) | Wird nachgeliefert |
| Touch- und Mobile-Verhalten des Flips | Bewusst nicht in V1 |
| Raum „Historische Spiele" | V2 — braucht Kuratierungskonzept |
| Raum „Ewige Legenden" | V2 — braucht Aufnahmekriterien |
| Manager-weite Hall of Fame | Später, als Design-Variante derselben Engine |
| `international_titles` | Leer bis Modul „Internationale Wettbewerbe" |
| Zu-Null-Spiele Torwart | Verworfen — bräuchte `report_data`-Scan oder neues Feld |

---

## Anhang A — Entscheidungslog

| ID | Entscheidung | Begründung |
|---|---|---|
| **E01** | „Echte Geschichte" startet mit realen Werten und wird von Sim-Leistungen überschrieben; „Neue Geschichte" zeigt nur Sim-Daten ab Simbeginn. | Erzeugt den stärksten Moment des Moduls („Vereinsrekord von 1959 gebrochen"), statt ein totes Archiv zu pflegen. |
| **E02** | Halle ist vereinsgebunden, nicht managergebunden. | Managerwechsel darf keine Historie löschen. |
| **E03** | Seed-Mechanik wird gebaut, Seed-Inhalte später geliefert. Denormalisierte Anzeigedaten. | Reale Rekordhalter existieren nicht als `Player`-Objekte. |
| **E04** | Katalog: 23 Rekorde. Gestrichen: Zuschauerrekord, schnellstes Tor, Joker-Tore, größte Entwicklung, Durchschnittsnote, Elfmeter-/Freistoßtore, Comeback, Zu-Null-Spiele, Erstes Pflichtspiel, Transfergewinn. | Kein Rekord darf `report_data` erfordern; keine Rekorde ohne Sim-Verdienst (keine In-Sim-Spielerentwicklung). |
| **E05** | Negativrekorde bleiben im Katalog. | Vereinsgeschichte lebt auch von Narben; gibt der Halle Glaubwürdigkeit. |
| **E06** | Materialisierung statt Live-Berechnung; Voll-Recompute statt Inkrementalität. | Eliminiert die Fehlerklasse „inkrementeller Drift"; Zustand jederzeit reproduzierbar. |
| **E07** | Strikte Trennung `SEED` / `SIM` per Unique Constraint und getrennte Schreibpfade. | Verhindert strukturell, dass ein Recompute recherchierte Werte zerstört. |
| **E08** | `ClubRecordBreak` protokolliert alle Wechsel, erzeugt aber keine Chronik-UI. | Dient dem „gilt seit"-Datum und der News-Auslösung. |
| **E09** | Vereinsnews **nur** bei Bruch eines Seed-Rekords. | Andernfalls entstünde in der Anfangsphase bei jedem Spieltag eine Meldungsflut. |
| **E10** | 5 Räume; „Saisonrekorde" entfällt (redundant), Titel wandern zu den Vereinsrekorden. | Vermeidet Redundanz und hält die Eingangshalle datenfrei. |
| **E11** | Öffentliche Vereinsseite unter `clubs/<id>/ruhmeshalle/`. | Erst Einsehbarkeit macht Rekorde zum Gesprächsstoff. Kein Mehraufwand, da ohnehin für alle Vereine gerechnet wird. |
| **E12** | Bild liefert nur Architektur, DOM liefert allen Inhalt; Grid statt Pixelmessung. | Eingebrannte Inhalte sind irgendwann falsch; Pixelpositionen waren die Ursache von 11 CSS-Versionen der alten Seite. |
| **E13** | Keine Overlays. Tafeln sind inert bis auf Flip; verlinkt wird nur, was als Entität existiert. Jede Tafel trägt ein Datum. | Direkte Entscheidung des Auftraggebers. |
| **E14** | Ein Antragsbutton pro Seite statt Stift je Tafel; Auswahlliste enthält nur Seed-Rekorde. | Sim-Rekorde sind berechnet und nicht per Antrag korrigierbar; 28 Stifte würden die Museumsoptik zerstören. |
| **E15** | Annahme eines Antrags schreibt automatisch und triggert Recompute. | Kein manuelles Nachpflegen; sonst sichert Disziplin statt Mechanik die Korrektheit. |
| **E16** | Feste Architektur: permanenter Slot je Rekord, identisch über alle Vereine, mit Reserve-Nischen. | Konsequent einmal bauen; Reserve erlaubt spätere Rekorde ohne neues Hintergrundbild. |
| **E17** | Flip mit Denkmal vorn und Kontext hinten; alle Links auf der Rückseite. | Vorn wäre unklar, ob ein Klick dreht oder navigiert. |
| **E18** | Pflichtspiele zählen, Freundschaftsspiele nie. Saisonrekorde ligagebunden, Serien wettbewerbsübergreifend. | Freundschaftsspiele sind nicht knapp und machten Rekorde beliebig herstellbar. |
| **E19** | Punkteschnitt nur Liga, mind. 30 Spiele. | Pokalspiele vergeben keine Punkte; 30 statt 34, da die 4 Ligen unterschiedlich groß sind. |
| **E20** | Elfmetersiege zählen als Siege. | Ein gewonnenes Elfmeterschießen fühlt sich als Sieg an; eine daran heimlich reißende Serie wäre ein wahrgenommener Fehler. |
| **E21** | Gleichstand: der Erste behält den Rekord. | Reale Konvention, trivial implementierbar, verhindert News- und Log-Flut. |
| **E22** | Mindestschwelle 50 Pflichtspiele für Spielerrekorde. | Auf der Tafel erklärbar; sorgt dafür, dass dort prägende Spieler stehen. |
| **E23** | `HistoricCoach` nach `Referee`-Muster mit eigenem Bildordner; `manager_avatar_url()` separat. | Ermöglicht Upload realer Trainerbilder wie bei Schiedsrichtern. |
| **E24** | Kontolöschung anonymisiert statt zu entfernen. | Verhindert Löcher in der Vereinshistorie und Recompute-Kaskaden; Personenbezug entfällt vollständig. |
| **E25** | Creator-Reiter in der Vereinsbearbeitung als einziger Schreibpfad; Übersichtsliste nur als Wegweiser. | Ein Ort, an dem geschrieben wird — sonst werden Werte widersprüchlich. |
| **E26** | Überall Freitext plus optionale Verknüpfung; Wappen und Link nur bei gesetzter Verknüpfung. | Historische Gegner und Spieler existieren nicht als Entitäten; ein Darstellungspfad für beide Quellen. |
| **E27** | Bronzefilter zur Laufzeit in CSS; Wappen schwächer gefiltert; Filter fährt beim Flip zurück. | Vorgerenderte Varianten je Rekordhalter wären eine Pflegepflicht, die reißt. |
| **E28** | Eingangshalle vollständig datenfrei, 6 leere Sockel, manuell befüllt. | Reiner Navigations-HUB; Statuen sind Dekoration ohne Daten. |
| **E29** | 12 feste Rekordmotive, vereinsunabhängig. | Skaliert (12 statt 12 × 26); ein Motiv illustriert den Charakter des Rekords, statt eine nie stattgefundene Szene zu behaupten. |
| **E30** | Marktwert-Rekord nur innerhalb der Vereinszugehörigkeit. | Snapshots sind nicht vereinsgebunden; sonst würden fremde Karrierephasen gutgeschrieben. |
| **E31** | Spieler zählt für einen Titel bei mindestens einem Pflichtspieleinsatz in der Titelsaison. | Billig, nachvollziehbar, schließt reine Kaderzugehörigkeit aus. |
| **E32** | Saisonvergleich rein nach Punkten, Liga und Platz als Kontext. | „2,4 Punkte pro Spiel" wäre als große Zahl auf einer Museumstafel wertlos. |
| **E33** | Modus-Bezeichnungen „Echte Geschichte" / „Neue Geschichte". | Der Unterschied ist der Zeitraum, nicht das Subjekt — beide zeigen Vereinsgeschichte. |
| **E34** | Bau in vier Stufen: Daten → Creator → Räume → Anträge. | In der alten Hall of Fame wurde Darstellung vor korrekter Datenlage gebaut; Ergebnis waren doppelte Kacheln. |
| **E35** | Statuen erkennbarer realer Fußballer werden nicht spezifiziert. | Persönlichkeitsrechte greifen auch ohne Namensnennung und bei KI-Erzeugung; Notice-and-Takedown deckt selbst eingebaute Gestaltungselemente nicht. Der Betreiber hat die Bilder außerhalb der Spezifikation selbst erzeugt und eingesetzt; sie sind reine Dekoration ohne Datenbezug und jederzeit durch ein neues Hintergrundbild ersetzbar. |
| **E36** | Transfergalerie entfällt, ihre 2 Rekorde wandern zu den Vereinsrekorden (16 Slots, 2 Reihen à 8). | Zwei Rekorde tragen keinen eigenen Raum. Abtrennung später über Registry möglich. |
| **E37** | Eingangshalle ist ein einziges Bild ohne Bild-Slots; Büsten und Schilder sind eingebrannt. | Der Raum ist reiner Navigations-HUB. Preis: Änderungen an den Legenden erfordern ein neues Bild. |
| **E38** | Hexagon mit flacher Ober- und Unterkante, Spitzen seitlich. | Entspricht der Raumvorlage und löst zugleich das Platzproblem der Rekordbezeichnung in der Schräge. |
| **E39** | Wert in drei Größenstufen nach Zeichenlänge; Bezeichnungen zweizeilig in der Registry. | Ohne Staffelung laufen lange Werte über den Rahmen; feste Zweizeilenhöhe hält die Werte auf einer Linie. |
| **E40** | Fallback-Bilder erhalten einen helleren Bronzefilter. | `default_player.png` ist eine dunkle Silhouette und säuft unter dem Standardfilter ab. |
| **E41** | Vermessung des Vereinsraums ergab gleichmäßige Panelbreiten (10,0–11,2 %); nur die Höhe wächst perspektivisch nach rechts. Zwei lineare Formeln für Ober- und Unterkante genügen. | Die anfängliche Sorge vor einer schrägen Kamera war unbegründet — es braucht keine 16 Einzelmessungen. |
