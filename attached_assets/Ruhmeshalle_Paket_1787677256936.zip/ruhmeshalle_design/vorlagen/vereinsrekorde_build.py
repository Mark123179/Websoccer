COLS=[(.0225,.1226),(.1335,.2382),(.2496,.3596),(.3717,.4809),
      (.4920,.6017),(.6128,.7251),(.7362,.8479),(.8610,.9664)]
def top(x): return .2288 - .1135*(x-.07)
def bot(x): return .6507 + .1445*(x-.07)
MID = .4440

REC=[
 ("Höchster<br>Sieg","8:0","12.04.2031","crest"),
 ("Höchste<br>Niederlage","0:6","03.11.2028","crest"),
 ("Längste<br>Siegesserie","14","Spiele",None),
 ("Serie ohne<br>Niederlage","28","Spiele",None),
 ("Serie ohne<br>Sieg","9","Spiele",None),
 ("Beste<br>Saison","2032/33","91 Punkte",None),
 ("Schlechteste<br>Saison","2027/28","32 Punkte",None),
 ("Meiste Tore<br>Saison","103","Tore",None),
 ("Wenigste<br>Gegentore","18","Gegentore",None),
 ("Meister&shy;schaften","8","Titel","trophy1"),
 ("Pokal&shy;siege","5","Titel","trophy2"),
 ("Internationale<br>Titel",None,None,None),
 ("Teuerster<br>Einkauf","28,5","Mio. €","player"),
 ("Teuerster<br>Verkauf","42,0","Mio. €","player"),
 (None,None,None,None),
 (None,None,None,None),
]

cells=[]
for i,(label,val,unit,extra) in enumerate(REC):
    row, col = divmod(i,8)
    x0,x1 = COLS[col]; cx=(x0+x1)/2
    y0,y1 = (top(cx),MID) if row==0 else (MID,bot(cx))
    pad = 0.0022
    L,Wd = x0*100, (x1-x0)*100
    T,Ht = (y0+pad)*100, (y1-y0-2*pad)*100
    style=f"left:{L:.3f}%;top:{T:.3f}%;width:{Wd:.3f}%;height:{Ht:.3f}%"
    if label is None:
        cells.append(f'<div class="zelle zelle--reserve" style="{style}"></div>')
        continue
    if val is None:
        cells.append(f'''<div class="zelle zelle--leer" style="{style}">
      <div class="lbl">{label}</div>
      <div class="leer">Dieser Rekord wartet<br>noch auf seine Geschichte.</div>
    </div>''')
        continue
    bild=""
    if extra=="crest":   bild='<img class="mark wappen" src="../platzhalter/wappen_gegner.png" alt="">'
    if extra=="trophy1": bild='<img class="mark trophy" src="../platzhalter/trophaee_meisterschaft.png" alt="">'
    if extra=="trophy2": bild='<img class="mark trophy" src="../platzhalter/trophaee_pokal.png" alt="">'
    if extra=="player":  bild='<img class="cutout" src="../platzhalter/default_player.png" alt="">'
    k = "wert--xl" if len(val)<=3 else ("wert--l" if len(val)<=4 else "wert--s")
    cells.append(f'''<div class="zelle" style="{style}">
      <div class="lbl">{label}</div>
      {bild}
      <div class="wert {k}"><b>{val}</b><small>{unit}</small></div>
    </div>''')

HTML=f'''<!DOCTYPE html><html lang="de"><head><meta charset="utf-8">
<title>Ruhmeshalle — Vereinsrekorde</title>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600&family=Bodoni+Moda:opsz,wght@6..96,700&family=Inter:wght@400;500&display=swap" rel="stylesheet">
<style>
:root{{
  --sidebar:232px; --dashboard-shell-width:1884px;
  --dashboard-content-width:calc(var(--dashboard-shell-width) - var(--sidebar));
  --dashboard-artboard-width:var(--dashboard-content-width);
  --gold:#c8a24c; --gold-bright:#eed398; --engrave:rgba(226,205,155,.72);
  --quiet:rgba(226,214,190,.5);
}}
*{{box-sizing:border-box}}
body{{margin:0;background:#050505;font-family:Inter,sans-serif;}}
.artboard{{width:var(--dashboard-artboard-width);position:relative;margin:0 auto;}}
.artboard>img.bg{{width:100%;height:auto;display:block;}}
.zone{{position:absolute;inset:0;}}
.zelle{{
  position:absolute; display:flex; flex-direction:column; align-items:center;
  overflow:hidden;
  background:linear-gradient(180deg,rgba(20,17,14,.34),rgba(6,6,6,.62));
}}
.zelle img.cutout{{
  position:absolute; left:50%; top:20%; width:66%; transform:translateX(-50%);
  opacity:.5;
  filter:grayscale(1) sepia(.55) brightness(1.35) contrast(1.05);
  -webkit-mask-image:linear-gradient(180deg,#000 34%,transparent 72%);
          mask-image:linear-gradient(180deg,#000 34%,transparent 72%);
}}
.zelle img.mark{{
  position:relative; z-index:2; margin-top:7%;
}}
.zelle img.trophy{{
  width:26%; opacity:.92;
  filter:brightness(1.02) drop-shadow(0 0 16px rgba(200,160,70,.34));
}}
.zelle img.wappen{{
  width:23%;
  filter:brightness(1.04) contrast(1.06) drop-shadow(0 0 12px rgba(0,0,0,.95));
}}
.lbl{{
  position:relative; z-index:2; margin-top:11%;
  font-family:Cinzel,serif; font-weight:600;
  font-size:.72vw; letter-spacing:.16em; line-height:1.5;
  color:var(--engrave); text-transform:uppercase; text-align:center;
  text-shadow:0 1px 3px rgba(0,0,0,.95);
}}
.wert{{
  position:relative; z-index:2; margin-top:auto; margin-bottom:17%;
  text-align:center;
}}
.wert b{{
  display:block; font-family:"Bodoni Moda",Didot,serif; font-weight:700;
  line-height:1; color:var(--gold-bright);
  text-shadow:0 2px 22px rgba(200,150,60,.5),0 1px 2px rgba(0,0,0,.9);
}}
.wert--xl b{{font-size:2.35vw;}}
.wert--l  b{{font-size:1.75vw;}}
.wert--s  b{{font-size:1.28vw;letter-spacing:-.01em;}}
.wert small{{
  display:block; margin-top:.5vw; font-family:Cinzel,serif;
  font-size:.6vw; letter-spacing:.24em; text-transform:uppercase; color:var(--quiet);
}}
.zelle--leer{{background:linear-gradient(180deg,rgba(14,12,10,.3),rgba(6,6,6,.5));}}
.zelle--leer .lbl{{color:rgba(226,205,155,.3);}}
.leer{{
  position:relative; z-index:2; margin-top:auto; margin-bottom:30%;
  font-size:.62vw; line-height:1.8; font-style:italic; text-align:center;
  color:rgba(226,214,190,.24);
}}
.zelle--reserve{{background:none;}}
</style></head><body>
<div class="artboard">
  <img class="bg" src="../hintergruende/raum_verein.jpg" alt="">
  <div class="zone">
    {''.join(cells)}
  </div>
</div>
</body></html>'''
open("vereinsrekorde.html","w").write(HTML)
print("gebaut")
