# Zu den Referenzbildern

Diese Bilder wurden mit einem Bildgenerator erzeugt und zeigen die **gewünschte Wirkung** —
schwarzer Marmor, Gold, indirektes Licht, Ehrfurcht, Museumsruhe.

**Sie zeigen NICHT die gewünschte technische Aufteilung.**

In den Bildern sind Tafeln, Zahlen, Namen und Figuren fest eingebrannt. Genau das ist der
Fehler, den dieses Design behebt: Rekordhalter wechseln, Slots können leer sein, Tafeln
drehen sich bei Hover. Alles Eingebrannte wäre irgendwann falsch.

| Datei | Zeigt | Übernehmen | Nicht übernehmen |
|---|---|---|---|
| `ruhmenshalle_hauptansicht.png` | Eingangshalle | Vitrine mit goldenem Ball, Überschrift mit Lorbeer, Farbwelt, Lichtstimmung | Sidebar (gestrichen), Rekordtafeln im Eingang (gestrichen), Bodenleiste in dieser Form |
| `ruhmenshalle_vereinsrekorde.png` | Vereinsrekord-Wand | Hochformatige Modulwand, Spielszene hinter dem Wert, Lichtband unten, Wert als Held | Eingebrannte Texte und Zahlen |

**Ein drittes Referenzbild fehlt in diesem Paket:** die Spielergalerie mit den hexagonalen,
leicht angeschrägten Metallplatten und dem Touchtable davor. Die Hexagon-Form ist für die
Spieler-, Trainer- und Transfergalerie verbindlich; der Touchtable ist gestrichen.
Bitte beim Auftraggeber nachfordern, falls die Form unklar ist.
