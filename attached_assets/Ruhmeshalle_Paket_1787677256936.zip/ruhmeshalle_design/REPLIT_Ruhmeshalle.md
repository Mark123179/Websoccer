# REPLIT-Handoff — Ruhmeshalle

**Repo:** `Mark123179/Websoccer` · **Replit:** `@Kirschgutzje/Websoccer` (replId `6e4eaecc-e6c5-4f64-8de5-e8845034f33b`)
**Verbindliche Spezifikation:** `SPEC_Ruhmeshalle.md` (Entscheidungslog E01–E41)

Vier Tickets, **nacheinander**, mit Review zwischen den Stufen. Nicht zusammenlegen — die Begründung steht in §11 der Spezifikation.

---

## Vorbemerkung: Was ersetzt wird

Unter `management/halloffame/` existiert bereits eine Hall-of-Fame-Seite (`views_management.py`, `halloffame.css` in Version 11). Sie berechnet drei Rekorde ad-hoc im Request; zwei Kacheln zeigen denselben Wert doppelt. Sie arbeitet mit pixelverifizierten Prozentpositionen auf einem festen 995×700-Bild.

**Diese Seite wird ersetzt, nicht erweitert.** In Ticket 3 wird ihre Route zum Redirect. Nichts aus `halloffame.css` wird übernommen.

---

## Ticket 1 — Datenschicht

**Kein Frontend. Keine Templates. Keine URLs.**

### Modelle (`game/models.py`)

| Modell | Vorbild im Repo |
|---|---|
| `ClubRecord` | — (Felddefinition in Spec §3.1) |
| `ClubRecordBreak` | — (§3.2) |
| `ClubRecordCorrectionRequest` | `PlayerEditRequest` (§3.3) |
| `HistoricCoach` | `Referee` — 1:1-Muster (§3.4) |

Unique Constraint auf `ClubRecord(club, record_key, source)` ist zwingend.

### Registry

Neue Datei `game/records/registry.py`. Ein Eintrag je Rekord: `record_key`, Bezeichnung **zweizeilig** (`Höchster<br>Sieg`), Raum, Slot-Nummer, Berechnungsfunktion, Seed-Fähigkeit, Bildquelle.

23 Rekorde, Verteilung siehe Spec §4. Ein neuer Rekord muss ein Registry-Eintrag plus eine Funktion sein — kein Eingriff in Engine oder Template.

### Berechnung

Neue Datei `game/records/engine.py`. **Genau eine** Funktion `rebuild_for_club(club)`, die alle Rekorde dieses Vereins neu berechnet und ausschließlich `source='SIM'`-Zeilen schreibt.

Quellen — **ausschließlich Aggregattabellen, kein `report_data`:**

`PlayerSeasonStat` · `LeagueStandings` · `SeasonFixture` · `CupFixture` · `MatchResult` · `PlayerTransferHistory` · `PlayerMarketValueSnapshot` · `ManagerCareerEntry` · `ClubTrophy` · `PlayerAwardTitle`

Regeln vollständig in Spec §5. Die vier, die am ehesten falsch umgesetzt werden:

1. **Freundschaftsspiele hart ausfiltern** (`match_type='freundschaft'`, `competition='Freundschaft'`).
2. **Punkteschnitt nur Liga**, mind. 30 Ligaspiele. Pokalspiele vergeben keine Punkte.
3. **Elfmetersiege zählen als Siege** — `CupFixture.winner_club` / `decided_by`.
4. **Gleichstand: der Erste behält den Rekord.** Sortierung Wert → Datum aufsteigend.

### Auslöser

- Celery-Task am Ende von `play_matchday`, **über alle Vereine** (kein Ermitteln der Betroffenen)
- ebenso bei Saisonabschluss und Transferabschluss
- `python manage.py rebuild_club_records [--club ID]` ruft dieselbe Funktion
- **Keine `post_save`-Signale** — sie würden bei Importen und Backfills feuern

### Vereinsnews

`ClubNewsItem` **nur** wenn `ClubRecordBreak.broke_seed = True`. Sim-interne Wechsel erzeugen keine News.

### Assets (`game/asset_urls.py`)

```python
def coach_face_url(fm_inside_id):   # /coaches/face_{id}.png — Kopie von referee_face_url()
def manager_avatar_url(manager):    # Avatar aus dem Managerprofil
```

Inklusive png/jpg/jpeg-Fallback und Default-Silhouette, wie bei den Schiedsrichtern. Bilder liegen auf dem Host unter `/var/www/assets/coaches/`, **nicht im Repo**.

### Abnahme

`rebuild_club_records` läuft durch, bei 26 Vereinen stehen plausible Werte. Prüfung allein über die Django-Shell. **Erst nach Freigabe geht es weiter.**

---

## Ticket 2 — Creator-Reiter

Neuer Reiter **„Ruhmeshalle"** in `creator/club_edit.html`, neben Trophäen- und Sponsorenpflege. **Einziger Schreibpfad für Seed-Daten.**

Je Rekord: Wert (numerisch + Anzeigeform), Halter als Freitext, optionale Verknüpfung auf `Player`/`HistoricCoach`, Gegner als Freitext, optionale Verknüpfung auf `Club`, Datum/Zeitraum, Kontextzeile, Quelle.

**Leer lassen heißt „kein Seed"** — die Nische bleibt leer, es wird kein Platzhalter erfunden. Speichern stößt Recompute für diesen Verein an.

Dazu ein `HistoricCoach`-Editor nach exaktem Vorbild `creator/referee_edit.html`.

**Abnahme:** Seed eintragbar, Merge beider Modi über die Shell prüfbar — weiterhin ohne Frontend.

---

## Ticket 3 — Die vier Räume

**Erst nach Abnahme von Ticket 1.** Die Design-Dateien aus dem Claude-Design-Durchlauf sind die verbindliche Vorlage — Geometrie, Typografie und Filterwerte werden übernommen, nicht neu erfunden.

### Routen (`game/urls.py`)

```
clubs/<int:club_id>/ruhmeshalle/            → Eingangshalle
clubs/<int:club_id>/ruhmeshalle/spieler/    → Galerie der Spieler
clubs/<int:club_id>/ruhmeshalle/trainer/    → Galerie der Trainer
clubs/<int:club_id>/ruhmeshalle/verein/     → Vereinsrekorde
```

Öffentlich einsehbar. Modus als Query-Parameter `?modus=echt|neu`, beim Raumwechsel mitgereicht, **nicht** pro Nutzer gespeichert.

### Pflichtpunkte, die erfahrungsgemäß untergehen

1. **Ruhmeshalle-Link im Vereinsprofil.** Einbauort ist die Vereins-Navigation rund um `club_detail` (`base.html` Zeile ~84 führt dorthin). Ohne diesen Link ist das Modul für Nutzer unerreichbar.
2. **Redirect** `management/halloffame/` → eigene Ruhmeshalle. Kein Bruch bestehender Links.
3. **Layout-Contract** aus `global-dashboard/layout-nav.css` einhalten: `--dashboard-artboard-width` erben, kein `100vw`, kein `max-width`, kein eigener `transform: scale()`. Details in `LAYOUT_CONTRACT.md`.

### Eingangshalle

Ein Template **ohne jede Datenabfrage**. Hintergrundbild plus Bodenleiste, sonst nichts. Kein Wappen, kein Antragsbutton, keine Bild-Slots.

**Vorschlag:** intern zweiteilen — erst Eingang und Spielergalerie, Review, dann Trainer und Verein nach demselben Muster. Spart Tokens, weil Korrekturen einmal statt viermal anfallen.

**Abnahme:** Alle vier Räume in beiden Modi, Layout-Contract eingehalten, Link im Vereinsprofil vorhanden.

---

## Ticket 4 — Antragswesen

Button pro Seite, **nur in den drei Rekordräumen**, **nur im Modus „Echte Geschichte"**. Beschriftung „Rekord korrigieren".

Formular mit Auswahlfeld, das **ausschließlich Rekorde dieses Vereins mit Seed-Ursprung** listet — Sim-Rekorde erscheinen nicht. Alt-Wert wird bei Auswahl automatisch gezogen. `source_reference` ist Pflichtfeld.

Bearbeitung im Creator-Reiter aus Ticket 2: offene Anträge oberhalb der Seed-Felder, Annehmen schreibt den Wert direkt und stößt Recompute an. Auf `creator/index.html` ein Zähler „Ruhmeshalle: N offene Anträge" mit Wegweiserliste — **Anzeige, kein zweiter Schreibpfad**.

Zusätzlich: **Kontolöschung anonymisiert** statt zu entfernen (Spec §7.4) — `holder_name` → „Ehemaliger Manager", `holder_manager` → NULL, `is_anonymized` → True. Kein Recompute, keine Kaskade.

---

## Agenten-Empfehlung

| Ticket | Modus | Primary Model | Effort |
|---|---|---|---|
| 1 — Datenschicht | Power | Claude Opus 5 | Hoch |
| 2 — Creator-Reiter | Economy | Claude Sonnet 5 | Mittel |
| 3 — Vier Räume | Power | Claude Opus 5 | Hoch |
| 4 — Antragswesen | Economy | Claude Sonnet 5 | Mittel |

**Vier getrennte Durchläufe, keine Zusammenlegung.**

Ticket 1 ist der einzige Teil, bei dem Fehler teuer sind: vier Modelle, eine Registry mit 23 Definitionen, Migrationen und Task-Anbindung. Das gehört in einen konzentrierten Durchlauf mit anschließendem Review.

Ticket 3 braucht Power wegen des Layout-Contracts — der Agent muss `global-dashboard/layout-nav.css` tatsächlich lesen und einhalten, sonst baut er wieder einen eigenen Scaler ein.

---

## Verifizierte Anknüpfungspunkte im Repo

| Was | Wo |
|---|---|
| Modelle | `game/models.py` (~7.100 Zeilen) |
| Asset-URLs | `game/asset_urls.py` — `player_face_url`, `club_logo_url`, `trophy_url`, `referee_face_url` |
| Creator-Views | `game/views_creator.py`, Templates unter `game/templates/game/creator/` |
| Vereinsbearbeitung | `creator/club_edit.html` (Trophäen- und Sponsorenpflege bereits vorhanden) |
| Schiedsrichter-Editor | `creator/referee_edit.html` — Vorbild für `HistoricCoach` |
| Spieltagslauf | `game/management/commands/play_matchday.py` |
| Layout-Contract | `game/static/game/css/global-dashboard/layout-nav.css`, Kopfkommentar |
| Alte Hall of Fame | `game/views_management.py` (~Zeile 1782), `game/static/game/css/halloffame.css` |
| Navigation | `game/templates/base.html` |

`PlayerSeasonStat` ist auf `(player, club, season, competition)` geschlüsselt — ein Transfer beendet die Historie nicht, ein weggewechselter Spieler bleibt Rekordhalter seines alten Vereins.

`PlayerMarketValueSnapshot` ist **nicht** vereinsgebunden — die Einschränkung auf die Vereinszugehörigkeit muss über `PlayerTransferHistory` selbst hergestellt werden (Spec §5.6).

---

## Was ausdrücklich NICHT gebaut wird

- ❌ Kein Detail-Overlay beim Klick auf eine Tafel — Tafeln sind inert bis auf den Flip
- ❌ Keine Sidebar, kein Touchtable, keine Chronik-Ansicht
- ❌ Keine eigene Transfergalerie
- ❌ Keine Bild-Slots in der Eingangshalle
- ❌ Kein `report_data`-Zugriff in der Engine
- ❌ Keine Touch-/Mobile-Optimierung in V1
- ❌ Räume „Historische Spiele" und „Ewige Legenden" erst in V2
