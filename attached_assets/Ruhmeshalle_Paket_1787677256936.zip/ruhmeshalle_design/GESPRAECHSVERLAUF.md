# Gesprächsverlauf — Designsession Ruhmeshalle

Protokoll der Interview-Session, in der die Ruhmeshalle entworfen wurde. Dient als Kontext bei Zweifelsfragen: **warum** eine Entscheidung so ausfiel, nicht nur **wie**.

Verbindlich ist der `DESIGN_BRIEF.md`, danach `SPEC_Ruhmeshalle.md`. Dieses Dokument erklärt, es entscheidet nicht.

---

## Ausgangslage

Der Auftraggeber hatte drei KI-generierte Referenzbilder eines Vereinsmuseums und einen Creative-Director-Prompt. Sein Ziel: kein Statistik-Dashboard, sondern ein digitales Vereinsmuseum. Sein Problem: Frühere Versuche mit Design-Tools ergaben „peinlichen Quatsch", weil die Werkzeuge zu starr mit HTML und CSS umgingen.

Erste Prüfung des Codebestands ergab:

- Es existiert bereits eine Hall-of-Fame-Seite (`management/halloffame/`, `halloffame.css` in Version 11). Sie berechnet drei Rekorde ad-hoc im Request; zwei Kacheln zeigen denselben Wert doppelt. Sie arbeitet mit pixelverifizierten Prozentpositionen auf einem festen 995×700-Bild — die elf CSS-Versionen sind die Spur dieses Ansatzes.
- Es existiert ein verbindlicher Layout-Contract, der eigene Artboard-Breiten, `100vw` und eigene Scaler untersagt.

Beide Funde haben die Architektur des neuen Moduls geprägt.

---

## Die Entscheidungen, chronologisch

### Zwei Historien

Zuerst geklärt: „Echte Geschichte" beginnt mit realen Vereinsdaten und wird von Simulationsleistungen überschrieben, sobald diese besser sind. Der zweite Modus zeigt nur Simulationsdaten ab Simulationsbeginn. Der Arbeitstitel „Meine Geschichte" aus dem Mockup war falsch — dort geht es nicht um den Manager, sondern um den Verein. Am Ende der Session wurde „Neue Geschichte" als Bezeichnung gewählt: Der Unterschied ist der Zeitraum, nicht das Subjekt.

### Der Katalog schrumpfte dreimal

Ursprünglich 28 Rekorde. Gestrichen wurden nacheinander:

- Zuschauerrekord, schnellstes Tor, Joker-Tore (Auftraggeber: kommen nicht)
- Höchste Durchschnittsnote (Auftraggeber: Noten gehören nicht in Rekorde)
- Elfmetertore, Freistoßtore, größtes Comeback (Auftraggeber: werden nicht erfasst)
- Zu-Null-Spiele Torwart (technisch: es gibt keine Aufstellungstabelle pro Spiel, nur `report_data`)
- Erstes Pflichtspiel, größter Transfergewinn (Auftraggeber)

Ergänzt wurden zwei Trainerrekorde, weil der Auftraggeber fünf statt drei wollte: bester Punkteschnitt und meiste Siege.

**Endstand: 23 Rekorde.** Wichtigste Nebenwirkung: Kein einziger Rekord benötigt noch einen Scan der `report_data`-JSONs. Die Engine liest ausschließlich Aggregattabellen und wurde dadurch erheblich schlanker.

### Warum die Halle öffentlich ist

Ursprünglich als Management-Seite gedacht (nur eigener Verein). Argument für die Öffnung: Ein Museum, das niemand besuchen kann, ist kein Museum. Erst die Einsehbarkeit macht Rekorde zum Gesprächsstoff und liefert den Hebel für Vereinsnews und das geplante Forum. Der Auftraggeber stimmte zu und merkte an, dass die Verlinkung im Vereinsprofil noch fehlt — sie ist als Pflichtpunkt in Stufe 3 vermerkt.

### Das Rendering-Prinzip

Der zentrale Konflikt der Session. Die Referenzbilder haben Tafeln, Zahlen und Spielerfiguren eingebrannt. Das kann nicht funktionieren, weil Rekordhalter wechseln, Slots leer sein können und Tafeln sich drehen sollen.

Ergebnis: **Bild = leere Architektur, DOM = aller Inhalt, Grid statt Pixelmessung.** Der Auftraggeber stimmte ausdrücklich zu.

Verschärft wurde das später durch den Wunsch nach drehenden Tafeln: Wenn eine Tafel sich dreht, darf im Hintergrund keine gemalte Tafel liegen, die beim Drehen freigelegt würde. Das Bild liefert deshalb nur **leere Nischen** — Vertiefungen mit Schattenkante und Lichtkegel.

### Feste Architektur statt adaptiver Wand

Zwischenzeitlich war ein umbrechendes Grid mit adaptiver Tafelgröße vorgeschlagen. Der Auftraggeber entschied dagegen:

> „Eigentlich sollte es für jeden Rekord einen festen Grid geben und entweder er ist befüllt oder leer. So entsteht auch keine Unterschiede je Verein und dann ist eine feste Anordnung nicht dramatisch sondern eher konsequent einmal machen und dann auf alle anderen Vereine anwenden."

Daraus folgten die Reserve-Slots: 8 Slots bei 6 Rekorden, 14 bei 12. Spätere Rekorde brauchen dann kein neues Hintergrundbild.

### Der Flip

Ursprünglich war ein Vitrinen-Overlay beim Klick vorgeschlagen, mit Rekordchronik. Der Auftraggeber lehnte ab: Tafeln sollen nichts tun außer aufleuchten, verlinkt wird nur, was schon existiert.

Er brachte den Flip stattdessen selbst ins Spiel: Hovern dreht die Tafel und zeigt Bild, Rekord und Zeitraum. Daraus wurde die Aufteilung vorn Denkmal / hinten Kontext, mit allen Links auf der Rückseite — weil vorn sonst unklar wäre, ob ein Klick dreht oder navigiert.

### Sidebar und Bodenleiste

Der Auftraggeber strich die Sidebar aus dem Mockup:

> „Sidebar kommt weg, wir haben dann nur aus der Bodenleiste und in jedem kann man dann zum nächsten nach links und rechts zwischen den Räumen hin und her wechseln."

Damit war der Modus-Umschalter heimatlos und wanderte als linke Zone in die Bodenleiste — bewusst nicht nach oben, weil der obere Bildbereich die Ehrfurcht trägt (Lorbeer, Wappen, Titel).

### Die Statuen

Der Auftraggeber wollte Bronzestatuen erkennbarer Fußballer in der Eingangshalle — Ronaldinho, Zidane, Ibrahimović, auch Messi und Ronaldo. Es folgte eine längere Auseinandersetzung über Persönlichkeitsrechte: Sie greifen auch ohne Namensnennung, auch bei KI-Erzeugung, und ein Notice-and-Takedown-Hinweis deckt selbst eingebaute Gestaltungselemente nicht ab. Der Vergleich mit Transfer-Accounts auf Social Media trägt nicht, weil dort die Presseschranke greift, Beiträge flüchtig sind und Rechteinhaber gegen Reichweitengeber nicht vorgehen — gegen ein Fußballmanagerspiel dagegen schon, weil genau dort lizenziert wird.

Ergebnis zunächst: Die Sockel bleiben leer, der Auftraggeber befüllt sie selbst.

> „okay, dann lass die Felder frei und leer....ich erstelle selbst welche zum Einfügen."

In der anschließenden Bildrunde erzeugte er dann selbst einen Raum mit acht erkennbaren Bronzebüsten und setzte ihn ein. Das ist seine Entscheidung als Betreiber und liegt außerhalb dieser Spezifikation. Für Design und Implementierung ändert sich dadurch nichts: Die Büsten sind Bestandteil des Hintergrundbildes, tragen keine Daten und sind durch Austausch einer einzigen Bilddatei ersetzbar.

### Die Titel

Erst in der Eingangshalle als Messingtafeln geplant, dann verworfen: Damit wäre der HUB doch wieder eine Datenseite geworden und hätte mit den Statuen um Aufmerksamkeit konkurriert. Die drei Titel-Slots wanderten zu den Vereinsrekorden, die Eingangshalle wurde vollständig datenfrei.

### Bildmaterial

Für die Vereinsrekord-Tafeln fehlte eine Bildquelle — Spielszenen existieren im Projekt nicht. Entschieden: **12 feste Motive pro Rekordtyp, vereinsunabhängig.** Zwölf Bilder gesamt statt zwölf pro Verein, und ehrlicher: Ein Motiv illustriert den Charakter eines Rekords, statt eine nie stattgefundene Szene zu behaupten. Die drei Titel-Slots nutzen stattdessen die bereits vorhandenen Trophäenbilder.

### Bronzefilter

Der Auftraggeber wollte durchgehend „einen Farbfilter drüber". Entschieden: CSS zur Laufzeit, nicht vorgerendert — weil Spielerdaten monatlich aktualisiert werden und Rekordhalter wechseln. Zwei Ausnahmen wurden ergänzt: Wappen werden nur schwach gefiltert (sonst nicht mehr erkennbar), und beim Flip fährt der Filter zurück.

> „wie im Beispiel, dass das normale Spielerbild genommen wird, aber ein bronze filter oder was auch immer drüber gelegt wird, sodass sich das edel und legendär anfühlt."

### Die Bildproduktion korrigierte die Spezifikation

Nach dem Interview folgte eine Bildrunde, in der mehrere Festlegungen fielen, die vorher nur theoretisch waren.

**Die Eingangshalle wurde ein einziges Bild.** Geplant waren sechs leere Sockel als DOM-Slots. Der Betreiber erzeugte stattdessen einen Raum mit acht eingebrannten Bronzebüsten in beleuchteten Vitrinen. Das ist konsistenter mit der Glasvitrine in der Mitte, kostet aber die Austauschbarkeit: Jede Änderung an den Legenden bedeutet ein neues Bild. Die Halle hat damit keinen einzigen Bild-Slot mehr und braucht keine Datenabfrage.

**Die Transfergalerie fiel weg.** Der Betreiber zählte die Räume durch und fand zwei Rekorde für einen ganzen Raum zu dünn. Sie wanderten als Slot 13 und 14 zu den Vereinsrekorden, die Wand wuchs auf 16 Slots in zwei Reihen à 8. Aus fünf Räumen wurden vier.

**Das Hexagon war falsch herum.** Der erste Tafel-Prototyp setzte die Spitzen oben und unten — dadurch lief die Rekordbezeichnung in die Schräge und wurde abgeschnitten. Die Raumvorlage zeigt flache Ober- und Unterkanten mit seitlichen Spitzen. Die Korrektur löste zugleich das Platzproblem der Beschriftung.

**Werte brauchen drei Größenstufen.** Beim Bau der Vereinswand zeigte sich: „8:0" und „2032/33" sind beide der Held ihrer Tafel, laufen bei gleicher Schriftgröße aber unterschiedlich über. Die Staffelung nach Zeichenlänge kam dazu, ebenso die Regel, Bezeichnungen bereits zweizeilig in der Registry zu hinterlegen statt CSS umbrechen zu lassen.

**Eine Warnung erwies sich als übertrieben.** Der Vereinsraum ist aus schräger Kamera gerendert, was zunächst nach 16 einzeln vermessenen Positionen aussah. Die Nachmessung ergab gleichmäßige Panelbreiten zwischen 10,0 und 11,2 % — nur die Höhe wächst perspektivisch. Zwei lineare Formeln genügten. Das Bild ist verwendbar wie es ist, die Vorlage liegt in `vorlagen/` bei.

**Der Bronzefilter braucht eine Fallback-Ausnahme.** `default_player.png` ist eine dunkle Silhouette mit hellen Konturkanten und säuft unter dem Standardfilter ab. Für Fallback-Bilder gilt deshalb ein hellerer Wert.

---

## Widersprüche, die aufgelöst wurden

| Ursprünglich | Endstand | Grund |
|---|---|---|
| Overlay mit Rekordchronik beim Klick | Kein Overlay, nur Flip | Auftraggeber wollte inerte Tafeln |
| Sidebar mit Modus-Umschalter | Bodenleiste mit zwei Zonen | Auftraggeber strich die Sidebar |
| Titel in der Eingangshalle | Titel bei den Vereinsrekorden | HUB soll datenfrei bleiben |
| Adaptives Grid, Tafelgröße nach Anzahl | Feste Slots mit Reserve | Konsistenz über alle 26 Vereine |
| Stift je Tafel für Korrekturanträge | Ein Button pro Seite | Sim-Rekorde sind nicht korrigierbar |
| Zentrale Creator-Seite „Rekorde" | Reiter in der Vereinsbearbeitung | Ein Schreibpfad, kein zweiter Ort |
| Statuen erkennbarer Legenden | Nicht spezifiziert; Betreiber setzt sie selbst ein | Persönlichkeitsrechte — siehe unten |
| 6 Sockel als DOM-Slots | Eingangshalle ganz ohne Bild-Slots | Büsten sind im Bild eingebrannt |
| Eigene Transfergalerie | Slots 13–14 der Vereinsrekorde | Zwei Rekorde tragen keinen Raum |
| Hexagon mit Spitzen oben/unten | Spitzen seitlich, Kanten flach | Raumvorlage; löst Beschriftungsproblem |
| Einheitliche Wertgröße | Drei Stufen nach Zeichenlänge | Lange Werte liefen über den Rahmen |

---

## Arbeitsweise des Auftraggebers

Relevant für Rückfragen: Er entscheidet selbst und erwartet Widerspruch, wo etwas nicht trägt. Sein Leitsatz für das gesamte Projekt lautet *„Mechanik erzwingt Korrektheit statt Disziplin"* — Lösungen, bei denen die Struktur des Systems das gewünschte Ergebnis erzwingt, sind solchen vorzuziehen, die auf Sorgfalt angewiesen sind.

Im Design heißt das konkret: Ein Grid, das Slots selbst verteilt, ist besser als 34 gepflegte Prozentwerte. Eine CSS-Filterregel ist besser als 500 vorgerenderte Bilddateien. Ein Leerzustand, der Teil des Entwurfs ist, ist besser als ein Platzhalter, den jemand pflegen muss.
