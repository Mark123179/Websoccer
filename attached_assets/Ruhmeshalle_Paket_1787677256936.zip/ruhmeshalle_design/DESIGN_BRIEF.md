# Design-Brief — Ruhmeshalle

**Für:** Claude Design
**Projekt:** Blueprint · Online-Fußballmanager (playwebsoccer.de)
**Modul:** Ruhmeshalle — digitales Vereinsmuseum
**Zieltechnik:** Django-Templates + statisches CSS. Kein React, kein Framework, kein Build-Step.

---

## 0. Was hier gebaut werden soll

**Fünf eigenständige HTML-Dateien** mit Platzhalterdaten aus `daten/*.json`. Jede Datei ist vollständig eigenständig lauffähig, damit sie im Browser direkt geprüft werden kann.

| Datei | Raum | Hintergrund |
|---|---|---|
| `01_eingangshalle.html` | Eingangshalle — datenfrei, reiner Navigations-HUB | `hintergruende/raum_eingang.jpg` ✅ liegt vor |
| `02_spielergalerie.html` | Galerie der Spieler — 8 Slots, 6 belegt | offen, siehe Bildauftrag |
| `03_trainergalerie.html` | Galerie der Trainer — 8 Slots, 5 belegt | dasselbe Bild wie Spieler |
| `04_vereinsrekorde.html` | Vereinsrekorde — 16 Slots, 14 belegt | `hintergruende/raum_verein.jpg` ✅ liegt vor |
| `06_leerzustand.html` | Verein ohne jeden Rekord — 16 leere Nischen | wie Vereinsrekorde |

**Eine Transfergalerie gibt es nicht.** Die zwei Transferrekorde sitzen als Slot 13 und 14 in den Vereinsrekorden.

Zusätzlich **eine gemeinsame `ruhmeshalle.css`**, die alle fünf Dateien einbinden — sie wird später 1:1 nach `game/static/game/css/ruhmeshalle.css` übernommen. Die `<style>`-Blöcke in den HTML-Dateien dürfen nur Demo-Overrides enthalten.

Die Umsetzung als Django-Template macht anschließend der Replit-Agent. Er bekommt diese Dateien als **verbindliche Vorlage** — was hier nicht drin steht, wird nicht gebaut.

---

## 1. Das Leitprinzip (nicht verhandelbar)

> **Das Hintergrundbild liefert ausschließlich Architektur. Jeder Inhalt ist DOM.**

Die Raumbilder zeigen Marmor, Wände, Decke, Spots, Vitrine und **leere Nischen** — dunkle Vertiefungen mit Schattenkante und Lichtkegel. Sie enthalten:

- ❌ keine Tafeln, Rahmen oder Hexagon-Formen
- ❌ keine Texte, keine Zahlen
- ❌ keine Figuren, keinen Touchtable

**Rahmen, Hexagon-Kanten, Goldränder, Glasreflexe, alle Inhalte: CSS und DOM.**

Warum: Rekorde sind dynamisch, brauchen einen Leerzustand, drehen sich bei Hover und sind teilweise verlinkt. Alles, was ins Bild eingebrannt ist, ist irgendwann falsch — und eine gemalte Tafel kann sich nicht drehen.

Die Referenzbilder in `referenz/` zeigen die **gewünschte Wirkung**, nicht die gewünschte Bildaufteilung. Dort sind Tafeln und Texte im Bild. Genau das ist der Fehler, den dieses Design behebt.

---

## 2. Layout-Contract (harte Vorgabe aus dem Projekt)

Wörtlich aus `game/static/game/css/global-dashboard/layout-nav.css`:

```
Pflicht für neue Seiten:
  - Liegen innerhalb .dashboard-scaler.
  - Äußerer Seitenwrapper nutzt var(--dashboard-content-width)
    (über --dashboard-artboard-width geerbt) — KEINE eigene
    Artboard-Breite definieren.
  - Internes Grid/Flex/Container-Queries: ok.
  - Horizontales Scrollen: nur mit fachlicher Begründung.

Verboten für Haupt-Artboards:
  - width: 100vw  |  width: clamp(...vw...)
  - max-width: 1180px / 1200px / 1440px
  - margin-inline:auto auf einem kleineren Artboard
  - eigene transform: scale() / eigener Viewport-Scaler
```

Konkret für die Ruhmeshalle:

```css
.ruhmeshalle-artboard {
  width: var(--dashboard-artboard-width);   /* NIE überschreiben */
  position: relative;
}
.ruhmeshalle-bg { width: 100%; height: auto; display: block; }
.ruhmeshalle-nischen {                       /* Overlay-Zone in % */
  position: absolute;
  inset: 18% 12% 38% 12%;                    /* Werte je Raum, siehe §5 */
  display: grid;
}
```

Fallback-Tokens für die Demo-Dateien (im Spiel per JS gesetzt):

```css
:root {
  --sidebar: 232px;
  --dashboard-shell-width: 1884px;
  --dashboard-content-width: calc(var(--dashboard-shell-width) - var(--sidebar));
  --dashboard-artboard-width: var(--dashboard-content-width);
}
```

**Was ausdrücklich verboten ist:** pixelverifizierte Einzelpositionen je Tafel. Die Vorgängerseite (`halloffame.css`, Version 11) hat genau das gemacht — jede Kachel prozentgenau auf ein 995×700-Bild gesetzt. Jede Bildänderung erzwang eine Neuvermessung. **Ein Grid in einer definierten Zone verteilt die Slots selbst.**

---

## 3. Gestalterische Richtung

Referenz sind Louvre, FIFA Museum, Mercedes-Museum, Apple Store. **Nicht** Transfermarkt, nicht Dashboard, nicht Excel.

Der Besucher soll beim Öffnen denken: *„Hier werden Vereinslegenden verewigt."*

| Achse | Vorgabe |
|---|---|
| **Grundton** | Schwarzer Marmor, sehr dunkel. Ruhe, nicht Protz. |
| **Akzent** | Gold/Messing für Gravuren, Rahmenkanten, Werte |
| **Bildbehandlung** | Bronzefilter (§6) |
| **Licht** | Indirekt, wenige gezielte Spotlights, Lichtkegel je Nische |
| **Bewegung** | Sparsam. Der Flip ist die einzige echte Interaktion. |

**Typografie — gesetzt, nicht zur Disposition:**

| Rolle | Schrift |
|---|---|
| Rekordbezeichnung | **Cinzel** 600 — römische Kapitalis, die Schrift echter Gravuren |
| Wert | **Bodoni Moda** 700 — hoher Strichkontrast, Museums- statt Sportanmutung |
| Rückseitentexte | **Inter** — Projekt-Basisschrift |

**Der Wert wird in drei Stufen gesetzt, nach Zeichenlänge:** ≤3 Zeichen groß (`8:0`, `186`), 4 Zeichen mittel (`28,5`), ≥5 Zeichen klein (`2032/33`). Ohne diese Staffelung laufen lange Werte über den Rahmen. Das Feld `wert_stufe` in den JSON-Daten liefert die Stufe bereits mit.

**Rekordbezeichnungen sind in den Daten bereits zweizeilig** (`Höchster<br>Sieg`). Nicht per CSS umbrechen lassen: Die feste Zweizeilenhöhe hält die Werte über alle Tafeln eines Raums auf einer Linie.

**Wo die Boldness liegen soll:** in der Nische und ihrem Lichtkegel — die Tafel muss aussehen, als läge sie physisch in einer beleuchteten Vertiefung, mit Tiefe, Schattenwurf auf die Rückwand und leichtem Reflex auf dem Rahmen. Alles andere bleibt still.

---

## 4. Die Tafel

### 4.1 Zwei Seiten

| Seite | Inhalt |
|---|---|
| **Vorn — das Denkmal** | Rekordbezeichnung (klein, Versalien, gesperrt) · Wert (groß, gold) · Bild mit Bronzefilter |
| **Hinten — der Kontext** | Name ausgeschrieben · Datum bzw. Zeitraum · Kontextzeile · Gegner mit Wappen · Vorgänger mit Wert (falls vorhanden) |

- Drehung bei **Hover**, `transform: rotateY(180deg)`, `transform-style: preserve-3d`.
- **Alle Links liegen auf der Rückseite.** Vorn wäre unklar, ob ein Klick dreht oder navigiert.
- Verlinkt wird nur, was als Entität existiert: Wappen → Vereinsprofil, Spielerbild → Spielerprofil, Ergebnis → Spielbericht. Felder ohne `url` im JSON werden **nicht** verlinkt.
- `prefers-reduced-motion`: Drehung entfällt, Rückseite wird stattdessen eingeblendet.

### 4.2 Formsprache je Raum

| Raum | Tafelform |
|---|---|
| Spielergalerie | **Hexagonal**, leicht angeschrägt, wie Metallplatten (siehe Referenzbild) |
| Trainergalerie | identisch hexagonal |
| Vereinsrekorde | **Hochrechteckig**, geschwungene Wand, Modul-Charakter |
| Transfergalerie | hexagonal wie Spieler |

Perspektivische Neigung über `transform: perspective() rotateY()` **pro Grid-Spalte** mit festem Winkel-Set — links positiv, Mitte 0, rechts negativ. Nicht je Tafel einzeln definieren.

### 4.3 Leerer Slot

Zeigt die gravierte Rekordbezeichnung und einen dezenten Hinweis. **Dreht sich nicht, ist nicht klickbar, hat kein Bild.**

Text: *„Dieser Rekord wartet noch auf seine Geschichte."*

Ein leerer Slot ist kein Fehlerzustand, sondern ein unbeschriebenes Kapitel — er darf ruhig und würdig aussehen, nicht wie ein Ladefehler.

---

## 5. Slot-Verteilung je Raum

**Feste Architektur.** Slots sind über alle 26 Vereine identisch. Reserve-Slots bleiben dauerhaft leer, damit später Rekorde ergänzt werden können, ohne ein Hintergrundbild neu zu erzeugen.

| Raum | Slots | belegt | Anordnung | Form |
|---|---|---|---|---|
| Spielergalerie | 8 | 6 | eine Reihe à 8 | hexagonal |
| Trainergalerie | 8 | 5 | eine Reihe à 8 | hexagonal |
| Vereinsrekorde | 16 | 14 | zwei Reihen à 8 | hochrechteckig |

**Hexagon:** `polygon(11% 0%, 89% 0%, 100% 47%, 89% 100%, 11% 100%, 0% 47%)` — flache Ober- und Unterkante, Spitzen seitlich auf halber Höhe. Nicht oben und unten.

**Vereinswand:** Die Rahmen liegen bereits im Hintergrundbild. Die vermessenen Positionen stehen in `vorlagen/vereinsrekorde_build.py` und sind übernehmbar: Spaltengrenzen als Konstante, Ober- und Unterkante als zwei lineare Formeln über die Bildbreite, Mitteltrenner konstant bei 44,4 %.

**Kein horizontales Scrollen.** Ein Museum zeigt seine Sammlung, es versteckt sie nicht hinter einer Geste.

---

## 6. Bronzefilter

Zur Laufzeit in CSS, **keine vorbereiteten Bilddateien**. Grund: Spielerdaten werden monatlich aktualisiert, Rekordhalter wechseln laufend — eine zweite eingefärbte Datei je möglichem Halter wäre eine Pflegepflicht, die reißt.

```css
.tafel-bild img {
  filter: grayscale(1) sepia(.45) brightness(.85) contrast(1.15);
}
/* darüber: Goldton-Overlay, mix-blend-mode: overlay */
/* darunter: Verlauf ins Schwarz, damit das Bild in die Tafel ausläuft
   statt hart abzuschneiden */
```

Die Werte oben sind ein Startpunkt, kein Dogma — Ziel ist „edel und legendär", eine Bronzebüste, kein Graustufenfoto. Justiere sie, bis die Wirkung stimmt, und dokumentiere die Endwerte im CSS.

**Drei Ausnahmen:**

1. **Fallback-Bilder werden heller gefiltert.** Greift `default_player.png` — eine dunkle Silhouette mit hellen Konturkanten —, säuft sie unter dem Standardfilter ab. Dort `brightness(1.35)` statt `.82`, gesteuert über eine Modifikatorklasse. Das Feld `bild_fallback` in den Daten zeigt den Fall an.
2. **Wappen erhalten einen deutlich schwächeren Filter.** Nur leichte Abdunklung und Goldkante, keine Entsättigung — der Zweck des Wappens ist, dass man den Gegner erkennt.
3. **Beim Flip fährt der Filter zurück.** Die Rückseite zeigt das Bild klarer und heller. Physische Logik: Das Denkmal ist bronzen, der Kontext dahinter ist das echte Bild.

---

## 7. Bodenleiste

Ein einziges schwebendes Bedienelement je Raum, unten mittig. Zwei Zonen, getrennt durch eine dünne Goldlinie:

```
┌──────────────────────────────────────────────────────────────┐
│  ECHTE GESCHICHTE │ NEUE GESCHICHTE  ┃  ‹  EINGANG · SPIELER │
│  Reale Vereins…   │ Seit Beginn…     ┃     TRAINER · VEREIN  │
│                                      ┃     TRANSFERS      ›  │
└──────────────────────────────────────────────────────────────┘
      Modus-Umschalter                    Raumnavigation
```

- **Keine Sidebar.** Der obere Bildbereich bleibt frei von Bedienelementen — er trägt Wappen, Lorbeer und Titel.
- Pfeile links/rechts wechseln den Raum in fester Reihenfolge, kreisförmig:
  Eingang → Spieler → Trainer → Verein → Transfers → Eingang.
- Modus-Wechsel wird visuell quittiert: kurzes Abdunkeln des Raums, dann erscheinen die Tafeln neu.
- Die Leiste erscheint in **allen fünf Räumen**, auch in der Eingangshalle.

---

## 8. Eingangshalle

**Vollständig datenfrei und ohne jedes Bild-Element im DOM.** Für alle 26 Vereine identisch.

Der Hintergrund `hintergruende/raum_eingang.jpg` enthält bereits alles: Vitrine mit goldenem Ball, acht beleuchtete Nischen mit Bronzebüsten, Marmorboden, Überschrift, Messingschilder.

Darüber kommt **ausschließlich die Bodenleiste.** Kein Wappen, kein Vereinsname, kein Antragsbutton, keine Rekord-Teaser, keine Sockel-Slots.

Das Template braucht dafür keine einzige Datenabfrage.

---

## 9. Antragsbutton

Ein Button pro Seite, **nur in den drei Rekordräumen** und **nur im Modus „Echte Geschichte"** sichtbar. In der Eingangshalle gibt es ihn nicht — dort ist kein Rekord zu sehen. Dezent, nicht in der Bodenleiste — er darf die Architektur nicht stören.

Öffnet ein Formular mit:
- Auswahlfeld (nur Rekorde mit realem Ursprung)
- Neuer Wert · Neuer Halter · Datum · **Quelle (Pflichtfeld)** · Notiz

Beschriftung: **„Rekord korrigieren"**. Kein „Melden", kein „Fehler". Der Nutzer trägt etwas bei, er beschwert sich nicht.

Das Formular darf als Overlay über dem Raum liegen — es ist das einzige Overlay im ganzen Modul.

---

## 10. Was NICHT gebaut wird

- ❌ Kein Detail-Overlay beim Klick auf eine Tafel — die Tafeln sind inert bis auf den Flip
- ❌ Keine Sidebar
- ❌ Kein Touchtable
- ❌ Keine Chronik-/Timeline-Ansicht
- ❌ Keine Tabellen, keine weißen Karten, keine Standard-Kacheln
- ❌ Keine eigene Transfergalerie
- ❌ Keine Bild-Slots in der Eingangshalle
- ❌ Kein `localStorage` / `sessionStorage`
- ❌ Keine Touch-/Mobile-Optimierung in dieser Version (Desktop-Browser genügt)

---

## 11. Abnahmekriterien

1. Fünf HTML-Dateien öffnen im Browser und zeigen jeweils einen vollständigen Raum.
2. Kein Artboard definiert eine eigene Breite; `--dashboard-artboard-width` wird respektiert.
3. Keine pixelverifizierten Einzelpositionen — Slots kommen aus einem Grid.
4. Tafeln drehen bei Hover; alle Links liegen hinten.
5. Leere Slots sind erkennbar, ruhig und drehen nicht.
6. Der Bronzefilter ist CSS, nicht in die Bilder gerechnet.
7. Ein Verein ohne jeden Rekord ergibt einen Raum voller leerer Nischen, der immer noch würdig aussieht — **als `06_leerzustand.html` mitliefern.**
8. `ruhmeshalle.css` ist eine einzige Datei, ohne Framework-Abhängigkeit, ohne Build-Step.

---

## 12. Beigelegte Dateien

| Datei | Inhalt |
|---|---|
| `SPEC_Ruhmeshalle.md` | Vollständige Modulspezifikation inkl. Datenmodell und Entscheidungslog E01–E41 |
| `vorlagen/vereinsrekorde.html` | **Funktionierende Vereinswand** auf dem echten Hintergrund, alle 16 Slots. Verbindliche Vorlage. |
| `vorlagen/vereinsrekorde_build.py` | Erzeugt die obige Datei; enthält die vermessenen Panelpositionen |
| `vorlagen/tafel_demo.html` | Einzelne Hexagon-Tafel mit Flip, alle drei Zustände |
| `hintergruende/*.png` | Raumbilder, soweit vorhanden |
| `GESPRAECHSVERLAUF.md` | Wie die Entscheidungen zustande kamen — für Kontext bei Zweifelsfragen |
| `daten/*.json` | Platzhalterdaten je Raum, Feldnamen entsprechen dem späteren Template-Kontext |
| `referenz/*.png` | KI-Referenzbilder: gewünschte **Wirkung**, nicht gewünschte Bildaufteilung |
| `LAYOUT_CONTRACT.md` | Wörtlicher Auszug der Projekt-Layoutregeln |

**Bei Widersprüchen gilt:** dieser Design-Brief → `SPEC_Ruhmeshalle.md` → Gesprächsverlauf → Referenzbilder.
