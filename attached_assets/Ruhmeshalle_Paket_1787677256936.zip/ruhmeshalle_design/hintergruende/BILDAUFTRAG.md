# Bildauftrag — Raumhintergründe und Rekordmotive

Diese Bilder erzeugt der Auftraggeber extern (GPT/Bildgenerator). Dieser Ordner ist beim Übergeben leer.
Bis sie vorliegen, arbeitet das Design mit CSS-Verläufen als Ersatzhintergrund — die Nischenzonen müssen
so definiert sein, dass ein Austausch des Hintergrunds keine Neuvermessung erzwingt.

## Stand

| Datei | Raum | Status |
|---|---|---|
| `raum_eingang.jpg` | Eingangshalle | ✅ **fertig** — Vitrine, 8 Büsten, alles eingebrannt |
| `raum_verein.jpg` | Vereinsrekorde | ✅ **fertig** — 16 leere Rahmen, zwei Reihen à 8 |
| `raum_spieler.png` | Spielergalerie | ⬜ **offen** — 8 leere Hexagon-Nischen |
| `raum_trainer.png` | Trainergalerie | ⬜ entfällt, nutzt dasselbe Bild wie Spieler |

`raum_spieler_ENTWURF.jpg` liegt bei und zeigt die richtige Formsprache — die Hexagon-Nischen sind gut, aber der Tisch mit dem Miniatur-Spielfeld im Vordergrund muss weg. Dort läuft die Bodenleiste.

**Prompt-Zusatz für den Neudurchlauf:**

> ...eight tall empty hexagonal wall niches with glowing golden edges, evenly spaced in a single row on a gently curved dark wall. The niches are COMPLETELY EMPTY — no images, no figures, no symbols, no text inside them. **No table, no miniature pitch, no furniture in the foreground — empty polished dark marble floor.** Symmetrical frontal view, camera centered on the wall.

Negativ: `table, miniature football pitch, furniture, figurines, text, symbols inside panels`

**Prompt-Grundgerüst (anzupassen je Raum):**

> Interior of a modern luxury football club museum. Black marble floor with subtle gold inlay,
> softly reflective. Curved dark stone walls. Very high ceiling. Indirect lighting with a few
> precise spotlights. Empty recessed niches in the wall with sharp shadow edges and a cone of
> light falling into each one — the niches are COMPLETELY EMPTY, no plaques, no frames, no text,
> no numbers, no figures, no furniture. Quiet, reverent, museum atmosphere. No stadium, no fans,
> no action. Photorealistic architectural render, dark, elegant, cinematic lighting.

**Zwingend im Bild NICHT enthalten:**
- keine Tafeln, Rahmen, Plaketten
- keine Texte, Zahlen, Beschriftungen
- keine Figuren, Statuen, Büsten
- kein Touchtable, keine Möbel
- keine Vereinslogos

Die Nischen müssen gleichmäßig verteilt und in gleicher Größe sein, damit ein CSS-Grid sie trifft.

## 9 Rekordmotive

Ein festes Motiv **pro Rekordtyp**, vereinsunabhängig, für alle 26 Vereine identisch.

| Datei | Rekord |
|---|---|
| `motiv_biggest_win.jpg`             | Höchster Sieg |
| `motiv_biggest_defeat.jpg`          | Höchste Niederlage |
| `motiv_longest_win_streak.jpg`      | Längste Siegesserie |
| `motiv_longest_unbeaten.jpg`        | Längste Serie ohne Niederlage |
| `motiv_longest_winless.jpg`         | Längste Serie ohne Sieg |
| `motiv_best_season.jpg`             | Beste Saison |
| `motiv_worst_season.jpg`            | Schlechteste Saison |
| `motiv_most_goals_season.jpg`       | Meiste Tore in einer Saison |
| `motiv_fewest_conceded_season.jpg`  | Wenigste Gegentore in einer Saison |
| (Slots 10–12) | nutzen die vorhandenen Trophäenbilder aus `ClubTrophy` |
| (Slots 13–14) | nutzen das Spieler-CutOut, kein eigenes Motiv |

**Vorgaben:** dunkle Stadionatmosphäre, hochformatig (ca. 3:4), passend zur Aussage des Rekords.
**Ohne erkennbare Gesichter, ohne Trikots, ohne Vereinsbezug, ohne Text.** Der Bronzefilter kommt
später per CSS darüber — die Motive selbst dürfen ruhig neutral belichtet sein.
