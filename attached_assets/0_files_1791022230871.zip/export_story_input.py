"""
Export für den Live-Ticker-Erzähler (Schritt 1).

Ausführen auf dem Server:
    docker exec -i websoccer-web-1 python manage.py shell < export_story_input.py

Ohne MATCH_IDS listet das Skript Kandidaten (torreich, 0:0, Pokal mit VL/Elfer)
und beendet sich. Mit MATCH_IDS schreibt es je Spiel eine JSON-Datei nach OUT_DIR.
Danach vom Server holen, z. B.:
    docker cp websoccer-web-1:/tmp/story_input ./story_input
"""
import json
import os
from collections import OrderedDict

from game.models import SimulatedMatch, TacticSetup
from game.tactics import SQUAD_PRO

MATCH_IDS = []              # z. B. [412, 398, 377] — leer lassen für die Kandidatenliste
OUT_DIR = "/tmp/story_input"


def _tactic_dump(club):
    t = TacticSetup.objects.filter(club=club, squad_scope=SQUAD_PRO).first()
    if not t:
        return None
    return {
        "formation": t.formation,
        "lineup": t.lineup,
        "bench": t.bench,
        "standards": t.standards,
        "substitutions": t.substitutions,
        "first_half": t.first_half,
        "second_half": t.second_half,
        "instructions": t.instructions,
        "conditions": t.conditions,
        "is_confirmed": t.is_confirmed,
        "updated_at": t.updated_at.isoformat() if t.updated_at else None,
    }


def _summary(m):
    rd = m.report_data or {}
    ms = rd.get("match_stats") or {}
    h, a = ms.get("home") or {}, ms.get("away") or {}
    return OrderedDict([
        ("id", m.id),
        ("typ", m.match_type),
        ("saison", m.season),
        ("nr", m.match_no),
        ("paarung", f"{m.home_club} - {m.away_club}"),
        ("ergebnis", f"{m.home_goals}:{m.away_goals}"),
        ("entschieden", rd.get("decided_by", "regular_time")),
        ("schuesse", f"{h.get('shots', '?')}/{a.get('shots', '?')}"),
        ("ecken", f"{h.get('corners', '?')}/{a.get('corners', '?')}"),
        ("fouls", f"{h.get('fouls', '?')}/{a.get('fouls', '?')}"),
        ("karten", len(rd.get("cards") or [])),
        ("wechsel", len(rd.get("substitutions") or [])),
    ])


def list_candidates():
    qs = SimulatedMatch.objects.select_related("home_club", "away_club").order_by("-id")[:300]
    rows = [_summary(m) for m in qs]
    tore = sorted(rows, key=lambda r: -sum(int(x) for x in r["ergebnis"].split(":")))[:5]
    nullnull = [r for r in rows if r["ergebnis"] == "0:0"][:5]
    ko = [r for r in rows if r["entschieden"] in ("extra_time", "penalties")][:5]

    def show(title, items):
        print(f"\n== {title} ==")
        for r in items:
            print("  " + " | ".join(f"{k}={v}" for k, v in r.items()))

    show("Torreich", tore)
    show("0:0", nullnull)
    show("Pokal mit VL / Elfmeterschießen", ko)
    print("\nMATCH_IDS im Skript setzen und erneut ausführen.")


def export(ids):
    os.makedirs(OUT_DIR, exist_ok=True)
    for mid in ids:
        m = SimulatedMatch.objects.select_related("home_club", "away_club", "referee").get(id=mid)
        payload = {
            "match": {
                "id": m.id,
                "match_type": m.match_type,
                "season": m.season,
                "match_no": m.match_no,
                "home_club": {"id": m.home_club_id, "name": str(m.home_club)},
                "away_club": {"id": m.away_club_id, "name": str(m.away_club)},
                "home_goals": m.home_goals,
                "away_goals": m.away_goals,
                "referee": str(m.referee) if m.referee_id else None,
                "simulated_at": m.simulated_at.isoformat() if m.simulated_at else None,
            },
            "report_data": m.report_data,
            "home_tactic": _tactic_dump(m.home_club),
            "away_tactic": _tactic_dump(m.away_club),
        }
        path = os.path.join(OUT_DIR, f"match_{mid}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=1, default=str)
        s = _summary(m)
        print(f"{path}  ({s['paarung']} {s['ergebnis']}, {s['entschieden']}, {os.path.getsize(path) // 1024} KB)")


if MATCH_IDS:
    export(MATCH_IDS)
else:
    list_candidates()
