"""Geografische Anker (Nominatim/OSM) in den Blaupausen-Rahmen (bg = Meter Ost/Nord vom bg-Ursprung) projizieren
und gegen die bg-Straßen/-Gebäude/-Flächen prüfen. Ursprung: OSM-Spielfeldmitte minus fieldC (Spielfeld als Passpunkt).
Aufruf: umfeld_anker.py <bundle.js.gz> "<Name>" <osm-ordner> <out.json> <pitch_way_json> <anker.json>"""
import sys, json, gzip, math, numpy as np
bundle, name, osmdir, out, pitchjson, ankerjson = sys.argv[1:7]
raw=gzip.open(bundle,"rt",encoding="utf-8").read(); data=json.loads(raw[raw.index("["):raw.rindex("]")+1])
g=next(s for s in data if s["meta"]["name"]==name); m=g["meta"]; bg=g["bg"]
pitch=json.load(open(pitchjson))
pc=pitch["geojson"]["coordinates"][0][:-1]; lat_p=sum(c[1] for c in pc)/len(pc); lon_p=sum(c[0] for c in pc)/len(pc)
K=111320*math.cos(math.radians(lat_p)); fx,fy=m["fieldC"]
# bg-Ursprung: Spielfeldmitte(OSM) - fieldC
lat0=lat_p-fy/110574; lon0=lon_p-fx/K
def xy(lon,lat): return ((lon-lon0)*K, (lat-lat0)*110574)
# OSM-Spielfeldachse
P=np.array([xy(*c) for c in pc]); Q=P-P.mean(0); ax=np.linalg.svd(Q,full_matrices=False)[2][0]
bearing=(math.degrees(math.atan2(ax[0],ax[1])))%180
th=m["axisTheta"]; bp_bearing=(math.degrees(math.atan2(math.cos(th),math.sin(th))))%180
def seg_dist(p,a,b):
    a=np.array(a[:2]);b=np.array(b[:2]);p=np.array(p); d=b-a; t=0 if d@d==0 else max(0,min(1,(p-a)@d/(d@d))); return float(np.linalg.norm(p-(a+t*d)))
def poly_dist(p,poly):
    return min(seg_dist(p,poly[i],poly[(i+1)%len(poly)]) for i in range(len(poly)))
def inside(poly,x,y):
    n=len(poly); c=False
    for i in range(n):
        x1,y1=poly[i][:2]; x2,y2=poly[(i+1)%n][:2]
        if (y1>y)!=(y2>y) and x<(x2-x1)*(y-y1)/(y2-y1+1e-12)+x1: c=not c
    return c
roads=[r["p"] for r in bg["roads"]]; buildings=[b if isinstance(b,list) else b["poly"] for b in bg["buildings"]]; green=bg["green"]
def nearest_road(p): 
    best=(1e9,None)
    for i,r in enumerate(roads):
        for j in range(len(r)-1):
            d=seg_dist(p,r[j],r[j+1]); best=min(best,(d,i))
    return best
def nearest_building(p):
    best=(1e9,None)
    for i,b in enumerate(buildings):
        d=0 if inside(b,*p) else poly_dist(p,b); best=min(best,(d,i))
    return best
# Stand-Richtungen
def frame(p):  # bg -> Spielfeldrahmen (u = +X NORD-Ende, v = +Y WEST-Seite)
    dx,dy=p[0]-fx,p[1]-fy; return (dx*math.cos(th)+dy*math.sin(th), -dx*math.sin(th)+dy*math.cos(th))
def side(p):
    u,v=frame(p); return ("NORD" if u>0 else "SUED") if abs(u)>abs(v) else ("WEST" if v>0 else "OST")
anchors=json.load(open(ankerjson)); result=[]
for a in anchors:
    geo=a["geojson"]; kind=geo["type"]
    if kind=="Point": pts=[xy(*geo["coordinates"])]
    elif kind=="LineString": pts=[xy(*c) for c in geo["coordinates"]]
    elif kind=="Polygon": pts=[xy(*c) for c in geo["coordinates"][0]]
    else: pts=[xy(*c) for c in geo["coordinates"][0][0]]
    arr=np.array(pts); c=arr.mean(0)
    entry={"merkmal":a["name"],"osm":a.get("osm"),"typ":a.get("typ"),"geometrie":kind,"lat":round(float(np.mean([a_[1] for a_ in (geo["coordinates"] if kind=="LineString" else [geo["coordinates"]] if kind=="Point" else geo["coordinates"][0] if kind=="Polygon" else geo["coordinates"][0][0])])),6),
           "bgZentrum":[round(float(c[0])),round(float(c[1]))],"spielfeldrahmen_uv":[round(x) for x in frame(c)],"seite":side(c),"peilungGrad":round((math.degrees(math.atan2(c[0]-fx,c[1]-fy)))%360)}
    if a.get("vergleich")=="road":
        ds=[nearest_road(p) for p in pts]; entry["bgStrasse_abstandMeter_median"]=round(float(np.median([d for d,_ in ds])),1); entry["bgStrassen"]=sorted({i for _,i in ds})
    elif a.get("vergleich")=="building":
        ds=[nearest_building(p) for p in pts]; entry["bgGebaeude_abstandMeter_median"]=round(float(np.median([d for d,_ in ds])),1); entry["bgGebaeude"]=sorted({i for _,i in ds})
    elif a.get("vergleich")=="green":
        entry["inBgGruenflaeche"]=any(inside(gp,*c) for gp in green)
    result.append(entry)
json.dump({"quelle":"OpenStreetMap (ODbL) über Nominatim, Abruf 13.10.2026","bgUrsprung":{"lat":round(lat0,6),"lon":round(lon0,6),"herleitung":"OSM-Spielfeldmitte minus fieldC"},
           "spielfeld":{"osm":pitch.get("osm_type","way")+" "+str(pitch.get("osm_id")),"mitte":{"lat":round(lat_p,6),"lon":round(lon_p,6)},"achsePeilungGrad":round(bearing,1),"blaupauseAxisThetaGrad":round(math.degrees(th),1),"blaupauseNordEndePeilungGrad":round(bp_bearing,1)},
           "anker":result},open(out,"w"),indent=1,ensure_ascii=False)
print(json.dumps({"bgUrsprung":[lat0,lon0],"spielfeldAchse":bearing,"blaupauseAchse":bp_bearing},indent=0))
for e in result: print(e["merkmal"],e["seite"],e["spielfeldrahmen_uv"],e.get("bgStrasse_abstandMeter_median",e.get("bgGebaeude_abstandMeter_median",e.get("inBgGruenflaeche"))))
