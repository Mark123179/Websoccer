# MHPArena · VfB Stuttgart (FMI 960) — Fassung 2 (Achsenkorrektur)

Stand 13.10.2026 · Quelle `stuttgart.bundle` (FM26 Stadium Megapack v3.0, 169 MB, SHA-256 `a444212d7919d458585e0b7c430bd079f3bac6efc6f85e5540842dd4cdc6072e`) + `stuttgart.json` (Sitzplätze), `_lightmaps.json`, `_lightprobes.json`.
assetVersion **`eb8360ccb45d2408`**, geometrySha256 `2e5e7fb416a6bdeed322ca2f407ed3eee7aca846d41b029ca6b426b19f20672a`, 200 Meshes (234.301 Dreiecke), 84 Texturen, **85 Assets**, 9,96 MB, 35 quellgeprüfte Leuchten → 12 Laufzeitleuchten. Keine Live-Registrierung vorhanden; keine lokale Vereins-/Stadion-ID im Paket (Identität nur `clubFmiId 960`).
**Voraussetzung:** Replit-Stand vom 13.10.2026 (Patch `surroundingsAxes` ist integriert: `dortmund_surroundings.js?v=52`, `unity_calibration.js?v=2`, `model_registry.validate_surroundings_axes`); kein Patch mehr im Paket, keine Renderer-Datei zum Zurückkopieren.

## Fassung 2 — was sich gegenüber Fassung 1 ändert (Replit-Review 13.10.)
Nur `calibration.standAxes` und `calibration.surroundingsAxes` im Manifest `models/960.json`; **Assets byteidentisch, assetVersion bleibt `eb8360ccb45d2408`** (festgenagelt mit `--asset-version`, geometrySha256 und alle 85 `assetSha256` unverändert — `quellbelege/nachweise_v2.json`). Der Manifest-Cache ist durch `?manifest=<revision>` in `unity_presentation()` abgesichert; die Assets auf dem Server müssen nicht neu übertragen werden.

| | Fassung 1 (falsch) | Fassung 2 (korrigiert) |
|---|---|---|
| standAxes | `+x OST, −x WEST, +z SUED, −z NORD` | **`+x OST, −x WEST, +z NORD, −z SUED`** |
| surroundingsAxes | `{NORD: −z, WEST: −x}` (Umfeld längs gespiegelt) | **`{NORD: +z, WEST: −x}`** (Standardabbildung, ausdrücklich deklariert) |

Vier Ebenen (Anweisung §2): **Real** — offizieller Arenaplan (mhparena-stuttgart.de/arena/arenaplan): Cannstatter Kurve = Heimkurve am NW-Ende beim Carl Benz Center, Untertürkheimer Kurve mit Gästebereich am SO-Ende bei der SCHARRena, Haupttribüne SW. **Modell** — Heimflächen `C_left1_C1-UltraHome`/Stehplatz-Handläufe bei +z, Gastflächen `C_back1_C2-UltraAway` bei −z/+x, Haupttribüne/Bänke/VIP (`front2_0/4`, Logen) bei −x (unverändert aus Fassung 1). **Blaupause** — `axisTheta 140°` → NORD-Ende NW (Carl Benz Center, Schleyerhalle), SUED-Ende SO (SCHARRena); die abgeleitete `homeStand SUED` (rows*seats) war irreführend. **Wirtschaft** — laut Replit liegt die große Stehplatzseite bereits im NORD; der öffentliche live-scene zeigt noch `homeStand SUED / mainStand SUED` (abgeleitet). Daraus +z = NORD, Umfeld ungespiegelt. Beleg beide Enden/beide Längsseiten: `bilder/fassung2/umfeld-ausrichtung-v1-v2.jpg` (Carl Benz Center und Schleyerhalle am Modell-NORD-/Heimende, SCHARRena, Robert-Schlienz-Stadion und Geschäftsstelle am SUED-/Gästeende, Schauffele-Halle/P7 OST, Haupttribüne WEST).
Ansichten Fassung 2 (aktueller Replit-Renderer): `bilder/fassung2/stuttgart-ansichten-v2.jpg` + Einzelbilder; Modell identisch zu Fassung 1 (Ticker 1,4 % abweichende Pixel durch das ungespiegelte Umfeld in den Durchblicken, Editor/Draufsicht 16–19 % = Umfeld). Dachliste 64.062/64.062, Tribünen 0/111.348, Spielfeld 105,000 × 68,000 nachgerechnet (`quellbelege/nachweise_v2.json`).
Metadaten in der Anwendung (laut Replit bereits lokal gesetzt, gesondert freizugeben, nicht Teil des Manifests): `meta.homeStand NORD`, `scene_meta.mainStand WEST`, `scene_meta.farStand OST`.

## Befund in einem Satz
Kompaktes, sauberes Bundle: 655 Meshes, davon 428 Figuren (`SCARECROW`), 23 Banden/Banner (`AD`), 4 Kulissen-/Netzflächen (per exakten Namen ausgeschlossen) und 200 Stadion-Meshes; keine Choreo-/Event-Objekte; das Membrandach mit Seilnetz, Masten und beiden Anzeigetafeln bildet eine eigene Familie (`front3_*`).

## Vorgehen
1. Inventur aller 655 Meshes (`quellbelege/inventar_alle.json`; keine LODs, alle Renderer aktiv), Ausdehnung gegen den Blaupausen-Umriss (±136 / ±131 m).
2. Ausschluss mit **exakten Namen** (`ausschluss_bericht.json`): `center2_24` Bodenplatte ±437 m, `center2_18` Kulissenfläche ±154/±191 m (Alpha-Maske), **`center2_28` + `center2_28.001` = Fangnetze hinter beiden Toren** (x ±40, y 1–11, z ±61–64, Alpha-Maske 85 % — Regel „Netze hinter den Toren aus"). `AD`/`SCARECROW` nicht übernommen; `EXTRA` = 22 Glas-/Fensterflächen der Haupttribüne und Logen (übernommen).
3. Dachschalter nach Gruppen-Isolierung (Dach/Körper aus drei Winkeln, `bilder/isolation/grp_blatt.jpg`) und Ein-/Ausblend-Differenzen der Sonderfälle (`sonder_diff_blatt.jpg`: Netze, `center2_11/13`, `center2_41`, `left2_3`, Dugout-Sitze `front2_*`, Anzeigetafeln, VfB-Logo — alle ≤ 0,04 % Pixel, Netze 0 %).
4. Bodenregeln → `boden_960.json`, OSM-Abgleich, Ansichten.

## Dachschalter
`roofMeshPrefixes ["front3_", "MESH_ROOT.001"]`, **`roofMinHeight −1`**: die 24 `front3_*`-Meshes sind Membran (`roof_stuttgart_canvas_06/07/11`), Dachring/Seilnetz (`metalpainted_arch`), Flutlichtzeilen (`light_fixture_a`), Laufstege, **Masten `front3_8` bis zum Boden (y −0,4…47,2)** — mit −1 gehen die Masten vollständig mit dem Dach (wie die Pylone in Leverkusen), kein Stummel bleibt — und die beiden **Anzeigetafel-Gehäuse an den Enden** (`front3_1/2/7`, y 20–26, `metal_scoreclock_01`) mit den Bildschirmflächen `MESH_ROOT.001` (Dachzustand-Regel; 4/4 Dreiecke Dach).
Nachrechnung (`quellbelege/nachweise.json`): **Dachliste 64.062 / 64.062; Tribünen `center1_*` 0 / 111.348, übriger Körper 0 / 52.458, Boden 0 / 1.255, Crowd 0 / 560, Spielfeld 0 / 4.618**. VfB-Logo/Schriftzug auf der Haupttribüne (`center1_90/111/65`, `center_df_0/4`, y 27–31) bleibt Körper. Sichtprüfung Dach aus: Ränge, Sitzmosaik, Logen, Außenhülle vollständig (`bilder/02b`, `07`, `09`).

## Ortsplan und Achsen (Fassung 1 — durch Fassung 2 oben ersetzt, zur Nachvollziehbarkeit belassen)
- OSM-Abgleich (`quellbelege/umfeld_pruefung.json`): Carl Benz Center (WNW, 19 m), Schleyerhalle (N, 10 m), Molly-Schauffele-Halle (O, 8 m), Parkhaus P7 (O, 11 m), VfB-Geschäftsstelle/Robert-Schlienz-Stadion (SO) treffen die bg-Gebäude → nordorientierte Karte; `axisTheta 140°` → Spielfeld +X (NORD-Ende) zeigt nach **NW**.
- Blaupause (öffentlicher live-scene): WEST = 3 VIP-Blöcke (Haupttribüne), **SUED = Heimblock mit 9 Stehplatzblöcken**, NORD = Gegenende. Modell: VIP-Logen/VfB-Logo/Dugout-Sitze (`front2_0/4`, x −39,8) bei −x → WEST; Heimkurve `C_left1_C1-UltraHome` bei +z → SUED; Gästeblock `C_back1_C2-UltraAway` in der Ecke +x/−z → OST/NORD.
- `standAxes {+x OST, −x WEST, +z SUED, −z NORD}`, `surroundingsAxes {NORD: −z, WEST: −x}` (gespiegelte Längsachse wie Frankfurt/Leipzig). Beleg `bilder/umfeld-ausrichtung.jpg`.
- **Hinweis zur Blaupause (nicht zum Modell):** Laut OSM hängt die SCHARRena am SO-Ende (= Blaupausen-SUED); real ist das die Untertürkheimer (Gäste-)Kurve, die Cannstatter (Heim-/Stehplatz-)Kurve liegt im NW. Die Blaupause führt den Heim-/Stehplatzblock aber im SUED. Das Modell folgt den Blaupausen-Labels (Heimkurve = SUED); wenn die Blaupause gedreht wird, reicht `standAxes`/`surroundingsAxes` tauschen (+z NORD, −z SUED → Standard-Adapter) ohne Asset-Änderung.
- Ticker-Kamera gemeinsam (`tickerRotationY −90`), `tickerFrontCut (1,0,0)/32`, Orbit 0,95/0,65/380 (Dachring bis ±143 m).

## Bodenregeln (`boden_960.json`, Re-Export deterministisch)
Transparent 1 (`field_1` Bodenziffern), Rasenangleichung 0 (keine Turf-Unterlage), transluzent 18 (Glas/Fenster 23–72 % Deckung), Alpha-Schnitt 22 (Gitter, Geländer, Laufstege, Pressebox, Logo-Schriftzug, Bildschirmflächen), unsichtbar 0. Spielfeld per `pitch_validation`: **105,000 × 68,000 m**; Spielfeldtextur der Quelle heißt `0002-Bayern 1` (generischer Rasen, Linien separat).

## Sichtprüfung
`bilder/stuttgart-ansichten.jpg`: Editor Dach an/aus, Ticker Dach an/aus, Ticker Nacht + Flutlicht, Draufsicht Dach an/aus, Dach aus von der Gegenseite. Sitzmosaik (rot/weiß) aus der Quelltextur `audi_seat_mat`.

## Offene Punkte (deine)
1. ~~Blaupausen-Frage Heimkurve SUED vs. real NW~~ — in Fassung 2 gelöst (Achsen korrigiert, Metadaten siehe oben).
2. Vorschau-Umfeld: 3 bg-Gebäude liegen innerhalb des Stadionumrisses (vermutlich SCHARRena/Anbauten, Blaupausen-Umriss ±136 m); nur in der Harness-Vorschau entfernt, Produktivbestand unberührt — ggf. Replit-Hinweis wie bei Leverkusen.

## Einspielen
1. Replit-Stand 13.10. (Patch integriert). 2. `scp -r stadium-models/960 root@49.13.5.151:/var/www/assets/stadium-models/` 3. `models/960.json` nach `stadium_editor/blueprints/v2/models/`, `/push`. 4. `check_stadium_model --fmi 960 --assets` → `Assets OK: 85 Dateien`. 5. Abnahme Livemodus (Carl Benz Center/Schleyerhalle am NORD-Ende = Heimkurve, SCHARRena am SUED-Ende, Schauffele-Halle/P7 an der OST-Seite). Falls `models/960.json` aus Fassung 1 schon registriert ist: nur diese Datei ersetzen, Assets bleiben.

## Reproduktion
```sh
python3 -I werkzeuge/export_stadium_model.py --bundle stuttgart.bundle --seats stuttgart.json --fmi 960 --name "MHPArena" \
  --out export --calibration kalibrierung.json --roots EXTRA --lamp-materials light_fixture \
  --ground boden_960.json --exclude-meshes center2_24,center2_18,center2_28,center2_28.001
#  Fassung 2 zusätzlich: --asset-version eb8360ccb45d2408 (Assets unverändert)
#  → assetVersion eb8360ccb45d2408
```
