FLAGGEN-PAKET playwebsoccer.de
================================
205 Flaggen nach FM-Nation-ID benannt ({fm_id}.png) - direkt nach /var/www/assets/flags/ hochladen.

UNMAPPED (39 Stueck, Ordner /unmapped): [96, 146, 147, 152, 179, 206, 207, 210, 211, 213, 215, 216, 220, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 243, 244, 245, 247, 249, 300, 301, 302, 303]
Grund: EA-Sonder-/Spezialeintraege (dunkle Serie 226-249 = vermutlich Legenden/Spezialteams),
Platzhalter (225 = leer, 216 = grau), oder Laender ohne FM-ID im Nations-Pack
(96 = US Virgin Islands, 179 = Pakistan). 146, 152, 207, 210, 211, 213, 215, 220, 300 = nicht eindeutig identifizierbar.
Bei Bedarf manuell pruefen und nachbenennen.

Hinweis: 68_Bermuda->363 ist die einzige Zuordnung mit Restunsicherheit auf FM-Seite.
KORREKTUR: f_100 = Botswana (klar erkannt, aber keine FM-ID im Nations-Pack) -> unmapped/f_100_botswana.png
