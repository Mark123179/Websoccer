# Handoff — Managerprofil · Reiter „Trikots"

Kleiderstange mit allen Trikots, die der Manager bei seinen Vereinen getragen hat. Echte 3D-Modelle (three.js), ziehen mit der Maus, Pendel- und Flatter-Physik.

## Inhalt
- `PROMPT_REPLIT.md` — **1:1 in Replit einfügen**. Verbote, Schritte, Abnahme-Checkliste.
- `BACKEND_SPEC.md` — Modell `KitVersion`, Pipeline (Bügel-Foto → Freistellen → 3D), View-Context.
- `replit_ready/` — **fertiger Vanilla-Code**:
  - `trikots_kleiderstange.html` — lauffähige Referenz (im Browser öffnen), alle Blöcke 0–3 markiert
  - `manager-trikots.css`, `manager-trikots.js` — fertige Dateien zum Ablegen
  - `assets/kits/` — Raumfoto, Stangen-Ebene, Bügel-PNGs (Fallback)
- `design_reference/` — Designquelle (`Managerprofil.dc.html`, Frame 2c) + `Trikot-Stange.html`
- `GESPRAECHSVERLAUF.md` — Entscheidungen

## Wichtig
- three.js **0.184.0** über die mitgelieferte Import-Map (mit Integrity-Hashes). Keine andere Version.
- Kein GLTFLoader nötig — ein schlanker GLB-Parser ist im JS enthalten.
- 3D-Modell fehlt/lädt nicht → automatischer Fallback auf Bügel-PNG.
