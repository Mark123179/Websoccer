# Backend-Spezifikation — Trikot-Historie & 3D-Pipeline

## Problem heute
`Club.kit_home_file / kit_away_file / kit_third_file` werden beim Upload **überschrieben** → keine Historie.

## Neues Modell
```python
# game/models.py
class KitVersion(models.Model):
    TYP = [("home", "Heim"), ("away", "Auswärts"), ("third", "Ausweich")]
    club = models.ForeignKey("Club", on_delete=models.CASCADE, related_name="kit_versions")
    typ = models.CharField(max_length=5, choices=TYP)
    texture = models.ImageField(upload_to="kits/textures/")        # 1024×1024 Kit-Raster
    checksum = models.CharField(max_length=64, db_index=True)       # sha256 der Textur
    hanger_png = models.ImageField(upload_to="kits/hanger/", blank=True)   # freigestelltes Bügel-Foto
    hanger_w = models.PositiveIntegerField(default=0)
    hanger_h = models.PositiveIntegerField(default=0)
    glb = models.FileField(upload_to="kits/glb/", blank=True)       # 3D-Modell
    status = models.CharField(max_length=12, default="pending")    # pending | hanger | model | ready | failed
    first_season = models.PositiveIntegerField()                    # Saison-Nr., ab der getragen
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [("club", "typ", "checksum")]
```

## Wann entsteht ein neuer Eintrag?
- Upload/Import einer Textur → `sha256` berechnen.
- Gibt es für `(club, typ)` schon eine Version mit gleicher Checksumme → **nichts tun**.
- Sonst neue `KitVersion(first_season=aktuelle_saison)` anlegen und Pipeline starten.

## Pipeline (einmal pro KitVersion, asynchron — z. B. Management-Command oder Celery-Task)
1. **Bügel-Foto** — Higgsfield `nano_banana_pro`, Textur als Referenz, 3:4, 2k:
   ```text
   The reference image is the flat UV texture map of a football (soccer) jersey: the large central panel is the shirt front, the panels left/right are sleeves and back. Create a photorealistic e-commerce product photo of exactly this jersey, assembled as a real short-sleeve football shirt, hanging on a simple black matte plastic hanger with a thin chrome hook at the top. Front view, perfectly centered, straight on, shirt hangs naturally with soft fabric folds. Reproduce all colors, stripes, sponsor logos, club crest and brand marks from the texture in their correct positions on the front and sleeves. Plain pure white background (#ffffff), soft even studio lighting, no mannequin, no person, no text, no watermark, whole hanger and shirt fully in frame with margin.
   ```
2. **Grünhintergrund** — gleiches Modell, Ergebnis aus 1 als Referenz:
   ```text
   Keep the jersey and hanger exactly identical (same shape, folds, colors, logos, position, scale). Only replace the entire background with a perfectly flat, uniform chroma-key green (#00FF00), no shadows, no gradient, no floor, no vignette.
   ```
3. **Freistellen** (serverseitig, Pillow): Grün-Überschuss `k = g − max(r, b)`; `k > 90` → transparent, `25 < k ≤ 90` → Alpha weich auslaufen, Spill entfernen; auf Inhalt zuschneiden; auf 900 px Höhe → `hanger_png`, `hanger_w/h`.
4. **3D-Modell** — Higgsfield `meshy_v7_image_to_3d`, Bild aus Schritt 1, `should_texture=true`, `target_polycount=40000` → GLB herunterladen → `glb`. **Kosten ca. 38 Credits**, Dauer 2–4 min.
5. `status = "ready"`.

Bei Fehler → `status="failed"`; das Frontend zeigt dann automatisch das Bügel-PNG (Fallback), sofern vorhanden.

## View-Context
```python
# game/views.py — in manager_profile()
stations = manager.career_stations()  # vorhandene Trainerstationen (Verein + Saisons)
kits = (KitVersion.objects
        .filter(club__in=[s.club for s in stations], status__in=["ready", "model"])
        .order_by("first_season", "typ"))
kits_json = [{
    "glb": k.glb.url if k.glb else "",
    "img": k.hanger_png.url if k.hanger_png else "",
    "W": k.hanger_w, "H": k.hanger_h,
} for k in kits if k.first_season in station_seasons(k.club)]
context["kits_json"] = kits_json
```
Nur Trikots von Vereinen und Saisons, in denen der Manager dort Trainer war.

## Bestehende GLBs der Demo
Die drei Demo-Modelle liegen derzeit bei Higgsfield (Links in `replit_ready/trikots_kleiderstange.html`). Einmal herunterladen und nach `/media/kits/glb/` legen:
- `1026_away` → `…/hf_20261001_145005_746f147a-….glb`
- `1050_away` → `…/hf_20261001_145009_95ca41fb-….glb`
- `1052_away` → `…/hf_20261001_145020_f1bba1be-….glb`
