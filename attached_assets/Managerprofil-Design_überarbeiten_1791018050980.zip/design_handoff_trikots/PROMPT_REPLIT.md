# Prompt für Replit — Reiter „Trikots" (Kleiderstange 3D)

> Kopiere alles ab hier 1:1 in Replit.

---

Du setzt im Managerprofil einen neuen Reiter **„TRIKOTS"** um. Das Design ist **fertig und abgenommen**. Deine Aufgabe ist ausschließlich die **1:1-Übernahme** des mitgelieferten Codes. Treffe **keine eigenen Designentscheidungen**.

## Verbote
- Keine Werte ändern (Maße, Farben, Physik-Konstanten, Kamera, Licht, Abstände).
- Kein Umformulieren, Kürzen, „Aufräumen" oder Refactoring des JS.
- Keine andere three.js-Version, keine zusätzlichen Libraries, kein GLTFLoader (der GLB-Parser ist absichtlich eingebaut).
- Keine Tailwind-/Bootstrap-Klassen, keine eigenen Styles.
- Keine zusätzlichen UI-Elemente (keine Pfeile, Filter, Info-Box, Leisten) — der Reiter besteht nur aus Header, Tabs und Kleiderstange.

## Dateien (aus `replit_ready/`)
| Quelle | Ziel im Repo |
|---|---|
| `manager-trikots.css` | `game/static/game/css/manager-trikots.css` |
| `manager-trikots.js` | `game/static/game/js/manager-trikots.js` |
| `assets/kits/rack-room.png` | `game/static/game/images/kits/rack-room.png` |
| `assets/kits/rack-bar.png` | `game/static/game/images/kits/rack-bar.png` |
| `assets/kits/hanger-*.png` | `game/static/game/images/kits/` (Fallback-Bilder) |
| `trikots_kleiderstange.html` | **nur Referenz** — zeigt alle Blöcke lauffähig zusammen |

## Schritte
1. **BLOCK 0 – Import-Map**: Den `<script type="importmap">…</script>` aus `trikots_kleiderstange.html` **unverändert** in den `<head>` von `game/templates/base.html` einfügen (vor allen anderen `type="module"`-Scripts). Inklusive `integrity`-Block.
2. **BLOCK 1 – CSS**: `manager-trikots.css` ablegen und im Template einbinden. Einzige erlaubte Änderung: die zwei Bild-URLs auf den Static-Pfad setzen:
   - `url('assets/kits/rack-room.png')` → `url('/static/game/images/kits/rack-room.png')`
3. **BLOCK 2 – Markup**: In `game/templates/game/manager_profile.html` einen dritten Tab-Inhalt **„TRIKOTS"** zwischen „MANNSCHAFTSFOTOS" und „SICHERHEIT & EINSTELLUNGEN" anlegen. Tab-Button exakt wie die bestehenden Tabs, Icon aus `design_reference/Managerprofil.dc.html` (Frame 2c, Trikot-Symbol). Inhalt = das `<div class="kit-rack">…</div>` aus BLOCK 2, `src` von `#kit-bar` → `{% static 'game/images/kits/rack-bar.png' %}`.
4. **Daten**: Direkt unter dem Markup `{{ kits_json|json_script:"kit-data" }}` ausgeben (erzeugt exakt das `<script id="kit-data">`-Element aus der Referenz).
5. **BLOCK 3 – JS**: `<script type="module" src="{% static 'game/js/manager-trikots.js' %}"></script>` **nach** dem `kit-data`-Script einbinden.
6. **View**: siehe `BACKEND_SPEC.md` — `kits_json` im Context von `manager_profile` bereitstellen.

## Datenformat `kits_json` (Liste, Saison aufsteigend)
```json
[
  {"glb": "/media/kits/1026_away_v1.glb", "img": "/media/kits/1026_away_v1_hanger.png", "W": 483, "H": 688}
]
```
- `glb` = 3D-Modell (Pflicht für 3D). Fehlt es oder lädt es nicht, fällt das Script automatisch auf `img` zurück.
- `img`, `W`, `H` = freigestelltes Bügel-PNG + Pixelmaße.

## Abnahme-Checkliste (alle Punkte müssen erfüllt sein)
- [ ] Tab-Reihenfolge: PROFIL · MANNSCHAFTSFOTOS · **TRIKOTS** · SICHERHEIT & EINSTELLUNGEN
- [ ] Kleiderstange exakt **1352 × 574 px**, Raumfoto vollflächig, Rand 1px `rgba(44,231,255,.18)`, Radius 8px
- [ ] Chromstange liegt **vor** den Haken (Haken verschwindet hinter der Stange)
- [ ] Aktives Trikot mittig, frontal; Nachbarn ~74° seitlich gedreht und abgedunkelt
- [ ] Ziehen mit der Maus verschiebt die Trikots, Loslassen rastet auf das nächste ein
- [ ] Beim Verschieben pendeln die Trikots am Haken nach und der Saum flattert kurz
- [ ] Klick auf ein seitliches Trikot holt es in die Mitte; ← / → funktionieren
- [ ] Browser-Konsole: **0 Fehler**
- [ ] Vergleich nebeneinander mit `replit_ready/trikots_kleiderstange.html`: kein sichtbarer Unterschied

Wenn ein Punkt nicht erfüllt ist: **nicht kreativ lösen**, sondern Abweichung melden.
