# Gesprächsverlauf — Reiter „Trikots"

**Datum:** 01.10.2026 · **Projekt:** Websoccer Managerprofil

## Entscheidungen
1. Neuer Reiter **TRIKOTS** zwischen Mannschaftsfotos und Sicherheit & Einstellungen.
2. Inhalt: alle Trikots aller Vereine, bei denen der Manager war; neuer Eintrag bei Vereinswechsel oder geändertem Design (Heim / Auswärts / Ausweich).
3. Wichtigstes Element: **Kleiderstange + Animation von Trikot zu Trikot** (Referenz: Video cambreedesigns).
4. Erste 2D-Version (CSS rotateY) verworfen: Trikots zu dünn, kein Flattern, Haken nicht an der Stange.
5. Raumfoto (Betonwand, Chromstange, Spot, Cyan-LED) über Higgsfield erzeugt; Stange als eigene Ebene **vor** den Haken.
6. Physik: Bügel rutscht kritisch gedämpft, Pendel um den Haken durch Beschleunigung, Saum zieht nach + Flattern (Vertex-Shader). → **„schütteln und Bewegung top"**.
7. Eigene Trikot-Vorlage (ein Mesh, UVs auf das 1024er-Kit-Raster) gebaut → **verworfen**, wirkt zu künstlich.
8. Entscheidung: **3D pro Trikot über Higgsfield** — Bügel-Foto (Nano Banana Pro) → 3D (Meshy 7, ~38 Credits, einmalig pro Trikot-Version). Tripo hing > 1 h in der Queue.
9. Haken-Höhe zweimal nachjustiert, aktuell `hookInset = KIT_H * -0.002`.
10. Vom Nutzer entfernt: Filter-Chips, Pfeile, Info-Box, Saison-Leiste → Reiter = Header + Tabs + Stange.

## Offene Punkte
- `KitVersion`-Historie im Backend (heute werden Kits überschrieben).
- Weitere 8 Texturen (Lokomotiv, Rotor, Spartak, Ural) durch die Pipeline schicken.
- Vereinsname für Textur `1026` (Horesca-Sponsor) unbekannt.
- Demo-GLBs liegen bei Higgsfield → nach `/media/kits/glb/` übernehmen.
