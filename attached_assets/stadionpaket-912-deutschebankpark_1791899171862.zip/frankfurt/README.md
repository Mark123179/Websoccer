# Deutsche Bank Park · Eintracht Frankfurt (FMI 912, Verein 6) — Fassung 1

Stand 13.10.2026 · Quelle `eintrachtfrankfurt.bundle` (FM26 Stadium Megapack v3.0, SHA-256 `5c64fcac68b03a224f50f727a2f201e35cdf3fcccab07aa96a880fcbc88aa04d`) + `eintrachtfrankfurt.json` (Sitzplätze), `_lightmaps.json`, `_lightprobes.json`.
assetVersion **`f00014f2a6dd940f`**, geometrySha256 `950202ecc0e4afe5bc00bef500a9c7f94aede1624a26f5a1bc0eebd8603c946d`, 299 Meshes, 113 Texturen, 16,54 MB Geometrie, 169 quellgeprüfte Leuchten → 12 Laufzeitleuchten. Noch keine Live-Registrierung für 912 vorhanden – dieses Paket legt sie an.

## Befund in einem Satz
Das Bundle ist vollständig und sauber: Membrandach (Außenmembran + Innenmembran mit blauer Glasur), Seilnetz, Dachrand, hängender Videowürfel und Tribünen mit „FRANKFURT"-Schriftzug kommen 1:1 aus der Quelle; versteckt werden nur die Fangnetze hinter beiden Toren und die Fernkulisse `center2_*`, Choreo-/Event-Objekte gibt es in diesem Bundle nicht (vollständiger Scan aller Wurzeln, keine LOD-Gruppen, alle Renderer aktiv).

## Vorgehen (Regeln vom 11./12.10.)
1. Inventur **aller** Meshes im Bundle über alle Wurzeln (`MAIN`, `AUDIAREA`, `PITCH2021`, `MESH_CROWD`, `EXTRA`, `AD`, `SCARECROW`): Renderer-Status, GameObject-Aktivität, LOD-Gruppen (keine), Material, Textur-Alpha, Blend-/Mask-Modus. `quellbelege/dach_inventar.json` = alle 94 Meshes mit y ≥ 25 m.
2. Isoliertes Ein-/Ausblenden jedes `front3_*`/`front3_df_*`/`front_df_*`-Meshes und der Sonderfälle im Spielrenderer (Replits zentraler `unity_stadium_scene.js` vom 12.10., Headless-Chromium): `bilder/isolation/iso_blatt_1.jpg`, `iso_blatt_2.jpg`, `sonderfaelle.jpg`.
3. Dachschalter als Präfixliste nach Quellprüfung (keine Höhentrennung allein), Nachrechnung mit der Renderer-Regel über das Binary.
4. Bodenregeln, Transluzenz- und Alpha-Schnitt-Heuristik → Sichtprüfung → festgeschrieben in `boden_912.json`; Re-Export mit `--ground boden_912.json` liefert byte-identisch dieselbe assetVersion.
5. Sichtprüfung der fünf Ansichten + Draufsicht (`bilder/`).

## Dachzuordnung (Quelle → Export → Schalter)
Alle 51 `front3_*` (MAIN) und 8 `front3_df_*` (EXTRA) liegen bei y 21,9–48,9 m und sind Dach oder dachgehängt; `roofMeshPrefixes = ["front3_"]`, `roofMinHeight 3`. Nachrechnung über das Binary mit der Renderer-Regel: **front3_ 102.524 / 102.524 Dreiecke Dach; Tribünen `center1_*` 0 / 206.269, Glas `front_df_*` 0 / 662, Boden `field_*` 0 / 6.764, Crowd 0 / 1.326, Spielfeld 0 / 4.618** – Ränge, Treppen, Sitzflächen, Unterbauten, Schriftzug und Glasfronten bleiben bei „Dach aus" vollständig; kein `front3_*`-Dreieck liegt unter 3 m.

| Gruppe | Meshes (Quelle) | Lage / Material | Behandlung |
|---|---|---|---|
| Außenmembran | `front3_28`, `front3_29` · MAIN | y 35,6–43,5, x ±93,6 / z ±113,7; `fabric_canvas_01_white`, `fabric_canvas_divided_01`, opak | Dach |
| Außenring, Rand, Randstützen | `front3_0`, `front3_6`, `front3_30`–`32`, `front3_26`, `front3_27`, `front3_1` | y 21,9–46,1; weiß/gelb lackiertes Metall, Alu, Beton schwarz; `front3_30` Wellblech 50 % → `transparent:true` | Dach |
| Seilringe, Innenring, Seilnetz | `front3_37` (9.264 Dreiecke), `front3_39`–`42`, `front3_44`–`50`, `front3_33`–`36`, `front3_38`, `front3_21`, `front3_23`, `front3_43`, `front3_df_3`, `front3_df_6` | y 28,5–48,9; Metall weiß/grau/dunkel, `metal_wire_01` (Seile, Alpha-Schnitt) | Dach |
| Innenmembran | `front3_df_4` · EXTRA | y 33,8–35,2, x ±52,3 / z ±75,7; `roof_canvas_08`, Textur-Alpha gleichmäßig → **81 % Deckung**, `transparent:true`, `alphaTest:0` | Dach |
| Blauglasur auf der Innenmembran | `front3_df_1` · EXTRA | deckungsgleich mit `front3_df_4`, 8 mm darüber; `glass_blue_02`, 20 % Deckung, `transparent:true` | Dach |
| Dachrand-Fensterrahmen | `front3_df_2` · EXTRA | y 31,1–34,2 Ring; `window_frame_tile`, Alpha-Schnitt | Dach |
| Leuchten / Flutlicht am Dach | `front3_2` (16.016), `front3_45` (30.030), `front3_3`, `front3_4`, `front3_44`, `front3_46`, `front3_5` | `light_e`, `street_lights`, `light_fixture_c`, `metal_base_white`; 169 Leuchten quellgeprüft → 12 Laufzeitleuchten (`--lamp-materials light_e_color,light_fixture`) | Dach |
| Laufsteg, Träger, Gitterstreifen | `front3_22` (Catwalk), `front3_18` (Gitterstreifen `metal_meshfence` an beiden Enden, y 10,4–33,8, z ±96; 72 Dreiecke, in der Isolierung kaum sichtbar), `front3_19`, `front3_20`, `front3_24`, `front3_25`, `front3_50` | Alpha-Schnitt bei Gitter/Geländer | Dach |
| **Videowürfel** (dachgehängt) | `front3_7`–`17`, `front3_df_0` (Bildschirme, `glass_tinted` 87 % → transluzent), `front3_df_5`, `front3_df_7` | y 26,0–41,2, x/z ±7,5 über dem Anstoßpunkt | Dach (hängt an den Seilen, verschwindet mit) |
| Glasfronten | `front_df_0`, `front_df_1`, `front_df_2` · EXTRA | Körper, 662 Dreiecke | Körper, bleibt |
| **Fangnetze** | `MESH_ROOT`, `MESH_ROOT.001` · MAIN | `plastic_netting_02_clean` 85 % Löcher, x ±36,9, y 1,9–31,1, z ±59,6–67,9 (direkt hinter beiden Toren) | **versteckt** (`skipMeshPrefixes: MESH_ROOT`) – Regel „Netze hinter Toren aus, Tore/Tribünen bleiben" |
| Fernkulisse | `center2_0`–`13` · MAIN | Bodenplatte ±445 m, Bergpanorama, Bäume, Fernbauten, **zwei 116-m-Gittermasten** `center2_4`–`8` westlich des Stadions (x −126…−108) | **versteckt** (`skipMeshPrefixes: center2_`); der Ortsplan ersetzt die Kulisse |
| Betonring am Sockel | `center2_14` · MAIN | 795 Dreiecke, `concrete_standard`, Ring x ±99,6 / z ±119,8, y −9,2…33,9 | **fällt mit** (Nebenwirkung, s. u.) |

Nicht übernommen (wie bei Bayern/Leverkusen): Wurzel `AD` (LED-Banden/Banner), `SCARECROW` (Figuren). Keine erfundene Fläche, keine Material- oder Farbänderung; Material und Textur jeder Fläche kommen aus dem Bundle.

## Bodenregeln (festgeschrieben in `boden_912.json`)
- Transparent (Alpha 1/255, Bodendecals): `field_10` Coach-Linien, `center1_detail_1` Vereinslogo auf dem Boden, `center1_133` Glas (`glass_clear_stjames`).
- Rasenangleichung: keine nötig (kein Rasenteil außer dem Spielfeld; `center2_0` Turf ist Kulisse und ohnehin versteckt). `uvProjection` identisch zur Bayern-Referenz (Spielfeld `st081_pitch_0` ±37,9 × ±57,2 m, Linienrasen ±34,1 × ±53,0 m).
- Transluzent (10 Teile): Innenmembran 81 %, Blauglasur 20 %, Wellblech 50 %, Videowürfel-Bildschirme 87 % (2×), Pressebox-/Logenglas `center1_84/150/156` 47 % und `center1_137/157` 23 %.
- Alpha-Schnitt (33 Teile): Geländer, Gitter, Seile, Tunnelbanden, Bodenlogo-Variante, Fangnetz-Halter – alle mit ≥ 50 % transparenter Textur, kein Bodenteil, kein transluzentes Teil.
- Unsichtbar-Kandidaten (≥ 99 % transparent): keine.

## Achsen und Kamera
- Prod-Szene Verein 6: homeStand NORD bei Szene +x, WEST (VIP) bei Szene +y. Modell: Trainerbänke/VIP bei −x → **WEST**; Heimkurve (`C_right*_UltraHome`) bei −z → **NORD**; Gästeblock (`C_left1_UltraAway`) bei +z → **SUED**. `standAxes = {+x: OST, −x: WEST, +z: SUED, −z: NORD}`.
- Damit ist die Längsachse gegenüber Bayern/Leverkusen (+z = NORD) **gespiegelt** – das Modell folgt der FM-Konvention (Heimbank/Heimkurve), nicht der Himmelsrichtung. Tribünenfarben, Blockzählung und Sitzansichten im Renderer laufen über `standAxes` und sind korrekt. Der Ortsplan-Adapter (`editorPointToDortmund`: Editor +X → Unity +Z, Editor +Y → Unity −X, ohne Spiegelung) setzt das Umfeld mit Nord bei +z – an den beiden Stadionenden ist das Umfeld dadurch vertauscht, an den Längsseiten stimmt es. Siehe „Offene Entscheidungen".
- Ticker: `tickerRotationY −90`, Schnittebene `[1,0,0] / 32` wie Leverkusen; Orbit `azimuth 0.95, elevation 0.65, distance 340` (Außenmembran reicht bis ±123,5 m, deshalb 340 statt 300).
- Spielfeld 105 × 68 zentriert, Kamera, Kapazität, Ausbau, Design, Vereinsdaten: unverändert (nicht Teil dieses Pakets).

## Bilder
`bilder/frankfurt-ansichten.jpg` = sieben Ansichten mit dem zentralen Renderer, 3D 1000×560, Ticker 1000×500: 3D Dach an/aus, Ticker Dach an/aus, Ticker Nacht + Flutlicht, Draufsicht Dach an (Membran + Seilnetz + Würfel, freie Feldöffnung) und Dach aus. Einzelbilder `02…07*.png` daneben. `bilder/isolation/`: jedes Dach-Mesh einzeln (`iso_blatt_1/2.jpg`), Sonderfälle (`sonderfaelle.jpg`: `center2_14` allein, Fangnetze im Ticker, Masten von Westen, Gesamtbild mit/ohne `center2_14`).

## Offene Entscheidungen (deine)
1. **`center2_14` (Betonring am Sockel)** fällt mit der Kulisse weg, weil der Vertrag nur Präfixe kennt (`center2_1` träfe auch `center2_14`). Empfehlung: so lassen – der Ring liegt außerhalb des Stadionkörpers, Gesamtbild mit/ohne in `sonderfaelle.jpg` Zeilen 4/5 praktisch gleich. Alternative (eine Zeile Kalibrierung, neue assetVersion nicht nötig): `skipMeshPrefixes` als Einzelliste `center2_0, center2_2 … center2_13` plus Ausschluss von `center2_1` (40 Dreiecke Bergpanorama) im Export.
2. **Zwei 116-m-Gittermasten** `center2_4`–`8` westlich des Stadions: versteckt (Kulisse). Empfehlung: versteckt lassen – sie stehen außerhalb der Ortsplan-Grundfläche und würden den Umfeld-Plan durchstoßen.
3. **Umfeld an den Stadionenden gespiegelt** (s. Achsen). Empfehlung: Replit-Zeile für den zentralen Renderer – `editorPointToDortmund` die Längsachse aus `calibration.standAxes` ableiten (Vorzeichen von z aus `+z`/`−z` = NORD) statt fest „Nord bei +z". Bis dahin: so lassen, keine Modelländerung (eine Spiegelung des Modells würde Schriftzüge und Windungsreihenfolge kippen; eine 180°-Drehung brächte die Haupttribüne nach Osten).
4. **Videowürfel** geht mit dem Dach aus (hängt am Seilnetz). Empfehlung: so lassen; wer ihn behalten will: `roofMeshPrefixes` als Einzelliste ohne `front3_7`–`17`, `front3_df_0/5/7`.

## Einspielen
1. `scp -r stadium-models/912 root@49.13.5.151:/var/www/assets/stadium-models/` (neuer Ordner `912/f00014f2a6dd940f`).
2. `models/912.json` nach `stadium_editor/blueprints/v2/models/912.json`, committen, pushen, `/push`.
3. `docker exec websoccer-web-1 python manage.py check_stadium_model --fmi 912 --assets` → `Assets OK: 114 Dateien`.
4. Fünf Ansichten live abnehmen (`/stadion/6/live/`), Ticker-Nacht mit Flutlicht.

## Reproduktion (byte-identisch geprüft)
```sh
python3 -I werkzeuge/export_stadium_model.py --bundle eintrachtfrankfurt.bundle --seats eintrachtfrankfurt.json \
  --fmi 912 --name "Deutsche Bank Park" --out export --calibration kalibrierung.json \
  --roots EXTRA --lamp-materials light_e_color,light_fixture --ground boden_912.json
#  → assetVersion f00014f2a6dd940f, alle 114 Assets + manifest.json identisch zu diesem Paket
python3 -I werkzeuge/roof_inventory.py eintrachtfrankfurt.bundle 25 dach_inventar.json         # Inventur
python3 -I werkzeuge/isolate.py export/manifest.json manifest_only.json only '^front3_df_4$'  # Isolierung (Harness &m=…)
```
Replits zentrales `scripts/export_stadium_model.py` kennt `--roots`, `--lamp-materials`, `--ground` und die Transluzenz-Regel weiterhin nicht; für eine byte-gleiche Reproduktion ist `werkzeuge/export_stadium_model.py` dieser Fassung nötig (Stand wie BayArena Fassung 2).
