# Replit-Prompt: Spielbericht-Ticker (MatchEngine / Websoccer)

Kopiere den folgenden Prompt in Replit. Das Paket enthält alles, was referenziert wird:

- `spielbericht-ticker.html` — fertige Referenz-UI (HTML/CSS/Vanilla-JS, keine Frameworks)
- `ticker_texte.json` — Text-Datenbank (~230 Varianten, 25 Event-Typen)
- `assets/crests/` — Beispiel-Wappen (908 = M'gladbach, 915 = Bayern; im Spiel liegen alle Wappen unter `game/static/game/images/crests/<fm_inside_id>.png`)

---

## PROMPT (ab hier kopieren)

Implementiere den **Ticker-Tab des Spielberichts** in unserem Django-Football-Manager (deutsches UI, dunkles "Football Command Center"-Design). Die Datei `spielbericht-ticker.html` ist die **verbindliche visuelle Referenz** — übernimm Markup-Struktur, CSS und Verhalten 1:1 und binde nur unsere echten Daten an. Erfinde keine eigenen Farben, Fonts oder Layouts.

### Kontext
- Das ist der **Spielbericht nach Abpfiff** (statische Auswertung), NICHT der Live-Ticker. Der Live-Ticker ist ein separates, späteres Feature auf einer anderen Seite — hier nichts dafür vorbereiten außer den Sound-Keys (siehe unten).
- Der Tab heißt "Ticker" und sitzt in der bestehenden Match-Seite neben Übersicht/Statistik/Aufstellungen/Spieler.
- Alles Deutsch. Schrift: Inter. Tokens (Farben, Radius, Schatten) stehen als CSS-Variablen im `<style>`-Block der Referenz — unverändert übernehmen.

### Aufbau (von oben nach unten)
1. **Filter-Chips**: Alle / Tore / Karten / Wechsel. Funktionieren rein über `data-flt` am `.ticker`-Container + CSS-Regeln (`.ticker[data-flt="tore"] .ev:not(.k-tor){display:none}`). Das 8-Zeilen-JS am Dateiende übernehmen.
2. **Spielverlauf-Leiste** (`.verlauf`): horizontale Minuten-Leiste 1'–90+. Obere Spur = Verein des eingeloggten Managers, untere = Gegner. Marker sind `<a href="#event-id">` mit `left: (minute / (90 + nachspielzeit)) * 100%`. Marker-Typen: `.m-tor` (Ball), `.m-gelb`/`.m-rot` (Karten-Rechteck), `.m-wechsel` (Pfeile), `.m-verletzung` (Kreuz). Nur Tore, Karten, Wechsel und Verletzungen erhalten Marker — kleinere Events nicht.
3. **Timeline** (`.timeline` mit `.spine`): chronologisch, Anpfiff oben, Abpfiff unten.

### Event-Typen → Markup-Vorlagen (alle in der Referenz enthalten)
| Engine-Event | Vorlage in Referenz | Filterklasse |
|---|---|---|
| Tor (alle Arten) | `.row.ev.k-tor` mit `.goal-card` | `k-tor` |
| Gelb / Gelb-Rot / Rot | `.row.ev.k-karte` (Rot: `.flash-r`, Node `.c-red-glow`) | `k-karte` |
| Wechsel | `.row.ev.k-wechsel` | `k-wechsel` |
| Verletzung | `.row` mit Node `.c-red` + Kreuz-Icon | — (im Verbund `k-wechsel`) |
| Ecke, Alu, Foul, Chance, Parade | `.row.ev` mit neutralem Node | nur unter "Alle" sichtbar |
| VAR, Elfmeter-Pfiff | `.row.ev` mit cyan Node | nur unter "Alle" |
| Abseits | `.row.ev` mit gelbem Fahnen-Node | nur unter "Alle" |
| Anpfiff / Halbzeit / Abpfiff | `.divider-card` (Abpfiff: `.final` mit Score-Pill) | immer sichtbar (kein `.ev`) |

Icons kommen aus dem SVG-Sprite oben in der Datei (`<use href="#i-ball">` usw.) — Sprite komplett übernehmen.

### Eigenes Team betonen
`.own` auf der Tor-Zeile schaltet die komplette Karte auf grün (sport-positiv): Node, Badge, Score, Sweep. Logik: `event.team_id === manager.club_id → class "own"`. Gegner-Tore bleiben cyan. Team-Chips an Textzeilen: `.teamchip.own` (grünlich) vs. `.teamchip.opp` (rötlich), Inhalt = Mini-Wappen + 3-Buchstaben-Kürzel.

### Zusammengehörige Events verbinden
Wenn auf eine Verletzung innerhalb weniger Minuten ein Wechsel desselben Teams folgt (oder Foul → Karte), beide Zeilen in `.group` wrappen — der `.group-link` (rot→grün-Verlauf auf der Spine) verbindet sie optisch.

### Texte aus `ticker_texte.json`
Die Datei enthält pro Event-Typ 6–20 Varianten mit Platzhaltern und liegt bei. Nutzung beim Generieren des Spielberichts:
1. Event-Typ mappen (z.B. Kopfballtor → `tor_kopfball`, sonst `tor`).
2. Varianten nach Kontext filtern: `phase` (frueh/mitte/spaet/nachspielzeit/any), `spielstand` (fuehrung/rueckstand/ausgleich/any, aus Sicht des Event-Teams), optional `ton` ("hype" max. ~20 % der Fälle).
3. Zufällige Variante ziehen, Platzhalter ersetzen: `{spieler}`, `{spieler2}`, `{torwart}`, `{team}`, `{gegner}`, `{spielstand}`, `{minute}`.
4. Spielernamen im gerenderten Text in `<strong>` setzen (eingewechselte Spieler in `<span class="in">`).
5. Denselben Varianten-Text nicht zweimal im selben Spiel verwenden (einfaches Used-Set).
6. Den `sound`-Key des Event-Typs am Event mitspeichern (z.B. `crowd_goal_roar`) — Audio kommt später, das Feld soll ab jetzt in den Spieldaten stehen.

### Animationen
Alle Animationen sind reines CSS (Keyframes in der Referenz). Die Staffelung läuft über `--d` (Delay) pro `.row` — beim Server-Rendern einfach fortlaufend vergeben (`0.1s + i * 0.2s`, Tore +0.2s extra). Kein JavaScript für Animationen. `prefers-reduced-motion` darfst du ergänzen (Animationen aus).

### Don'ts
- Keine Spielerfotos im Ticker (bewusste Entscheidung).
- Keine anderen Farben/Fonts/Radien als die Tokens; kein Bootstrap/Tailwind.
- Reihenfolge niemals umdrehen — Spielbericht ist chronologisch.
- Die Demo-Daten (BMG vs. FCB, 2:3) sind Platzhalter — durch echte Engine-Events ersetzen, Markup-Struktur beibehalten.

### Akzeptanzkriterien
- [ ] Filter-Chips schalten korrekt um, "Alle" zeigt alles, Trennkarten bleiben immer sichtbar
- [ ] Klick auf Verlaufs-Marker springt zum Event (Anchor-Scroll, `scroll-margin-top` beachten)
- [ ] Eigene Tore grün, Gegner-Tore cyan, Team-Chips an jeder Textzeile
- [ ] Texte kommen aus `ticker_texte.json`, keine Dopplungen im selben Spiel
- [ ] Events ticken beim Laden gestaffelt ein; Hover-Zustände auf Zeilen, Karten und Markern
- [ ] Layout hält von ~900px bis 1884px Breite ohne horizontales Scrollen
