# Websoccer Tactic Integration Patch V1

## Was Replit übernehmen soll

Die einzige Produktionsdatei, die gegenüber dem zuletzt gelieferten Replit-Export geändert wurde, ist:

- `run_match.py`

Bitte diese Datei im Projekt durch die beiliegende `run_match.py` ersetzen.

## Voraussetzung

Die Datei `tactic_compiler.py` muss im selben Verzeichnis liegen wie `run_match.py`.
Im letzten Export war `tactic_compiler.py` bereits vorhanden und wurde hier nicht geändert.

## Optional

- `run_tactic_analysis.py` ist nur ein Analysehelfer für lokale Batch-Auswertungen.
- `run_match.diff` zeigt die Änderungen gegenüber der letzten Replit-Version.
- `PATCH_NOTES.md` beschreibt kurz, was integriert wurde.

## Testbefehle

Nach dem Ersetzen sollten diese Befehle funktionieren:

```bash
python run_match.py bayern_fixture.json 1000
python batch_tactic_tests.py bayern_fixture.json 1000
```

## Wichtigster Inhalt der Änderung

Die alten wirkungslosen Stubs in `run_match.py` werden nicht mehr genutzt:

- `_pressing_modifier(...) -> 1.0`
- `_attack_focus_modifier(...) -> 1.0`
- `_teamwork_modifier(...) -> 1.0`

Stattdessen importiert `run_match.py` jetzt:

```python
from tactic_compiler import compile_tactic, calculate_zone_strengths
```

und nutzt die kompilierten Taktikwerte für:

- Expected Goals
- Schüsse
- Ballbesitz
- Angriffszonen links / Zentrum / rechts
- Pressing-Ballgewinne
- Pressing überspielt
- Fouls und Karten
- Frischekosten
- Kohärenz
- Komplexität
- Debug-Ausgaben
