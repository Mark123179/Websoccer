# Tactics Integrated V1 — Local Analysis Patch

This package is a local analysis patch based on `websoccer_sim_export (1).zip`.

Main change:
- `run_match.py` now imports and uses `compile_tactic()` and `calculate_zone_strengths()` from `tactic_compiler.py`.
- Line multipliers, xG multipliers, shot volume/quality, possession bonus, zone weights, pressing stats, fouls/cards/fatigue/coherence/complexity are now used in the standalone simulation.

Added:
- `run_tactic_analysis.py`: runs multiple tactical variants and writes JSON/CSV reports.
- `tactic_test_results_integrated_v1.json`
- `tactic_test_results_integrated_v1.csv`

Important:
- This is not final production balancing.
- This is a test harness to make tactical values measurable and to run mass simulations.
- The prior Replit export had `tactic_compiler.py`, but `run_match.py` still had no active compiler integration.
