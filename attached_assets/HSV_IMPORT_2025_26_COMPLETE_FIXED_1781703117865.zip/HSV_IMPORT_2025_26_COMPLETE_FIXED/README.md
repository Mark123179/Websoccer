# HSV Importpaket – vollständig validiert

Datenstand: 2026-06-17
Saison: 2025/26
Spieler: 32
Importbereit: JA

## Quellenregeln
- ausschließlich FMInside FM26.2
- ausschließlich aktuelle EA-FC-26-Daten aus CMTracker/SoFIFA
- keine FM25-/FC25-/EA25-Werte
- keine geschätzten Ersatzattribute

## Stadion
- 57.000 Gesamtplätze
- 47.000 Sitzplätze
- 10.000 Stehplätze
- Tribünenverteilung nach WS_STADIUM_QUADRANT_V1

## Besonderheit Mario Vušković
Der Spieler gehört zum bindenden FM26-Kader. Wegen seiner laufenden Sperre veröffentlicht
die aktuelle EA-FC-26-Quelle keinen aktiven Detailattributsatz. Dieser Zustand ist explizit
als NOT_IN_ACTIVE_EA_FC26_DATABASE dokumentiert. Für die Stärkeberechnung gilt FMI_ONLY_X2.
Es wurden keine älteren EA-Werte übernommen.


## Datumsformat
Alle Werte in `date_of_birth` sind als Text im ISO-Format `YYYY-MM-DD` gespeichert. Excel-Seriennummern sind nicht zulässig und werden als Blocker validiert.
