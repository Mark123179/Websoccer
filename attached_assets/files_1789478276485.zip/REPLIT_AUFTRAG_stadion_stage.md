# Replit-Auftrag: Stadion-Bühne V1 in Editor und 2D-Modus einbinden

Stand: 15.09.2026 · Paket: `stadium_stage_replit_paket.zip` · Konzept: `claude_2d-stadion.md` · Verlauf: `GESPRAECHSVERLAUF.md`

---

## 0. Ein Satz

Ersetze den Canvas-Renderer des Livemodus und der Editor-3D-Ansicht durch das mitgelieferte three.js-Modul `stadium_stage.js`, erweitere die Live-Scene **additiv** um die Felder, die das Modul liest, und liefere Geometrie über die Blaupause V2 (OSM + Steckbrief) — **ohne** Endpunkte, Modelle, Kapazitätsregeln oder bestehende Tests zu brechen.

---

## 1. Leitplanken — was nicht angefasst wird

| Bleibt unverändert | Warum |
|---|---|
| URLs `/management/stadion/editor/`, `/stadion/<club_id>/live/`, `/stadion/<club_id>/live-scene/` | Bühne, Spielbericht und Design-Prototyp verlinken darauf |
| Modelle `StadiumGeometry`, `StadiumDesign`, `Stadium` (12 Kapazitätsfelder) | Kapazität bleibt allein im `Stadium`-Modell autoritativ (Kapazitätsregel) |
| Editor-Werkzeuge (Blockauswahl, Zauberstab, Palette, RLE-Bearbeitung, Undo/Redo, Speichern) | Nur die 3D-Ansicht wird getauscht |
| Scene-Schema `websoccer.stadium-live-scene` Version 1, alle bestehenden Felder | Neue Felder kommen **dazu**, keins fällt weg, keins ändert Bedeutung |
| Bestehende Tests | Müssen grün bleiben; neue Tests kommen dazu |
| `match_engine.py` und alles Ökonomische | Kein Bezug |

Regel für jede Änderung: **additiv, hinter Schalter, mit Rückfall.** Der alte Canvas-Renderer bleibt im Repo und wird per Setting `STADIUM_STAGE_RENDERER = "three" | "canvas"` gewählt (Standard nach Abnahme: `three`).

---

## 2. Lieferumfang im Paket

| Datei | Zweck |
|---|---|
| `stadium_stage.js` | Das Modul. ES-Modul, importiert `three` und `three/addons/utils/BufferGeometryUtils.js`. **Blackbox — nicht umschreiben.** Nur Pfade/Importmap anpassen |
| `vendor/three.module.js`, `vendor/BufferGeometryUtils.js` | three.js 0.170, ohne Bundler nutzbar (Importmap, siehe `index.html`) |
| `index.html` | Testseite: Szene per URL laden, alle Ansichten (`?view=match|orbit|seat&light=day|night`) |
| `stadion_duo.html` | Einzeldatei mit vier Stadien inline — Referenz, wie das Ergebnis aussehen soll |
| `blueprint_v2.py` | **Python-Referenz** der Blaupause V2 (OSM → Blöcke, Ränge, Dach, Laufbahn, Steckbrief, Standard-Design, Umfeld) — als Management-Command übernehmen |
| `steckbrief.json` | Ebene 2: die Steckbriefe der vier Beispiele (Format siehe §5) |
| `osm/*.json` | Overpass-Rohdaten der vier Beispiele (Cache) |
| `scenes/*_v2.json` | Fertige Szenen der vier Beispiele — so muss der Endpunkt liefern |
| `render_duo.py` | Headless-Render (Playwright + SwiftShader) für Screenshots und Abnahme |
| `out/*.png` | Abnahmebilder (Spielkamera, Außen, Draufsicht, Sitzblick, Flutlicht) |

---

## 3. Arbeitspakete in dieser Reihenfolge

### A · Modul einbinden (Frontend)

1. `stadium_stage.js`, `vendor/` nach `stadium_editor/static/stadium_editor/stage/`. Importmap in den Templates:
   ```html
   <script type="importmap">{"imports":{"three":"{% static 'stadium_editor/stage/vendor/three.module.js' %}","three/addons/":"{% static 'stadium_editor/stage/vendor/addons/' %}"}}</script>
   ```
2. **Livemodus** (`live_mode.html`): Canvas durch `createStadiumStage({canvas, scene, width, height, view:'match', lighting})` ersetzen. Kamera-Preset liegt im Modul (42 m / 28 m / 43° / Zoom 700) — nicht überschreiben, kein Auto-Fit. Tag/Flutlicht-Umschalter als Query-Parameter oder Knopf.
3. **Spielbericht-Einbettung**: derselbe Aufruf, gleiche Kamera, Höhe 260–460 px bleibt. `project(xm, ym, zm)` nach außen reichen (`window.stadiumStage.project`) — die Figuren-Ebene der 2D-Bühne wird später durch diese Funktion gezeichnet.
4. **Editor-3D-Ansicht**: `view:'orbit'` mit `design: {blocks: {<id>: rle, …}}` aus dem ungespeicherten Editorzustand. Bei jeder Änderung neu aufbauen (Aufbau ≈ 0,2–1 s; Debounce 300 ms reicht). Zusätzlich `view:'seat'` per Klick auf einen Block (Sitz über `stage.seatAt(block, row, col)`).
5. `adaptQuality(dt, now)` im Animationsloop aufrufen, falls ein Loop existiert; bei Standbild nicht nötig.

### B · Live-Scene additiv erweitern (Serializer)

Neue Felder, alle optional, alle vom Modul gelesen (Werte siehe `scenes/*_v2.json`):

| Feld | Inhalt | Quelle |
|---|---|---|
| `mainStand` | NORD/OST/SUED/WEST — Kameraseite | Langseite mit den meisten VIP-Plätzen; Steckbrief kann überschreiben |
| `farStand` | Gegentribüne | gegenüber `mainStand` |
| `capacity` | Zahl aus `Stadium.capacity_total` | `Stadium` |
| `clubColors` | `{primary, secondary}` Hex | neue Felder am Verein (C) |
| `steckbrief` | globaler Teil des Steckbriefs (`corners`, `roofType`, `pylons`, `floodlights`, `sunken`, …) | Steckbrief (F) |
| `facade` | bool — Fassade zeichnen (nur Ringstadien) | Blaupause |
| `facadeSegments` | Liste `[[x,y],[x,y]]` — nur Außenkanten (bei C-förmigen Gebäuden ohne Innenkante) | Blaupause |
| `standsBounds` | `[minx, miny, maxx, maxy]` der Blöcke | berechnet |
| `groundHole` | konvexes Polygon fürs Gelände-Loch bei `sunken` | Blaupause |
| `track` | `{outer:[…], inner:[…]}` Laufbahn | OSM, wenn vorhanden |
| `surroundings` | `{buildings:[{poly,h}], roads:[{w,p}], green:[…]}` | Bundle `bg` bzw. OSM |

Bestehende Validierung bleibt (RLE-Summe, IDs, Quads, `z1 > z0`). **Neu:** `sum(rle) == rows × seats` gilt weiter, aber `rows`/`seats` sind ab V2 das **physische Raster** (Tiefe / 0,8 m × Breite / 0,5 m), und die Kapazität je Block steht im Feld `capacity` (Verteilung wie bisher über `distribute_capacities`, Gewicht = `rows × seats`). Die Summe der `capacity`-Felder ist die `Stadium`-Kapazität — das ist die Invariante, nicht die Rastersumme.

### C · Vereinsfarben und Standard-Design

1. `Club.color_primary`, `Club.color_secondary` (Hex, Admin-editierbar). Einmaliger Command `derive_club_colors`, der aus dem Wappen die zwei dominanten Farben zieht (K-Means auf dem PNG, Weiß/Schwarz-Hintergrund ignorieren); Ergebnis nur setzen, wenn leer.
2. Der Live-Scene-Endpunkt antwortet **auch ohne `StadiumDesign`**: dann Standard-Design serverseitig — Schalen in Farbe 1, Band in Farbe 2 bei 45–60 % der Reihen (Funktion `standard_design` in `blueprint_v2.py`). `404` nur noch ohne Stadion oder ohne Geometrie.

### D · Blaupause V2 als Management-Command

`import_stadium_blueprint_v2 --club <id> [--osm <datei>] [--dry-run]`:

1. OSM-Daten laden (Cache-Datei im Repo unter `stadium_editor/osm/<club>.json`; Command `fetch_stadium_osm` holt sie per Overpass mit Bbox um `Stadium.city`/Koordinaten — Overpass ist unzuverlässig, deshalb Cache **immer** committen).
2. Weg wählen (Reihenfolge, Logik in `blueprint_v2.py`):
   - **Tribünenpolygone** (`building=grandstand` / `building:part` je Tribüne) → `build_elversberg`-Muster
   - **Stadionring** (`building=stadium` Multipolygon mit Innenring) → `build_dortmund`-Muster (Seiten + Eckfächer)
   - **Terrassenringe** (`building:part` mit `min_height`/`height`) → `build_camp_nou`-Muster (Oval)
   - **Ein Gebäudepolygon mit Laufbahn** (`leisure=track`-Relation) → `build_olympiastadion`-Muster (Oval, Ränge nach Tiefenanteil, Lücke)
   - Rückfall: Außenkontur um Feld + Abstand (heutiger Bundle-Stand)
3. Feste Regeln (Konstanten, nicht je Verein): Mindestabstand Front–Feld **5 m Langseite / 7 m Torseite**; Blockbreite ~22 m; Raster 0,8 × 0,5 m; Steigung Unterrang 16°, Oberrang 30°, ein Rang 22°; Umlauf 2 m; **eine Tiefe je Tribünenpolygon** (Median); Treppe 0,6 m zwischen Ovalblöcken; Dach ab `zTop + 3 m` (innen) / `+ 4,5 m` (außen).
4. Ergebnis in `StadiumGeometry.geometry` schreiben (bestehendes Format + neue Felder aus B), `source = "OSM/BLUEPRINT V2"`, Steckbrief in `StadiumGeometry.steckbrief` (F). **Bestehende Geometrie nie automatisch überschreiben** — nur per explizitem Command je Verein; bestehendes Design wird dabei auf Standard zurückgesetzt (Block-IDs ändern sich), das ist vor dem Launch akzeptiert und im Command-Output zu melden.

### E · Ausbau wächst die Geometrie

`refresh_geometry_after_capacity_change` erweitern: je zugebauter Reihe Hinterkante um 0,8 m entlang der Blocknormalen nach außen und `z1` um die Rangsteigung; ab 42 Reihen additiv ein neuer Rang außen (`z0 = alte Oberkante + 2 m`, gleiche Blockbreite, Standard-Design). Bestehende Blöcke, IDs und Designs bleiben. Die Kapazitätsregel bleibt: ein Ausbau wird nie blockiert; scheitert die Geometrie, bleibt sie unverändert und `last_warning` meldet es.

### F · Steckbrief

`StadiumGeometry.steckbrief = JSONField(default=dict)`, Admin-editierbar, Format aus `steckbrief.json`:

```json
{
  "_global": {"corners": "closed|open|oval", "roofType": "ring|separate|plate", "pylons": {"count": 8, "color": "#f7d418", "height": 62},
              "floodlights": {"type": "rim|masts", "count": 4, "height": 30}, "sunken": 12, "mainStand": "WEST"},
  "SUED": {"tiers": 1, "rake": 30, "standing": true, "roof": true, "span": 30}
}
```
Fehlt ein Wert, gilt die Konstante aus D. Der Serializer legt `_global` als `steckbrief` in die Szene.

### G · Tests (neu, zusätzlich zu den bestehenden)

- Live-Scene ohne `StadiumDesign` liefert 200 mit Standard-Design; Palette enthält beide Vereinsfarben.
- Live-Scene enthält `mainStand`, `farStand`, `capacity`, `standsBounds`; alte Felder unverändert.
- Blaupause V2 erzeugt aus jeder der vier OSM-Cachedateien eine gültige Szene (RLE-Summen, `z1 > z0`, Mindestabstand ≥ 5/7 m, keine Tribünenfront im Feld).
- Ausbau: Tiefe und `z1` wachsen, IDs bleiben, Design bleibt.
- Editor speichert weiterhin; 3D-Ansicht rendert (Playwright-Smoke wie in `render_duo.py`: keine Konsolenfehler, Canvas nicht leer).

---

## 4. Abnahme

Für jedes Stadion die vier Bilder aus `render_duo.py` (Spielkamera Tag, Außenansicht Tag, Draufsicht, Spielkamera Flutlicht) und die fünf Prüfpunkte aus `claude_2d-stadion.md`: Maßstab (Feldecken auf identischen Pixeln — messbar über `project`), Form, Ränge, Dach, Pressen (Testmuster lesbar, nicht gespiegelt). Vergleichsbilder: `out/` im Paket und `stadion_duo.html`.

Reihenfolge der Vereine: Dortmund und Elversberg (Prüfpaar), dann alle Vereine mit Blaupause im Bundle, zuletzt Vereine ohne Blaupause (Generator-Rückfall + Steckbrief).

---

## 5. Was nicht Teil dieses Auftrags ist

Zuschauer/Auslastung, Rasenmuster, Choreo-Karten je Spiel, Figuren/Ball/HUD der 2D-Bühne (kommen aus Claude Design über `project()`), Fassadenraster mit Stützen, Dachträger, Bäume, Sitz-Klick-Picking, Ko-fi-„dein Platz". Alles davon liegt als Regel im Konzept und wird nach der Abnahme beauftragt.
