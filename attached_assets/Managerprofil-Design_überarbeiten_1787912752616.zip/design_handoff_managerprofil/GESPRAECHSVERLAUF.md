# Gesprächsverlauf & Entscheidungen — Managerprofil-Redesign

Chronologisches Protokoll der Design-Entscheidungen (Stand: 28.08.2026). Quelle der Wahrheit für „warum ist das so".

## Phase 1 — Grundgerüst & Varianten
- Ausgangspunkt: Replit-Stand des Managerprofils + FM-Screenshot als Timeline-Vorbild; Quellcode aus GitHub `Mark123179/Websoccer` (manager_profile.html, views, urls).
- 3 Varianten gebaut (1a FM Broadcast, 1b Command Center, 1c Saison-Kapitel). **Entscheidung: 1a**, später zu **2a „FM Broadcast v2"** weiterentwickelt; 1b/1c verworfen und entfernt.
- Timeline: FM-Stil — farbcodierte Karten je Event-Typ, abwechselnd über/unter der Achse, Kategorie-Label + Icon je Karte, zeitproportionale Abstände (daher ungleiche Lücken), Filter-Chips, Saison-Zoom per Klick aufs Saison-Label.
- **Fester Farbcode** (einheitlich, mit Legende): Gold = Titel/Historie · Cyan = Verein/Liga · Grün = Jugend/aktuelles Amt · Rot = Finale verloren/Entlassung.
- Europa-Karte mit Auto-Zoom aus dem Bestand übernommen (bewährt), Marker-Klick öffnet Stations-Panel.

## Phase 2 — Funktionen im Profil
- **Avatar-Edit**: Stift am Profilbild (+ Reset ✕). Trainer-Typ wird ebenfalls im Profil geändert, nicht in den Einstellungen.
- **Jugend** als Timeline-Kategorie ergänzt.
- **Anträge**: Spieler-Button „Eintrag einreichen" (Datum, Kategorie, Titel, Beschreibung, Verein — nur eigene Stationen); Admin übernimmt/lehnt ab; Admin kann manuell hinzufügen. Reiter „Transfers" komplett entfernt.
- **Statistik folgt der Vereinswahl**: Vereins-Leiste als Dropdown (skaliert für beliebig viele Stationen, kein 4-Vereine-Limit), ein „ALLE"-Button für Gesamtkarriere; Karten-Marker-Klick wechselt ebenfalls.
- **Rekordbuch ↔ Badges getauscht**: Badges & Auszeichnungen links groß (wächst mit der Zeit), Rekordbuch rechts kompakt in Statistik-Breite.
- KPI umbenannt: **„Saison-Score"** (statt Highscore). Trophäen-Zelle: Anzahl zentriert, darunter max. 6 Wettbewerbslogos.
- **Saison-Notation überall `#1, #2, …`** statt „2023/24".
- **Trainer-Titel**: Auszeichnungen schalten Titel frei (Pokalheld → „Pokaljäger"; weitere wie „Feuerwehrmann", „Quälix"), je Titel „x % der Manager haben diesen Titel", freigeschaltete farblich markiert. Separate Kachel **„Badges"** ergänzt.
- **„Nicht aufgestellt" — 3 Stufen** (je mit Nachricht): 1) Malus + Zählerhinweis pro verpasstem Spiel · 2) Transfersperre bei 2 in Folge/3 pro Saison, bis wieder selbst aufgestellt · 3) Vereinsverlust bei 3 in Folge/5 pro Saison + Timeline-Eintrag „Entlassung". Anzeige „2/5 SAISON · 1/3 FOLGE", Details im i-Tooltip; Urlaubsmodus pausiert, Saisonwechsel resettet.

## Phase 3 — Trophäen-Vitrine
- „Alle Trophäen ansehen" öffnet Popup mit **realistischem Vitrinen-Schrank** (Bild vom User, `assets/vitrine/schrank.png`).
- **3 Trophäen pro Regalreihe**, exakt auf den Regalböden (Positionen mehrfach feinjustiert), danach **Seiten-Paging**.
- Nur Pokale sichtbar; **Hover-Tooltip**: Wettbewerbslogo, Verein(e) mit Wappen + Saison `#n`, Anzahl. Ein Wettbewerb kann mit mehreren Vereinen gewonnen sein (Demo: 2 Vereine).

## Phase 4 — Sicherheit & Einstellungen (Frame 1d)
- Kontodaten (Wohnort **editierbar**), Konto verwalten, Passwort ändern mit Checkliste, Sichtbarkeit & Privatsphäre (10 Toggles). Trainer-Typ hier bewusst entfernt.
- **Urlaubsmodus**: Kalender-Auswahl, max. 14 Tage am Stück, 1× pro Saison, alternativ 2 Blöcke à 5 Tage, nicht rückwirkend; pausiert Nicht-aufgestellt-Zähler.

## Phase 5 — Mannschaftsfotos (Frame 2b, neuer Tab)
- Saisonale **Momentaufnahme des 1. Kaders** vor generischem Stadion (Bild vom User via Higgsfield; Video-Wand bleibt neutral).
- Ränge + Bande werden **in Vereinsfarben eingefärbt** (weiche Farbmaske statt harter Schwelle); Bande trägt Wappen + Vereinsname („MatchEngine"-Schriftzug entfernt), davor Gras-Streifen.
- 18–**60** Spieler (von 70 reduziert), Reihe 1 sitzend, dahinter stehend, nach hinten gestaffelt; Layout passt sich der Kadergröße an. Torhüter: kein eigenes TW-Trikot-Rendering — generischer TW-Look, individuelles Gesicht/Hautfarbe, außen platziert.
- **Spieler-Renders via Gemini API** (`gemini-2.5-flash-image`): Referenz 1 = Pose-Render mit Vereins-Kit (stehend/sitzend), Referenz 2 = Cutout-Kopf; weiß freistellen + zuschneiden per Canvas; **1× pro Saison zum Stichtag** generiert und gecacht (kein Live-Rendering). Testlauf: 16/16 Renders mit echten Köpfen fehlerfrei (diverse Hauttöne/Frisuren). Verworfene Ansätze: 2D-Kit-Overlay auf generische Körper, SVG-Körper, Vereinsfarben-Bodies — Qualität unzureichend.
- **Trophäen-Präsentation** am Saisonende: Toggle blendet gewonnene Pokale vor der Bande ein (Titel 1 links vom Wappen, Titel 2 rechts vom Text, 3/4 weiter außen). Pokal-Größen vom User final justiert (links 124×184, rechts 120×241).

## Phase 6 — Dummies & Paket
- **FC Porto** als Dummy-Erststation eingebaut (Saison #1, Aug 2022–Jun 2023): Karte (Position Atlantikküste — später echte Stadion-Koordinaten), Timeline, Vereins-Dropdown, Statistik, Vitrine.
- Alte Varianten 1b/1c aus der Datei entfernt. Paket: Standalone (`standalone/Managerprofil_standalone.html`, alle Assets eingebettet), aktualisierter Replit-Prompt, dieses Protokoll.

## Offene Punkte
- Echte Stadion-Koordinaten für die Karte (ersetzt Dummy-`x/y`).
- Weitere Trainer-Titel definieren (User liefert Liste).
- Gemini-API-Key serverseitig hinterlegen (nie im Frontend); Batch-Job zum Saison-Stichtag.
- Linker Bildrand im Mannschaftsfoto (äußerster Spieler leicht angeschnitten) — optional stauchen; Torhüter-Positionen außen.
