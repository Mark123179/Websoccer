# Prompt für den Replit-Agenten (Copy & Paste)

Setze das beiliegende Redesign des **Managerprofils** in unserem bestehenden Django-Projekt (Websoccer) um.

**Wichtigste Regel: KEINE eigenen Designentscheidungen.** Das UI/UX ist fertig abgenommen. Deine Aufgabe ist reine Implementierung: Werte, Farben, Abstände, Copy und Verhalten exakt aus den beiliegenden Dateien übernehmen. Wo fertiger Vanilla-Code beiliegt (`replit_ready/`), diesen **wörtlich kopieren** — nicht umformulieren, nicht „verbessern", keine eigenen Styles.

**Kontext**
- Ziel-Dateien: `game/templates/game/manager_profile.html`, `game/static/game/css/manager-profile.css`, `game/views.py` (+ Migrationen). Plain Django-Templates + CSS + Vanilla-JS — kein React, kein Build-Step.
- `design_reference/Managerprofil.dc.html` ist die **Design-Referenz** (kein Produktionscode). Maßgeblich: Frame **„2a FM Broadcast v2"** (Profil-Tab), Frame **„2b Mannschaftsfotos"** und Frame **„1d Sicherheit & Einstellungen"**. Alle Farben/Größen/Copy exakt aus den Inline-Styles; Details in `README.md`.
- `standalone/Managerprofil_standalone.html` ist der klickbare Soll-Zustand — im Browser öffnen und als Abnahme-Maßstab verwenden.
- Design-Tokens (`--panel`, `--line`, `#22e6ff`, `#30f29c`, `#ffd166`, `#ff5570`, Inter, Radius 8px) wie im Projekt üblich.
- **Saison-Notation überall: `#1`, `#2`, `#3` …** — niemals Jahreszahlen wie „2023/24" anzeigen.

**Umzusetzen (Reihenfolge einhalten)**

1. **Karriere-Timeline im FM-Stil** über Stadionfoto: Events proportional zum Datum auf horizontaler Achse, Karten abwechselnd über/unter der Achse (Icon-Chip, Kategorie-Label, Datum, Titel, Beschreibung, Vereinswappen), Verbindungsstiel + Glow-Punkt. Filter-Chips ALLE/VEREIN/TITEL/FINALE/JUGEND/STATUS (kein Transfers-Filter). Saison-Label-Klick = Zoom (Monats-Ticks, Reset-Chip). HEUTE-Marker + HEUTE-Button. **Fester Farbcode** mit Legende: Gold = Titel/Historie, Cyan = Verein/Liga, Grün = Jugend/aktuelles Amt, Rot = Finale verloren/Entlassung. → Fertiger Code in `replit_ready/timeline_trophies.html` (CSS/Markup/JS-Blöcke sind markiert).
2. **Timeline-Einträge & Anträge:** Modelle `TimelineEvent` + `TimelineEventRequest`. Jeder Spieler: Button „EINTRAG EINREICHEN" (Datum, Kategorie, betroffener Verein — nur eigene Stationen —, Titel, Beschreibung) → Antrag. Admins (`is_staff`): „ANTRÄGE" (Zähler, ÜBERNEHMEN/ABLEHNEN) + „+ EREIGNIS" (manuell). Übernommene Einträge erscheinen sofort.
3. **Vereins-Leiste mit Umschalter:** Vereinsname öffnet Dropdown aller Karrierestationen; Auswahl aktualisiert die 6 Kennzahlen **und** die Statistik-Karte. Karten-Marker-Klick wählt den Verein ebenfalls.
4. **Statistik-Karte:** „STATISTIK · <Verein>", genau ein Toggle „ALLE" für die Gesamtkarriere (serverseitig aggregiert, deutsches Zahlenformat).
5. **KPI-Leiste v2** (9 Zellen, Details README): u. a. **SAISON-SCORE** (statt Highscore) `12.480` gold + Trend; **TROPHÄEN**: Anzahl zentriert, darunter bis zu 6 Wettbewerbslogos, Link „Alle ansehen" → öffnet die Vitrine (Punkt 6); **NICHT AUFGESTELLT** `1/3` mit Segmenten + i-Tooltip (Punkt 10).
6. **Trophäen-Vitrine (Popup):** Öffnet über „Alle ansehen". Realistischer Schrank (`assets/vitrine/schrank.png`), **max. 3 Trophäen pro Regalreihe**, exakt auf den Regalböden stehend, danach **seitenweises Blättern** (‹ 1/2 ›). Nur die Trophäe im Schrank sichtbar; **Hover-Tooltip** zeigt Wettbewerbslogo, je Verein Wappen + Saison (`#1, #3`) und Anzahl (ein Wettbewerb kann mit mehreren Vereinen gewonnen sein). → Fertiger Code in `replit_ready/timeline_trophies.html`.
7. **Avatar-Bearbeitung:** Stift-Button (cyan, unten rechts) öffnet Upload; Reset-Button (✕) stellt Standard-Avatar wieder her. **Trainer-Typ wird ebenfalls hier im Profil geändert** (Stift am Badge), nicht in den Einstellungen.
8. **Grid unten:** Reihe „Badges & Auszeichnungen" (links groß) mit **„Trainer-Titel"**: direkt wählbare Typen + freischaltbare Titel (z. B. Auszeichnung „Pokalheld" schaltet Titel „Pokaljäger" frei); jede Titel-Kachel zeigt „x % der Manager haben diesen Titel"; freigeschaltete Titel farblich abgesetzt. Daneben eigene Kachel **„Badges"**. **Rekordbuch** rechts kompakt in Statistik-Spaltenbreite (~300 px).
9. **Interaktive Europa-Karte** unverändert übernehmen (bestehende Auto-Zoom-Logik + `CITY_MAP_PCT` aus `game/views.py`), Marker-Klick zusätzlich mit Statistik-Auswahl verknüpft. Dummy-Station **FC Porto** (Saison #1) ist in der Referenz enthalten; Koordinaten später durch echte Stadion-Koordinaten ersetzen.
10. **„Nicht aufgestellt"-System (3 Stufen, je mit Nachricht an den Manager):**
    - Stufe 1 — jedes verpasste Spiel: bestehender Stärkemalus + Hinweis auf Zählerstand.
    - Stufe 2 — 2 in Folge **oder** 3 in der Saison: **Transfersperre**, bis wieder selbst aufgestellt wurde (letzte Warnung).
    - Stufe 3 — 3 in Folge **oder** 5 in der Saison: **Verein verloren** + Timeline-Eintrag „Entlassung".
    - KPI-Zelle zeigt beide Zähler („2/5 SAISON · 1/3 FOLGE"); im Urlaubsmodus laufen beide nicht weiter; bei Saisonwechsel beide auf 0. Stufen-Details im i-Hover-Tooltip.
11. **Tab „Sicherheit & Einstellungen"** (Frame 1d): Kontodaten (E-Mail verifiziert-Chip, Land/Lieblingsverein-Selects, **Wohnort editierbar**, KEIN Trainer-Typ hier), Konto verwalten, Passwort ändern (grüne Checkliste), Sichtbarkeit & Privatsphäre (10 Toggles), plus **Urlaubsmodus**: einschaltbar mit Kalender-Auswahl — max. **14 Tage am Stück, 1× pro Saison**, alternativ **2 Blöcke à 5 Tage**, **nicht rückwirkend**; pausiert die „Nicht aufgestellt"-Zähler.
12. **Tab „Mannschaftsfotos"** (Frame 2b, zwischen Profil und Einstellungen): Saisonale Momentaufnahme des 1. Kaders vor Stadion-Hintergrund.
    - Stage: `assets/mannschaftsfoto/stadion-leer.png`; Ränge/Bande werden in Vereinsfarben eingefärbt (weiche Farbmaske, Videowand ausgenommen); Bande (`bande-leer.png`) trägt Wappen + Vereinsname (kein „MatchEngine"); Gras-Streifen vor der Bande.
    - Aufstellung: 18–**60** Spieler, Reihe 1 sitzend, dahinter stehend, Reihen nach hinten gestaffelt/kleiner; Torhüter (HP = TW) generisch im TW-Look, nur Gesicht/Hautfarbe individuell, außen platziert.
    - Spieler-Renders: **einmal pro Saison** (Stichtag) via **Gemini API** (`gemini-2.5-flash-image`): Referenzbild 1 = Pose-Render (`render-stehend-pose.png` / `render-sitzend-pose.png`, Kit des Vereins), Referenzbild 2 = Cutout-Kopf des Spielers; Ergebnis weiß freistellen + auf Inhalt zuschneiden (Canvas, Schwelle min(R,G,B) > 242), dann als PNG cachen. Prompt-Wortlaut in der Referenz-Logikklasse (`RenderPilot`-Abschnitt im README).
    - Toggle „Trophäen": am Saisonende gewonnene Pokale vor der Bande präsentieren — Titel 1 links vom Wappen, Titel 2 rechts vom Schriftzug, Titel 3/4 weiter außen, abwechselnd.
    - Pro Saison gespeichert und im Profil abrufbar (Saison-Auswahl `#1, #2 …`).

Halte dich strikt an die Werte aus `README.md` und der Referenz. **Abnahme-Checkliste:** Timeline-Filter & Saison-Zoom · Antrags-Flow (einreichen → übernehmen → erscheint) · Vereins-/ALLE-Umschalter (Leiste, Karte, Statistik synchron) · Vitrine (3 pro Reihe, Paging, Hover-Tooltip, Mehrvereins-Wettbewerb) · Nicht-aufgestellt-Zähler inkl. Urlaubspause · Urlaubsmodus-Regeln (14 Tage/1×, 2×5 Tage, nicht rückwirkend) · Mannschaftsfoto mit 18 und mit 60 Spielern · Saison-Notation überall `#n`. Vergleiche jeden Screen mit `standalone/Managerprofil_standalone.html` — Abweichung = Fehler.
