# Gesprächsverlauf & Entscheidungen — Kalender-Screen

Kurzprotokoll der Design-Session, damit ein neuer Chat/Agent nahtlos weiterarbeiten kann.

## Ausgangslage

Wunsch: Kalender-Bereich für Websoccer. Oben der bestehende "normale" Kalender mit den
nächsten Tagen, darunter umschaltbar **Jahr / Monat / Woche**. Jede Saison eigene Farbe,
damit Unterschiede sichtbar sind. Spieltage markiert, im Detail gegen wen / wann / wo.
Monatsbilder passend zur echten Jahreszeit und mit Fußball-Bezug.

## Entscheidungen

| Thema | Entscheidung |
| --- | --- |
| Saisonfarben | Saison **#0** Cyan `#22e6ff`, Saison **#1** Grün `#30f29c`; als Tweaks änderbar |
| Saison #1 | Kein eigenes Zeitfenster vorhanden → Termine aus Saison #0 +364 Tage, überall **gestrichelt** = Prognose |
| Saisonende | Letzter Spieltag laut Terminplan (34. Spieltag) |
| Benennung | Konsequent "Saison #0" / "Saison #1", nicht "Saisonjahr 2026/27" |
| Ansichten | Jahr (12 Monatskarten), Monat (großes Gitter), Woche (7 Spalten) in **einem** Panel |
| Monatsbilder | 12 gelieferte Bilder, Januar oben links → Dezember unten rechts, als Kachel-Hintergrund; Tönung pro Jahreszeit |
| Wettbewerbe | Immer mit Logo (Bundesliga / DFB-Pokal / Champions League) in Streifen, Monat, Woche, Detail und "Nächste Termine" |
| Wording | "WO" → **"ORT"** |
| Kopf-Streifen | Vom Nutzer im Editor entfernt — der Screen beginnt direkt mit dem Saisonplaner-Panel |
| Monatskarten-Fußzeile | Vom Nutzer geleert (kein "X Spiele" / "Saisonpause" mehr) |
| Wetter/U21 | Waren im Kopf-Streifen (Tile-Badge + U21-Mark, wie `weather_icon.html`); mit dem Streifen entfallen |

## Iterationen

1. Erste Fassung: Streifen + Saisonplaner mit Jahr/Monat/Woche, Zeitachse, Detailpanel,
   "Nächste Termine". Farben und Prognose-Logik etabliert.
2. Wochenansicht war zu eng → Wappen über den Vereinsnamen gesetzt, Kurznamen
   ("B. M'gladbach", "E. Frankfurt"), kürzere Status-Pills ("Bereit", "Offen", "Prognose").
3. Kopf-Streifen vervollständigt: Wetter-Badge (Icon + Temperatur, jahreszeit-plausibel,
   nur bis heute+7, vergangene Tage gedimmt) und grüner U21-Mark.
4. Wettbewerbslogos überall ergänzt, "WO" → "ORT".
5. Design-System-Bundle eingebunden, Komponenten (Panel, Tabs, Tag, Button, IconButton,
   Crest) statt handgebauter Elemente; Tokens via `var(--*)`.
6. 12 Monatsbilder aus dem gelieferten 4×3-Raster geschnitten und eingesetzt; Tönung
   entschärft, damit die Motive sichtbar bleiben.
7. Kopf-Streifen und Monatskarten-Fußzeile per Editor-Edit entfernt.
8. Benennung auf "Saison #0 / #1" umgestellt.

## Offene Punkte / Vorschläge (nicht gebaut)

- U21/Jugend-Spiele als zweite Spur im Kalender
- Sperren und Verletzungs-Rückkehr als eigene Marker
- Transfer-/Vertrags-Stichtage (Deadlines aus `game/transfer_v2/calendar_dates.py`)
- Länderspielpausen sichtbar machen
- Trainingslager / Freundschaftsspiele selbst ansetzen
- Wetterprognose im Tagesdetail, iCal-Export, "Aufstellung fehlt"-Warnung X Tage vorher
- Echtes Zeitfenster für Saison #1, sobald der Terminplan steht

## Datenquellen im Repo

`game/static/game/css/global-dashboard/header.css`,
`game/templates/game/partials/game_header.html`,
`game/templates/game/partials/weather_icon.html` + `weather_icon_svg.html`,
`game/context_processors.py`, `game/transfer_v2/calendar_dates.py`,
`.agents/memory/global-calendar-architecture.md`,
Assets: `game/static/game/images/{crests,competitions,stadiums/germany,backgrounds}`.
