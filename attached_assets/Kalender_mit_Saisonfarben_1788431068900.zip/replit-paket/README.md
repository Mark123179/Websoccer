# Replit-Paket — Websoccer Kalender

| Datei | Zweck |
| --- | --- |
| `kalender-standalone.html` | Design-Referenz, komplett offline lauffähig (Bilder, Fonts, Design-System inline). Im Browser öffnen. |
| `PROMPT.md` | Fertiger Prompt für den Replit-Agenten — Auftrag, Regeln, Abnahmekriterien. |
| `GESPRAECHSVERLAUF.md` | Entscheidungen, Iterationen und offene Punkte der Design-Session. |
| `quelle/Kalender.dc.html` | Design-Quelle inkl. Logik (Spielplan-Generierung, Saisonfenster, Jahreszeiten). |
| `assets/monate/` | Die 12 Monatsbilder (Januar → Dezember) für `game/static/game/images/monate/`. |

## Vorgehen in Replit

1. `kalender-standalone.html` öffnen und durch Jahr / Monat / Woche klicken.
2. `assets/monate/` nach `game/static/game/images/monate/` kopieren.
3. `PROMPT.md` in den Replit-Agenten geben, `kalender-standalone.html` und
   `quelle/Kalender.dc.html` als Referenz mit anhängen.
4. Ergebnis gegen die Abnahmekriterien am Ende von `PROMPT.md` prüfen.

Die Referenz nutzt Mock-Spielpläne (34 Liga-Spieltage, 6 Pokalrunden, 12 CL-Termine,
10 Gegner-Wappen). Für die Integration nur die Datenquelle tauschen — Feldnamen siehe
`plan()` in `quelle/Kalender.dc.html`.
