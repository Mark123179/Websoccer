# PROMPT für Replit / Coding-Agent — Websoccer Kalender-Screen

Kopiere diesen Prompt in Replit (Agent/Assistant). Die Referenz liegt daneben:
`kalender-standalone.html` (offline lauffähiges Design, im Browser öffnen) und
`quelle/Kalender.dc.html` (Design-Quelle mit Logik).

---

## Auftrag

Baue den **Kalender-Screen** des Websoccer-Managers (Django, deutschsprachig) exakt nach
der Design-Referenz `kalender-standalone.html`. Umsetzung als **Django-Template + CSS**
(kein React, kein Build-Step) im bestehenden Projekt `Mark123179/Websoccer`.

Zielauflösung 1440×900, Desktop-first, feste 232px-Sidebar bleibt unangetastet.

## Was gebaut wird

Ein Screen mit drei umschaltbaren Ansichten in **einem** Glass-Panel:

1. **Jahr** — 12 Monatskarten (4×3 Grid). Jede Karte: Monatsbild als Hintergrund
   (`assets/monate/NN-monat.png`), Monatsname + Jahr, Jahreszeit-Chip, Saison-Chip
   (`#0` / `#1`), darunter ein Mini-Monatsgitter mit 26px-Tageskacheln. Spieltage sind
   farbig gefüllt, Klick wählt den Tag.
2. **Monat** — großer Monatskopf (150px Bild) + 7-Spalten-Gitter mit 92px-Zellen.
   Spieltag-Zellen zeigen Wappen, Kürzel, H/A-Pill, Anstoßzeit + Wettbewerbslogo und
   einen Status ("Aufstellung ok" / "Aufstellung offen" / "Prognose" / "abgeschlossen").
3. **Woche** — 7 Spalten à ~250px: Wettbewerbslogo + Name, Wappen über Vereinsnamen,
   Anstoßzeit groß, Stadion, Status-Pill. Spielfreie Tage zeigen "Spielfrei · Training",
   "Winterpause" bzw. "Saisonpause".

Dazu, ansichtsübergreifend:

- **Kopfzeile**: Label "Kalender", Bereichstitel (`Saison #0` / Monat+Jahr / Wochenspanne),
  Untertitel mit Saisonfenster-Daten.
- **Steuerung rechts**: Tabs (Jahr/Monat/Woche), drei Filter-Tags (LIGA / POKAL / EUROPA,
  togglebar), ‹ › Schrittnavigation, Button "HEUTE".
- **Saison-Zeitachse**: 8px-Balken über beide Saisonfenster, Saison #0 durchgezogen,
  Saison #1 diagonal gestreift (= Prognose), weißer Heute-Marker, Legende darunter.
- **Rechte Spalte (320px, sticky)**: Detailkarte zum gewählten Tag (Stadionbild,
  Wettbewerbs-Chip mit Logo, Wappen, Gegner, Zeilen WANN / **ORT** / WETTBEWERB /
  STATUS bzw. ERGEBNIS, drei Aktions-Buttons) und darunter "NÄCHSTE TERMINE"
  (5 Einträge: Saison-Punkt, Wappen, Wettbewerbslogo, Gegner, Datum/Zeit/H-A, "in Xd").

## Fachliche Regeln (wichtig)

- **Saisonfarben**: Saison #0 = Cyan `#22e6ff`, Saison #1 = Grün `#30f29c`. Jede Saison
  bekommt ihre Farbe in Kacheln, Rändern, Chips, Zeitachse und Punkten.
- **Saison #1 hat noch kein eigenes Zeitfenster** → Termine werden vorläufig aus Saison #0
  übernommen (+364 Tage) und **überall gestrichelt** dargestellt, Status "Prognose".
  Sobald ein echter Terminplan existiert, nur die Datenquelle tauschen — die Darstellung
  bleibt.
- **Saisonende** = letzter Spieltag laut Terminplan (34. Spieltag).
- **Wettbewerbe** immer mit Logo: `bundesliga.png`, `dfb-pokal.png`, `champions-league.png`.
- **Jahreszeiten**: Dez–Feb Winter, Mär–Mai Frühling, Jun–Aug Sommer, Sep–Nov Herbst.
  Jede Jahreszeit hat eine eigene Farb-Tönung über dem Monatsbild und eine Chip-Farbe.
- Wappen kommen aus `game/static/game/images/crests/<fm_inside_id>.png`,
  Stadionbilder aus `game/static/game/images/stadiums/germany/`.

## Design-System (bindend)

Websoccer "MatchEngine": Stadion-Dunkel `#03070c`–`#07111a`, Glass-Panels
`rgba(9,23,34,.82)` mit 1px Cyan-Hairline `rgba(34,230,255,.18)` und weichem 70px-Schatten.
Cyan = funktionales Licht (Rahmen, Fokus, Werte), Grün = Sport-positiv, Gelb `#ffd166` =
Achtung/Prognose, Rot `#ff5570` = fehlende Aufstellung. Inter, Standardgewicht 700,
Headlines/Werte 900. Micro-Labels 12px/900/uppercase/+0.7px. Radius 8px überall,
999px nur für Pills, 4px für Kalenderkacheln. Keine Karte in einer Karte.
Alle Werte als `var(--*)`-Tokens aus `game/static/game/css/` verwenden, nichts neu erfinden.

## Datenanbindung

Aus dem bestehenden Modell (`SeasonFixture` o. ä.) pro Spiel: Datum, Anstoßzeit,
Wettbewerb, Runde/Spieltag, Gegner-ID, Heim/Auswärts, Stadion, Ergebnis (falls gespielt),
Aufstellung-gespeichert-Flag, Saison-Nummer. Die Referenz nutzt Mock-Daten mit genau
dieser Struktur — Feldnamen siehe `plan()` in `quelle/Kalender.dc.html`.

## Abnahmekriterien

- Jahr/Monat/Woche umschaltbar ohne Reload, Auswahl bleibt beim Wechsel erhalten.
- Filter LIGA/POKAL/EUROPA wirken in allen drei Ansichten.
- "HEUTE" springt auf den aktuellen Tag und setzt die Auswahl auf das nächste Spiel.
- Saison #1 ist visuell klar als Prognose erkennbar (gestrichelt + Chip).
- Kein horizontales Scrollen bei 1440px Breite.
- Deutsche Copy, keine Emoji in Datenbereichen.
