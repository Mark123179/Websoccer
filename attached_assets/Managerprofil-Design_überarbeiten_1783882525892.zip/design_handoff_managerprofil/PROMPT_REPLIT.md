# Prompt für den Replit-Agenten (Copy & Paste)

Setze das beiliegende Redesign des **Managerprofils** in unserem bestehenden Django-Projekt (Websoccer) um.

**Kontext & Regeln**
- Ziel-Dateien: `game/templates/game/manager_profile.html`, `game/static/game/css/manager-profile.css`, `game/views.py` (+ Migrationen). Plain Django-Templates + CSS + Vanilla-JS — kein React, kein Build-Step.
- Die Datei `design_reference/Managerprofil.dc.html` ist die **Design-Referenz** (kein Produktionscode): Maßgeblich ist der Frame mit `data-screen-label="2a FM Broadcast v2 — Managerprofil"` (Profil-Tab) und der Frame `1d` (Sicherheit & Einstellungen). Frames 1a–1c ignorieren. Alle Farben/Größen/Copy exakt aus den Inline-Styles übernehmen; Details stehen in `README.md`.
- Design-Tokens (`--panel`, `--line`, `#22e6ff`, `#30f29c`, `#ffd166`, `#ff5570`, Inter, Radius 8px) wie im Projekt üblich verwenden.

**Umzusetzen**
1. **Karriere-Timeline im FM-Stil** über Stadionfoto: Events proportional zum Datum auf einer horizontalen Achse, Karten abwechselnd über/unter der Achse mit Kategorie-Icon-Chip, Datum, Titel, Beschreibung, Vereinswappen; Verbindungsstiel + Glow-Punkt. Filter-Chips ALLE/VEREIN/TITEL/FINALE/JUGEND/STATUS (kein Transfers-Filter). Klick auf Saison-Label = Zoom auf die Saison (Monats-Ticks, Reset-Chip). HEUTE-Marker + HEUTE-Button. **Fester Farbcode** (mit Legende im Karten-Footer): Gold = Titel/Historie, Cyan = Verein/Liga, Grün = Jugend/aktuelles Amt, Rot = Finale verloren/Entlassung. Kartenstil: Vollfarb-Verlauf („solid") mit dunklem Text.
2. **Timeline-Einträge & Anträge:** Neues Modell `TimelineEvent` + `TimelineEventRequest`. Jeder Spieler hat den Button „EINTRAG EINREICHEN" (Formular: Datum, Kategorie, betroffener Verein — nur eigene Karrierestationen —, Titel, Beschreibung) → erzeugt Antrag. Admins (`is_staff`) sehen zusätzlich „ANTRÄGE" (mit Zähler, ÜBERNEHMEN/ABLEHNEN) und „+ EREIGNIS" (manuelles Hinzufügen, gleiches Formular). Übernommene/manuelle Einträge erscheinen sofort in der Timeline.
3. **Vereins-Leiste mit Umschalter:** Vereinsname öffnet Dropdown aller Karrierestationen (skaliert für beliebig viele Vereine); Auswahl aktualisiert die 6 Kennzahlen der Leiste **und** die Statistik-Karte. Karten-Marker-Klick wählt den Verein ebenfalls.
4. **Statistik-Karte:** Titel „STATISTIK · <Verein>", genau **ein** Toggle-Button „ALLE" für die Gesamtkarriere (aggregierte Werte serverseitig, deutsches Zahlenformat).
5. **KPI-Leiste v2** im Header: 9 Zellen mit Icons und Mikro-Visuals (XP-Bar, Highscore-Trend, 3 Mini-Trophäenlogos, gestapelter S/U/N-Balken bei Siegquote, Segmente bei „Nicht aufgestellt", grüner Check bei Transfersperre) — Details im README.
6. **Avatar-Bearbeitung:** Stift-Button (cyan, unten rechts am Avatar) öffnet den bestehenden Upload-Flow; kleiner Reset-Button (✕) stellt den Standard-Avatar wieder her.
7. **Grid-Anpassung unten:** Badges & Auszeichnungen links groß (zweispaltig, erweiterbar), Rekordbuch rechts kompakt in Statistik-Spaltenbreite (~300px).
8. **Interaktive Europa-Karte unverändert übernehmen** (bestehende Auto-Zoom-Logik + `CITY_MAP_PCT` aus `game/views.py` weiterverwenden), nur Marker-Klick zusätzlich mit der Statistik-Auswahl verknüpfen.
9. **Tab „Sicherheit & Einstellungen"** gemäß Frame 1d: Kontodaten (mit Selects), Konto verwalten, Passwort ändern (mit grüner Checkliste), Sichtbarkeit & Privatsphäre (10 Toggles „Für alle"/„Nur ich").

Arbeite die Punkte in dieser Reihenfolge ab, halte dich strikt an die Werte aus `README.md` und der Referenzdatei, und teste Timeline-Filter, Saison-Zoom, Antrags-Flow (einreichen → übernehmen → erscheint in Timeline) sowie den Vereins-/ALLE-Umschalter.
