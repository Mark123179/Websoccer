# Handoff: Managerprofil-Redesign (Websoccer / MatchEngine)

## Overview
Redesign der Seite **Managerprofil** (`/manager/profil`) für Websoccer: FM-Style-Karriere-Timeline mit festem Farbcode, Admin-Workflow für Timeline-Einträge (Anträge von Managern + manuelles Hinzufügen), Vereins-Umschalter der die Statistik steuert, aufgewertete KPI-Leiste, Avatar-Bearbeitung sowie der Tab „Sicherheit & Einstellungen".

## Über die Design-Dateien
Die Datei `design_reference/Managerprofil.dc.html` ist eine **Design-Referenz aus einem Design-Tool** (HTML-Prototyp) — sie zeigt Aussehen und Verhalten, ist aber **kein Produktionscode**. Aufgabe: das Design **im bestehenden Django-Projekt nachbauen** — in `game/templates/game/manager_profile.html`, `game/static/game/css/manager-profile.css` und `game/views.py` (plain HTML/CSS/JS, kein React, kein Build-Step). Maßgeblich ist der Frame **„2a FM Broadcast v2"** (Profil-Tab) und **„1d"** (Einstellungen-Tab); die Frames 1a–1c sind verworfene Varianten.

## Fidelity
**High-fidelity.** Farben, Typografie, Abstände, Radien und Copy sind final und pixelgenau umzusetzen. Alle Werte unten sind exakt.

---

## Design Tokens (bereits im Projekt vorhanden — `:root` aus dem Design-System)
- Flächen: `--app-bg #03070c` · `--stadium-bg #07111a` · `--panel rgba(9,23,34,.82)` · `--panel-strong rgba(12,31,45,.94)`
- Cyan (funktionales Licht): `--cyan #22e6ff` · Hairline `--line rgba(44,231,255,.18)` · aktiv `--line-strong rgba(44,231,255,.38)`
- Signale: Grün `#30f29c` (positiv/aktuell) · Gelb/Gold `#ffd166` · Rot `#ff5570` · Orange-Badge-Gradient `#ff9f1c→#d85d00`
- Text: `#f4fbff` · `--muted rgba(244,251,255,.64)` · `--faint rgba(244,251,255,.38)` · Dunkeltext auf Farbflächen `#061018`
- Schrift: nur **Inter**; Micro-Labels 8,5–9px/900/uppercase/+0,7–1px Tracking; Werte 14–21px/900
- Radius **8px** überall (Pills 999px) · Kartenabstand **16px** · Seitenpadding **44px** · Artboard **1440px**

## FESTER FARBCODE der Timeline (überall einheitlich, inkl. Legende)
| Farbe | Kategorien |
|---|---|
| Gold `#ffd166` | TITEL, HISTORIE |
| Cyan `#22e6ff` | VEREIN (Amtsantritt), LIGA (Tabellen-Meilensteine) |
| Grün `#30f29c` | JUGEND, aktuelles Amt |
| Rot `#ff5570` | FINALE (verloren), STATUS/ENTLASSUNG |

Die Farbe steuert: Kartenfüllung, Rahmen, Icon-Chip, Kategorie-Label, Punkt auf der Achse. **Default-Kartenstil „solid"**: Vollfarb-Verlauf (z. B. Gold `linear-gradient(165deg,#ffd166,#e0a034)`) mit dunklem Text `#061018` (bei Rot: weißer Text). Alternativer Stil „glass" (getöntes Glas + farbige Hairline) ist als Option dokumentiert im Prototyp (`timelineFill`).

---

## Screens / Views

### 1) Profil-Tab (Frame „2a")
Reihenfolge von oben: Header → Tabs → Karriere-Timeline → Vereins-Leiste → Grid Reihe 1 (Trophäen+Login | Karte | Statistik) → Grid Reihe 2 (Badges | Rekordbuch).

#### Header (Grid `352px 1fr`, gap 16)
- **Identitätspanel** (`--panel-strong`, 1px `--line`, Radius 8, Padding 16): Avatar 88×88 (Radius 8, Rand `--line-strong`, Glow `0 0 18px rgba(34,230,255,.25)`), darunter Vereinswappen 40px mit Cyan-Dropshadow. Name 20px/900, Flagge (18×12) + Land 11px/700, Badge-Pill „TAKTIKFUCHS" (Cyan-Pill 9px/900), Vereinsblock (Name 12px/800, „Seit …", „Mitglied seit: …" 10px/700 faint).
- **Avatar-Bearbeitung:** Stift-Button 24px, runde Cyan-Fläche (`linear-gradient(180deg,#19c8e0,#12a7c4)`, Icon dunkel), Position unten-rechts am Avatar (−7px überlappend); Reset-Button 20px unten-links (dunkle Fläche, rotes ✕, Border `rgba(255,85,112,.5)`). Klick öffnet File-Upload (bestehende Endpoints `mpAvatarEditBtn`/Upload-Logik wiederverwenden).
- **KPI-Leiste v2** (Grid `1.2fr 1fr 1fr .9fr 1.15fr 1fr .95fr 1.05fr .95fr`, Zellen: Padding 14px 12px, Trenner `border-left: 1px --line`, Hover-Wash `rgba(34,230,255,.04)`). Jede Zelle: Label-Zeile mit 11px-Stroke-Icon (Cyan 75 %) + Micro-Label; großer Wert; Mikro-Visual:
  1. MANAGERLEVEL: Level-Chip 32px (Cyan-Box „7") + „NÄCHSTES LEVEL: 8" + XP-Bar 5px (62 %, Cyan-Gradient + Glow) + „9.300 / 15.000 XP"
  2. HIGHSCORE: `12.480` 21px/900 Gold + Trend „↑ +320 diese Woche" (grün, 9px) + „Platz 214 von 18.402"
  3. TROPHÄEN: `3` Cyan + 3 Mini-Wettbewerbslogos 18px + Link „Alle ansehen"
  4. SPIELE GESAMT: `119` + „seit Aug. 2023"
  5. SIEGQUOTE: `55 %` grün + **gestapelter Balken** 5px (55 % grün / 20 % weiß 30 % / 25 % rot) + „65 S · 24 U · 30 N"
  6. NICHT AUFGESTELLT: `1/3` + 3 Segmente 14×5px (1 gelb gefüllt) + „ab 3: Transfersperre"
  7. TRANSFERSPERRE: grüner Check + „Keine" + „Konto in gutem Stand"
  8. LETZTE ANMELDUNG: `11.07.2026` / „17:29 Uhr"
  9. REGISTRIERT AM: `02.06.2026` + „Gründungsmitglied"

#### Tabs
„PROFIL" (aktiv: Cyan, 2px Unterstrich) · „SICHERHEIT & EINSTELLUNGEN" (faint) — 11px/900, +0,9px, mit 14px-Stroke-Icons.

#### Karriere-Timeline (Herzstück)
Container: Radius 8, Rand `rgba(44,231,255,.28)`, Hintergrund = Stadionfoto (`fc-bayern-stadium.jpg`, center 32 %/cover) unter `linear-gradient(180deg, rgba(3,7,12,.72), rgba(3,7,12,.88))`.

**Kopfzeile** (Padding 13px 16px, Trennlinie unten): Titel „KARRIERE TIMELINE" 13px/900 +1,1px · Filter-Chips `ALLE · VEREIN · TITEL · FINALE · JUGEND · STATUS` (9px/900, Radius 6; aktiv: Cyan-Füllung `rgba(34,230,255,.16)` + Rand `.55`) — **kein TRANSFERS-Filter**. Rechts: Button „EINTRAG EINREICHEN" (grüner Ghost, für alle Spieler) · orangefarbener Tag „ADMIN" · „ANTRÄGE" mit orangem Zähler-Pill (nur Admins/`is_staff`) · „+ EREIGNIS" (Cyan-Ghost, nur Admins) · Nav ‹ › · „HEUTE"-Button (Cyan).

**Zeitachsen-Engine** (JS):
- Horizontale Achse in vertikaler Mitte; Karten **proportional zum Datum** positioniert: `x = padL + (t − t0)/(t1 − t0) · (baseW − padL − padR)` mit `padL 56`, `padR 96`, `baseW 2900` (Track horizontal scrollbar, Höhe 352px).
- Karten **abwechselnd über/unter** der Achse (chronologischer Index gerade = oben). Anti-Kollision je Spur: `x = max(x, prevX + Kartenbreite 234 + 16)`; Track wächst bei Bedarf.
- Verbindung: 2px-Stiel (Farbton, 55 % Opazität, 20px) + 9px-Glow-Punkt auf der Achse (Position `x+26`).
- **Saison-Zoom:** Klick auf Saison-Label (2023/24 · 2024/25 · 2025/26, unten zentriert je Saisonmitte) zoomt auf die Saison (`baseW 1256`, Monats-Ticks Jul–Jun); goldener Reset-Chip „SAISON 2024/25 ✕" in der Kopfzeile.
- **HEUTE-Marker:** gestrichelte vertikale Linie + Cyan-Pill „HEUTE" (dunkler Text, Glow) an Datumsposition; „HEUTE"-Button scrollt ans Ende.
- Optional „kompakt"-Modus (gleichmäßige Abstände 127px statt Zeitproportion — im Prototyp als Tweak `timelineDichte`).

**Event-Karte** (234px breit, Radius 8, Padding 10px 12px 12px): Kopfzeile = Icon-Chip 20px (Kategorie-Icon, 11–12px SVG) + Kategorie-Label 9px/900/+1px + Datum rechts 9,5px/700; Titel 13px/900; Beschreibung 10,5px/600 (rechts 40px frei); Vereinswappen 30px unten-rechts. Icons: Pokal (fill) für Titel/Historie, Person (stroke) für Verein, Sprössling (stroke) für Jugend, Warndreieck (stroke) für Status/Liga, Cup (fill) für Finale.

**Legende (Footer der Timeline-Karte):** „FARBCODE" + 4 Glow-Punkte mit Beschriftung (Gold Titel·Historie / Cyan Verein·Liga / Grün Jugend·Aktuelles Amt / Rot Finale verloren·Entlassung), 9px/700.

**Admin-Panel** (klappt unter der Kopfzeile auf, `rgba(3,7,12,.72)`; 3 Tabs mit Cyan-Unterstrich):
1. **ANTRÄGE VON MANAGERN** (+ Zähler): Zeilen mit Kategorie-Chip (gold), Titel + Datum, Beschreibung, „Antrag von <Manager>"; Buttons **ÜBERNEHMEN** (grün — erzeugt Timeline-Event) und **ABLEHNEN** (rot Ghost). Leerzustand: „Keine offenen Anträge — alles abgearbeitet, Chef!"
2. **MANUELL HINZUFÜGEN** (Admin): Formular `DATUM (date) · KATEGORIE (Select, mit Farbangabe: „Historie · Gold" …) · BETREFFENDER VEREIN (Select) · TITEL · BESCHREIBUNG` + Button „ZUR TIMELINE" (Cyan-Gradient, dunkler Text). Eintrag erscheint sofort.
3. **EINTRAG EINREICHEN (SPIELER)**: identisches Formular, aber **Vereins-Select nur mit Stationen des Spielers**; Button „ANTRAG SENDEN" (grün) → landet als Antrag in Tab 1 mit `from = eingeloggter Manager`.

#### Vereins-Leiste (steuert die Statistik)
`--panel`, Radius 8, Padding 12px 16px. Links: Wappen 42px (bei „Gesamte Karriere": Schild-Icon in Cyan-Box) · **Vereinsname als Dropdown-Trigger** (13px/900 + Chevron; Hover cyan) · „Zeitraum: …" 10px faint. Dropdown (300px, `rgba(8,22,40,.98)`, Rand `--line-strong`, Schatten): Überschrift „DEINE TRAINERSTATIONEN" + eine Zeile je Karrierestation (Wappen 24px, Name, Zeitraum; aktive Zeile cyan) — **skaliert für beliebig viele Stationen**. Daneben Pill-Button „VEREIN WECHSELN →". Rechts 6 Kennzahl-Zellen (Trenner-Hairlines): ZEIT ALS TRAINER · SPIELE GESAMT · TITEL GEWONNEN (gold) · FINALE VERLOREN · BESTE PLATZIERUNG · PUNKTE/SPIEL (grün) — Werte wechseln mit der Auswahl.

#### Grid Reihe 1 (`336px 684px 1fr`, gap 16)
- **Trophäensammlung** (336): 3 Slots (Logo 54px mit Gold-Glow, Zähler-Pill orange „1×", Name+Jahr 9,5px).
- **Login Belohnungen** (336, unter Trophäen): Check-Kreis grün, „+150 / +1 Bonus" gold, „Streak: 7 Tage · nächste Belohnung in 2 Tagen", Pip-Reihe 1–7 (grün, 7 aktiv cyan) + 14/30 (dim).
- **Trainerstationen · Europa** (684×372 + Kopfzeile): `europe-night.png` mit **bestehender Auto-Zoom-Logik** aus `manager_profile.html` (Bounding-Box aller Marker, Padding, Tile-Aspekt, `objectFit fill` — Code 1:1 übernehmen). Marker: Wappen 34px rund (Rand weiß 45 %, aktiv grün + Puls-Ring), Stadt-Label 8,5px/900 (über dem Marker, wenn nahe Unterkante). **Klick auf Marker = Verein auswählen** (synchronisiert Vereins-Leiste + Statistik) **und** Stations-Panel öffnen (unten überlagernd: Wappen, Verein, Stadt, Zeitraum-Chip, ✕; darunter SPIELE GESAMT cyan / TITEL GEWONNEN gold / Saison-Zeilen). Hinweis in Kopfzeile: „Marker anklicken → Statistik wechselt mit".
- **Statistik** (≈300): Titel „STATISTIK · <VEREIN|GESAMTE KARRIERE>" + **ein** Toggle-Button „ALLE" (aktiv: „✓ GESAMTE KARRIERE", Cyan-Füllung). Hinweiszeile „Verein über die Leiste oben oder die Karte wählen". 12 Zeilen (11px/700, Trenner `rgba(44,231,255,.09)`, dickerer Separator nach Gegentore): Spiele, Siege (grün), Unentschieden, Niederlagen (rot), Tore, Gegentore | Punkte (cyan), Punkte/Spiel, Tore/Spiel, Gegentore/Spiel, Siegesserie, Niederlagenserie.

#### Grid Reihe 2 (`1fr 300px`, gap 16) — **Badges links groß, Rekordbuch rechts kompakt**
- **Badges & Auszeichnungen** (1fr): innen zweispaltig (`1fr 1.2fr`): links „DIREKT WÄHLBAR" als 2-Spalten-Buttongrid (8 Typen; aktiver Typ „Taktikfuchs" cyan gefüllt + Glow); rechts „FREISCHALTBARE TITEL" als 2-Spalten-Grid von Tiles (freigeschaltet: grüner Rand + „✓ Freigeschaltet"; sonst Fortschritt `x/y` + 4px-Cyan-Progressbar).
- **Rekordbuch** (300px = Statistik-Breite): 6 kompakte Zeilen Label/Wert: Höchster Sieg (grün „6:0 · Bochum"), Höchste Niederlage (rot „0:4 · Leipzig"), Meiste Siege in Folge 9, Meiste Tore in einem Spiel 6, Teuerster Einkauf 65,0 Mio. €, Teuerster Verkauf 48,0 Mio. €.

### 2) Einstellungen-Tab (Frame „1d")
Kompakter Header (Avatar 52px, Name, „Botswana · Taktikfuchs · Borussia Mönchengladbach", grüner Pill „KONTO VERIFIZIERT"), Tabs (Einstellungen aktiv). Drei Spalten (`1fr 1fr 1fr`):
1. **Kontodaten**: Zeilen mit Cyan-Icon + Label (118px) + Wert; E-Mail mit grünem „Verifiziert"-Chip; Land/Lieblingsverein/Trainer-Typ als Select-Buttons (dunkel, Chevron). Button „SPEICHERN" (voll breit, Cyan-Gradient, dunkler Text, Glow). Darunter **Konto verwalten**: E-Mail ändern (cyan Ghost) / Konto löschen (rot Ghost) / Daten herunterladen + Sicherheits-Notiz.
2. **Passwort ändern**: 3 Passwortfelder (dunkle Inputs, Fokus: Cyan-Rand + Ring), grüne Checkliste (12 Zeichen, Groß/Klein, Zahl, keine Muster, nicht in letzten 5), Button „PASSWORT ÄNDERN", Hinweis „Nach der Änderung wirst du auf allen anderen Geräten abgemeldet."
3. **Sichtbarkeit & Privatsphäre**: Tabellenkopf FELD / ÖFFENTLICH ANZEIGEN; 10 Zeilen (Profilbild, Nickname, Trainer-Typ, Landesflagge, Lieblingsverein, E-Mail, Geburtstag, Wohnort, Registriert am, Letzte Anmeldung) mit Status-Text („Für alle" cyan / „Nur ich" faint) + **Toggle** 32×18px (an: Cyan-Gradient-Track, Knopf weiß 14px, 0,15s ease). Button „SPEICHERN".

---

## Interactions & Behavior (Zusammenfassung)
- Filter-Chips: Events per Typ ein-/ausblenden (Positionen werden neu berechnet).
- Saison-Label-Klick → Zoom; ✕-Chip → Reset; ‹/› scrollen ±680px smooth; HEUTE scrollt ans Ende.
- Marker-Klick → wählt Verein (Leiste + Statistik) + öffnet Panel; erneuter Klick/✕ schließt.
- Vereins-Dropdown → Auswahl setzt Leiste + Statistik; „ALLE"-Button toggelt Gesamtkarriere.
- Antrag ÜBERNEHMEN → Event sofort in Timeline (Kategorie→Farbe per Farbcode); ABLEHNEN → entfernt.
- „ANTRAG SENDEN" (Spieler) → neuer Antrag in Admin-Liste.
- Hover generell: Rand auf `--line-strong`, leichte Cyan-Aufhellung; Buttons Press-Nudge `translateY(1px)`; Transitions 0,15s ease. Einziger Loop: Puls-Ring des aktiven Markers (1,8s).

## State / Backend (Django-Empfehlung)
- Vorhandene Modelle nutzen: `ManagerProfile`, `ManagerCareerStation` (Stationen/Karte), `ClubTrophy`.
- **Neu:** `TimelineEvent` (manager FK, date, category [TITEL/HISTORIE/LIGA/VEREIN/FINALE/JUGEND/STATUS], title, body, club FK nullable, source [auto/admin/antrag]) und `TimelineEventRequest` (dieselben Felder + requested_by, status offen/übernommen/abgelehnt). Anträge-UI nur für `request.user.is_staff`; „Eintrag einreichen" für alle; Vereins-Select des Spielers aus dessen `ManagerCareerStation`s.
- Statistik-Endpoint/Context: Kennzahlen je Station + Aggregat „alle" (Summen; Prozentwerte serverseitig formatiert, deutsches Zahlenformat mit Komma).
- Karten-Zoom: bestehendes Skript + `CITY_MAP_PCT` aus `game/views.py` unverändert weiterverwenden.

## Assets
- Bereits im Repo: Wappen `game/static/game/images/crests/{918,915,907,908}.png`, Karte `backgrounds/europe-night.png`, Avatar, DFB-Pokal/Supercup-Logos.
- Beiliegend (ggf. ins Repo kopieren): `assets/fc-bayern-stadium.jpg` (Timeline-Hintergrund), `assets/bundesliga.png`, `assets/champions-league.png`, `assets/dfb-pokal.png`, `assets/supercup.png`.
- Flaggen: `https://flagcdn.com/w40/<code>.png` (wie bisher).

## Files
- `design_reference/Managerprofil.dc.html` — kompletter Prototyp (Frame 2a = Profil-Tab, Frame 1d = Einstellungen; 1a–1c = verworfene Varianten). Markup/Inline-Styles als exakte Referenz für Werte; die JS-Logikklasse am Dateiende enthält die Timeline-Engine, den Karten-Zoom und die Admin-Handler als Referenzimplementierung.
- `PROMPT_REPLIT.md` — fertiger Prompt für den Replit-Agenten.
