"""
batch_tactic_tests.py — Taktik-Batch-Analyse für Websoccer
===========================================================

Verwendung
----------
    python batch_tactic_tests.py [fixture.json] [n_sims] [--minutes]

    python batch_tactic_tests.py                              # 5.000 Sims
    python batch_tactic_tests.py fixture.json 10000           # 10.000 Sims
    python batch_tactic_tests.py fixture.json 10000 --minutes # Minuten-Modus
"""

import json
import sys
import time
from collections import defaultdict

from run_match import simulate_match, simulate_match_minutes
from tactic_compiler import compile_tactic, select_active_condition_plan


# ═══════════════════════════════════════════════════════════════════════════════
# Hilfsfunktionen
# ═══════════════════════════════════════════════════════════════════════════════

def _avg(values: list) -> float:
    return sum(values) / len(values) if values else 0.0


def _score_at_minute(goal_events: list, minute: int) -> tuple[int, int]:
    """Spielstand (Heim, Gast) am Ende von Minute `minute`."""
    h, a = 0, 0
    for evt in goal_events:
        if evt['minute'] <= minute:
            if evt['team'] == 'home':
                h += 1
            else:
                a += 1
    return h, a


def _was_trailing(goal_events: list) -> bool:
    """War Heim zu irgendeinem Zeitpunkt im Rückstand?"""
    h, a = 0, 0
    for evt in sorted(goal_events, key=lambda e: e['minute']):
        if evt['team'] == 'home':
            h += 1
        else:
            a += 1
            if a > h:
                return True
    return False


# ═══════════════════════════════════════════════════════════════════════════════
# Batch-Runner
# ═══════════════════════════════════════════════════════════════════════════════

def run_batch(
    home_team:   dict,
    away_team:   dict,
    home_tactic: dict | None = None,
    away_tactic: dict | None = None,
    n:           int  = 5_000,
    label:       str  = 'Basis',
    use_minutes: bool = False,
) -> dict:
    """Führt n Simulationen durch und gibt aggregierte Statistiken zurück.

    Im Minuten-Modus (use_minutes=True) werden zusätzlich erfasst:
      avg_plan_activations, plan_activation_counts,
      avg_goals_after_plan, avg_conceded_after_plan,
      leads_protected_after_80, leads_lost_after_80,
      comeback_wins, comeback_draws
    """
    sim_fn = simulate_match_minutes if use_minutes else simulate_match

    outcomes                                 = {'home': 0, 'draw': 0, 'away': 0}
    goals_home: list[int]                    = []
    goals_away: list[int]                    = []
    possessions: list[float]                 = []
    shots_home: list[float]                  = []
    shots_away: list[float]                  = []

    plan_activations_total                   = 0
    plan_activation_counts: dict[str, int]   = defaultdict(int)
    goals_after_plan: list[int]              = []
    conceded_after_plan: list[int]           = []
    leads_protected_after_80                 = 0
    leads_lost_after_80                      = 0
    comeback_wins                            = 0
    comeback_draws                           = 0

    for _ in range(n):
        r  = sim_fn(home_team, away_team, home_tactic, away_tactic)
        hg = r['home_goals']
        ag = r['away_goals']

        goals_home.append(hg)
        goals_away.append(ag)
        possessions.append(r['match_stats']['home_possession'])
        shots_home.append(r['match_stats']['home_shots'])
        shots_away.append(r['match_stats']['away_shots'])

        if hg > ag:
            outcomes['home'] += 1
        elif hg == ag:
            outcomes['draw'] += 1
        else:
            outcomes['away'] += 1

        if use_minutes:
            evts = r.get('goal_events', [])
            pl   = r.get('plan_log', [])

            # Plan-Aktivierungen zählen
            plan_activations_total += len(pl)
            for entry in pl:
                for plan_key in (entry.get('home_plan'), entry.get('away_plan')):
                    if plan_key:
                        plan_activation_counts[plan_key] += 1

            # Tore/Gegentore nach erster Plan-Aktivierung
            if pl:
                first_min = pl[0]['minute']
                goals_after_plan.append(
                    sum(1 for e in evts if e['minute'] >= first_min and e['team'] == 'home')
                )
                conceded_after_plan.append(
                    sum(1 for e in evts if e['minute'] >= first_min and e['team'] == 'away')
                )

            # Führung nach Minute 80 gehalten / verloren
            h80, a80 = _score_at_minute(evts, 80)
            if h80 > a80:
                if hg > ag:
                    leads_protected_after_80 += 1
                else:
                    leads_lost_after_80 += 1

            # Aufholjagden
            if _was_trailing(evts):
                if hg > ag:
                    comeback_wins += 1
                elif hg == ag:
                    comeback_draws += 1

    result: dict = {
        'label':          label,
        'n':              n,
        'mode':           'minutes' if use_minutes else 'single',
        'home_win_pct':   outcomes['home'] / n * 100,
        'draw_pct':       outcomes['draw'] / n * 100,
        'away_win_pct':   outcomes['away'] / n * 100,
        'avg_goals_h':    round(_avg(goals_home), 3),
        'avg_goals_a':    round(_avg(goals_away), 3),
        'avg_goals':      round(_avg([h + a for h, a in zip(goals_home, goals_away)]), 3),
        'avg_possession': round(_avg(possessions), 1),
        'avg_shots_h':    round(_avg(shots_home), 1),
        'avg_shots_a':    round(_avg(shots_away), 1),
    }

    if use_minutes:
        result.update({
            'avg_plan_activations':         round(plan_activations_total / n, 3),
            'plan_activation_counts':       dict(plan_activation_counts),
            'avg_goals_after_plan':         round(_avg(goals_after_plan), 3),
            'avg_conceded_after_plan':      round(_avg(conceded_after_plan), 3),
            'leads_protected_after_80':     leads_protected_after_80,
            'leads_protected_after_80_pct': round(leads_protected_after_80 / n * 100, 2),
            'leads_lost_after_80':          leads_lost_after_80,
            'leads_lost_after_80_pct':      round(leads_lost_after_80 / n * 100, 2),
            'comeback_wins':                comeback_wins,
            'comeback_wins_pct':            round(comeback_wins / n * 100, 2),
            'comeback_draws':               comeback_draws,
            'comeback_draws_pct':           round(comeback_draws / n * 100, 2),
        })

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# Ausgabe
# ═══════════════════════════════════════════════════════════════════════════════

def print_batch(b: dict) -> None:
    mode_tag = f' [{b["mode"]}]' if 'mode' in b else ''
    print(f'\n── {b["label"]}{mode_tag} ({b["n"]:,} Simulationen) ─────────────────')
    print(f'  Heimsieg:      {b["home_win_pct"]:>5.1f} %')
    print(f'  Unentschieden: {b["draw_pct"]:>5.1f} %')
    print(f'  Auswärtssieg:  {b["away_win_pct"]:>5.1f} %')
    print(f'  Ø Tore/Spiel:  {b["avg_goals"]:.2f}  '
          f'(Heim {b["avg_goals_h"]:.2f} | Gast {b["avg_goals_a"]:.2f})')
    print(f'  Ø Ballbesitz H:{b["avg_possession"]:.1f} %')
    print(f'  Ø Schüsse:     Heim {b["avg_shots_h"]:.1f} | Gast {b["avg_shots_a"]:.1f}')

    if b.get('mode') == 'minutes':
        avg_act = b.get('avg_plan_activations', 0.0)
        print(f'  Ø Plan-Aktiv.: {avg_act:.2f}/Spiel')
        counts = b.get('plan_activation_counts', {})
        if counts:
            for plan, cnt in sorted(counts.items(), key=lambda x: -x[1]):
                print(f'    {plan:<30} {cnt:>6}×  ({cnt / b["n"] * 100:.1f} %)')
        if avg_act > 0:
            print(f'  Ø Tore n. Plan:        {b["avg_goals_after_plan"]:.2f}')
            print(f'  Ø Gegentore n. Plan:   {b["avg_conceded_after_plan"]:.2f}')
        print(f'  Führung ≥80\' gehalten: {b["leads_protected_after_80_pct"]:.1f} %  '
              f'({b["leads_protected_after_80"]})')
        print(f'  Führung ≥80\' verloren: {b["leads_lost_after_80_pct"]:.1f} %  '
              f'({b["leads_lost_after_80"]})')
        print(f'  Aufholjagd-Siege:      {b["comeback_wins_pct"]:.1f} %  '
              f'({b["comeback_wins"]})')
        print(f'  Aufholjagd-Remis:      {b["comeback_draws_pct"]:.1f} %  '
              f'({b["comeback_draws"]})')


def print_compiler(team: dict, tactic: dict | None, label: str) -> None:
    c = compile_tactic(team, tactic)
    print(f'\n  compile_tactic() → {label}')
    print(f'    orientation:      {c["orientation"]:.1f}')
    print(f'    tempo:            {c["tempo"]:.1f}')
    print(f'    pressing_index:   {c["pressing_index"]:.3f}')
    print(f'    xg_for:           {c["xg_for"]:.3f}')
    print(f'    xg_against:       {c["xg_against"]:.3f}')
    print(f'    possession_bonus: {c["possession_bonus"]:+.3f}')
    print(f'    shot_volume:      {c["shot_volume"]:.3f}')
    print(f'    shot_quality:     {c["shot_quality"]:.3f}')
    print(f'    directness:       {c["directness"]:+.3f}')
    print(f'    risk:             {c["risk"]:+.3f}')
    print(f'    fatigue_cost:     {c["fatigue_cost"]:.3f}')
    print(f'    foul_multiplier:  {c["foul_multiplier"]:.3f}')
    print(f'    teamwork_avg:     {c["teamwork_avg"]}')
    print(f'    teamwork_factor:  {c["teamwork_factor"]:.4f}')
    print(f'    complexity:       {c["complexity"]:.1f}')
    print(f'    coherence:        {c["coherence"]:.4f}')
    lm = c['line_multipliers']
    print(f'    line_multipliers: def={lm["defense"]:.3f} '
          f'mid={lm["midfield"]:.3f} '
          f'atk={lm["attack"]:.3f} '
          f'overall={lm["overall"]:.4f}')
    zw = c['zone_weights']
    print(f'    zone_weights:     L={zw["left"]:.2f} '
          f'C={zw["center"]:.2f} '
          f'R={zw["right"]:.2f}')


# ═══════════════════════════════════════════════════════════════════════════════
# Taktik-Varianten
# ═══════════════════════════════════════════════════════════════════════════════

def build_variants(base: dict) -> list[tuple[str, dict]]:
    """Klassische Taktik-Varianten (Single + Minutes)."""
    return [
        ('Basis (Ist-Taktik)', base),
        ('Hohes Pressing (alle Linien)', {
            **base,
            'pressing': {'defense': 'hoch', 'midfield': 'hoch', 'attack': 'hoch'},
        }),
        ('Passives Pressing', {
            **base,
            'pressing': {'defense': 'passiv', 'midfield': 'passiv', 'attack': 'passiv'},
        }),
        ('Angriffsfokus: Durch die Mitte',   {**base, 'attack_focus': 'durch_mitte'}),
        ('Angriffsfokus: Flügelspiel',        {**base, 'attack_focus': 'fluegelspiel'}),
        ('Spieltempo 90 (sehr schnell)',      {**base, 'buildup': {**base.get('buildup', {}), 'tempo': 90}}),
        ('Spieltempo 10 (sehr langsam)',      {**base, 'buildup': {**base.get('buildup', {}), 'tempo': 10}}),
        ('Triggerpressing: Ballverlust',      {**base, 'pressing_triggers': {**base.get('pressing_triggers', {}), 'ballverlust': True}}),
        ('Schlussangriff-Modus (Plan-Override)', {**base, '_active_plan': 'schlussangriff'}),
        ('Defensiv: Kompakt sichern (Plan)',     {**base, '_active_plan': 'kompakt_sichern'}),
    ]


def build_condition_variants(base: dict) -> list[tuple[str, dict]]:
    """5 Bedingungsvarianten — nur sinnvoll im Minuten-Modus."""
    base_clean = {**base, 'conditions': []}

    return [
        # 1. Keine Bedingungen — reines Referenzsignal
        ('baseline_no_conditions', base_clean),

        # 2. Nur Zeitspiel bei Führung ab Min 75
        ('conditions_time_wasting_only', {
            **base_clean,
            'conditions': [
                {'active': True, 'minute': 75, 'condition': 'fuehrung', 'plan': 'zeitspiel'},
            ],
        }),

        # 3. Aggressiv bei Rückstand ab Min 60
        ('conditions_aggressive_when_behind', {
            **base_clean,
            'conditions': [
                {'active': True, 'minute': 60, 'condition': 'rueckstand', 'plan': 'aggressiv_risiko'},
            ],
        }),

        # 4. Schlussangriff bei Rückstand ab Min 80 (+ Rückstand ≥2 ab Min 85)
        ('conditions_late_final_push', {
            **base_clean,
            'conditions': [
                {'active': True, 'minute': 80, 'condition': 'rueckstand',   'plan': 'schlussangriff'},
                {'active': True, 'minute': 85, 'condition': 'rueckstand_2', 'plan': 'schlussangriff'},
            ],
        }),

        # 5. Vollständiger Matchplan: alle 4 Bedingungen aktiv
        ('conditions_full_matchplan', {
            **base_clean,
            'conditions': [
                {'active': True, 'minute': 60, 'condition': 'rueckstand',   'plan': 'aggressiv_risiko'},
                {'active': True, 'minute': 75, 'condition': 'fuehrung',     'plan': 'zeitspiel'},
                {'active': True, 'minute': 80, 'condition': 'rueckstand',   'plan': 'schlussangriff'},
                {'active': True, 'minute': 85, 'condition': 'rueckstand_2', 'plan': 'schlussangriff'},
            ],
        }),
    ]


# ═══════════════════════════════════════════════════════════════════════════════
# Statischer Bedingungstest
# ═══════════════════════════════════════════════════════════════════════════════

def test_conditions(tactic: dict) -> None:
    print('\n── Bedingungen / Matchpläne (statisch) ─────────────────────────')
    scenarios = [
        (60, 0, 1, True,  0, 0, 'Min 60, Rückstand 0:1 (Heim)'),
        (75, 1, 1, True,  0, 0, 'Min 75, Unentschieden 1:1 (Heim)'),
        (80, 2, 0, True,  0, 0, 'Min 80, Führung 2:0 (Heim)'),
        (85, 0, 2, True,  0, 0, 'Min 85, Rückstand 2+ 0:2 (Heim)'),
        (70, 1, 0, True,  1, 0, 'Min 70, knappe Führung + eigene Rote'),
        (65, 1, 2, False, 0, 1, 'Min 65, Auswärts Führung 2:1, Gegner Rote'),
    ]
    for minute, hg, ag, is_home, own_red, opp_red, desc in scenarios:
        plan = select_active_condition_plan(tactic, minute, hg, ag, is_home, own_red, opp_red)
        print(f'  {desc}')
        print(f'    → {plan if plan else "(kein Plan aktiv)"}')


# ═══════════════════════════════════════════════════════════════════════════════
# Hauptprogramm
# ═══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    raw_args    = sys.argv[1:]
    use_minutes = '--minutes' in raw_args
    args        = [a for a in raw_args if a != '--minutes']

    fixture_path = args[0] if len(args) > 0 else 'bayern_fixture.json'
    n_sims       = int(args[1]) if len(args) > 1 else 5_000

    print(f'Lade Fixture: {fixture_path}')
    with open(fixture_path, encoding='utf-8') as f:
        team = json.load(f)

    team_name   = team['team']['name']
    base_tactic = team.get('tactic', {})
    mode_label  = 'Minuten-Simulation' if use_minutes else 'Single-Pass'

    print(f'Team:          {team_name}')
    print(f'Spieler:       {len(team["players"])}  Startelf: {len(team["lineup"])}')
    print(f'Simulationen:  {n_sims:,} pro Variante')
    print(f'Modus:         {mode_label}')

    # ── Compiler-Vorschau ─────────────────────────────────────────────────────
    print('\n══ TAKTIK-COMPILER ══════════════════════════════════════════════')
    variants = build_variants(base_tactic)
    for label, tactic in variants[:3]:
        print_compiler(team, tactic, label)

    test_conditions(base_tactic)

    all_results: list[dict] = []
    t0 = time.perf_counter()

    # ── Taktik-Varianten ──────────────────────────────────────────────────────
    print(f'\n══ TAKTIK-VARIANTEN ({n_sims:,}× {mode_label}) ══════════════════════')
    variant_results: list[dict] = []
    for label, tactic in variants:
        b = run_batch(team, team, home_tactic=tactic, n=n_sims,
                      label=label, use_minutes=use_minutes)
        variant_results.append(b)
        all_results.append(b)
        print_batch(b)

    # ── Bedingungsvarianten (nur --minutes) ───────────────────────────────────
    condition_results: list[dict] = []
    if use_minutes:
        cond_variants = build_condition_variants(base_tactic)
        print(f'\n══ BEDINGUNGSVARIANTEN ({n_sims:,}× Minuten-Simulation) ══════════')
        for label, tactic in cond_variants:
            b = run_batch(team, team, home_tactic=tactic, n=n_sims,
                          label=label, use_minutes=True)
            condition_results.append(b)
            all_results.append(b)
            print_batch(b)

    elapsed    = time.perf_counter() - t0
    total_sims = n_sims * len(all_results)

    print(f'\n══ FERTIG ═══════════════════════════════════════════════════════')
    print(f'{total_sims:,} Simulationen in {elapsed:.1f}s '
          f'({total_sims / elapsed:,.0f} Sims/s)')

    # ── Vergleichs-Tabelle ────────────────────────────────────────────────────
    print('\n── Vergleich: Heimsieg-% ────────────────────────────────────────')
    base_win = variant_results[0]['home_win_pct']
    for b in all_results:
        delta = b['home_win_pct'] - base_win
        sign  = '+' if delta >= 0 else ''
        tag   = f'[{b["mode"]}]' if 'mode' in b else ''
        print(f'  {b["label"]:<44} {b["home_win_pct"]:>5.1f} %  ({sign}{delta:.1f} %) {tag}')

    # ── JSON-Ausgabe ──────────────────────────────────────────────────────────
    out = {
        'fixture':            fixture_path,
        'team':               team_name,
        'n_sims':             n_sims,
        'mode':               'minutes' if use_minutes else 'single',
        'elapsed_s':          round(elapsed, 2),
        'tactic_variants':    variant_results,
        'condition_variants': condition_results,
    }
    out_path = 'tactic_results.json'
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f'\nJSON gespeichert: {out_path}')


if __name__ == '__main__':
    main()
