"""
batch_tactic_tests.py — Taktik-Batch-Analyse für Websoccer
===========================================================
Führt 10.000 Simulationen pro Taktik-Variante durch und vergleicht
die Ergebnisse statistisch. Keine Django-Abhängigkeit.

Verwendung
----------
    python batch_tactic_tests.py [fixture.json] [n_sims]

    python batch_tactic_tests.py                      # 5.000 Sims, Bayern-Fixture
    python batch_tactic_tests.py fixture.json 10000   # 10.000 Sims
"""

import json
import sys
import time
from collections import defaultdict

from run_match import simulate_match
from tactic_compiler import compile_tactic, select_active_condition_plan


# ═══════════════════════════════════════════════════════════════════════════════
# Hilfsfunktionen
# ═══════════════════════════════════════════════════════════════════════════════

def _avg(values: list) -> float:
    return sum(values) / len(values) if values else 0.0


def _pct(count: int, total: int) -> str:
    return f'{count / total * 100:.1f} %' if total else '—'


def run_batch(home_team: dict, away_team: dict,
              home_tactic: dict | None = None,
              away_tactic: dict | None = None,
              n: int = 5_000,
              label: str = 'Basis') -> dict:
    """Führt n Simulationen durch und gibt aggregierte Statistiken zurück."""
    outcomes = {'home': 0, 'draw': 0, 'away': 0}
    goals_home, goals_away = [], []
    possessions = []
    shots_home, shots_away = [], []

    for _ in range(n):
        r = simulate_match(home_team, away_team, home_tactic, away_tactic)
        hg, ag = r['home_goals'], r['away_goals']
        goals_home.append(hg)
        goals_away.append(ag)
        possessions.append(r['match_stats']['home_possession'])
        shots_home.append(r['match_stats']['home_shots'])
        shots_away.append(r['match_stats']['away_shots'])
        if hg > ag:
            outcomes['home'] += 1
        elif hg == ag:
            outcomes['draw'] += 1
        else:
            outcomes['away'] += 1

    return {
        'label':         label,
        'n':             n,
        'home_win_pct':  outcomes['home'] / n * 100,
        'draw_pct':      outcomes['draw'] / n * 100,
        'away_win_pct':  outcomes['away'] / n * 100,
        'avg_goals_h':   _avg(goals_home),
        'avg_goals_a':   _avg(goals_away),
        'avg_goals':     _avg([h + a for h, a in zip(goals_home, goals_away)]),
        'avg_possession':_avg(possessions),
        'avg_shots_h':   _avg(shots_home),
        'avg_shots_a':   _avg(shots_away),
    }


def print_batch(b: dict) -> None:
    """Gibt einen Batch-Ergebnis-Block aus."""
    print(f'\n── {b["label"]} ({b["n"]:,} Simulationen) ─────────────────')
    print(f'  Heimsieg:      {b["home_win_pct"]:>5.1f} %')
    print(f'  Unentschieden: {b["draw_pct"]:>5.1f} %')
    print(f'  Auswärtssieg:  {b["away_win_pct"]:>5.1f} %')
    print(f'  Ø Tore/Spiel:  {b["avg_goals"]:.2f}  '
          f'(Heim {b["avg_goals_h"]:.2f} | Gast {b["avg_goals_a"]:.2f})')
    print(f'  Ø Ballbesitz H:{b["avg_possession"]:.1f} %')
    print(f'  Ø Schüsse:     Heim {b["avg_shots_h"]:.1f} | Gast {b["avg_shots_a"]:.1f}')


def print_compiler(team: dict, tactic: dict | None, label: str) -> None:
    """Gibt compile_tactic()-Output kompakt aus."""
    c = compile_tactic(team, tactic)
    print(f'\n  compile_tactic() → {label}')
    print(f'    orientation:        {c["orientation"]:.1f}')
    print(f'    tempo:              {c["tempo"]:.1f}')
    print(f'    pressing_index:     {c["pressing_index"]:.3f}')
    print(f'    xg_for:             {c["xg_for"]:.3f}')
    print(f'    xg_against:         {c["xg_against"]:.3f}')
    print(f'    possession_bonus:   {c["possession_bonus"]:+.3f}')
    print(f'    shot_volume:        {c["shot_volume"]:.3f}')
    print(f'    shot_quality:       {c["shot_quality"]:.3f}')
    print(f'    directness:         {c["directness"]:+.3f}')
    print(f'    risk:               {c["risk"]:+.3f}')
    print(f'    fatigue_cost:       {c["fatigue_cost"]:.3f}')
    print(f'    foul_multiplier:    {c["foul_multiplier"]:.3f}')
    print(f'    teamwork_avg:       {c["teamwork_avg"]}')
    print(f'    teamwork_factor:    {c["teamwork_factor"]:.4f}')
    print(f'    complexity:         {c["complexity"]:.1f}')
    print(f'    coherence:          {c["coherence"]:.4f}')
    lm = c['line_multipliers']
    print(f'    line_multipliers:   def={lm["defense"]:.3f} '
          f'mid={lm["midfield"]:.3f} '
          f'atk={lm["attack"]:.3f} '
          f'overall={lm["overall"]:.4f}')
    zw = c['zone_weights']
    print(f'    zone_weights:       L={zw["left"]:.2f} '
          f'C={zw["center"]:.2f} '
          f'R={zw["right"]:.2f}')


# ═══════════════════════════════════════════════════════════════════════════════
# Taktik-Varianten
# ═══════════════════════════════════════════════════════════════════════════════

def build_variants(base: dict) -> list[tuple[str, dict]]:
    """Gibt Taktik-Varianten als (Label, tactic_dict)-Liste zurück."""
    return [
        ('Basis (Ist-Taktik)', base),
        ('Hohes Pressing (alle Linien)', {
            **base,
            'pressing': {'defense': 'hoch', 'midfield': 'hoch', 'attack': 'hoch'},
        }),
        ('Passives Pressing', {
            **base,
            'pressing': {'defense': 'passiv', 'midfield': 'passiv', 'attack': 'passiv'},
        }),
        ('Angriffsfokus: Durch die Mitte', {
            **base, 'attack_focus': 'durch_mitte',
        }),
        ('Angriffsfokus: Flügelspiel', {
            **base, 'attack_focus': 'fluegelspiel',
        }),
        ('Spieltempo 90 (sehr schnell)', {
            **base,
            'buildup': {**base.get('buildup', {}), 'tempo': 90},
        }),
        ('Spieltempo 10 (sehr langsam)', {
            **base,
            'buildup': {**base.get('buildup', {}), 'tempo': 10},
        }),
        ('Triggerpressing: Ballverlust', {
            **base,
            'pressing_triggers': {
                **base.get('pressing_triggers', {}),
                'ballverlust': True,
            },
        }),
        ('Schlussangriff-Modus (Plan-Override)', {
            **base, '_active_plan': 'schlussangriff',
        }),
        ('Defensiv: Kompakt sichern (Plan)', {
            **base, '_active_plan': 'kompakt_sichern',
        }),
    ]


# ═══════════════════════════════════════════════════════════════════════════════
# Conditions-Test
# ═══════════════════════════════════════════════════════════════════════════════

def test_conditions(tactic: dict) -> None:
    """Testet select_active_condition_plan() für typische Spielsituationen."""
    print('\n── Bedingungen / Matchpläne ───────────────────────────────────')
    scenarios = [
        (60, 0, 1, True,  0, 0, 'Min 60, Rückstand 0:1 (Heim)'),
        (75, 1, 1, True,  0, 0, 'Min 75, Unentschieden 1:1 (Heim)'),
        (80, 2, 0, True,  0, 0, 'Min 80, Führung 2:0 (Heim)'),
        (85, 0, 2, True,  0, 0, 'Min 85, Rückstand 2+ 0:2 (Heim)'),
        (70, 1, 0, True,  1, 0, 'Min 70, knappe Führung + eigene Rote'),
        (65, 1, 2, False, 0, 1, 'Min 65, Auswärts Führung 2:1, Gegner Rote'),
    ]
    for minute, hg, ag, is_home, own_red, opp_red, desc in scenarios:
        plan = select_active_condition_plan(tactic, minute, hg, ag, is_home, own_red, opp_red)
        plan_str = plan if plan else '(kein Plan aktiv)'
        print(f'  {desc}')
        print(f'    → {plan_str}')


# ═══════════════════════════════════════════════════════════════════════════════
# Hauptprogramm
# ═══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    fixture_path = sys.argv[1] if len(sys.argv) > 1 else 'bayern_fixture.json'
    n_sims = int(sys.argv[2]) if len(sys.argv) > 2 else 5_000

    print(f'Lade Fixture: {fixture_path}')
    with open(fixture_path, encoding='utf-8') as f:
        team = json.load(f)

    team_name = team['team']['name']
    base_tactic = team.get('tactic', {})

    print(f'Team: {team_name}')
    print(f'Spieler im Kader: {len(team["players"])}')
    print(f'Startelf-Slots:   {len(team["lineup"])}')
    print(f'Simulationen:     {n_sims:,} pro Variante')

    # ── Compiler-Ausgabe (keine Simulation) ──────────────────────────────────
    print('\n══ TAKTIK-COMPILER (compile_tactic) ════════════════════════════')
    variants = build_variants(base_tactic)
    for label, tactic in variants[:3]:  # Erste 3 als Compiler-Preview
        print_compiler(team, tactic, label)

    # ── Bedingungen ──────────────────────────────────────────────────────────
    test_conditions(base_tactic)

    # ── Batch-Simulationen ───────────────────────────────────────────────────
    print(f'\n══ BATCH-SIMULATIONEN ({n_sims:,}×) ══════════════════════════════')
    results = []
    t0 = time.perf_counter()

    for label, tactic in variants:
        b = run_batch(team, team, home_tactic=tactic, n=n_sims, label=label)
        results.append(b)
        print_batch(b)

    elapsed = time.perf_counter() - t0
    total_sims = n_sims * len(variants)
    print(f'\n══ FERTIG ═══════════════════════════════════════════════════════')
    print(f'{total_sims:,} Simulationen in {elapsed:.1f}s '
          f'({total_sims / elapsed:,.0f} Sims/s)')

    # ── Vergleichs-Tabelle ───────────────────────────────────────────────────
    print('\n── Vergleich: Heimsieg-% ────────────────────────────────────────')
    base_win = results[0]['home_win_pct']
    for b in results:
        delta = b['home_win_pct'] - base_win
        sign = '+' if delta >= 0 else ''
        print(f'  {b["label"]:<42} {b["home_win_pct"]:>5.1f} %  ({sign}{delta:.1f} %)')


if __name__ == '__main__':
    main()
