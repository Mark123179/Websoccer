"""
run_match.py — Websoccer Match Simulation (Standalone, Django-free)
Tactics-integrated V1 + Minuten-Simulation mit aktiven Bedingungen.
"""
from __future__ import annotations

import json
import math
import random
from typing import Optional

from tactic_compiler import (
    compile_tactic,
    calculate_zone_strengths,
    select_active_condition_plan,
)

_GROUP_KEY: dict[str, str] = {
    'goalkeeper':        'goalkeeper',
    'defense':           'defense',
    'defensive_midfield':'midfield',
    'midfield':          'midfield',
    'offensive_midfield':'midfield',
    'attack':            'attack',
}

_GOAL_WEIGHTS: dict[str, float] = {
    'goalkeeper':         0.01,
    'defense':            0.04,
    'defensive_midfield': 0.07,
    'midfield':           0.13,
    'offensive_midfield': 0.22,
    'attack':             0.53,
}


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _pos_factor(player: dict, position_code: str) -> tuple[float, str]:
    if position_code in player.get('main_positions', []):
        return 1.0, 'HP'
    if position_code in player.get('secondary_positions', []):
        return 0.90, 'NP'
    return 0.80, 'FP'


def calculate_lineup_strength(
    team: dict,
    tactic_override: Optional[dict] = None,
    compiled_tactic: Optional[dict] = None,
) -> dict:
    """Berechnet Linienstärken inkl. Taktik-Multiplikatoren."""
    players_by_id = {p['id']: p for p in team.get('players', [])}
    if compiled_tactic is None:
        compiled_tactic = compile_tactic(team, tactic_override or team.get('tactic', {}), half='full')

    multipliers = compiled_tactic.get('line_multipliers', {})
    lines: dict[str, list[float]] = {
        'goalkeeper': [], 'defense': [], 'midfield': [], 'attack': []
    }

    for slot in team.get('lineup', []):
        pid = slot.get('player_id')
        if not pid:
            continue
        player = players_by_id.get(pid)
        if not player:
            continue

        group = slot.get('group', 'attack')
        line = _GROUP_KEY.get(group, 'attack')
        factor, _fit = _pos_factor(player, slot['position'])
        strength = player.get('final_strength', 50.0) * factor
        strength *= multipliers.get(line, 1.0)
        lines[line].append(strength)

    def avg(lst: list[float]) -> float:
        return sum(lst) / len(lst) if lst else 50.0

    gk = avg(lines['goalkeeper'])
    de = avg(lines['defense'])
    mi = avg(lines['midfield'])
    at = avg(lines['attack'])
    all_vals = lines['goalkeeper'] + lines['defense'] + lines['midfield'] + lines['attack']
    overall = avg(all_vals) * multipliers.get('overall', 1.0)

    return {
        'goalkeeper': round(gk, 2),
        'defense':    round(de, 2),
        'midfield':   round(mi, 2),
        'attack':     round(at, 2),
        'overall':    round(overall, 2),
    }


def _poisson(lam: float) -> int:
    L = math.exp(-lam)
    k, p = 0, 1.0
    while p > L:
        k += 1
        p *= random.random()
    return k - 1


def _balanced_zone_baseline(own_zone: dict, opp_zone: dict) -> float:
    balanced = {'left': 0.33, 'center': 0.34, 'right': 0.33}
    return _weighted_zone_ratio(own_zone, opp_zone, balanced)


def _weighted_zone_ratio(own_zone: dict, opp_zone: dict, weights: dict) -> float:
    own_attack = own_zone.get('attack', {})
    opp_def    = opp_zone.get('defense', {})
    pairs = [('left', 'right'), ('center', 'center'), ('right', 'left')]
    val = 0.0
    for own_z, opp_z in pairs:
        val += weights.get(own_z, 0.0) * (
            own_attack.get(own_z, 1.0) / max(opp_def.get(opp_z, 1.0), 1.0)
        )
    return val


def _zone_factor(own_compiled: dict, own_zone: dict, opp_zone: dict) -> float:
    weights = own_compiled.get('zone_weights', {'left': 0.33, 'center': 0.34, 'right': 0.33})
    raw  = _weighted_zone_ratio(own_zone, opp_zone, weights)
    base = _balanced_zone_baseline(own_zone, opp_zone)
    if base <= 0:
        return 1.0
    return _clamp(raw / base, 0.93, 1.07)


def _expected_goals(
    own_strength:       dict,
    opp_strength:       dict,
    own_compiled:       Optional[dict] = None,
    opp_compiled:       Optional[dict] = None,
    own_zone_strengths: Optional[dict] = None,
    opp_zone_strengths: Optional[dict] = None,
) -> float:
    """Expected goals from line strength + compiled tactical effects."""
    own_off = (
        own_strength['overall'] * 0.45
        + own_strength['attack']   * 0.32
        + own_strength['midfield'] * 0.23
    )
    opp_def = (
        opp_strength['overall']    * 0.35
        + opp_strength['defense']   * 0.42
        + opp_strength['goalkeeper']* 0.23
    )
    base_xg = 1.36 * (own_off / max(opp_def, 1.0))

    if own_compiled:
        base_xg *= own_compiled.get('xg_for', 1.0)
        base_xg *= own_compiled.get('shot_quality', 1.0)
        base_xg *= 0.85 + 0.15 * own_compiled.get('shot_volume', 1.0)
    if opp_compiled:
        base_xg *= opp_compiled.get('xg_against', 1.0)
    if own_compiled and own_zone_strengths and opp_zone_strengths:
        base_xg *= _zone_factor(own_compiled, own_zone_strengths, opp_zone_strengths)

    return _clamp(base_xg, 0.2, 4.5)


def _lineup_players(team: dict) -> list[dict]:
    pid_map = {p['id']: p for p in team.get('players', [])}
    result = []
    for slot in team.get('lineup', []):
        p = pid_map.get(slot.get('player_id'))
        if p:
            result.append({**p, 'position': slot['position'], 'group': slot.get('group', 'attack')})
    return result


def _goal_events(
    n: int,
    team_key: str,
    lineup_players: list[dict],
    minute_pool: list[int],
) -> list[dict]:
    if not lineup_players:
        return []
    weights = [_GOAL_WEIGHTS.get(p.get('group', 'attack'), 0.05) for p in lineup_players]
    w_sum = sum(weights) or 1.0
    weights = [w / w_sum for w in weights]
    events = []
    for _ in range(n):
        minute = (
            minute_pool.pop(random.randint(0, len(minute_pool) - 1))
            if minute_pool
            else random.randint(1, 90)
        )
        scorer   = random.choices(lineup_players, weights=weights, k=1)[0]
        assister = None
        if random.random() < 0.72:
            cands = [p for p in lineup_players if p['id'] != scorer['id']]
            if cands:
                assister = random.choice(cands)
        events.append({
            'minute':        minute,
            'team':          team_key,
            'scorer_id':     scorer['id'],
            'scorer_name':   scorer['name'],
            'scorer_pos':    scorer.get('position', '?'),
            'assister_id':   assister['id']   if assister else None,
            'assister_name': assister['name'] if assister else None,
        })
    return events


def _distribute_attacks(total: int, weights: dict) -> dict[str, int]:
    zones  = ['left', 'center', 'right']
    counts = {z: 0 for z in zones}
    w = [weights.get(z, 0.0) for z in zones]
    if sum(w) <= 0:
        w = [0.33, 0.34, 0.33]
    for z in random.choices(zones, weights=w, k=max(0, int(total))):
        counts[z] += 1
    return counts


def _team_stats(goals: int, own_compiled: dict) -> dict:
    shot_volume   = own_compiled.get('shot_volume',   1.0)
    shot_quality  = own_compiled.get('shot_quality',  1.0)
    width         = own_compiled.get('width',          0.0)
    pressing_index = own_compiled.get('pressing_index', 0.35)

    base_on    = goals + random.randint(2, 5)
    on_target  = max(goals, int(round(base_on * _clamp(shot_quality, 0.75, 1.25))))
    total_shots = on_target + random.randint(3, 9)
    total_shots = max(goals, int(round(total_shots * _clamp(shot_volume, 0.70, 1.50))))

    corners_base = random.randint(2, 10)
    corner_mult  = 1.0 + max(0.0, width) * 0.30 + max(0.0, shot_volume - 1.0) * 0.25
    corners      = max(0, int(round(corners_base * corner_mult)))

    fouls       = max(1, int(round(random.randint(8, 20) * own_compiled.get('foul_multiplier', 1.0))))
    yellow_base = random.randint(0, 3)
    yellow      = int(round(
        yellow_base * own_compiled.get('card_multiplier', 1.0)
        + max(0, fouls - 14) * 0.05
    ))
    yellow      = max(0, min(7, yellow))
    red_prob    = 0.025 * own_compiled.get('card_multiplier', 1.0)
    red         = 1 if random.random() < min(0.12, red_prob) else 0

    pressing_wins_lam    = 1.5 + pressing_index * 4.2 + own_compiled.get('pressing_ball_win_bonus', 0.0) * 18
    pressing_bypassed_lam = max(0.1, own_compiled.get('pressing_bypassed_risk', 0.0) * 9
                                    + max(0, own_compiled.get('risk', 0.0)) * 3)

    return {
        'shots':               total_shots,
        'shots_on_target':     on_target,
        'corners':             corners,
        'fouls':               fouls,
        'yellow':              yellow,
        'red':                 red,
        'pressing_ball_wins':  _poisson(pressing_wins_lam),
        'pressing_bypassed':   _poisson(pressing_bypassed_lam),
    }


def _match_stats(
    h_str:  dict,
    a_str:  dict,
    hg:     int,
    ag:     int,
    h_comp: dict,
    a_comp: dict,
) -> dict:
    h, a  = h_str['overall'], a_str['overall']
    total = h + a or 1.0
    possession_delta = (h_comp.get('possession_bonus', 0.0) - a_comp.get('possession_bonus', 0.0)) * 35
    build_delta      = (h_comp.get('build_control',    0.0) - a_comp.get('build_control',    0.0)) * 10
    home_poss = int(round(_clamp(50 + (h - a) / total * 22 + possession_delta + build_delta, 30, 70)))

    hs  = _team_stats(hg, h_comp)
    as_ = _team_stats(ag, a_comp)

    h_attacks_total = hs['shots'] + hs['corners'] + random.randint(8, 18)
    a_attacks_total = as_['shots'] + as_['corners'] + random.randint(8, 18)
    h_z = _distribute_attacks(h_attacks_total, h_comp.get('zone_weights', {}))
    a_z = _distribute_attacks(a_attacks_total, a_comp.get('zone_weights', {}))

    return {
        'home_possession':       home_poss,
        'away_possession':       100 - home_poss,
        'home_shots':            hs['shots'],
        'away_shots':            as_['shots'],
        'home_shots_on_target':  hs['shots_on_target'],
        'away_shots_on_target':  as_['shots_on_target'],
        'home_corners':          hs['corners'],
        'away_corners':          as_['corners'],
        'home_fouls':            hs['fouls'],
        'away_fouls':            as_['fouls'],
        'home_yellow':           hs['yellow'],
        'away_yellow':           as_['yellow'],
        'home_red':              hs['red'],
        'away_red':              as_['red'],
        'home_attacks_left':     h_z['left'],
        'home_attacks_center':   h_z['center'],
        'home_attacks_right':    h_z['right'],
        'away_attacks_left':     a_z['left'],
        'away_attacks_center':   a_z['center'],
        'away_attacks_right':    a_z['right'],
        'home_pressing_ball_wins': hs['pressing_ball_wins'],
        'away_pressing_ball_wins': as_['pressing_ball_wins'],
        'home_pressing_bypassed':  hs['pressing_bypassed'],
        'away_pressing_bypassed':  as_['pressing_bypassed'],
        'home_fatigue_cost':       h_comp.get('fatigue_cost', 1.0),
        'away_fatigue_cost':       a_comp.get('fatigue_cost', 1.0),
        'home_tactic_coherence':   h_comp.get('coherence',   1.0),
        'away_tactic_coherence':   a_comp.get('coherence',   1.0),
        'home_tactic_complexity':  h_comp.get('complexity',  0.0),
        'away_tactic_complexity':  a_comp.get('complexity',  0.0),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Simulation V1 — Einzel-Poisson (schnell, kein Minutenstatus)
# ═══════════════════════════════════════════════════════════════════════════════

def simulate_match(
    home_team:    dict,
    away_team:    dict,
    home_tactic:  Optional[dict] = None,
    away_tactic:  Optional[dict] = None,
) -> dict:
    """Schnelle Simulation: ein Poisson-Zug pro Mannschaft für 90 Minuten.

    Bedingungen/Matchpläne wirken nur, wenn sie über `_active_plan` explizit
    im Taktik-Dict gesetzt sind. Für automatische Plan-Aktivierung nach
    Spielstand → simulate_match_minutes().
    """
    home_tactic = home_tactic or home_team.get('tactic', {})
    away_tactic = away_tactic or away_team.get('tactic', {})

    h_comp = compile_tactic(home_team, home_tactic, half='full')
    a_comp = compile_tactic(away_team, away_tactic, half='full')
    h_zone = calculate_zone_strengths(home_team)
    a_zone = calculate_zone_strengths(away_team)

    h_str = calculate_lineup_strength(home_team, home_tactic, h_comp)
    a_str = calculate_lineup_strength(away_team, away_tactic, a_comp)

    h_xg = _expected_goals(h_str, a_str, h_comp, a_comp, h_zone, a_zone)
    a_xg = _expected_goals(a_str, h_str, a_comp, h_comp, a_zone, h_zone)
    h_goals = _poisson(h_xg)
    a_goals = _poisson(a_xg)

    h_lineup = _lineup_players(home_team)
    a_lineup = _lineup_players(away_team)

    minutes = list(range(1, 91))
    random.shuffle(minutes)
    events = sorted(
        _goal_events(h_goals, 'home', h_lineup, minutes)
        + _goal_events(a_goals, 'away', a_lineup, minutes),
        key=lambda e: e['minute'],
    )

    h_stats = {p['id']: {'goals': 0, 'assists': 0} for p in h_lineup}
    a_stats = {p['id']: {'goals': 0, 'assists': 0} for p in a_lineup}
    for evt in events:
        sm = h_stats if evt['team'] == 'home' else a_stats
        if evt['scorer_id'] in sm:
            sm[evt['scorer_id']]['goals'] += 1
        if evt['assister_id'] and evt['assister_id'] in sm:
            sm[evt['assister_id']]['assists'] += 1

    def _enrich(lineup: list[dict], stats: dict) -> list[dict]:
        return [{**p, **stats.get(p['id'], {'goals': 0, 'assists': 0})} for p in lineup]

    h_players = _enrich(h_lineup, h_stats)
    a_players = _enrich(a_lineup, a_stats)
    stats = _match_stats(h_str, a_str, h_goals, a_goals, h_comp, a_comp)
    h_teamwork = sum(p.get('teamwork', 50) for p in h_players)
    a_teamwork = sum(p.get('teamwork', 50) for p in a_players)

    return {
        'home_team':             home_team['team']['name'],
        'away_team':             away_team['team']['name'],
        'home_goals':            h_goals,
        'away_goals':            a_goals,
        'home_xg':               round(h_xg, 4),
        'away_xg':               round(a_xg, 4),
        'goal_events':           events,
        'match_stats':           stats,
        'home_players':          h_players,
        'away_players':          a_players,
        'home_strength':         h_str,
        'away_strength':         a_str,
        'home_teamwork':         h_teamwork,
        'away_teamwork':         a_teamwork,
        'home_compiled_tactic':  h_comp,
        'away_compiled_tactic':  a_comp,
        'home_zone_strengths':   h_zone,
        'away_zone_strengths':   a_zone,
        'simulation_mode':       'single',
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Simulation V2 — Minuten-Simulation mit aktiven Bedingungen
# ═══════════════════════════════════════════════════════════════════════════════

_SEGMENT = 5  # Segmentlänge in Minuten


def simulate_match_minutes(
    home_team:   dict,
    away_team:   dict,
    home_tactic: Optional[dict] = None,
    away_tactic: Optional[dict] = None,
) -> dict:
    """Minuten-Simulation: 18 Segmente à 5 Min., Bedingungen werden live geprüft.

    Jedes Segment:
      1. Aktuellen Spielstand + Rote Karten prüfen.
      2. select_active_condition_plan() → Plan aktivieren wenn Bedingung erfüllt.
      3. Taktik mit aktivem Plan neu kompilieren.
      4. Poisson-λ × (5/90) → Tore für dieses Segment.
      5. Torereignisse mit Spieler + Minuten erzeugen.

    Rückgabe-Extras gegenüber simulate_match():
      plan_log       — Liste aller Plan-Aktivierungen mit Minute, Score, Plan
      simulation_mode — 'minutes'
      home/away_red_cards — tatsächlich gezogene Rote Karten
    """
    base_ht = home_tactic or home_team.get('tactic', {})
    base_at = away_tactic or away_team.get('tactic', {})

    h_zone   = calculate_zone_strengths(home_team)
    a_zone   = calculate_zone_strengths(away_team)
    h_lineup = _lineup_players(home_team)
    a_lineup = _lineup_players(away_team)

    # Basis-Kompilierung für Endstatistiken (ohne Plan-Override)
    h_comp_base = compile_tactic(home_team, base_ht, half='full')
    a_comp_base = compile_tactic(away_team, base_at, half='full')
    h_str_base  = calculate_lineup_strength(home_team, base_ht, h_comp_base)
    a_str_base  = calculate_lineup_strength(away_team, base_at, a_comp_base)

    # Laufender Spielstand
    h_goals: int = 0
    a_goals: int = 0
    h_red:   int = 0
    a_red:   int = 0

    events:   list[dict] = []
    plan_log: list[dict] = []

    prev_h_plan: Optional[str] = None
    prev_a_plan: Optional[str] = None

    for seg_start in range(1, 91, _SEGMENT):
        seg_end = min(seg_start + _SEGMENT - 1, 90)
        seg_len = seg_end - seg_start + 1
        half    = 'first' if seg_end <= 45 else 'second'

        # ── 1. Bedingungen prüfen ─────────────────────────────────────────────
        h_plan = select_active_condition_plan(
            base_ht, seg_start,
            h_goals, a_goals,
            is_home=True, own_red=h_red, opp_red=a_red,
        )
        a_plan = select_active_condition_plan(
            base_at, seg_start,
            a_goals, h_goals,
            is_home=False, own_red=a_red, opp_red=h_red,
        )

        # Plan-Log: nur bei Änderung schreiben
        if h_plan != prev_h_plan or a_plan != prev_a_plan:
            if h_plan or a_plan:
                plan_log.append({
                    'minute':     seg_start,
                    'score':      f'{h_goals}:{a_goals}',
                    'home_plan':  h_plan,
                    'away_plan':  a_plan,
                })
            prev_h_plan = h_plan
            prev_a_plan = a_plan

        # ── 2. Taktik (neu) kompilieren ───────────────────────────────────────
        h_tac = {**base_ht, '_active_plan': h_plan} if h_plan else base_ht
        a_tac = {**base_at, '_active_plan': a_plan} if a_plan else base_at

        h_comp = compile_tactic(home_team, h_tac, half=half)
        a_comp = compile_tactic(away_team, a_tac, half=half)
        h_str  = calculate_lineup_strength(home_team, h_tac, h_comp)
        a_str  = calculate_lineup_strength(away_team, a_tac, a_comp)

        # ── 3. Expected Goals für dieses Segment ─────────────────────────────
        h_xg_full = _expected_goals(h_str, a_str, h_comp, a_comp, h_zone, a_zone)
        a_xg_full = _expected_goals(a_str, h_str, a_comp, h_comp, a_zone, h_zone)
        h_xg_seg  = h_xg_full * seg_len / 90
        a_xg_seg  = a_xg_full * seg_len / 90

        # ── 4. Tore ziehen ────────────────────────────────────────────────────
        h_seg_goals = _poisson(h_xg_seg)
        a_seg_goals = _poisson(a_xg_seg)

        # ── 5. Torereignisse erzeugen ─────────────────────────────────────────
        seg_pool = list(range(seg_start, seg_end + 1))
        events.extend(_goal_events(h_seg_goals, 'home', h_lineup, seg_pool))
        events.extend(_goal_events(a_seg_goals, 'away', a_lineup, seg_pool))

        h_goals += h_seg_goals
        a_goals += a_seg_goals

        # ── 6. Rote Karten (probabilistisch, selten) ──────────────────────────
        seg_frac = seg_len / 90
        if random.random() < 0.025 * h_comp.get('card_multiplier', 1.0) * seg_frac:
            h_red += 1
        if random.random() < 0.025 * a_comp.get('card_multiplier', 1.0) * seg_frac:
            a_red += 1

    # ── Nachbereitung ─────────────────────────────────────────────────────────
    events.sort(key=lambda e: e['minute'])

    h_stats_map = {p['id']: {'goals': 0, 'assists': 0} for p in h_lineup}
    a_stats_map = {p['id']: {'goals': 0, 'assists': 0} for p in a_lineup}
    for evt in events:
        sm = h_stats_map if evt['team'] == 'home' else a_stats_map
        if evt['scorer_id'] in sm:
            sm[evt['scorer_id']]['goals'] += 1
        if evt['assister_id'] and evt['assister_id'] in sm:
            sm[evt['assister_id']]['assists'] += 1

    def _enrich(lineup: list[dict], sm: dict) -> list[dict]:
        return [{**p, **sm.get(p['id'], {'goals': 0, 'assists': 0})} for p in lineup]

    h_players  = _enrich(h_lineup, h_stats_map)
    a_players  = _enrich(a_lineup, a_stats_map)
    stats      = _match_stats(h_str_base, a_str_base, h_goals, a_goals, h_comp_base, a_comp_base)
    h_teamwork = sum(p.get('teamwork', 50) for p in h_players)
    a_teamwork = sum(p.get('teamwork', 50) for p in a_players)

    # xG-Referenzwerte aus Basis-Kompilierung (ohne Plan-Override)
    h_xg_ref = _expected_goals(h_str_base, a_str_base, h_comp_base, a_comp_base, h_zone, a_zone)
    a_xg_ref = _expected_goals(a_str_base, h_str_base, a_comp_base, h_comp_base, a_zone, h_zone)

    return {
        'home_team':             home_team['team']['name'],
        'away_team':             away_team['team']['name'],
        'home_goals':            h_goals,
        'away_goals':            a_goals,
        'home_xg':               round(h_xg_ref, 4),
        'away_xg':               round(a_xg_ref, 4),
        'goal_events':           events,
        'match_stats':           stats,
        'home_players':          h_players,
        'away_players':          a_players,
        'home_strength':         h_str_base,
        'away_strength':         a_str_base,
        'home_teamwork':         h_teamwork,
        'away_teamwork':         a_teamwork,
        'home_compiled_tactic':  h_comp_base,
        'away_compiled_tactic':  a_comp_base,
        'home_zone_strengths':   h_zone,
        'away_zone_strengths':   a_zone,
        'plan_log':              plan_log,
        'simulation_mode':       'minutes',
        'home_red_cards':        h_red,
        'away_red_cards':        a_red,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import sys

    fixture_path = sys.argv[1] if len(sys.argv) > 1 else 'bayern_fixture.json'
    n_sims       = int(sys.argv[2]) if len(sys.argv) > 2 else 1000

    with open(fixture_path, encoding='utf-8') as f:
        team = json.load(f)

    team_name = team['team']['name']

    # ── Bulk-Statistiken (simulate_match, schnell) ────────────────────────────
    print(f'Simuliere {n_sims}× {team_name} vs {team_name} …')
    outcomes     = {'home': 0, 'draw': 0, 'away': 0}
    total_goals  = 0
    total_poss   = 0
    total_hxg    = 0.0
    total_axg    = 0.0

    for _ in range(n_sims):
        r = simulate_match(team, team)
        hg, ag = r['home_goals'], r['away_goals']
        total_goals += hg + ag
        total_poss  += r['match_stats']['home_possession']
        total_hxg   += r['home_xg']
        total_axg   += r['away_xg']
        if hg > ag:
            outcomes['home'] += 1
        elif hg == ag:
            outcomes['draw'] += 1
        else:
            outcomes['away'] += 1

    print(f'\nErgebnisse ({n_sims} Spiele):')
    print(f'  Heimsieg:       {outcomes["home"]:>5}  ({outcomes["home"]/n_sims*100:.1f} %)')
    print(f'  Unentschieden:  {outcomes["draw"]:>5}  ({outcomes["draw"]/n_sims*100:.1f} %)')
    print(f'  Auswärtssieg:   {outcomes["away"]:>5}  ({outcomes["away"]/n_sims*100:.1f} %)')
    print(f'  Ø Tore/Spiel:   {total_goals / n_sims:.2f}')
    print(f'  Ø xG:           Heim {total_hxg/n_sims:.3f} | Gast {total_axg/n_sims:.3f}')
    print(f'  Ø Ballbesitz H: {total_poss / n_sims:.1f} %')

    sample = simulate_match(team, team)
    print(f'\nBeispiel-Stärken (simulate_match):')
    for k, v in sample['home_strength'].items():
        print(f'  {k:<15} {v}')
    print(f'  Teamwork:       {sample["home_teamwork"]}')
    print(f'  Compiled:       pressing={sample["home_compiled_tactic"]["pressing_index"]:.3f}'
          f', tempo={sample["home_compiled_tactic"]["tempo"]:.0f}'
          f', coherence={sample["home_compiled_tactic"]["coherence"]:.3f}')

    # ── Minuten-Simulation Demo (mit aktiven Bedingungen) ─────────────────────
    print(f'\n── Minuten-Simulation Demo ──────────────────────────────────────')

    # Taktik mit 3 aktiven Bedingungen für die Demo
    demo_tactic = {
        **team['tactic'],
        'conditions': [
            {'active': True,  'minute': 60, 'condition': 'rueckstand',   'plan': 'aggressiv_risiko'},
            {'active': True,  'minute': 80, 'condition': 'fuehrung',     'plan': 'zeitspiel'},
            {'active': True,  'minute': 85, 'condition': 'rueckstand_2', 'plan': 'schlussangriff'},
        ],
    }

    # 5 Demo-Spiele mit Minuten-Simulation
    for i in range(5):
        r = simulate_match_minutes(team, team, home_tactic=demo_tactic, away_tactic=demo_tactic)
        hg, ag = r['home_goals'], r['away_goals']
        result = 'H' if hg > ag else ('U' if hg == ag else 'A')
        plans  = r['plan_log']
        plan_str = ', '.join(
            f'[Min {p["minute"]} {p["score"]} → H:{p["home_plan"] or "–"} A:{p["away_plan"] or "–"}]'
            for p in plans
        ) if plans else '(keine Bedingung ausgelöst)'
        print(f'  Spiel {i+1}: {hg}:{ag} ({result})  Pläne: {plan_str}')

    # Batch-Vergleich: simulate_match vs simulate_match_minutes
    print(f'\n── Vergleich: single vs minutes ({n_sims} Sims) ─────────────────')
    for mode, fn, tac in [
        ('single  ', simulate_match,         team['tactic']),
        ('minutes ', simulate_match_minutes, demo_tactic),
    ]:
        h_wins = 0
        g_total = 0
        plans_fired = 0
        for _ in range(n_sims):
            r = fn(team, team, home_tactic=tac, away_tactic=tac)
            if r['home_goals'] > r['away_goals']:
                h_wins += 1
            g_total += r['home_goals'] + r['away_goals']
            plans_fired += len(r.get('plan_log', []))
        print(f'  {mode}  Heimsieg {h_wins/n_sims*100:.1f} %'
              f'  Ø Tore {g_total/n_sims:.2f}'
              f'  Plan-Aktivierungen/Spiel {plans_fired/n_sims:.2f}')
