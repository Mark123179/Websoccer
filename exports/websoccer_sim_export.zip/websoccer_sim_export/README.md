# Websoccer Match Simulation — Export

Standalone-Exportpaket zur externen Analyse der Spielsimulation.
**Kein Django, kein ORM, keine Datenbank** erforderlich — nur Python 3.10+.

---

## Schnellstart

```bash
# 1 Simulation (Konsolenausgabe)
python run_match.py bayern_fixture.json 1

# 1.000 Simulationen Bayern vs. Bayern
python run_match.py bayern_fixture.json 1000

# 10.000 Simulationen
python run_match.py bayern_fixture.json 10000
```

Als Python-Modul:

```python
import json
from run_match import simulate_match

with open('bayern_fixture.json', encoding='utf-8') as f:
    team = json.load(f)

result = simulate_match(home_team=team, away_team=team)
print(result['home_goals'], ':', result['away_goals'])
```

---

## Dateiübersicht

| Datei                  | Typ        | Zweck |
|------------------------|------------|-------|
| `run_match.py`         | Standalone | Haupt-Einstiegspunkt — Django-frei, direkt ausführbar |
| `tactic_compiler.py`   | Standalone | Taktik → Spiel-Multiplikatoren (compile_tactic) |
| `batch_tactic_tests.py`| Standalone | 10.000-Simulations-Vergleiche über alle Taktik-Varianten |
| `bayern_fixture.json`  | Daten      | Vollständige Bayern-Daten (25 Spieler, Startelf, Taktik) |
| `tactics.py`           | Django     | Original Taktik-System mit allen Konstanten (ORM-abhängig) |
| `match_engine.py`      | Django     | Original Spielsimulation (ORM-abhängig) |
| `match_readiness.py`   | Django     | Aufstellungs- & Stärke-Logik (ORM-abhängig) |

---

## Welche Funktion kompiliert die Taktik?

```python
from tactic_compiler import compile_tactic

compiled = compile_tactic(team, tactic=None, half='full')
```

`compile_tactic(team, tactic, half)` in **`tactic_compiler.py`** ist der Kern-Compiler.

| Parameter | Typ | Bedeutung |
|-----------|-----|-----------|
| `team`    | dict | Team-Dict im Format von `bayern_fixture.json` |
| `tactic`  | dict \| None | Überschreibt `team['tactic']` — für Varianten-Analyse |
| `half`    | `'first'` \| `'second'` \| `'full'` | Halbzeit-Kontext; `'full'` = Durchschnitt beider Hälften |

---

## Welche Werte gibt der Compiler zurück?

`compile_tactic()` gibt ein Dict mit folgenden Feldern zurück:

### Spielausrichtung

| Feld | Typ | Bedeutung |
|------|-----|-----------|
| `orientation` | float 0–100 | Grundausrichtung (0 = sehr defensiv, 100 = sehr offensiv) |
| `tempo` | float 0–100 | Spieltempo aus `buildup.tempo` |
| `zone_weights` | dict | Angriffsschwerpunkte — `{left, center, right}` normiert auf 1.0 |

### Linien-Multiplikatoren

```python
compiled['line_multipliers']
# {'goalkeeper': 1.0, 'defense': 0.98–1.10, 'midfield': …, 'attack': …, 'overall': …}
```

`overall` = `teamwork_factor × coherence` — wird als globaler Stärke-Multiplikator verwendet.

### Expected Goals

| Feld | Typ | Bedeutung |
|------|-----|-----------|
| `xg_for` | float | Multiplikator auf eigene Torchancen (Standard: 1.0) |
| `xg_against` | float | Multiplikator auf gegnerische Torchancen |

### Schüsse & Ballbesitz

| Feld | Typ | Bedeutung |
|------|-----|-----------|
| `possession_bonus` | float −0.20 … +0.20 | Additive Korrektur auf Ballbesitz-Formel |
| `shot_volume` | float | Multiplikator auf Schussanzahl |
| `shot_quality` | float | Multiplikator auf Schussqualität (Trefferrate) |

### Pressing

| Feld | Typ | Bedeutung |
|------|-----|-----------|
| `pressing_index` | float 0–1 | Gewichteter Pressing-Wert (Def×0.3 + Mid×0.4 + Atk×0.3) |
| `pressing_ball_win_bonus` | float | Wahrscheinlichkeit Ballgewinn durch Pressing |
| `pressing_bypassed_risk` | float | Risiko, dass Pressing überspielt wird |

### Zweikampf & Disziplin

| Feld | Typ | Bedeutung |
|------|-----|-----------|
| `foul_multiplier` | float | Multiplikator auf Foulanzahl |
| `card_multiplier` | float | Multiplikator auf Kartenanzahl |
| `fatigue_cost` | float | Frischeverbrauch-Multiplikator (1.0 = normal) |

### Spielstil

| Feld | Typ | Bedeutung |
|------|-----|-----------|
| `directness` | float −0.30 … +0.30 | Direktheit des Spiels (negativ = geduldig, positiv = direkt) |
| `risk` | float | Risikobereitschaft |
| `width` | float | Spielbreite (negativ = eng, positiv = breit) |
| `build_control` | float | Aufbaukontrolle / Ballbesitz-Orientierung |

### Teamwork & Qualität

| Feld | Typ | Bedeutung |
|------|-----|-----------|
| `teamwork_avg` | float | Durchschnittlicher Teamwork-Wert der Startelf |
| `teamwork_factor` | float | Multiplikator aus Teamwork × Taktik-Komplexität (0.96–1.04) |
| `complexity` | float 0–100 | Taktische Komplexität (viele Sonderfunktionen = höher) |
| `coherence` | float 0.85–1.05 | Widerspruchsfreiheit der Taktik (z. B. Gegenpressing + passiv = Malus) |

### Debug-Dict

```python
compiled['debug']
# {'attack_focus': 'fluegelspiel', 'pressing_index': 0.612, 'active_triggers': ['ballverlust'], …}
```

---

## Wie startet man 10.000 Simulationen?

### Option 1 — Kommandozeile (schnellste)

```bash
python run_match.py bayern_fixture.json 10000
```

Ausgabe: Heimsieg/Unentschieden/Auswärtssieg in %, Ø Tore, Ø Ballbesitz, Beispiel-Stärken.

### Option 2 — Batch-Varianten-Vergleich

```bash
# 10 Taktik-Varianten × 5.000 Sims = 50.000 Simulationen
python batch_tactic_tests.py bayern_fixture.json 5000

# 10.000 Sims pro Variante
python batch_tactic_tests.py bayern_fixture.json 10000
```

`batch_tactic_tests.py` vergleicht automatisch: Basis-Taktik, Hohes Pressing, Passiv,
Angriffsfokus-Varianten, Tempo-Extreme, Trigger-Pressing und Matchplan-Overrides.

### Option 3 — Python-Modul für eigene Analysen

```python
import json
from run_match import simulate_match
from tactic_compiler import compile_tactic

with open('bayern_fixture.json', encoding='utf-8') as f:
    team = json.load(f)

base_tactic = team['tactic']

# Eigene Variante definieren
high_press = {
    **base_tactic,
    'pressing': {'defense': 'hoch', 'midfield': 'hoch', 'attack': 'hoch'},
}

# Compiler-Output (ohne Simulation)
compiled = compile_tactic(team, high_press)
print(f'Pressing-Index: {compiled["pressing_index"]:.3f}')
print(f'Fatigue-Cost:   {compiled["fatigue_cost"]:.3f}')

# 10.000 Simulationen
n = 10_000
results = [simulate_match(team, team, home_tactic=high_press) for _ in range(n)]

avg_goals = sum(r['home_goals'] + r['away_goals'] for r in results) / n
win_rate  = sum(1 for r in results if r['home_goals'] > r['away_goals']) / n
print(f'Ø Tore/Spiel:   {avg_goals:.2f}')
print(f'Heimsieg:       {win_rate*100:.1f} %')
```

---

## Welche Taktikfeatures wirken bereits?

### In `run_match.py` (Simulation)

| Feature | Wo | Effekt |
|---------|-----|--------|
| **Spielerstärke** (`final_strength`) | `calculate_lineup_strength()` | Direkte Eingabe in Poisson-λ |
| **Positions-Fit** HP / NP / FP | `_pos_factor()` | ×1.00 / ×0.90 / ×0.80 auf Stärke |
| **Poisson-Torberechnung** | `_poisson()` + `_expected_goals()` | λ = 1.4 × (Stärke / Gegnerstärke) |
| **Ballbesitz-Formel** | `_match_stats()` | 50 + Stärkedifferenz × 22, begrenzt 30–70 |
| **Tor-Events** mit Schütze & Vorlage | `_goal_events()` | Gewichtet nach Position (ST 53 %, TW 1 %) |
| **Teamwork-Ausgabe** | `simulate_match()` | Summe in `home_teamwork` / `away_teamwork` |

### In `tactic_compiler.py` (Multiplikatoren — bereit für Integration)

| Feature | Compiler-Feld | Berechnungslogik |
|---------|--------------|-----------------|
| **Angriffsfokus** | `zone_weights`, `line_multipliers` | 7 Optionen → normierte Zone-Intensitäten |
| **Pressing** je Linie | `pressing_index` | Def×0.3 + Mid×0.4 + Atk×0.3, Wert 0–1 |
| **Pressing-Trigger** | `pressing_ball_win_bonus`, `pressing_bypassed_risk` | Budget-Check (max. 3 Punkte); 4 Auslöser |
| **Spielaufbau** (defense/midfield/attack/height) | `directness`, `possession_bonus`, `build_control` | Jede Option addiert Deltas auf State |
| **Spieltempo** | `tempo`, `fatigue_cost`, `shot_volume` | td = (tempo−50)/50; beeinflusst 5 Felder |
| **Deckung & Zweikämpfe** | `foul_multiplier`, `card_multiplier`, `defense_delta` | Raum/Mann/Hybrid + Zweikampfstil |
| **Matchplan-Override** | alle Felder | `_active_plan`-Key überschreibt Deltas via `CONDITION_PLAN_MODIFIERS` |
| **Bedingungen** | — | `select_active_condition_plan()` wertet alle 7 Bedingungstypen aus |
| **Teamwork × Komplexität** | `teamwork_factor` | Multiplikator 0.96–1.04, nur wenn Komplexität > 30 |
| **Kohärenz** | `coherence` | Widersprüche (z. B. Gegenpressing + passiv) senken Faktor |

---

## Welche Features sind noch bewusst vereinfacht?

Diese Features sind im Compiler vollständig berechnet, aber in `run_match.py`
noch **nicht in die Torsimulation eingespeist**. Die Stubs sind vorbereitet:

| Feature | Status | Stub in `run_match.py` | Nächster Schritt |
|---------|--------|----------------------|-----------------|
| **Pressing → Stärke-Bonus** | Stub | `_pressing_modifier()` | `pressing_index` aus Compiler × Stärke multiplizieren |
| **Angriffsfokus → Linien-Shift** | Stub | `_attack_focus_modifier()` | `line_multipliers` aus Compiler auf `calculate_lineup_strength()` anwenden |
| **Teamwork-Multiplikator** | Stub | `_teamwork_modifier()` | `teamwork_factor` aus Compiler auf `overall` anwenden |
| **Tempo → Frischeverbrauch** | Noch nicht integriert | — | `fatigue_cost` aus Compiler auf Spieler-`freshness` anwenden |
| **Matchplan-Wechsel zur Laufzeit** | Noch nicht integriert | — | `select_active_condition_plan()` pro Spielminute aufrufen |
| **Halbzeit-Konditionswechsel** | Halbzeit-Daten vorhanden | — | Erste/zweite Hälfte mit separaten `compile_tactic(…, half='first')` simulieren |
| **Schussqualität** | Compiler berechnet `shot_quality` | — | In `_goal_events()` als Treffer-Wahrscheinlichkeit nutzen |
| **Foul/Karten aus Taktik** | Compiler berechnet `foul/card_multiplier` | — | In `_match_stats()` anwenden |
| **Zone-Stärken** | `calculate_zone_strengths()` fertig | — | Angriffszonen × Defensivzonen für xG-Berechnung nutzen |

---

## Taktik-Varianten analysieren

### Pressing-Intensität vergleichen

```python
from run_match import simulate_match
from tactic_compiler import compile_tactic

# Compiler-Ausgabe ohne Simulation
for level in ('passiv', 'normal', 'intensiv', 'hoch'):
    t = {**base_tactic, 'pressing': {'defense': level, 'midfield': level, 'attack': level}}
    c = compile_tactic(team, t)
    print(f'{level:10} pressing_index={c["pressing_index"]:.3f}  fatigue={c["fatigue_cost"]:.3f}')
```

### Matchplan-Override testen

```python
from tactic_compiler import compile_tactic, CONDITION_PLAN_MODIFIERS

for plan in CONDITION_PLAN_MODIFIERS:
    t = {**base_tactic, '_active_plan': plan}
    c = compile_tactic(team, t)
    print(f'{plan:25} xg_for={c["xg_for"]:.3f}  risk={c["risk"]:+.3f}')
```

### Bedingungen auswerten

```python
from tactic_compiler import select_active_condition_plan

# Greift "Schlussangriff" bei Rückstand ab Minute 75?
plan = select_active_condition_plan(
    tactic=base_tactic,
    minute=76,
    home_goals=0, away_goals=1,
    is_home=True,
)
print(plan)  # z.B. 'schlussangriff' oder None
```

---

## Datenformat — `bayern_fixture.json`

```jsonc
{
  "team": {"id": 2, "name": "FC Bayern München", "fm_inside_id": 915},
  "formation_raw": {"defense": "4n", "defensive_midfield": "2", ...},
  "players": [
    {
      "id": 21609,
      "name": "Harry Kane",
      "main_positions": ["ST"],
      "secondary_positions": [],
      "age": 31,
      "base_strength": 178.5,
      "final_strength": 178.5,
      "freshness": 100.0,
      "form_modifier": 0.0,
      "teamwork": 75,
      "injury_days": 0,
      "suspension_matches": 0,
      "in_lineup": true
    }
  ],
  "lineup": [
    {"slot": "ST-1", "position": "ST", "group": "attack", "player_id": 21609}
  ],
  "tactic": {
    "attack_focus": "ausgewogen",
    "buildup": {"defense": "standard", "midfield": "standard",
                "attack": "standard", "defense_height": "standard", "tempo": 50},
    "defending": {"deckung": "hybrid", "zweikampf": "normal",
                  "breite": "standard", "umschalten": "ausgewogen"},
    "pressing": {"defense": "normal", "midfield": "normal", "attack": "normal"},
    "pressing_triggers": {"ballverlust": false, "langer_ball": false,
                          "schlechter_pass": false, "torwart_druck": false},
    "conditions": [
      {"active": false, "minute": 60, "condition": "rueckstand", "plan": "aggressiv_risiko"}
    ],
    "first_half":  {"orientation": 50, "effort": "normal"},
    "second_half": {"orientation": 50, "effort": "normal"}
  }
}
```

---

## Systemanforderungen

- Python 3.10+
- Nur Standardbibliothek (`math`, `random`, `json`, `time`, `sys`)
- Keine externen Pakete
- Alle Standalone-Dateien (`run_match.py`, `tactic_compiler.py`, `batch_tactic_tests.py`) funktionieren ohne Django
