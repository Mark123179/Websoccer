# WebSoccer Minutes Patch V1

Enthält die Standalone-Minuten-Simulation und den erweiterten Batch-Testmodus.

## Dateien

- `run_match.py`  
  Enthält weiterhin `simulate_match(...)` und zusätzlich `simulate_match_minutes(...)` mit 5-Minuten-Segmenten, Live-Bedingungsprüfung und Plan-Aktivierungen.

- `batch_tactic_tests.py`  
  Unterstützt jetzt den Minutenmodus:
  ```bash
  python batch_tactic_tests.py bayern_fixture.json 10000 --minutes
  ```

- `tactic_compiler.py`  
  Enthält zusätzlich den Tempo-Fix: hohes Tempo senkt nicht mehr pauschal die Chancenqualität.

- `tactic_test_results_minutes_v1_2500.json/.csv`  
  Auswertung eines 2.500-Sims-pro-Variante Minutenlaufs.

## Akzeptanztests

```bash
python run_match.py bayern_fixture.json 1000
python batch_tactic_tests.py bayern_fixture.json 1000
python batch_tactic_tests.py bayern_fixture.json 1000 --minutes
```

## Minutenmodus

`simulate_match_minutes()` simuliert in 5-Minuten-Segmenten:

1. aktiven Plan über `select_active_condition_plan()` bestimmen
2. Plan über `_active_plan` in `compile_tactic()` anwenden
3. Segment-xG berechnen: Match-xG × Segmentlänge / 90
4. Tore und Tor-Events mit echter Minute erzeugen
5. rote Karten akkumulieren
6. Plan-Aktivierungen, Comebacks und gehaltene Führungen tracken

Bedingungen gelten ab Minute X, nicht nur in Minute X.
