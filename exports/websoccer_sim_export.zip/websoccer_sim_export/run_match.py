"""
run_match.py — Websoccer Match Simulation (Standalone, Django-free)
Tactics-integrated V1 for external batch testing.
"""
from __future__ import annotations

import json
import math
import random
from copy import deepcopy
from typing import Optional

from tactic_compiler import compile_tactic, calculate_zone_strengths, select_active_condition_plan

_GROUP_KEY: dict[str, str] = {
    'goalkeeper': 'goalkeeper',
    'defense': 'defense',
    'defensive_midfield': 'midfield',
    'midfield': 'midfield',
    'offensive_midfield': 'midfield',
    'attack': 'attack',
}

_GOAL_WEIGHTS: dict[str, float] = {
    'goalkeeper': 0.01,
    'defense': 0.04,
    'defensive_midfield': 0.07,
    'midfield': 0.13,
    'offensive_midfield': 0.22,
    'attack': 0.53,
}


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _pos_factor(player: dict, position_code: str) -> tuple[float, str]:
    if position_code in player.get('main_positions', []):
        return 1.0, 'HP'
    if position_code in player.get('secondary_positions', []):
        return 0.90, 'NP'
    return 0.80, 'FP'


def calculate_lineup_strength(
    team: dict,
    tactic_override: Optional[dict] = None,
    compiled_tactic: Optional[dict] = None,
) -> dict:
    """Berechnet Linienstärken inkl. Taktik-Multiplikatoren."""
    players_by_id = {p['id']: p for p in team.get('players', [])}
    if compiled_tactic is None:
        compiled_tactic = compile_tactic(team, tactic_override or team.get('tactic', {}), half='full')

    multipliers = compiled_tactic.get('line_multipliers', {})
    lines: dict[str, list[float]] = {
        'goalkeeper': [], 'defense': [], 'midfield': [], 'attack': []
    }

    for slot in team.get('lineup', []):
        pid = slot.get('player_id')
        if not pid:
            continue
        player = players_by_id.get(pid)
        if not player:
            continue

        group = slot.get('group', 'attack')
        line = _GROUP_KEY.get(group, 'attack')
        factor, fit = _pos_factor(player, slot['position'])
        strength = player.get('final_strength', 50.0) * factor
        strength *= multipliers.get(line, 1.0)
        lines[line].append(strength)

    def avg(lst: list[float]) -> float:
        return sum(lst) / len(lst) if lst else 50.0

    gk = avg(lines['goalkeeper'])
    de = avg(lines['defense'])
    mi = avg(lines['midfield'])
    at = avg(lines['attack'])
    all_vals = lines['goalkeeper'] + lines['defense'] + lines['midfield'] + lines['attack']
    overall = avg(all_vals) * multipliers.get('overall', 1.0)

    return {
        'goalkeeper': round(gk, 2),
        'defense': round(de, 2),
        'midfield': round(mi, 2),
        'attack': round(at, 2),
        'overall': round(overall, 2),
    }


def _poisson(lam: float) -> int:
    L = math.exp(-lam)
    k, p = 0, 1.0
    while p > L:
        k += 1
        p *= random.random()
    return k - 1


def _balanced_zone_baseline(own_zone: dict, opp_zone: dict) -> float:
    balanced = {'left': 0.33, 'center': 0.34, 'right': 0.33}
    return _weighted_zone_ratio(own_zone, opp_zone, balanced)


def _weighted_zone_ratio(own_zone: dict, opp_zone: dict, weights: dict) -> float:
    own_attack = own_zone.get('attack', {})
    opp_def = opp_zone.get('defense', {})
    pairs = [('left', 'right'), ('center', 'center'), ('right', 'left')]
    val = 0.0
    for own_z, opp_z in pairs:
        val += weights.get(own_z, 0.0) * (own_attack.get(own_z, 1.0) / max(opp_def.get(opp_z, 1.0), 1.0))
    return val


def _zone_factor(own_compiled: dict, own_zone: dict, opp_zone: dict) -> float:
    weights = own_compiled.get('zone_weights', {'left': 0.33, 'center': 0.34, 'right': 0.33})
    raw = _weighted_zone_ratio(own_zone, opp_zone, weights)
    base = _balanced_zone_baseline(own_zone, opp_zone)
    if base <= 0:
        return 1.0
    return _clamp(raw / base, 0.93, 1.07)


def _expected_goals(
    own_strength: dict,
    opp_strength: dict,
    own_compiled: Optional[dict] = None,
    opp_compiled: Optional[dict] = None,
    own_zone_strengths: Optional[dict] = None,
    opp_zone_strengths: Optional[dict] = None,
) -> float:
    """Expected goals from line strength + compiled tactical effects."""
    own_off = (
        own_strength['overall'] * 0.45
        + own_strength['attack'] * 0.32
        + own_strength['midfield'] * 0.23
    )
    opp_def = (
        opp_strength['overall'] * 0.35
        + opp_strength['defense'] * 0.42
        + opp_strength['goalkeeper'] * 0.23
    )
    base_xg = 1.36 * (own_off / max(opp_def, 1.0))

    if own_compiled:
        base_xg *= own_compiled.get('xg_for', 1.0)
        base_xg *= own_compiled.get('shot_quality', 1.0)
        # Shot volume should influence total danger, but only moderately.
        base_xg *= 0.85 + 0.15 * own_compiled.get('shot_volume', 1.0)
    if opp_compiled:
        base_xg *= opp_compiled.get('xg_against', 1.0)
    if own_compiled and own_zone_strengths and opp_zone_strengths:
        base_xg *= _zone_factor(own_compiled, own_zone_strengths, opp_zone_strengths)

    return _clamp(base_xg, 0.2, 4.5)


def _lineup_players(team: dict) -> list[dict]:
    pid_map = {p['id']: p for p in team.get('players', [])}
    result = []
    for slot in team.get('lineup', []):
        p = pid_map.get(slot.get('player_id'))
        if p:
            result.append({**p, 'position': slot['position'], 'group': slot.get('group', 'attack')})
    return result


def _goal_events(n: int, team_key: str, lineup_players: list[dict], minute_pool: list[int]) -> list[dict]:
    if not lineup_players:
        return []
    weights = [_GOAL_WEIGHTS.get(p.get('group', 'attack'), 0.05) for p in lineup_players]
    w_sum = sum(weights) or 1.0
    weights = [w / w_sum for w in weights]
    events = []
    for _ in range(n):
        minute = minute_pool.pop(random.randint(0, len(minute_pool) - 1)) if minute_pool else random.randint(1, 90)
        scorer = random.choices(lineup_players, weights=weights, k=1)[0]
        assister = None
        if random.random() < 0.72:
            cands = [p for p in lineup_players if p['id'] != scorer['id']]
            if cands:
                assister = random.choice(cands)
        events.append({
            'minute': minute,
            'team': team_key,
            'scorer_id': scorer['id'],
            'scorer_name': scorer['name'],
            'scorer_pos': scorer.get('position', '?'),
            'assister_id': assister['id'] if assister else None,
            'assister_name': assister['name'] if assister else None,
        })
    return events


def _distribute_attacks(total: int, weights: dict) -> dict[str, int]:
    zones = ['left', 'center', 'right']
    counts = {z: 0 for z in zones}
    w = [weights.get(z, 0.0) for z in zones]
    if sum(w) <= 0:
        w = [0.33, 0.34, 0.33]
    for z in random.choices(zones, weights=w, k=max(0, int(total))):
        counts[z] += 1
    return counts


def _team_stats(goals: int, own_compiled: dict) -> dict:
    shot_volume = own_compiled.get('shot_volume', 1.0)
    shot_quality = own_compiled.get('shot_quality', 1.0)
    width = own_compiled.get('width', 0.0)
    pressing_index = own_compiled.get('pressing_index', 0.35)

    base_on = goals + random.randint(2, 5)
    on_target = max(goals, int(round(base_on * _clamp(shot_quality, 0.75, 1.25))))
    total_shots = on_target + random.randint(3, 9)
    total_shots = max(goals, int(round(total_shots * _clamp(shot_volume, 0.70, 1.50))))

    corners_base = random.randint(2, 10)
    corner_mult = 1.0 + max(0.0, width) * 0.30 + max(0.0, shot_volume - 1.0) * 0.25
    corners = max(0, int(round(corners_base * corner_mult)))

    fouls = max(1, int(round(random.randint(8, 20) * own_compiled.get('foul_multiplier', 1.0))))
    yellow_base = random.randint(0, 3)
    # Higher foul counts nudge cards upward while keeping randomness.
    yellow = int(round(yellow_base * own_compiled.get('card_multiplier', 1.0) + max(0, fouls - 14) * 0.05))
    yellow = max(0, min(7, yellow))
    red_prob = 0.025 * own_compiled.get('card_multiplier', 1.0)
    red = 1 if random.random() < min(0.12, red_prob) else 0

    pressing_wins_lam = 1.5 + pressing_index * 4.2 + own_compiled.get('pressing_ball_win_bonus', 0.0) * 18
    pressing_bypassed_lam = max(0.1, own_compiled.get('pressing_bypassed_risk', 0.0) * 9 + max(0, own_compiled.get('risk', 0.0)) * 3)

    return {
        'shots': total_shots,
        'shots_on_target': on_target,
        'corners': corners,
        'fouls': fouls,
        'yellow': yellow,
        'red': red,
        'pressing_ball_wins': _poisson(pressing_wins_lam),
        'pressing_bypassed': _poisson(pressing_bypassed_lam),
    }


def _match_stats(
    h_str: dict,
    a_str: dict,
    hg: int,
    ag: int,
    h_comp: dict,
    a_comp: dict,
) -> dict:
    h, a = h_str['overall'], a_str['overall']
    total = h + a or 1.0
    possession_delta = (h_comp.get('possession_bonus', 0.0) - a_comp.get('possession_bonus', 0.0)) * 35
    build_delta = (h_comp.get('build_control', 0.0) - a_comp.get('build_control', 0.0)) * 10
    home_poss = int(round(_clamp(50 + (h - a) / total * 22 + possession_delta + build_delta, 30, 70)))

    hs = _team_stats(hg, h_comp)
    as_ = _team_stats(ag, a_comp)

    h_attacks_total = hs['shots'] + hs['corners'] + random.randint(8, 18)
    a_attacks_total = as_['shots'] + as_['corners'] + random.randint(8, 18)
    h_z = _distribute_attacks(h_attacks_total, h_comp.get('zone_weights', {}))
    a_z = _distribute_attacks(a_attacks_total, a_comp.get('zone_weights', {}))

    return {
        'home_possession': home_poss,
        'away_possession': 100 - home_poss,
        'home_shots': hs['shots'],
        'away_shots': as_['shots'],
        'home_shots_on_target': hs['shots_on_target'],
        'away_shots_on_target': as_['shots_on_target'],
        'home_corners': hs['corners'],
        'away_corners': as_['corners'],
        'home_fouls': hs['fouls'],
        'away_fouls': as_['fouls'],
        'home_yellow': hs['yellow'],
        'away_yellow': as_['yellow'],
        'home_red': hs['red'],
        'away_red': as_['red'],
        'home_attacks_left': h_z['left'],
        'home_attacks_center': h_z['center'],
        'home_attacks_right': h_z['right'],
        'away_attacks_left': a_z['left'],
        'away_attacks_center': a_z['center'],
        'away_attacks_right': a_z['right'],
        'home_pressing_ball_wins': hs['pressing_ball_wins'],
        'away_pressing_ball_wins': as_['pressing_ball_wins'],
        'home_pressing_bypassed': hs['pressing_bypassed'],
        'away_pressing_bypassed': as_['pressing_bypassed'],
        'home_fatigue_cost': h_comp.get('fatigue_cost', 1.0),
        'away_fatigue_cost': a_comp.get('fatigue_cost', 1.0),
        'home_tactic_coherence': h_comp.get('coherence', 1.0),
        'away_tactic_coherence': a_comp.get('coherence', 1.0),
        'home_tactic_complexity': h_comp.get('complexity', 0.0),
        'away_tactic_complexity': a_comp.get('complexity', 0.0),
    }


def simulate_match(
    home_team: dict,
    away_team: dict,
    home_tactic: Optional[dict] = None,
    away_tactic: Optional[dict] = None,
) -> dict:
    home_tactic = home_tactic or home_team.get('tactic', {})
    away_tactic = away_tactic or away_team.get('tactic', {})

    h_comp = compile_tactic(home_team, home_tactic, half='full')
    a_comp = compile_tactic(away_team, away_tactic, half='full')
    h_zone = calculate_zone_strengths(home_team)
    a_zone = calculate_zone_strengths(away_team)

    h_str = calculate_lineup_strength(home_team, home_tactic, h_comp)
    a_str = calculate_lineup_strength(away_team, away_tactic, a_comp)

    h_xg = _expected_goals(h_str, a_str, h_comp, a_comp, h_zone, a_zone)
    a_xg = _expected_goals(a_str, h_str, a_comp, h_comp, a_zone, h_zone)
    h_goals = _poisson(h_xg)
    a_goals = _poisson(a_xg)

    h_lineup = _lineup_players(home_team)
    a_lineup = _lineup_players(away_team)

    minutes = list(range(1, 91))
    random.shuffle(minutes)
    events = sorted(
        _goal_events(h_goals, 'home', h_lineup, minutes)
        + _goal_events(a_goals, 'away', a_lineup, minutes),
        key=lambda e: e['minute'],
    )

    h_stats = {p['id']: {'goals': 0, 'assists': 0} for p in h_lineup}
    a_stats = {p['id']: {'goals': 0, 'assists': 0} for p in a_lineup}
    for evt in events:
        stats_map = h_stats if evt['team'] == 'home' else a_stats
        if evt['scorer_id'] in stats_map:
            stats_map[evt['scorer_id']]['goals'] += 1
        if evt['assister_id'] and evt['assister_id'] in stats_map:
            stats_map[evt['assister_id']]['assists'] += 1

    def _enrich(lineup: list[dict], stats: dict) -> list[dict]:
        return [{**p, **stats.get(p['id'], {'goals': 0, 'assists': 0})} for p in lineup]

    h_players = _enrich(h_lineup, h_stats)
    a_players = _enrich(a_lineup, a_stats)
    stats = _match_stats(h_str, a_str, h_goals, a_goals, h_comp, a_comp)
    h_teamwork = sum(p.get('teamwork', 50) for p in h_players)
    a_teamwork = sum(p.get('teamwork', 50) for p in a_players)

    return {
        'home_team': home_team['team']['name'],
        'away_team': away_team['team']['name'],
        'home_goals': h_goals,
        'away_goals': a_goals,
        'home_xg': round(h_xg, 4),
        'away_xg': round(a_xg, 4),
        'goal_events': events,
        'match_stats': stats,
        'home_players': h_players,
        'away_players': a_players,
        'home_strength': h_str,
        'away_strength': a_str,
        'home_teamwork': h_teamwork,
        'away_teamwork': a_teamwork,
        'home_compiled_tactic': h_comp,
        'away_compiled_tactic': a_comp,
        'home_zone_strengths': h_zone,
        'away_zone_strengths': a_zone,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Minuten-Simulation V1
# ═══════════════════════════════════════════════════════════════════════════════

def _with_active_plan(tactic: Optional[dict], plan: Optional[str]) -> dict:
    """Returns a tactic copy with an optional _active_plan override."""
    t = deepcopy(tactic or {})
    if plan:
        t['_active_plan'] = plan
    else:
        t.pop('_active_plan', None)
    return t


def _minute_segment_starts(segment_minutes: int = 5) -> list[int]:
    segment_minutes = max(1, int(segment_minutes or 5))
    return list(range(1, 91, segment_minutes))


def _segment_len(start_minute: int, segment_minutes: int = 5) -> int:
    return max(1, min(segment_minutes, 91 - start_minute))


def _red_card_this_segment(compiled: dict, seg_len: int) -> int:
    """Very small red-card probability per segment, scaled from match rate."""
    match_prob = 0.025 * compiled.get('card_multiplier', 1.0)
    return 1 if random.random() < min(0.08, match_prob * seg_len / 90.0) else 0


def _segment_team_stats(goals: int, comp: dict, seg_len: int) -> dict:
    """Segment-scaled lightweight stats for minute simulation."""
    scale = seg_len / 90.0
    shot_volume = comp.get('shot_volume', 1.0)
    shot_quality = comp.get('shot_quality', 1.0)
    width = comp.get('width', 0.0)
    pressing_index = comp.get('pressing_index', 0.35)

    shots_lam = max(0.05, (9.6 * shot_volume + goals * 1.8) * scale)
    shots = max(goals, _poisson(shots_lam))
    on_lam = max(0.03, shots * _clamp(0.36 * shot_quality, 0.22, 0.55))
    shots_on = max(goals, min(shots, _poisson(on_lam) + goals))

    corner_mult = 1.0 + max(0.0, width) * 0.30 + max(0.0, shot_volume - 1.0) * 0.25
    corners = _poisson(max(0.02, 5.2 * corner_mult * scale))

    fouls = _poisson(max(0.05, 14.0 * comp.get('foul_multiplier', 1.0) * scale))
    yellow = _poisson(max(0.01, (1.35 * comp.get('card_multiplier', 1.0) + max(0, fouls - 2) * 0.05) * scale))

    pressing_wins_lam = (1.5 + pressing_index * 4.2 + comp.get('pressing_ball_win_bonus', 0.0) * 18) * scale
    pressing_bypassed_lam = max(0.02, (comp.get('pressing_bypassed_risk', 0.0) * 9 + max(0, comp.get('risk', 0.0)) * 3) * scale)

    attack_total = shots + corners + _poisson(max(0.05, 12.0 * scale))
    zones = _distribute_attacks(attack_total, comp.get('zone_weights', {}))

    return {
        'shots': shots,
        'shots_on_target': shots_on,
        'corners': corners,
        'fouls': fouls,
        'yellow': yellow,
        'pressing_ball_wins': _poisson(max(0.01, pressing_wins_lam)),
        'pressing_bypassed': _poisson(max(0.01, pressing_bypassed_lam)),
        'attacks_left': zones['left'],
        'attacks_center': zones['center'],
        'attacks_right': zones['right'],
    }


def _empty_minute_stats() -> dict:
    return {
        'possession_weighted': 0.0,
        'minutes_weighted': 0,
        'shots': 0,
        'shots_on_target': 0,
        'corners': 0,
        'fouls': 0,
        'yellow': 0,
        'red': 0,
        'attacks_left': 0,
        'attacks_center': 0,
        'attacks_right': 0,
        'pressing_ball_wins': 0,
        'pressing_bypassed': 0,
        'fatigue_cost_weighted': 0.0,
        'coherence_weighted': 0.0,
        'complexity_weighted': 0.0,
    }


def _add_segment_stats(total: dict, seg: dict, comp: dict, possession: int, seg_len: int, red: int) -> None:
    total['possession_weighted'] += possession * seg_len
    total['minutes_weighted'] += seg_len
    total['shots'] += seg['shots']
    total['shots_on_target'] += seg['shots_on_target']
    total['corners'] += seg['corners']
    total['fouls'] += seg['fouls']
    total['yellow'] += seg['yellow']
    total['red'] += red
    total['attacks_left'] += seg['attacks_left']
    total['attacks_center'] += seg['attacks_center']
    total['attacks_right'] += seg['attacks_right']
    total['pressing_ball_wins'] += seg['pressing_ball_wins']
    total['pressing_bypassed'] += seg['pressing_bypassed']
    total['fatigue_cost_weighted'] += comp.get('fatigue_cost', 1.0) * seg_len
    total['coherence_weighted'] += comp.get('coherence', 1.0) * seg_len
    total['complexity_weighted'] += comp.get('complexity', 0.0) * seg_len


def simulate_match_minutes(
    home_team: dict,
    away_team: dict,
    home_tactic: Optional[dict] = None,
    away_tactic: Optional[dict] = None,
    segment_minutes: int = 5,
) -> dict:
    """Simulates a match in 5-minute segments and activates pre-match conditions live.

    This is V1 for balancing, not a final production-grade event engine.
    Conditions are checked at the start of every segment using the current score and red cards.
    """
    home_base_tactic = deepcopy(home_tactic or home_team.get('tactic', {}))
    away_base_tactic = deepcopy(away_tactic or away_team.get('tactic', {}))
    h_zone = calculate_zone_strengths(home_team)
    a_zone = calculate_zone_strengths(away_team)
    h_lineup = _lineup_players(home_team)
    a_lineup = _lineup_players(away_team)

    h_goals = 0
    a_goals = 0
    h_xg_total = 0.0
    a_xg_total = 0.0
    h_red = 0
    a_red = 0
    events: list[dict] = []
    plan_activations: list[dict] = []
    plan_active_segments = {'home': {}, 'away': {}}
    plan_seg_stats = {'home': {}, 'away': {}}
    last_plan = {'home': None, 'away': None}
    goals_while_plan = {
        'home_for': 0, 'home_against': 0,
        'away_for': 0, 'away_against': 0,
        'by_plan_home': {}, 'by_plan_away': {},
    }
    h_stats_total = _empty_minute_stats()
    a_stats_total = _empty_minute_stats()
    score_at_60 = None
    score_at_80 = None
    last_h_comp = None
    last_a_comp = None
    last_h_str = None
    last_a_str = None

    for minute in _minute_segment_starts(segment_minutes):
        seg_len = _segment_len(minute, segment_minutes)
        end_min = minute + seg_len - 1
        half = 'first' if minute <= 45 else 'second'

        h_plan = select_active_condition_plan(home_base_tactic, minute, h_goals, a_goals, True, h_red, a_red)
        a_plan = select_active_condition_plan(away_base_tactic, minute, h_goals, a_goals, False, a_red, h_red)

        for side, plan in (('home', h_plan), ('away', a_plan)):
            if plan:
                plan_active_segments[side][plan] = plan_active_segments[side].get(plan, 0) + 1
            if plan != last_plan[side]:
                if plan:
                    plan_activations.append({
                        'minute': minute,
                        'side': side,
                        'plan': plan,
                        'score': f'{h_goals}:{a_goals}',
                    })
                last_plan[side] = plan

        h_tactic_seg = _with_active_plan(home_base_tactic, h_plan)
        a_tactic_seg = _with_active_plan(away_base_tactic, a_plan)
        h_comp = compile_tactic(home_team, h_tactic_seg, half=half)
        a_comp = compile_tactic(away_team, a_tactic_seg, half=half)
        h_str = calculate_lineup_strength(home_team, h_tactic_seg, h_comp)
        a_str = calculate_lineup_strength(away_team, a_tactic_seg, a_comp)
        last_h_comp, last_a_comp = h_comp, a_comp
        last_h_str, last_a_str = h_str, a_str

        h_xg_match = _expected_goals(h_str, a_str, h_comp, a_comp, h_zone, a_zone)
        a_xg_match = _expected_goals(a_str, h_str, a_comp, h_comp, a_zone, h_zone)
        h_xg_seg = h_xg_match * seg_len / 90.0
        a_xg_seg = a_xg_match * seg_len / 90.0
        h_xg_total += h_xg_seg
        a_xg_total += a_xg_seg

        hg = _poisson(h_xg_seg)
        ag = _poisson(a_xg_seg)
        minute_pool = list(range(minute, min(90, end_min) + 1))
        events.extend(_goal_events(hg, 'home', h_lineup, minute_pool.copy()))
        events.extend(_goal_events(ag, 'away', a_lineup, minute_pool.copy()))

        if h_plan:
            goals_while_plan['home_for'] += hg
            goals_while_plan['home_against'] += ag
            goals_while_plan['by_plan_home'][h_plan] = goals_while_plan['by_plan_home'].get(h_plan, 0) + hg
        if a_plan:
            goals_while_plan['away_for'] += ag
            goals_while_plan['away_against'] += hg
            goals_while_plan['by_plan_away'][a_plan] = goals_while_plan['by_plan_away'].get(a_plan, 0) + ag

        h_goals += hg
        a_goals += ag

        h_red_seg = _red_card_this_segment(h_comp, seg_len)
        a_red_seg = _red_card_this_segment(a_comp, seg_len)
        h_red += h_red_seg
        a_red += a_red_seg

        # Segment possession uses current compiled tactics and line strength.
        total_strength = h_str['overall'] + a_str['overall'] or 1.0
        poss_delta = (h_comp.get('possession_bonus', 0.0) - a_comp.get('possession_bonus', 0.0)) * 35
        build_delta = (h_comp.get('build_control', 0.0) - a_comp.get('build_control', 0.0)) * 10
        home_poss = int(round(_clamp(50 + (h_str['overall'] - a_str['overall']) / total_strength * 22 + poss_delta + build_delta, 30, 70)))

        h_seg_stats = _segment_team_stats(hg, h_comp, seg_len)
        a_seg_stats = _segment_team_stats(ag, a_comp, seg_len)
        _add_segment_stats(h_stats_total, h_seg_stats, h_comp, home_poss, seg_len, h_red_seg)
        _add_segment_stats(a_stats_total, a_seg_stats, a_comp, 100 - home_poss, seg_len, a_red_seg)

        for _side, _plan, _my_seg, _opp_seg, _my_xg, _opp_xg, _my_goals, _opp_goals, _my_comp in [
            ('home', h_plan, h_seg_stats, a_seg_stats, h_xg_seg, a_xg_seg, hg, ag, h_comp),
            ('away', a_plan, a_seg_stats, h_seg_stats, a_xg_seg, h_xg_seg, ag, hg, a_comp),
        ]:
            if _plan:
                pss = plan_seg_stats[_side]
                if _plan not in pss:
                    pss[_plan] = {
                        'segments': 0, 'minutes': 0,
                        'goals_for': 0, 'goals_against': 0,
                        'xg_for': 0.0, 'xg_against': 0.0,
                        'shots_for': 0, 'shots_against': 0,
                        'fouls': 0, 'yellow': 0, 'fatigue_sum': 0.0,
                    }
                s = pss[_plan]
                s['segments'] += 1
                s['minutes'] += seg_len
                s['goals_for'] += _my_goals
                s['goals_against'] += _opp_goals
                s['xg_for'] += _my_xg
                s['xg_against'] += _opp_xg
                s['shots_for'] += _my_seg['shots']
                s['shots_against'] += _opp_seg['shots']
                s['fouls'] += _my_seg['fouls']
                s['yellow'] += _my_seg['yellow']
                s['fatigue_sum'] += _my_comp.get('fatigue_cost', 1.0) * seg_len

        if score_at_60 is None and minute <= 60 <= end_min:
            score_at_60 = {'home': h_goals, 'away': a_goals}
        if score_at_80 is None and minute <= 80 <= end_min:
            score_at_80 = {'home': h_goals, 'away': a_goals}

    events = sorted(events, key=lambda e: e['minute'])

    h_player_stats = {p['id']: {'goals': 0, 'assists': 0} for p in h_lineup}
    a_player_stats = {p['id']: {'goals': 0, 'assists': 0} for p in a_lineup}
    for evt in events:
        stats_map = h_player_stats if evt['team'] == 'home' else a_player_stats
        if evt['scorer_id'] in stats_map:
            stats_map[evt['scorer_id']]['goals'] += 1
        if evt['assister_id'] and evt['assister_id'] in stats_map:
            stats_map[evt['assister_id']]['assists'] += 1

    def _enrich(lineup: list[dict], stats: dict) -> list[dict]:
        return [{**p, **stats.get(p['id'], {'goals': 0, 'assists': 0})} for p in lineup]

    def _final_stats(home_total: dict, away_total: dict) -> dict:
        hm = max(1, home_total['minutes_weighted'])
        am = max(1, away_total['minutes_weighted'])
        return {
            'home_possession': int(round(home_total['possession_weighted'] / hm)),
            'away_possession': int(round(away_total['possession_weighted'] / am)),
            'home_shots': home_total['shots'],
            'away_shots': away_total['shots'],
            'home_shots_on_target': home_total['shots_on_target'],
            'away_shots_on_target': away_total['shots_on_target'],
            'home_corners': home_total['corners'],
            'away_corners': away_total['corners'],
            'home_fouls': home_total['fouls'],
            'away_fouls': away_total['fouls'],
            'home_yellow': home_total['yellow'],
            'away_yellow': away_total['yellow'],
            'home_red': home_total['red'],
            'away_red': away_total['red'],
            'home_attacks_left': home_total['attacks_left'],
            'home_attacks_center': home_total['attacks_center'],
            'home_attacks_right': home_total['attacks_right'],
            'away_attacks_left': away_total['attacks_left'],
            'away_attacks_center': away_total['attacks_center'],
            'away_attacks_right': away_total['attacks_right'],
            'home_pressing_ball_wins': home_total['pressing_ball_wins'],
            'away_pressing_ball_wins': away_total['pressing_ball_wins'],
            'home_pressing_bypassed': home_total['pressing_bypassed'],
            'away_pressing_bypassed': away_total['pressing_bypassed'],
            'home_fatigue_cost': round(home_total['fatigue_cost_weighted'] / hm, 4),
            'away_fatigue_cost': round(away_total['fatigue_cost_weighted'] / am, 4),
            'home_tactic_coherence': round(home_total['coherence_weighted'] / hm, 4),
            'away_tactic_coherence': round(away_total['coherence_weighted'] / am, 4),
            'home_tactic_complexity': round(home_total['complexity_weighted'] / hm, 2),
            'away_tactic_complexity': round(away_total['complexity_weighted'] / am, 2),
        }

    score_at_60 = score_at_60 or {'home': h_goals, 'away': a_goals}
    score_at_80 = score_at_80 or {'home': h_goals, 'away': a_goals}
    lead_after_80 = score_at_80['home'] > score_at_80['away']
    lead_lost_after_80 = bool(lead_after_80 and h_goals <= a_goals)
    lead_protected_after_80 = bool(lead_after_80 and h_goals > a_goals)
    trailed_at_60 = score_at_60['home'] < score_at_60['away']
    comeback_win = bool(trailed_at_60 and h_goals > a_goals)
    comeback_draw = bool(trailed_at_60 and h_goals == a_goals)

    match_stats = _final_stats(h_stats_total, a_stats_total)
    h_players = _enrich(h_lineup, h_player_stats)
    a_players = _enrich(a_lineup, a_player_stats)

    return {
        'home_team': home_team['team']['name'],
        'away_team': away_team['team']['name'],
        'home_goals': h_goals,
        'away_goals': a_goals,
        'home_xg': round(h_xg_total, 4),
        'away_xg': round(a_xg_total, 4),
        'goal_events': events,
        'match_stats': match_stats,
        'home_players': h_players,
        'away_players': a_players,
        'home_strength': last_h_str or {},
        'away_strength': last_a_str or {},
        'home_teamwork': sum(p.get('teamwork', 50) for p in h_players),
        'away_teamwork': sum(p.get('teamwork', 50) for p in a_players),
        'home_compiled_tactic': last_h_comp or {},
        'away_compiled_tactic': last_a_comp or {},
        'home_zone_strengths': h_zone,
        'away_zone_strengths': a_zone,
        'simulation_mode': 'minutes',
        'segment_minutes': segment_minutes,
        'plan_activations': plan_activations,
        'condition_debug': {
            'plan_activations': plan_activations,
            'plan_activation_counts': {
                'home': {p: sum(1 for e in plan_activations if e['side'] == 'home' and e['plan'] == p)
                         for p in sorted({e['plan'] for e in plan_activations if e['side'] == 'home'})},
                'away': {p: sum(1 for e in plan_activations if e['side'] == 'away' and e['plan'] == p)
                         for p in sorted({e['plan'] for e in plan_activations if e['side'] == 'away'})},
            },
            'plan_active_segments': plan_active_segments,
            'plan_seg_stats': plan_seg_stats,
            'goals_after_plan_activation': goals_while_plan['home_for'],
            'conceded_after_plan_activation': goals_while_plan['home_against'],
            'goals_while_plan': goals_while_plan,
            'score_at_60': score_at_60,
            'score_at_80': score_at_80,
            'lead_after_80': lead_after_80,
            'lead_protected_after_80': lead_protected_after_80,
            'lead_lost_after_80': lead_lost_after_80,
            'trailed_at_60': trailed_at_60,
            'comeback_win': comeback_win,
            'comeback_draw': comeback_draw,
        },
    }


if __name__ == '__main__':
    import sys
    fixture_path = sys.argv[1] if len(sys.argv) > 1 else 'bayern_fixture.json'
    n_sims = int(sys.argv[2]) if len(sys.argv) > 2 else 1000

    with open(fixture_path, encoding='utf-8') as f:
        team = json.load(f)

    print(f'Simuliere {n_sims}× {team["team"]["name"]} vs {team["team"]["name"]} …')
    outcomes = {'home': 0, 'draw': 0, 'away': 0}
    total_goals = 0
    total_poss = 0
    total_hxg = 0.0
    total_axg = 0.0
    for _ in range(n_sims):
        r = simulate_match(team, team)
        hg, ag = r['home_goals'], r['away_goals']
        total_goals += hg + ag
        total_poss += r['match_stats']['home_possession']
        total_hxg += r['home_xg']
        total_axg += r['away_xg']
        if hg > ag:
            outcomes['home'] += 1
        elif hg == ag:
            outcomes['draw'] += 1
        else:
            outcomes['away'] += 1
    print(f'\nErgebnisse ({n_sims} Spiele):')
    print(f'  Heimsieg:       {outcomes["home"]:>5}  ({outcomes["home"]/n_sims*100:.1f} %)')
    print(f'  Unentschieden:  {outcomes["draw"]:>5}  ({outcomes["draw"]/n_sims*100:.1f} %)')
    print(f'  Auswärtssieg:   {outcomes["away"]:>5}  ({outcomes["away"]/n_sims*100:.1f} %)')
    print(f'  Ø Tore/Spiel:   {total_goals / n_sims:.2f}')
    print(f'  Ø xG:           Heim {total_hxg/n_sims:.3f} | Gast {total_axg/n_sims:.3f}')
    print(f'  Ø Ballbesitz H: {total_poss / n_sims:.1f} %')
    sample = simulate_match(team, team)
    print(f'\nBeispiel-Stärken:')
    for k, v in sample['home_strength'].items():
        print(f'  {k:<15} {v}')
    print(f'  Teamwork:       {sample["home_teamwork"]}')
    print(f'  Compiled:       pressing={sample["home_compiled_tactic"]["pressing_index"]:.3f}, tempo={sample["home_compiled_tactic"]["tempo"]:.0f}, coherence={sample["home_compiled_tactic"]["coherence"]:.3f}')
