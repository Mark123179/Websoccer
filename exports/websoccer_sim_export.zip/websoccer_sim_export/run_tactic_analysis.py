from __future__ import annotations
import json, random, time, copy, csv
from pathlib import Path
from run_match import simulate_match
from tactic_compiler import compile_tactic

ROOT=Path(__file__).resolve().parent
team=json.load(open(ROOT/'bayern_fixture.json', encoding='utf-8'))
base=team['tactic']

def deepmerge(d, updates):
    out=copy.deepcopy(d)
    for k,v in updates.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k]=deepmerge(out[k], v)
        else:
            out[k]=copy.deepcopy(v)
    return out

variants=[
    ('baseline_vs_baseline', base),
    ('ueber_links_vs_baseline', deepmerge(base, {'attack_focus':'ueber_links'})),
    ('ueber_rechts_vs_baseline', deepmerge(base, {'attack_focus':'ueber_rechts'})),
    ('durch_mitte_vs_baseline', deepmerge(base, {'attack_focus':'durch_mitte'})),
    ('fluegelspiel_vs_baseline', deepmerge(base, {'attack_focus':'fluegelspiel'})),
    ('halbraeume_vs_baseline', deepmerge(base, {'attack_focus':'ueber_halbraeume'})),
    ('flanke_kopfball_vs_baseline', deepmerge(base, {'attack_focus':'flanke_kopfball'})),
    ('high_press_vs_baseline', deepmerge(base, {'pressing': {'defense':'hoch','midfield':'hoch','attack':'hoch'}})),
    ('passive_press_vs_baseline', deepmerge(base, {'pressing': {'defense':'passiv','midfield':'passiv','attack':'passiv'}})),
    ('gegenpressing_trigger_vs_baseline', deepmerge(base, {'pressing_triggers': {'ballverlust': True, 'langer_ball': False, 'schlechter_pass': False, 'torwart_druck': False}})),
    ('all_triggers_budget_test_vs_baseline', deepmerge(base, {'pressing_triggers': {'ballverlust': True, 'langer_ball': True, 'schlechter_pass': True, 'torwart_druck': True}})),
    ('tempo_90_vs_baseline', deepmerge(base, {'buildup': {'tempo':90}})),
    ('tempo_10_vs_baseline', deepmerge(base, {'buildup': {'tempo':10}})),
    ('schlussangriff_vs_baseline', deepmerge(base, {'_active_plan':'schlussangriff'})),
    ('kompakt_sichern_vs_baseline', deepmerge(base, {'_active_plan':'kompakt_sichern'})),
    ('zeitspiel_vs_baseline', deepmerge(base, {'_active_plan':'zeitspiel'})),
    ('widerspruch_defensiv_angriffspressing_vs_baseline', deepmerge(base, {'first_half': {'orientation': 0, 'attack':'anlaufen'}, 'second_half': {'orientation': 0, 'attack':'anlaufen'}, 'pressing': {'defense':'passiv','midfield':'passiv','attack':'hoch'}})),
]

stat_keys=[
 'home_possession','away_possession','home_shots','away_shots','home_shots_on_target','away_shots_on_target',
 'home_corners','away_corners','home_fouls','away_fouls','home_yellow','away_yellow','home_red','away_red',
 'home_attacks_left','home_attacks_center','home_attacks_right','away_attacks_left','away_attacks_center','away_attacks_right',
 'home_pressing_ball_wins','away_pressing_ball_wins','home_pressing_bypassed','away_pressing_bypassed',
 'home_fatigue_cost','away_fatigue_cost','home_tactic_coherence','away_tactic_coherence','home_tactic_complexity','away_tactic_complexity'
]

def run_variant(name, tactic, n=10000, seed=1000):
    random.seed(seed)
    home_win=draw=away_win=0
    sums={k:0.0 for k in stat_keys}
    sums.update({'home_goals':0.0,'away_goals':0.0,'home_xg':0.0,'away_xg':0.0})
    score_counts={}
    for i in range(n):
        r=simulate_match(team, team, home_tactic=tactic, away_tactic=base)
        hg,ag=r['home_goals'], r['away_goals']
        sums['home_goals']+=hg; sums['away_goals']+=ag
        sums['home_xg']+=r['home_xg']; sums['away_xg']+=r['away_xg']
        if hg>ag: home_win+=1
        elif hg==ag: draw+=1
        else: away_win+=1
        score_counts[f'{hg}-{ag}']=score_counts.get(f'{hg}-{ag}',0)+1
        ms=r['match_stats']
        for k in stat_keys:
            sums[k]+=ms.get(k,0)
    avg={k: v/n for k,v in sums.items()}
    comp=compile_tactic(team, tactic)
    return {
        'name': name,
        'n': n,
        'home_wins': home_win,
        'draws': draw,
        'away_wins': away_win,
        'home_win_pct': home_win/n*100,
        'draw_pct': draw/n*100,
        'away_win_pct': away_win/n*100,
        'avg': avg,
        'compiled_home': comp,
        'score_counts_top': dict(sorted(score_counts.items(), key=lambda kv: kv[1], reverse=True)[:15]),
    }

if __name__=='__main__':
    import sys
    n=int(sys.argv[1]) if len(sys.argv)>1 else 10000
    t0=time.time(); results=[]
    for idx,(name,tac) in enumerate(variants):
        res=run_variant(name,tac,n,seed=12345+idx)
        results.append(res)
        a=res['avg']
        print(f"{name:48} H {res['home_win_pct']:5.1f} D {res['draw_pct']:5.1f} A {res['away_win_pct']:5.1f} | Tore {a['home_goals']:.2f}:{a['away_goals']:.2f} xG {a['home_xg']:.3f}:{a['away_xg']:.3f} Poss {a['home_possession']:.1f} PressWins {a['home_pressing_ball_wins']:.1f} Fat {a['home_fatigue_cost']:.3f} Coh {a['home_tactic_coherence']:.3f}")
    report={'fixture': team['team']['name'], 'n_per_variant': n, 'engine':'integrated_tactics_v1_local_patch', 'results': results, 'elapsed_sec': time.time()-t0}
    out=ROOT/'tactic_test_results_integrated_v1.json'
    json.dump(report, open(out,'w',encoding='utf-8'), ensure_ascii=False, indent=2)
    # CSV compact
    csv_out=ROOT/'tactic_test_results_integrated_v1.csv'
    with open(csv_out,'w',encoding='utf-8',newline='') as f:
        fieldnames=['name','n','home_win_pct','draw_pct','away_win_pct','avg_home_goals','avg_away_goals','avg_home_xg','avg_away_xg','avg_home_possession','avg_home_shots','avg_away_shots','avg_home_fouls','avg_home_yellow','avg_home_attacks_left','avg_home_attacks_center','avg_home_attacks_right','avg_home_pressing_ball_wins','avg_home_pressing_bypassed','avg_home_fatigue_cost','avg_home_coherence','avg_home_complexity']
        w=csv.DictWriter(f, fieldnames=fieldnames); w.writeheader()
        for r in results:
            a=r['avg']
            w.writerow({
                'name':r['name'],'n':r['n'],'home_win_pct':r['home_win_pct'],'draw_pct':r['draw_pct'],'away_win_pct':r['away_win_pct'],
                'avg_home_goals':a['home_goals'],'avg_away_goals':a['away_goals'],'avg_home_xg':a['home_xg'],'avg_away_xg':a['away_xg'],
                'avg_home_possession':a['home_possession'],'avg_home_shots':a['home_shots'],'avg_away_shots':a['away_shots'],
                'avg_home_fouls':a['home_fouls'],'avg_home_yellow':a['home_yellow'],
                'avg_home_attacks_left':a['home_attacks_left'],'avg_home_attacks_center':a['home_attacks_center'],'avg_home_attacks_right':a['home_attacks_right'],
                'avg_home_pressing_ball_wins':a['home_pressing_ball_wins'],'avg_home_pressing_bypassed':a['home_pressing_bypassed'],
                'avg_home_fatigue_cost':a['home_fatigue_cost'],'avg_home_coherence':a['home_tactic_coherence'],'avg_home_complexity':a['home_tactic_complexity'],
            })
    print('wrote', out)
    print('wrote', csv_out)
